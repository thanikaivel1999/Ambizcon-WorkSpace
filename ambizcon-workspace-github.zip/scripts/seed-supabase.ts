/**
 * Seeds a Supabase project with demo users, clients and records (needs 0001–0003 applied first).
 *   SEED_PASSWORD='choose-a-strong-one' npm run seed
 * Reads NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY from .env.local. Never commit those values.
 */
import { createClient } from '@supabase/supabase-js';
import { randomUUID } from 'node:crypto';
import { existsSync, readFileSync } from 'node:fs';
import { MODULES } from '../src/lib/modules';
import { buildDemoTasks, buildSeed, DEMO_CLIENTS, DEMO_USERS } from '../src/lib/seed';

if (existsSync('.env.local'))
  for (const line of readFileSync('.env.local', 'utf8').split(/\r?\n/)) {
    const m = line.match(/^([A-Z0-9_]+)=(.*)$/);
    if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
const password = process.env.SEED_PASSWORD;
if (!url || !key) throw new Error('Set NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY in .env.local');
if (!password || password.length < 10) throw new Error('Set SEED_PASSWORD (min 10 characters) for the demo accounts');

const sb = createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });

async function main() {
  // users: create auth accounts, then set team/role on the auto-created profile
  const idMap = new Map<string, string>();
  for (const u of DEMO_USERS) {
    const { data, error } = await sb.auth.admin.createUser({ email: u.email, password: password!, email_confirm: true, user_metadata: { name: u.name } });
    if (error) throw new Error(`${u.email}: ${error.message}`);
    idMap.set(u.id, data.user.id);
    const { error: pe } = await sb.from('profiles').update({ name: u.name, team: u.team, role: u.role }).eq('id', data.user.id);
    if (pe) throw pe;
  }
  const users = DEMO_USERS.map((u) => ({ ...u, id: idMap.get(u.id)! }));

  const clients = DEMO_CLIENTS.map((c) => ({ ...c, id: randomUUID(), assigned_ids: c.assigned_ids.map((u) => idMap.get(u)!) }));
  const { error: ce } = await sb.from('clients').insert(clients.map(({ assigned_ids: _a, ...c }) => c));
  if (ce) throw ce;
  const { error: me } = await sb.from('client_members').insert(clients.flatMap((c) => c.assigned_ids.map((user_id) => ({ client_id: c.id, user_id }))));
  if (me) throw me;

  const { records } = buildSeed(users, clients, randomUUID);
  for (const m of MODULES) {
    const rows = records[m.key];
    if (!rows?.length) continue;
    const { error } = await sb.from(m.table).insert(rows);
    if (error) throw new Error(`${m.table}: ${error.message}`);
    console.log(`seeded ${m.table} (${rows.length})`);
  }
  const tasks = buildDemoTasks(users, clients, randomUUID);
  const { error: te } = await sb.from('tasks').insert(tasks);
  if (te) throw new Error(`tasks: ${te.message}`);
  console.log(`seeded tasks (${tasks.length})`);
  console.log('Done. Sign in with the demo emails (e.g. thanikaivel@ambizcon.demo) and SEED_PASSWORD.');
}
main().catch((e) => { console.error(e); process.exit(1); });
