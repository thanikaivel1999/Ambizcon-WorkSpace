// Runs the project's SQL migrations against an in-process Postgres (PGlite) with minimal Supabase stubs,
// then exercises the workflow triggers and RLS as different users.
import { PGlite } from '@electric-sql/pglite';
import { readFileSync } from 'node:fs';

const dir = process.argv[2] ?? process.cwd();
const db = new PGlite();
const run = async (label, sql) => {
  try { await db.exec(sql); }
  catch (e) { console.error(`✗ ${label}: ${e.message}`); process.exit(1); }
  console.log(`✓ ${label}`);
};

await run('supabase stubs', `
  create schema auth; create schema storage;
  create role authenticated; create role anon; create role service_role;
  create table auth.users (id uuid primary key default gen_random_uuid(), email text, raw_user_meta_data jsonb default '{}');
  create or replace function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('request.jwt.claim.sub', true), '')::uuid $$;
  create table storage.buckets (id text primary key, name text, public boolean);
  create table storage.objects (id uuid default gen_random_uuid(), bucket_id text, name text);
  create or replace function storage.extension(name text) returns text language sql as $$ select lower(substring(name from '\.([^.]*)$')) $$;
  alter table storage.objects enable row level security;
  create publication supabase_realtime;
  grant usage on schema public, auth to authenticated;
`);
for (const f of ['0001_core.sql', '0002_modules.sql', '0003_motivations.sql', '0004_clients_tasks.sql', '0005_customization.sql']) {
  await run(f, readFileSync(`${dir}/supabase/migrations/${f}`, 'utf8').replace(/create extension if not exists "pgcrypto";/, '-- pgcrypto skipped in PGlite (gen_random_uuid is built in)'));
}
await db.exec(`grant all on all tables in schema public to authenticated; grant execute on all functions in schema public to authenticated;`);
await run('0006_scheduled_reminders.sql', readFileSync(`${dir}/supabase/migrations/0006_scheduled_reminders.sql`, 'utf8'));  // loaded after the blanket grant so its REVOKE is what gets tested

// ---- users ----
const U = { admin: '00000000-0000-0000-0000-00000000000a', lead: '00000000-0000-0000-0000-0000000000b1', emp: '00000000-0000-0000-0000-0000000000b2', mkt: '00000000-0000-0000-0000-0000000000c1', dev: '00000000-0000-0000-0000-0000000000d1' };
for (const [k, id] of Object.entries(U)) await db.exec(`insert into auth.users(id, email) values ('${id}', '${k}@x.test')`);
await db.exec(`update public.profiles set team='admin', role='admin' where id='${U.admin}';
  update public.profiles set team='creative', role='lead' where id='${U.lead}';
  update public.profiles set team='creative' where id='${U.emp}';
  update public.profiles set team='marketing' where id='${U.mkt}';
  update public.profiles set team='development' where id='${U.dev}';`);

const as = async (who, sql) => {
  await db.exec(`set role authenticated; select set_config('request.jwt.claim.sub', '${U[who]}', false);`);
  try { return await db.query(sql); } finally { await db.exec(`reset role; select set_config('request.jwt.claim.sub', '', false);`); }
};
let failed = 0;
const expectOk = async (name, who, sql) => { try { const r = await as(who, sql); console.log(`✓ ${name}`); return r; } catch (e) { failed++; console.error(`✗ ${name}: ${e.message}`); } };
const expectNoRows = async (name, who, sql) => { try { const r = await as(who, sql); if (r.rows.length === 0) console.log(`✓ ${name} (0 rows affected: RLS hides them)`); else { failed++; console.error(`✗ ${name}: ${r.rows.length} rows affected`); } } catch (e) { console.log(`✓ ${name} (blocked: ${e.message.slice(0, 60)})`); } };
const expectFail = async (name, who, sql, re) => { try { await as(who, sql); failed++; console.error(`✗ ${name}: expected an error`); } catch (e) { if (re && !re.test(e.message)) { failed++; console.error(`✗ ${name}: wrong error: ${e.message}`); } else console.log(`✓ ${name} (blocked: ${e.message.slice(0, 70)})`); } };

// ---- tasks workflow ----
const t = await expectOk('lead creates a task for the creative team', 'lead', `insert into tasks(title, team, assigned_to, reviewer_id) values ('Banner', 'creative', '${U.emp}', '${U.lead}') returning id`);
const tid = t.rows[0].id;
await expectFail('assignee cannot complete before approval', 'emp', `update tasks set status='Completed' where id='${tid}'`, /approval/);
await expectOk('assignee submits for review', 'emp', `update tasks set review_status='Requested' where id='${tid}'`);
await expectFail('assignee cannot approve own task', 'emp', `update tasks set review_status='Approved' where id='${tid}'`, /reviewer|own/i);
await expectNoRows('other team cannot update the task', 'dev', `update tasks set title='x' where id='${tid}' returning id`);
await expectOk('reviewer approves with rating', 'lead', `update tasks set review_status='Approved', review_rating=5 where id='${tid}'`);
await expectOk('assignee completes after approval', 'emp', `update tasks set status='Completed' where id='${tid}'`);
const done = await db.query(`select status, review_status, completed_at is not null as stamped from tasks where id='${tid}'`);
console.log(done.rows[0].status === 'Completed' && done.rows[0].stamped ? '✓ completed_at stamped by trigger' : '✗ completed_at not stamped'); if (done.rows[0].status !== 'Completed' || !done.rows[0].stamped) failed++;
const ev = await db.query(`select action from task_events where task_id='${tid}' order by created_at, id`);
console.log('  task history:', ev.rows.map((r) => r.action).join(' → '));
await expectFail('task history cannot be forged', 'emp', `insert into task_events(task_id, action, detail) values ('${tid}', 'approved', 'fake')`, /row-level security/);
const vis = await as('dev', `select count(*)::int as n from tasks`);
console.log(vis.rows[0].n === 0 ? '✓ development user cannot see creative tasks' : `✗ dev sees ${vis.rows[0].n} tasks`); if (vis.rows[0].n !== 0) failed++;
await expectOk('comment on a visible task', 'emp', `insert into task_comments(task_id, body) values ('${tid}', 'Uploaded final files')`);
await expectFail('cannot comment as someone else', 'emp', `insert into task_comments(task_id, user_id, body) values ('${tid}', '${U.lead}', 'spoof')`, /row-level security/);

// ---- privilege escalation / audit protection ----
await expectFail('member cannot make themself admin', 'emp', `update profiles set role='admin', team='admin' where id='${U.emp}'`, /admin/i);
const nLogs = (await db.query(`select count(*)::int n from user_logs`)).rows[0].n; console.log(`  user_logs rows present: ${nLogs}`); await expectNoRows('member cannot edit audit logs', 'emp', `update user_logs set description='x' returning id`);
const ul = await as('emp', `delete from user_logs returning id`); console.log(ul.rows.length === 0 ? '✓ audit log rows cannot be deleted by a member' : '✗ audit rows deleted'); if (ul.rows.length) failed++;

// ---- clients ----
await expectFail('non-admin cannot create a client', 'lead', `insert into clients(name, client_type) values ('Nope', 'Specialist')`, /row-level security/);
await expectOk('admin creates a client', 'admin', `insert into clients(name, client_type, joined_on, md_name, location) values ('Test Clinic', 'Specialist', current_date, 'Dr T', 'Chennai')`);
await expectFail('invalid client type is rejected', 'admin', `insert into clients(name, client_type) values ('Bad', 'Dentist')`, /check/);

// ---- creative module rules + requester access ----
const cl = (await as('admin', `select id from clients limit 1`)).rows[0].id;
const art = await expectOk('marketing raises a creative request', 'mkt', `insert into creative_artworks(task, client_id, status, request_source, requested_by, due_date, reviewer, assigned_to) values ('Email banner', '${cl}', 'New', 'Marketing · Mailer', '${U.mkt}', current_date + 5, '${U.lead}', '${U.emp}') returning id`);
const aid = art.rows[0].id;
const own = await as('mkt', `select count(*)::int n from creative_artworks`);
console.log(own.rows[0].n === 1 ? '✓ marketing can read back its own request' : `✗ marketing sees ${own.rows[0].n}`); if (own.rows[0].n !== 1) failed++;
await expectNoRows('marketing cannot update the creative record', 'mkt', `update creative_artworks set status='Completed' where id='${aid}' returning id`);
await expectFail('creative cannot complete before approval', 'emp', `update creative_artworks set status='Completed' where id='${aid}'`, /approval/);
await expectOk('designer submits for review', 'emp', `update creative_artworks set status='Submitted for Review' where id='${aid}'`);
const rv = await db.query(`select review_status from creative_artworks where id='${aid}'`);
console.log(rv.rows[0].review_status === 'In review' ? '✓ review_status synced to In review' : `✗ review_status ${rv.rows[0].review_status}`); if (rv.rows[0].review_status !== 'In review') failed++;
await expectFail('designer cannot approve own work', 'emp', `update creative_artworks set review_status='Approved' where id='${aid}'`, /reviewer|own/i);
await expectOk('reviewer approves', 'lead', `update creative_artworks set review_status='Approved' where id='${aid}'`);
await expectOk('designer completes', 'emp', `update creative_artworks set status='Completed' where id='${aid}'`);
const fin = await db.query(`select status, completion_date is not null as dated from creative_artworks where id='${aid}'`);
console.log(fin.rows[0].dated ? '✓ completion_date stamped' : '✗ completion_date missing'); if (!fin.rows[0].dated) failed++;
const nt = await db.query(`select title from notifications where user_id='${U.mkt}' order by created_at`);
console.log('  marketer notifications:', nt.rows.map((r) => r.title).join(' | '));
if (!nt.rows.some((r) => /submitted/i.test(r.title)) || !nt.rows.some((r) => /approved/i.test(r.title)) || !nt.rows.some((r) => /completed/i.test(r.title))) { failed++; console.error('✗ requester was not notified of submit/approve/complete'); } else console.log('✓ requester notified on submit, approve and complete');

// ---- team isolation on module tables ----
const dv = await as('dev', `select count(*)::int n from creative_artworks`);
console.log(dv.rows[0].n === 0 ? '✓ development cannot read creative records' : '✗ leak'); if (dv.rows[0].n) failed++;
await expectOk('development inserts a backup', 'dev', `insert into website_backups(website, client_id, verification, next_backup_date) values ('a.example.com', '${cl}', 'Unverified', current_date + 7)`);
await expectFail('invalid verification value rejected', 'dev', `insert into website_backups(website, verification, next_backup_date) values ('b.example.com', 'Maybe', current_date)`, /check/);
await expectFail('creative cannot insert dev records', 'emp', `insert into website_backups(website, next_backup_date) values ('c.example.com', current_date)`, /row-level security/);

// ---- permissions and customization ----
await expectFail('non-admin cannot grant module access', 'lead', `insert into module_permissions(team, module_key, level) values ('creative', 'backups', 'write')`, /row-level security/);
const bk = (await as('admin', `select id from website_backups limit 1`)).rows[0]?.id;
const seeA = await as('mkt', `select count(*)::int n from website_backups`);
console.log(seeA.rows[0].n === 0 ? '✓ marketing sees no development records by default' : '✗ cross-team leak'); if (seeA.rows[0].n) failed++;
await expectOk('admin grants marketing read access to backups', 'admin', `insert into module_permissions(team, module_key, level) values ('marketing', 'backups', 'read')`);
const seeB = await as('mkt', `select count(*)::int n from website_backups`);
console.log(seeB.rows[0].n >= 1 ? '✓ marketing can now read backups' : '✗ grant not effective'); if (seeB.rows[0].n < 1) failed++;
await expectFail('read access does not allow writes', 'mkt', `insert into website_backups(website, next_backup_date) values ('x.example.com', current_date)`, /row-level security/);
await expectNoRows('read access does not allow updates', 'mkt', `update website_backups set website='hacked' returning id`);
await expectOk('admin upgrades marketing to write', 'admin', `update module_permissions set level='write' where team='marketing' and module_key='backups'`);
await expectOk('marketing can now write backups', 'mkt', `insert into website_backups(website, next_backup_date) values ('m.example.com', current_date)`);
await expectOk('admin removes the grant', 'admin', `delete from module_permissions where team='marketing' and module_key='backups'`);
const seeC = await as('mkt', `select count(*)::int n from website_backups`);
console.log(seeC.rows[0].n === 0 ? '✓ access removed again' : '✗ revoke not effective'); if (seeC.rows[0].n) failed++;
const audit = await db.query(`select count(*)::int n from user_logs where module_name = 'Configuration'`);
console.log(audit.rows[0].n >= 3 ? `✓ permission changes were audited (${audit.rows[0].n} entries)` : '✗ no config audit rows'); if (audit.rows[0].n < 3) failed++;
const cm = await expectOk('admin creates a custom module', 'admin', `insert into custom_modules(slug, title, team, fields) values ('vendor-list', 'Vendor List', 'development', '[{"key":"vendor","label":"Vendor","type":"text","required":true},{"key":"cost","label":"Cost","type":"number"},{"key":"site","label":"Site","type":"url"},{"key":"tier","label":"Tier","type":"select","options":["Gold","Silver"]}]'::jsonb) returning id`);
const cmid = cm.rows[0].id;
await expectFail('non-admin cannot create custom modules', 'dev', `insert into custom_modules(slug, title, team) values ('sneaky', 'Sneaky', 'development')`, /row-level security/);
await expectOk('team member adds a valid custom record', 'dev', `insert into custom_records(module_id, data) values ('${cmid}', '{"vendor":"Acme","cost":120,"site":"https://acme.test","tier":"Gold"}')`);
await expectFail('required custom field is enforced', 'dev', `insert into custom_records(module_id, data) values ('${cmid}', '{"cost":5}')`, /required/);
await expectFail('number type is enforced', 'dev', `insert into custom_records(module_id, data) values ('${cmid}', '{"vendor":"A","cost":"lots"}')`, /number/);
await expectFail('url format is enforced', 'dev', `insert into custom_records(module_id, data) values ('${cmid}', '{"vendor":"A","site":"javascript:alert(1)"}')`, /http/);
await expectFail('select option is enforced', 'dev', `insert into custom_records(module_id, data) values ('${cmid}', '{"vendor":"A","tier":"Bronze"}')`, /invalid option/);
const crossCr = await as('mkt', `select count(*)::int n from custom_records`);
console.log(crossCr.rows[0].n === 0 ? '✓ other teams cannot read a development custom module' : '✗ custom record leak'); if (crossCr.rows[0].n) failed++;
await expectFail('invalid custom field key rejected', 'admin', `insert into custom_field_definitions(module_key, key, label, type) values ('backups', 'Bad Key!', 'x', 'text')`, /check/);
await expectOk('admin adds a custom field to a built-in module', 'admin', `insert into custom_field_definitions(module_key, key, label, type) values ('backups', 'retention_days', 'Retention days', 'number')`);
await expectOk('custom values live in the record', 'dev', `update website_backups set custom = '{"retention_days": 30}' where id = '${bk}'`);

// ---- settings ----
await expectFail('non-admin cannot change settings', 'lead', `insert into app_settings(key, value) values ('scoring', '{}')`, /row-level security/);
await expectOk('admin saves settings', 'admin', `insert into app_settings(key, value) values ('scoring', '{"onTime": 50}')`);

// ---- scheduled reminders ----
await expectFail('members cannot run the reminder job', 'emp', `select run_reminders()`, /permission denied/);
await db.exec(`insert into ssl_expiry(website, ssl_expiry_date, assigned_to, status) values ('https://soon.test', current_date + 30, '${U.dev}', 'Pending'), ('https://later.test', current_date + 45, '${U.dev}', 'Pending'), ('https://gone.test', current_date - 1, '${U.dev}', 'Completed');
  insert into tasks(title, team, assigned_to, due_date, status) values ('Late thing', 'development', '${U.dev}', current_date - 2, 'In Progress');`);
const first = (await db.query(`select run_reminders() as n`)).rows[0].n;
const second = (await db.query(`select run_reminders() as n`)).rows[0].n;
const exp30 = (await db.query(`select count(*)::int n from notifications where kind='expiry' and title = 'SSL certificate expires in 30 days'`)).rows[0].n;
const noLater = (await db.query(`select count(*)::int n from notifications where kind='expiry' and (body like '%later.test%' or body like '%gone.test%')`)).rows[0].n;
const overdue = (await db.query(`select count(*)::int n from notifications where user_id='${U.dev}' and title = 'Task overdue'`)).rows[0].n;
const ok1 = first >= 3 && second === 0 && exp30 >= 2 && noLater === 0 && overdue === 1;
console.log(ok1 ? `✓ reminder job: ${first} created, rerun created ${second}; only threshold days alert; completed records skipped; overdue task flagged` : `✗ reminder job (first=${first}, second=${second}, exp30=${exp30}, noLater=${noLater}, overdue=${overdue})`); if (!ok1) { failed++; console.log((await db.query(`select title, body from notifications where kind in ('expiry','overdue','due')`)).rows); }

console.log(failed ? `\n${failed} check(s) FAILED` : '\nAll SQL checks passed');
process.exit(failed ? 1 : 0);
