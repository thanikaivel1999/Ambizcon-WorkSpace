import { describe, expect, it } from 'vitest';
import { csvCell, toCsv } from '../src/lib/csv';

describe('csv', () => {
  it('quotes commas, quotes and newlines', () => {
    expect(csvCell('a,b')).toBe('"a,b"');
    expect(csvCell('say "hi"')).toBe('"say ""hi"""');
    expect(csvCell('x\ny')).toBe('"x\ny"');
  });
  it('neutralises spreadsheet formulas but leaves numbers alone', () => {
    expect(csvCell('=HYPERLINK("http://evil")')).toMatch(/^"'=/);
    expect(csvCell('+1')).toBe("'+1");
    expect(csvCell(-5)).toBe('-5');
    expect(csvCell(null)).toBe('');
  });
  it('builds rows with a header', () => {
    expect(toCsv([{ a: 1, b: 'x' }], [{ label: 'A', value: (r) => r.a }, { label: 'B', value: (r) => r.b }])).toBe('A,B\r\n1,x');
  });
});
