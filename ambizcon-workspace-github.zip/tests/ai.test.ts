import { afterEach, describe, expect, it, vi } from 'vitest';
import { buildFacts, systemPrompt } from '../src/lib/ai/facts';
import { AiError, getProvider } from '../src/lib/ai/provider';
import { rateLimit, resetRateLimits } from '../src/lib/ai/ratelimit';
import { addDays } from '../src/lib/utils';
import type { Client, Rec, Task } from '../src/lib/types';

const today = new Date().toISOString().slice(0, 10);
const users = [
  { id: 'a', name: 'Admin A', team: 'admin', role: 'admin' }, { id: 'd1', name: 'Dev One', team: 'development', role: 'member' }, { id: 'c1', name: 'Creative One', team: 'creative', role: 'member' },
] as const;
const clients = [{ id: 'k1', name: 'Sunrise Hospital', client_type: 'Specialist', joined_on: null, md_name: null, location: 'Chennai', category: null, website: null, status: 'active', notes: null, assigned_ids: [] }] as Client[];
const rec = (o: Record<string, unknown>) => ({ id: Math.random().toString(36), created_at: '2026-01-01T00:00:00Z', updated_at: '2026-01-01T00:00:00Z', created_by: null, updated_by: null, ...o }) as Rec;
const task = (o: Partial<Task>): Task => ({
  id: Math.random().toString(36), title: 'T', description: null, client_id: 'k1', team: 'development', assigned_to: 'd1', created_by: 'a', reviewer_id: null, priority: 'High', status: 'In Progress', review_status: 'None', review_rating: null,
  date_assigned: '2026-01-01', due_date: addDays(-3), output_link: null, thumbnail: null, remarks: null, completed_at: null, created_at: '2026-01-01T00:00:00Z', updated_at: '2026-01-01T00:00:00Z', ...o,
});

describe('provider selection', () => {
  it('is not configured without all three variables', () => {
    expect(getProvider({})).toBeNull();
    expect(getProvider({ AI_PROVIDER: 'anthropic', AI_API_KEY: 'k' })).toBeNull();
    expect(getProvider({ AI_PROVIDER: 'nope', AI_API_KEY: 'k', AI_MODEL: 'm' })).toBeNull();
  });
  it('builds either provider from the environment', () => {
    expect(getProvider({ AI_PROVIDER: 'anthropic', AI_API_KEY: 'k', AI_MODEL: 'm' })?.name).toBe('anthropic');
    expect(getProvider({ AI_PROVIDER: 'openai', AI_API_KEY: 'k', AI_MODEL: 'm' })?.name).toBe('openai');
  });
});

describe('providers call the right API shape and never echo the key', () => {
  afterEach(() => vi.unstubAllGlobals());
  it('anthropic', async () => {
    const fetchMock = vi.fn(async () => new Response(JSON.stringify({ content: [{ type: 'text', text: 'Hello' }], model: 'm1' }), { status: 200 }));
    vi.stubGlobal('fetch', fetchMock);
    const p = getProvider({ AI_PROVIDER: 'anthropic', AI_API_KEY: 'secret-key', AI_MODEL: 'm1' })!;
    const out = await p.complete({ system: 'sys', messages: [{ role: 'user', content: 'hi' }] });
    expect(out.text).toBe('Hello');
    const [url, init] = fetchMock.mock.calls[0] as unknown as [string, RequestInit];
    expect(url).toContain('/v1/messages');
    expect((init.headers as Record<string, string>)['x-api-key']).toBe('secret-key');
    expect(JSON.parse(init.body as string).system).toBe('sys');
  });
  it('openai-compatible, with provider errors surfaced as AiError', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({ error: { message: 'bad key' } }), { status: 401 })));
    const p = getProvider({ AI_PROVIDER: 'openai', AI_API_KEY: 'secret-key', AI_MODEL: 'm1', AI_BASE_URL: 'https://gw.example/v1/' })!;
    await expect(p.complete({ system: 's', messages: [{ role: 'user', content: 'q' }] })).rejects.toBeInstanceOf(AiError);
    await expect(p.complete({ system: 's', messages: [{ role: 'user', content: 'q' }] })).rejects.not.toThrow(/secret-key/);
  });
});

describe('rate limiting', () => {
  it('blocks after the limit and recovers after the window', () => {
    resetRateLimits();
    for (let n = 0; n < 3; n++) expect(rateLimit('u', 3, 1000, 1000 + n).ok).toBe(true);
    const blocked = rateLimit('u', 3, 1000, 1500);
    expect(blocked.ok).toBe(false);
    expect(blocked.retryAfterSec).toBeGreaterThan(0);
    expect(rateLimit('u', 3, 1000, 2500).ok).toBe(true);
    expect(rateLimit('other', 3, 1000, 1500).ok).toBe(true);
  });
});

describe('facts respect scope and never invent data', () => {
  const records: Record<string, Rec[]> = {
    'ssl-expiry': [rec({ website: 'a.example.com', client_id: 'k1', ssl_expiry_date: addDays(12), date_confidence: 'Confirmed', status: 'Pending', assigned_to: 'd1' }), rec({ website: 'b.example.com', client_id: 'k1', ssl_expiry_date: null, date_confidence: 'Unknown', status: 'Pending' })],
    backups: [rec({ website: 'a.example.com', client_id: 'k1', backup_date: addDays(-2), verification: 'Unverified', next_backup_date: addDays(5) })],
    artworks: [rec({ task: 'Banner', client_id: 'k1', status: 'In Progress', due_date: addDays(-1), assigned_to: 'c1' })],
  };
  const tasks = [task({ title: 'Dev overdue thing' }), task({ title: 'Creative overdue thing', team: 'creative', assigned_to: 'c1' })];

  it('a creative user gets no development, expiry-owner or performance data', () => {
    const f = buildFacts({ team: 'creative', today, users: [...users], clients, tasks, records: { artworks: records.artworks } });
    expect(f.text).toContain('Creative overdue thing');
    expect(f.text).not.toContain('Dev overdue thing');
    expect(f.text).not.toMatch(/Employee performance/);
    expect(f.text).not.toContain('a.example.com');
  });
  it('an admin gets everything including performance, and expiry items show unknown dates as unknown', () => {
    const f = buildFacts({ team: 'admin', today, users: [...users], clients, tasks, records });
    expect(f.text).toContain('Dev overdue thing');
    expect(f.text).toMatch(/Employee performance/);
    expect(f.text).toMatch(/EXPIRING \| Website SSL Expiry/);
    expect(f.text).toMatch(/UNKNOWN DATE \| Website SSL Expiry[^\n]*b\.example\.com/);
    expect(f.sections.length).toBeGreaterThan(3);
  });
  it('backups are described as unverified rather than successful', () => {
    const f = buildFacts({ team: 'development', today, users: [...users], clients, tasks, records: { backups: records.backups } });
    expect(f.text).toMatch(/Unverified/);
    expect(f.text).toMatch(/only "Verified" has been checked/);
  });
  it('the prompt forbids invention and writes, and contains the facts', () => {
    const p = systemPrompt('admin', 'FACTS-HERE');
    expect(p).toMatch(/Never invent/);
    expect(p).toMatch(/read-only/);
    expect(p).toContain('FACTS-HERE');
  });
});
