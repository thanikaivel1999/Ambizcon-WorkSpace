import { describe, expect, it } from 'vitest';
import { canAccess, isCrossTeamPath, modulePath } from '../src/lib/access';
import { keyify, levelFor, moduleFromCustom, packCustom, slugify, toPermMap, unpackCustom, withCustomFields } from '../src/lib/custom';
import { MODULE_BY_KEY, modulesOf } from '../src/lib/modules';
import { buildNav } from '../src/lib/nav';
import { getAlertDays, normalizeAlertDays, setAlertDays, expiryInfo, addDays, tierOrder, DEFAULT_ALERT_DAYS } from '../src/lib/utils';
import type { CustomFieldDef, CustomModule, Rec } from '../src/lib/types';

const def = (o: Partial<CustomFieldDef>): CustomFieldDef => ({ id: 'f1', module_key: 'backups', key: 'retention', label: 'Retention days', type: 'number', options: [], required: false, position: 0, archived: false, ...o } as CustomFieldDef);

describe('custom fields on built-in modules', () => {
  it('adds active custom fields before Notes and ignores archived or other modules', () => {
    const m = withCustomFields(MODULE_BY_KEY.backups, [def({}), def({ id: 'f2', key: 'old', archived: true }), def({ id: 'f3', module_key: 'seo', key: 'other' })]);
    const keys = m.fields.map((f) => f.key);
    expect(keys).toContain('cf_retention');
    expect(keys).not.toContain('cf_old');
    expect(keys).not.toContain('cf_other');
    expect(keys.indexOf('cf_retention')).toBeLessThan(keys.indexOf('remark'));
    expect(withCustomFields(MODULE_BY_KEY.backups, [])).toBe(MODULE_BY_KEY.backups);
  });
  it('packs cf_ values into the custom object and unpacks them back', () => {
    const packed = packCustom({ website: 'a.com', cf_retention: 30, cf_tier: 'Gold' });
    expect(packed).toEqual({ website: 'a.com', custom: { retention: 30, tier: 'Gold' } });
    const rec = unpackCustom({ id: '1', custom: { retention: 30 } } as unknown as Rec);
    expect(rec.cf_retention).toBe(30);
    expect(packCustom({ website: 'a.com' })).toEqual({ website: 'a.com' });
  });
  it('makes safe keys and slugs', () => {
    expect(keyify('Retention (days)!')).toBe('retention_days');
    expect(keyify('123 numbers')).toMatch(/^[a-z]/);
    expect(slugify('Vendor List 2026')).toBe('vendor-list-2026');
  });
});

describe('custom registers', () => {
  const cm: CustomModule = { id: 'abc', slug: 'vendor-list', title: 'Vendor List', team: 'development', icon: 'Wrench', blurb: '', archived: false, created_at: '', fields: [{ key: 'vendor', label: 'Vendor', type: 'text', required: true }, { key: 'tier', label: 'Tier', type: 'select', options: ['Gold', 'Silver'] }, { key: 'doc', label: 'Contract', type: 'file' }] };
  it('builds a module definition the generic pages can render', () => {
    const m = moduleFromCustom(cm);
    expect(m.key).toBe('custom:abc');
    expect(m.customId).toBe('abc');
    expect(m.titleField).toBe('vendor');
    expect(m.fields.find((f) => f.key === 'tier')?.options).toEqual(['Gold', 'Silver']);
    expect(m.fields.find((f) => f.key === 'doc')?.type).toBe('file');
    expect(m.fields[0].type).toBe('client');
    expect(modulePath(m)).toBe('/development/vendor-list');
  });
});

describe('team access', () => {
  const backups = MODULE_BY_KEY.backups;
  it('defaults: own team writes, other teams have none, admin always writes', () => {
    expect(levelFor('development', backups, {})).toBe('write');
    expect(levelFor('marketing', backups, {})).toBe('none');
    expect(levelFor('admin', backups, {})).toBe('write');
  });
  it('overrides win in both directions', () => {
    const pm = toPermMap([{ team: 'marketing', module_key: 'backups', level: 'read' }, { team: 'development', module_key: 'backups', level: 'none' }]);
    expect(levelFor('marketing', backups, pm)).toBe('read');
    expect(levelFor('development', backups, pm)).toBe('none');
  });
  it('route guard: cross-team paths need a grant, admin pages are admin-only', () => {
    const granted = [modulePath(backups)];
    expect(canAccess('marketing', '/development/backups')).toBe(false);
    expect(canAccess('marketing', '/development/backups', granted)).toBe(true);
    expect(canAccess('marketing', '/development/backups/', granted)).toBe(true);
    expect(canAccess('marketing', '/development/seo-updates', granted)).toBe(false);
    expect(canAccess('marketing', '/development', granted)).toBe(false);
    expect(canAccess('marketing', '/marketing/content-calendar')).toBe(true);
    expect(canAccess('development', '/admin/customization')).toBe(false);
    expect(canAccess('admin', '/development/backups')).toBe(true);
    expect(isCrossTeamPath('marketing', '/development/backups')).toBe(true);
    expect(isCrossTeamPath('marketing', '/clients')).toBe(false);
  });
});

describe('sidebar', () => {
  it('hides and orders modules, and lists granted modules from other teams last', () => {
    const own = modulesOf('development');
    const nav = buildNav('development', [...own, MODULE_BY_KEY['spot-calendar']], { hidden: ['seo'], order: { development: ['ssl-expiry', 'backups'] } });
    const labels = nav.map((n) => n.label);
    expect(labels).not.toContain('SEO Updates');
    expect(labels.indexOf('SSL Expiry')).toBeLessThan(labels.indexOf('Website Backups'));
    expect(labels.some((l) => l.includes('Content Calendar') && l.includes('Marketing'))).toBe(true);
    expect(labels[0]).toBe('Dashboard');
  });
  it('admin sidebar links to the studio, performance and expiry pages', () => {
    const hrefs = buildNav('admin', []).map((n) => n.href);
    expect(hrefs).toEqual(expect.arrayContaining(['/admin/customization', '/admin/performance', '/admin/expiry-management', '/development/user-logs']));
  });
});

describe('configurable expiry alert schedule', () => {
  it('buckets by the configured days and restores the defaults', () => {
    setAlertDays([45, 10]);
    expect(getAlertDays()).toEqual([45, 10]);
    expect(expiryInfo(addDays(8))?.tier).toBe('d10');
    expect(expiryInfo(addDays(30))?.tier).toBe('d45');
    expect(expiryInfo(addDays(60))?.tier).toBe('ok');
    expect(expiryInfo(addDays(-2))?.tier).toBe('expired');
    expect(tierOrder()).toEqual(['expired', 'd10', 'd45', 'ok']);
    setAlertDays(DEFAULT_ALERT_DAYS);
    expect(tierOrder()).toEqual(['expired', 'd1', 'd7', 'd14', 'd30', 'd60', 'd90', 'ok']);
  });
  it('rejects junk and never produces an empty schedule', () => {
    expect(normalizeAlertDays(['x', -3, 7.5, 7, 7, 30])).toEqual([30, 7]);
    expect(normalizeAlertDays([])).toEqual(DEFAULT_ALERT_DAYS);
    expect(normalizeAlertDays('nope')).toEqual(DEFAULT_ALERT_DAYS);
  });
});
