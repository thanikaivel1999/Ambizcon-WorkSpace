import { describe, expect, it } from 'vitest';
import { computeMetrics, DEFAULT_WEIGHTS, lastThreeCompletedMonths, monthPeriod, rankBy, type WorkItem } from '../src/lib/performance';

let n = 0;
const item = (o: Partial<WorkItem>): WorkItem => ({
  id: `i${n++}`, assignee: 'a', team: 'development', client_id: null, priority: 'Medium', assigned_on: '2026-09-01', due_on: '2026-09-10', completed_on: '2026-09-09', completed_ts: '2026-09-09T05:00:00Z',
  state: 'done', verified: true, rating: 4, ...o,
});
const SEP = monthPeriod(2026, 8);
const TODAY = '2026-10-09';

describe('metrics', () => {
  it('computes on-time rate, counting open overdue work as a miss', () => {
    const items = [item({}), item({}), item({ completed_on: '2026-09-15' }), item({ state: 'open', completed_on: null, completed_ts: null, due_on: '2026-09-20', verified: false, rating: null })];
    const m = computeMetrics(items, SEP, TODAY, { ...DEFAULT_WEIGHTS, minCompleted: 1 });
    // 2 on time out of (3 completed + 1 open overdue) = 50%
    expect(m.onTimeRate).toBeCloseTo(0.5);
    expect(m.completed).toBe(3);
    expect(m.overdue).toBe(1);
  });
  it('ignores missing ratings instead of treating them as zero', () => {
    const rated = [item({ rating: 5 }), item({ rating: 5 }), item({ rating: 5 })];
    const mixed = [...rated, item({ rating: null }), item({ rating: null })];
    expect(computeMetrics(mixed, SEP, TODAY).quality).toBe(5);
    expect(computeMetrics(mixed, SEP, TODAY).ratedCount).toBe(3);
    const none = computeMetrics([item({ rating: null }), item({ rating: null }), item({ rating: null })], SEP, TODAY);
    expect(none.quality).toBeNull();
    expect(none.used.quality).toBe(false); // weight is redistributed, not scored as 0
    expect(none.score).not.toBeNull();
  });
  it('does not rank people below the minimum completed count', () => {
    const m = computeMetrics([item({}), item({})], SEP, TODAY);
    expect(m.eligible).toBe(false);
    expect(m.score).toBeNull();
  });
  it('doing more tasks does not raise the score (rates and means, not totals)', () => {
    const few = Array.from({ length: 3 }, () => item({}));
    const many = Array.from({ length: 30 }, () => item({}));
    expect(computeMetrics(many, SEP, TODAY).score).toBe(computeMetrics(few, SEP, TODAY).score);
  });
  it('ranks higher quality and on-time work first', () => {
    const good = Array.from({ length: 4 }, () => item({ assignee: 'good', rating: 5 }));
    const weak = Array.from({ length: 12 }, () => item({ assignee: 'weak', rating: 2, completed_on: '2026-09-20', verified: false }));
    const r = rankBy([...good, ...weak], (i) => i.assignee, SEP, TODAY, DEFAULT_WEIGHTS);
    expect(r[0].key).toBe('good');
  });
  it('unverified self-reported completions lower the verified component', () => {
    const verified = computeMetrics(Array.from({ length: 3 }, () => item({})), SEP, TODAY);
    const unverified = computeMetrics(Array.from({ length: 3 }, () => item({ verified: false })), SEP, TODAY);
    expect(unverified.score!).toBeLessThan(verified.score!);
  });
});

describe('history', () => {
  it('work completed after the period still counts as open (and overdue) at the end of it', () => {
    const late = item({ due_on: '2026-09-20', completed_on: '2026-10-05', completed_ts: '2026-10-05T05:00:00Z' });
    const m = computeMetrics([late], SEP, TODAY);
    expect(m.completed).toBe(0);
    expect(m.pending).toBe(1);
    expect(m.overdue).toBe(1);
  });
});

describe('periods', () => {
  it('three-month window excludes the running month', () => {
    const p = lastThreeCompletedMonths('2026-10-09');
    expect(p.from).toBe('2026-07-01');
    expect(p.to).toBe('2026-09-30');
    expect(p.label).toBe('Jul 2026 – Sep 2026');
  });
  it('handles year boundaries', () => {
    const p = lastThreeCompletedMonths('2027-01-15');
    expect(p.from).toBe('2026-10-01');
    expect(p.to).toBe('2026-12-31');
  });
  it('February in a leap year', () => {
    expect(monthPeriod(2028, 1).to).toBe('2028-02-29');
  });
});
