import { beforeAll, describe, expect, it } from 'vitest';

// The demo backend is browser-local; give it a tiny localStorage/document so it can run under Node.
const store = new Map<string, string>();
Object.assign(globalThis, {
  localStorage: { getItem: (k: string) => store.get(k) ?? null, setItem: (k: string, v: string) => void store.set(k, v), removeItem: (k: string) => void store.delete(k) },
  document: { cookie: '' },
});

import { DEMO_PASSWORD } from '../src/lib/seed';
import { MODULE_BY_KEY } from '../src/lib/modules';
import { validateRecord } from '../src/lib/validate';
import type { Profile } from '../src/lib/types';

let demoApi: typeof import('../src/lib/data/demo').demoApi;
const users: Record<string, Profile> = {};
const login = async (email: string) => {
  const p = await demoApi.auth.signIn(email, DEMO_PASSWORD);
  return p;
};

beforeAll(async () => {
  demoApi = (await import('../src/lib/data/demo')).demoApi;
  for (const [k, email] of Object.entries({ admin: 'thanikaivel@ambizcon.demo', dev: 'karthik@ambizcon.demo', mkt: 'meera@ambizcon.demo', lead: 'ananya@ambizcon.demo', emp: 'vikram@ambizcon.demo' })) users[k] = await login(email);
});

describe('authentication', () => {
  it('rejects a wrong password and a disabled account', async () => {
    await expect(demoApi.auth.signIn('thanikaivel@ambizcon.demo', 'nope')).rejects.toThrow(/Invalid/);
    const u = users.emp;
    await demoApi.users.update(u.id, { status: 'disabled' });
    await expect(demoApi.auth.signIn(u.email, DEMO_PASSWORD)).rejects.toThrow(/disabled/);
    await demoApi.users.update(u.id, { status: 'active' });
  });
});

describe('clients', () => {
  it('only an admin can create or edit clients, and names are unique', async () => {
    const input = { name: 'Test Clinic', client_type: 'Specialist' as const, joined_on: '2026-10-01', md_name: 'Dr T', location: 'Chennai', category: null, website: null, status: 'active' as const, notes: null, assigned_ids: [] };
    await expect(demoApi.clients.create(input, users.mkt)).rejects.toThrow(/admin/);
    const c = await demoApi.clients.create(input, users.admin);
    await expect(demoApi.clients.create({ ...input, name: 'test clinic' }, users.admin)).rejects.toThrow(/already exists/);
    const archived = await demoApi.clients.update(c.id, { status: 'archived' }, users.admin);
    expect(archived.status).toBe('archived');
    await expect(demoApi.clients.update(c.id, { name: 'x' }, users.dev)).rejects.toThrow(/admin/);
  });
});

describe('module record permissions (mirrors RLS)', () => {
  it('a team cannot write to another team module, but marketing can raise a creative request', async () => {
    await expect(demoApi.records.create(MODULE_BY_KEY.backups, { website: 'x.example.com', next_backup_date: '2026-11-01' }, users.mkt)).rejects.toThrow(/access/);
    const req = await demoApi.records.create(MODULE_BY_KEY.artworks, { task: 'Mailer banner', due_date: '2026-11-01', priority: 'Medium', status: 'New', request_source: 'Marketing · Mailer', requested_by: users.mkt.id, reviewer: users.lead.id, assigned_to: users.emp.id }, users.mkt);
    expect(req.id).toBeTruthy();
    // marketing may read back only its own requests
    await login('meera@ambizcon.demo');
    const mine = await demoApi.records.list(MODULE_BY_KEY.artworks);
    expect(mine.every((r) => r.requested_by === users.mkt.id)).toBe(true);
    expect(await demoApi.records.list(MODULE_BY_KEY.backups)).toEqual([]);
    await expect(demoApi.records.update(MODULE_BY_KEY.artworks, req.id, { status: 'Completed' }, users.mkt)).rejects.toThrow(/access/);
  });
});

describe('creative review workflow', () => {
  it('needs approval from the reviewer before completing, and notifies the requester', async () => {
    const m = MODULE_BY_KEY.artworks;
    await login('thanikaivel@ambizcon.demo');
    const req = await demoApi.records.create(m, { task: 'Festival banner', due_date: '2026-11-01', priority: 'High', status: 'In Progress', request_source: 'Marketing · Mailer', requested_by: users.mkt.id, reviewer: users.lead.id, assigned_to: users.emp.id, review_status: 'Not reviewed' }, users.admin);
    await expect(demoApi.records.update(m, req.id, { status: 'Completed' }, users.emp)).rejects.toThrow(/approval/);
    const sub = await demoApi.records.update(m, req.id, { status: 'Submitted for Review' }, users.emp);
    expect(sub.review_status).toBe('In review');
    await expect(demoApi.records.update(m, req.id, { review_status: 'Approved' }, users.emp)).rejects.toThrow(/reviewer/);
    const ok = await demoApi.records.update(m, req.id, { review_status: 'Approved' }, users.lead);
    expect(ok.status).toBe('Approved');
    const done = await demoApi.records.update(m, req.id, { status: 'Completed' }, users.emp);
    expect(done.completion_date).toBeTruthy();
    const notes = await demoApi.notifications.list(users.mkt);
    const titles = notes.map((n) => n.title);
    expect(titles).toEqual(expect.arrayContaining(['Creative submitted for review', 'Creative approved', 'Creative completed']));
  });
});

describe('tasks and comments', () => {
  it('runs the full task lifecycle with history and notifications', async () => {
    const t = await demoApi.tasks.create({ title: 'Test task', team: 'creative', assigned_to: users.emp.id, reviewer_id: users.lead.id, priority: 'High', due_date: '2026-12-01' }, users.lead);
    expect(t.status).toBe('Assigned');
    await expect(demoApi.tasks.update(t.id, { status: 'Completed' }, users.emp)).rejects.toThrow(/approval/);
    await demoApi.tasks.update(t.id, { review_status: 'Requested' }, users.emp);
    const approved = await demoApi.tasks.update(t.id, { review_status: 'Approved', review_rating: 4 }, users.lead);
    expect(approved.status).toBe('Approved');
    const done = await demoApi.tasks.update(t.id, { status: 'Completed' }, users.emp);
    expect(done.completed_at).toBeTruthy();
    await demoApi.tasks.addComment(t.id, 'Final files uploaded', users.emp);
    await expect(demoApi.tasks.addComment(t.id, '   ', users.emp)).rejects.toThrow();
    const events = (await demoApi.tasks.events(t.id)).map((e) => e.action);
    expect(events).toEqual(['created', 'review', 'approved', 'completed']);
    expect((await demoApi.tasks.comments(t.id)).length).toBe(1);
    await expect(demoApi.tasks.create({ title: 'Sneaky', team: 'development' }, users.emp)).rejects.toThrow(/own team/);
  });
});

describe('settings', () => {
  it('only an admin can save settings', async () => {
    await expect(demoApi.settings.set('scoring', { onTime: 10 }, users.dev)).rejects.toThrow(/admin/);
    await demoApi.settings.set('scoring', { onTime: 50 }, users.admin);
    expect(await demoApi.settings.get<{ onTime: number }>('scoring')).toEqual({ onTime: 50 });
  });
});

describe('record validation rules', () => {
  it('a backup cannot be Verified without a link', () => {
    const base = { website: 'a.example.com', backup_date: '2026-10-01', next_backup_date: '2026-10-08', verification: 'Verified', backup_link: '' };
    expect(validateRecord(MODULE_BY_KEY.backups, base).errors.backup_link).toMatch(/link/i);
    expect(validateRecord(MODULE_BY_KEY.backups, { ...base, backup_link: 'https://drive.google.com/x' }).ok).toBe(true);
    expect(validateRecord(MODULE_BY_KEY.backups, { ...base, backup_link: 'not a url' }).errors.backup_link).toBeTruthy();
  });
  it('a published blog needs a publication date', () => {
    const v = { blog_title: 'Post', blog_status: 'Published', published_date: '' };
    expect(validateRecord(MODULE_BY_KEY.blogs, v).errors.published_date).toBeTruthy();
  });
  it('an expiry marked Unknown stays empty and is not required', () => {
    const r = validateRecord(MODULE_BY_KEY['website-expiry'], { domain: 'a.example.com', status: 'Pending', date_confidence: 'Unknown', expiry_date: '2026-12-31' });
    expect(r.ok).toBe(true);
    expect(r.data.expiry_date).toBeNull();
    const missing = validateRecord(MODULE_BY_KEY['website-expiry'], { domain: 'a.example.com', status: 'Pending', date_confidence: 'Confirmed', expiry_date: '' });
    expect(missing.errors.expiry_date).toBeTruthy();
  });
  it('mailer rates use the right denominators and show a dash when data is missing', () => {
    const m = MODULE_BY_KEY['mailer-reports'];
    const f = (k: string, r: Record<string, unknown>) => m.derived.find((d) => d.key === k)!.fn(r);
    const r = { total_recipients: 1000, delivered: 950, unique_opens: 190, unique_clicks: 19 };
    expect(f('delivery_rate', r)).toBeCloseTo(95);
    expect(f('open_rate', r)).toBeCloseTo(20);
    expect(f('click_rate', r)).toBeCloseTo(2);
    expect(f('open_rate', { delivered: 0, unique_opens: 5 })).toBe('—');
    expect(f('open_rate', { delivered: 100 })).toBe('—');
  });
});

describe('admin-configured access (permissions)', () => {
  it('grants, enforces read-only, and revokes cross-team access', async () => {
    const m = MODULE_BY_KEY.backups;
    await login('thanikaivel@ambizcon.demo');
    await expect(demoApi.permissions.set('marketing', 'backups', 'read', users.dev)).rejects.toThrow(/admin/);
    await login('meera@ambizcon.demo');
    expect(await demoApi.records.list(m)).toEqual([]);
    await login('thanikaivel@ambizcon.demo');
    await demoApi.permissions.set('marketing', 'backups', 'read', users.admin);
    await login('meera@ambizcon.demo');
    expect((await demoApi.records.list(m)).length).toBeGreaterThan(0);
    await expect(demoApi.records.create(m, { website: 'x.example.com', next_backup_date: '2026-11-01', verification: 'Unverified' }, users.mkt)).rejects.toThrow(/read-only/);
    await login('thanikaivel@ambizcon.demo');
    await demoApi.permissions.set('marketing', 'backups', 'write', users.admin);
    const rec = await demoApi.records.create(m, { website: 'x.example.com', next_backup_date: '2026-11-01', verification: 'Unverified' }, users.mkt);
    expect(rec.id).toBeTruthy();
    await demoApi.permissions.set('marketing', 'backups', null, users.admin);
    await login('meera@ambizcon.demo');
    expect(await demoApi.records.list(m)).toEqual([]);
    await login('thanikaivel@ambizcon.demo');
    const trail = await demoApi.records.list(MODULE_BY_KEY['user-log']);
    expect(trail.filter((r) => r.module_name === 'Configuration').length).toBeGreaterThanOrEqual(3);
  });
});

describe('custom registers and fields', () => {
  it('admin builds a register; the team uses it; values merge instead of replacing', async () => {
    const { moduleFromCustom } = await import('../src/lib/custom');
    await expect(demoApi.customModules.save({ slug: 'vendors', title: 'Vendors', team: 'development', icon: 'Wrench', blurb: '', fields: [{ key: 'vendor', label: 'Vendor', type: 'text', required: true }], archived: false }, users.dev)).rejects.toThrow(/admin/);
    const cm = await demoApi.customModules.save({ slug: 'vendors', title: 'Vendors', team: 'development', icon: 'Wrench', blurb: '', fields: [{ key: 'vendor', label: 'Vendor', type: 'text', required: true }, { key: 'cost', label: 'Cost', type: 'number' }], archived: false }, users.admin);
    await expect(demoApi.customModules.save({ slug: 'vendors', title: 'Dup', team: 'development', icon: 'Wrench', blurb: '', fields: [], archived: false }, users.admin)).rejects.toThrow(/already uses/);
    const m = moduleFromCustom(cm);
    await login('karthik@ambizcon.demo');
    const r = await demoApi.records.create(m, { vendor: 'Acme', cost: 10 }, users.dev);
    expect((await demoApi.records.list(m)).length).toBe(1);
    await login('meera@ambizcon.demo');
    expect(await demoApi.records.list(m)).toEqual([]);
    await login('karthik@ambizcon.demo');
    // custom values on a built-in module are merged
    const b = MODULE_BY_KEY.backups;
    const first = (await demoApi.records.list(b))[0];
    await demoApi.records.update(b, first.id, { custom: { retention: 30 } }, users.dev);
    const after = await demoApi.records.update(b, first.id, { custom: { tier: 'Gold' } }, users.dev);
    expect(after.custom).toEqual({ retention: 30, tier: 'Gold' });
    await demoApi.records.remove(m, r.id, users.dev);
    expect(await demoApi.records.list(m)).toEqual([]);
    await login('thanikaivel@ambizcon.demo');
  });
  it('custom field definitions are admin-only and keys are unique per module', async () => {
    const f = { module_key: 'backups', key: 'retention', label: 'Retention', type: 'number' as const, options: [], required: false, position: 0, archived: false };
    await expect(demoApi.customFields.save(f, users.dev)).rejects.toThrow(/admin/);
    const saved = await demoApi.customFields.save(f, users.admin);
    await expect(demoApi.customFields.save({ ...f, label: 'Again' }, users.admin)).rejects.toThrow(/already has a field/);
    await demoApi.customFields.remove(saved.id, users.admin);
    expect((await demoApi.customFields.list()).length).toBe(0);
  });
});
