import { describe, expect, it } from 'vitest';
import { applyTaskTransition, isOverdue, isVerified } from '../src/lib/taskflow';
import type { Task } from '../src/lib/types';

const base: Task = {
  id: 't1', title: 'Banner', description: null, client_id: null, team: 'creative', assigned_to: 'emp', created_by: 'lead', reviewer_id: 'rev', priority: 'Medium', status: 'In Progress',
  review_status: 'None', review_rating: null, date_assigned: '2026-10-01', due_date: '2026-10-10', output_link: null, thumbnail: null, remarks: null, completed_at: null,
  created_at: '2026-10-01T00:00:00Z', updated_at: '2026-10-01T00:00:00Z',
};
const emp = { id: 'emp', team: 'creative', role: 'member' } as const;
const rev = { id: 'rev', team: 'creative', role: 'lead' } as const;
const admin = { id: 'adm', team: 'admin', role: 'admin' } as const;

describe('task workflow', () => {
  it('cannot complete a reviewed task before approval', () => {
    expect(applyTaskTransition(base, { status: 'Completed' }, emp).ok).toBe(false);
  });
  it('submitting for review needs a reviewer and sets Requested', () => {
    expect(applyTaskTransition({ ...base, reviewer_id: null }, { status: 'Submitted for Review' }, emp).ok).toBe(false);
    const r = applyTaskTransition(base, { review_status: 'Requested' }, emp);
    expect(r.ok && r.next.status).toBe('Submitted for Review');
  });
  it('only the reviewer or an admin may approve, and never the assignee', () => {
    const submitted = { ...base, status: 'Submitted for Review' as const, review_status: 'Requested' as const };
    expect(applyTaskTransition(submitted, { review_status: 'Approved' }, emp).ok).toBe(false);
    expect(applyTaskTransition(submitted, { review_status: 'Approved' }, { id: 'other', team: 'creative', role: 'member' }).ok).toBe(false);
    const ok = applyTaskTransition(submitted, { review_status: 'Approved', review_rating: 5 }, rev);
    expect(ok.ok && ok.next.status).toBe('Approved');
    // reviewer is also the assignee: blocked unless admin
    expect(applyTaskTransition({ ...submitted, assigned_to: 'rev' }, { review_status: 'Approved' }, rev).ok).toBe(false);
    expect(applyTaskTransition({ ...submitted, assigned_to: 'rev' }, { review_status: 'Approved' }, admin).ok).toBe(true);
  });
  it('cannot approve a task that was never submitted (non-admin)', () => {
    expect(applyTaskTransition(base, { review_status: 'Approved' }, rev).ok).toBe(false);
  });
  it('Approved status cannot be set directly', () => {
    expect(applyTaskTransition(base, { status: 'Approved' }, emp).ok).toBe(false);
  });
  it('approved task can be completed, stamps completed_at and is verified', () => {
    const approved = { ...base, status: 'Approved' as const, review_status: 'Approved' as const };
    const r = applyTaskTransition(approved, { status: 'Completed' }, emp, '2026-10-05T10:00:00Z');
    expect(r.ok).toBe(true);
    if (r.ok) expect(r.next.completed_at).toBe('2026-10-05T10:00:00Z');
    expect(isVerified({ status: 'Completed', review_status: 'Approved' })).toBe(true);
  });
  it('a task without reviewer can be self-completed but is recorded as unverified', () => {
    const r = applyTaskTransition({ ...base, reviewer_id: null }, { status: 'Completed' }, emp);
    expect(r.ok && r.events.some((e) => /unverified/.test(e.detail))).toBe(true);
    expect(isVerified({ status: 'Completed', review_status: 'None' })).toBe(false);
  });
  it('only the reviewer can record a rating, 1 to 5 only', () => {
    expect(applyTaskTransition(base, { review_rating: 5 }, emp).ok).toBe(false);
    expect(applyTaskTransition(base, { review_rating: 9 }, rev).ok).toBe(false);
  });
  it('reopening clears completed_at', () => {
    const done = { ...base, status: 'Completed' as const, review_status: 'Approved' as const, completed_at: '2026-10-05T10:00:00Z' };
    const r = applyTaskTransition(done, { status: 'In Progress' }, emp);
    expect(r.ok && r.next.completed_at).toBe(null);
  });
  it('overdue ignores closed tasks', () => {
    expect(isOverdue({ status: 'In Progress', due_date: '2026-10-01' }, '2026-10-09')).toBe(true);
    expect(isOverdue({ status: 'Completed', due_date: '2026-10-01' }, '2026-10-09')).toBe(false);
    expect(isOverdue({ status: 'In Progress', due_date: null }, '2026-10-09')).toBe(false);
  });
});
