-- Ambizcon Team Workspace — core schema, helper functions, RLS and audit triggers.
-- Run in order: 0001_core.sql, 0002_modules.sql (generated), 0003_motivations.sql (generated).

create extension if not exists "pgcrypto";

-- ───────── teams / roles ─────────
create table public.teams (
  id text primary key,                 -- 'admin' | 'development' | 'marketing' | 'creative'
  name text not null
);
insert into public.teams values ('admin','Admin'),('development','Development'),('marketing','Marketing'),('creative','Creative');

create table public.roles (
  id text primary key,                 -- 'admin' | 'lead' | 'member'
  description text not null
);
insert into public.roles values ('admin','Full access to every team'),('lead','Team lead'),('member','Team member');

-- ───────── profiles (the "users" table; auth.users holds credentials) ─────────
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null,
  email text not null unique,
  team text not null references public.teams(id) default 'development',
  role text not null references public.roles(id) default 'member',
  status text not null default 'active' check (status in ('active','disabled')),
  avatar_url text,
  last_login timestamptz,
  created_at timestamptz not null default now(),
  constraint admin_team_consistency check ((role = 'admin') = (team = 'admin'))
);
create index on public.profiles(team);

create table public.clients (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  created_at timestamptz not null default now()
);

-- ───────── helper functions (SECURITY DEFINER so policies never recurse into profiles RLS) ─────────
create or replace function public.my_team() returns text
language sql stable security definer set search_path = public as $$
  select team from public.profiles where id = auth.uid() and status = 'active'
$$;

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select role = 'admin' and team = 'admin' from public.profiles where id = auth.uid() and status = 'active'), false)
$$;

create or replace function public.can_access_team(t text) returns boolean
language sql stable as $$ select public.is_admin() or public.my_team() = t $$;

-- Per-team, per-module access overrides set by an admin (cross-team collaboration). No row = default: a team has write access to
-- its own modules and none to other teams' modules.
create table public.module_permissions (
  team text not null check (team in ('development', 'marketing', 'creative')),
  module_key text not null,
  level text not null check (level in ('none', 'read', 'write')),
  primary key (team, module_key)
);
alter table public.module_permissions enable row level security;
create policy module_permissions_read on public.module_permissions for select to authenticated using (public.my_team() is not null);
create policy module_permissions_admin on public.module_permissions for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- plpgsql (late binding) so it can be used by policies in later migrations.
create or replace function public.module_level(p_team text, p_key text) returns text
language plpgsql stable security definer set search_path = public as $$
declare lvl text;
begin
  if public.is_admin() then return 'write'; end if;
  select level into lvl from public.module_permissions where team = public.my_team() and module_key = p_key;
  if lvl is not null then return lvl; end if;
  if public.my_team() = p_team then return 'write'; end if;
  return 'none';
end $$;

-- Configuration and permission changes are written to the audit trail (user_logs) by trigger, never by clients.
create or replace function public.log_config_change() returns trigger
language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid();
begin
  insert into public.user_logs(user_id, team, action, module_name, record_title, description)
    values (uid, 'admin', lower(tg_op), 'Configuration', tg_argv[0], initcap(lower(tg_op)) || ' ' || tg_argv[0]);
  return coalesce(new, old);
end $$;
create trigger module_permissions_audit after insert or update or delete on public.module_permissions for each row execute function public.log_config_change('module permission');

-- New auth user → profile row. Role/team default to the least-privileged values; admins promote via /api/admin/users.
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, name, email)
  values (new.id, coalesce(new.raw_user_meta_data->>'name', split_part(new.email,'@',1)), new.email);
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

-- Users may edit only their own non-privileged columns; role/team/status changes require an admin (or the service role).
create or replace function public.profiles_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or public.is_admin() then return new; end if;
  if new.role <> old.role or new.team <> old.team or new.status <> old.status or new.email <> old.email then
    raise exception 'Only an admin can change role, team, status or email';
  end if;
  return new;
end $$;
create trigger profiles_guard_trg before update on public.profiles for each row execute function public.profiles_guard();

create or replace function public.log_profile_change() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.role is distinct from old.role or new.team is distinct from old.team or new.status is distinct from old.status then
    insert into public.user_logs(user_id, team, action, module_name, record_title, description)
      values (auth.uid(), 'admin', 'permission', 'Employee accounts', new.name,
        'Changed ' || new.name || ': ' || old.team || '/' || old.role || '/' || old.status || ' → ' || new.team || '/' || new.role || '/' || new.status);
  end if;
  return new;
end $$;
create trigger profiles_audit after update on public.profiles for each row execute function public.log_profile_change();

create or replace function public.set_updated_at() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

-- ───────── shared tables ─────────
create table public.activity_logs (
  id uuid primary key default gen_random_uuid(),
  module text not null,
  record_id uuid not null,
  record_title text,
  team text,
  user_id uuid references public.profiles(id) on delete set null,
  action text not null check (action in ('created','status','completed','assigned','output','updated','deleted')),
  detail text not null,
  created_at timestamptz not null default now()
);
create index on public.activity_logs(module, record_id, created_at);

create table public.user_logs (            -- development "User Log" module (read-only)
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete set null,
  team text not null,
  action text not null,
  module_name text not null,
  record_title text,
  description text,
  ip text,
  created_at timestamptz not null default now()
);
create index on public.user_logs(created_at desc);

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,   -- one row per recipient
  title text not null,
  body text not null,
  kind text not null check (kind in ('expiry','due','overdue','creative','marketing','completed','admin','priority','check')),
  link text,
  read boolean not null default false,
  created_at timestamptz not null default now()
);
create index on public.notifications(user_id, created_at desc);

create table public.daily_motivations (
  id uuid primary key default gen_random_uuid(),
  message text not null,
  team text not null check (team in ('all','admin','development','marketing','creative')),
  date date,                           -- optional: pin a message to a specific day
  image text,                          -- character key (development|marketing|creative|admin)
  active boolean not null default true
);

create table public.motivation_shown (
  user_id uuid not null references public.profiles(id) on delete cascade,
  motivation_id uuid not null references public.daily_motivations(id) on delete cascade,
  shown_on date not null default current_date,
  primary key (user_id, shown_on)
);

-- ───────── notification helpers ─────────
create or replace function public.notify_team(t text, p_title text, p_body text, p_kind text, p_link text)
returns void language sql security definer set search_path = public as $$
  insert into public.notifications (user_id, title, body, kind, link)
  select id, p_title, p_body, p_kind, p_link from public.profiles where status = 'active' and (team = t or (t = 'admin' and role = 'admin'))
$$;

-- ───────── generic record trigger: activity timeline, user log, admin notifications ─────────
-- TG_ARGV: 0 module key, 1 team, 2 title column, 3 status column ('' if none), 4 completed-values (comma list), 5 href
create or replace function public.log_record_change() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  rec jsonb; old_rec jsonb; title text; ev text; detail text; uid uuid := auth.uid();
  ip text := coalesce(nullif(current_setting('request.headers', true), '')::json->>'x-forwarded-for', null);
  st_col text := tg_argv[3]; done_vals text[] := string_to_array(tg_argv[4], ',');
  team_name text := initcap(tg_argv[1]);
  module_title text := initcap(replace(tg_argv[0], '-', ' '));
begin
  if tg_op = 'DELETE' then rec := to_jsonb(old); else rec := to_jsonb(new); end if;
  title := coalesce(rec->>tg_argv[2], module_title);
  if tg_op = 'INSERT' then
    ev := 'created'; detail := 'Created ' || title;
    insert into public.activity_logs(module, record_id, record_title, team, user_id, action, detail) values (tg_argv[0], new.id, title, tg_argv[1], uid, ev, detail);
    if rec ? 'request_source' and coalesce(rec->>'request_source','') <> '' then
      perform public.notify_team('creative', 'New creative request', title || ' · from ' || (rec->>'request_source'), 'creative', tg_argv[5]);
      perform public.notify_team('admin', 'New creative request', title || ' requested', 'creative', tg_argv[5]);
    end if;
    if rec->>'assigned_to' is not null and (rec->>'assigned_to')::uuid is distinct from uid then
      insert into public.notifications(user_id, title, body, kind, link) values ((rec->>'assigned_to')::uuid, 'New task assigned', title || ' · ' || module_title, 'due', tg_argv[5]);
    end if;
  elsif tg_op = 'UPDATE' then
    old_rec := to_jsonb(old);
    if st_col <> '' and rec->>st_col is distinct from old_rec->>st_col then
      if (rec->>st_col) = any(done_vals) then
        ev := 'completed'; detail := 'Status changed to Completed';
        perform public.notify_team('admin', team_name || ' Team completed', team_name || ' Team completed: ' || title, 'completed', tg_argv[5]);
      else ev := 'status'; detail := 'Status changed to ' || coalesce(rec->>st_col, 'none'); end if;
      insert into public.activity_logs(module, record_id, record_title, team, user_id, action, detail) values (tg_argv[0], new.id, title, tg_argv[1], uid, ev, detail);
    end if;
    if rec->>'assigned_to' is distinct from old_rec->>'assigned_to' and rec->>'assigned_to' is not null then
      insert into public.activity_logs(module, record_id, record_title, team, user_id, action, detail)
        values (tg_argv[0], new.id, title, tg_argv[1], uid, 'assigned', 'Assigned to ' || coalesce((select name from public.profiles where id = (rec->>'assigned_to')::uuid), 'someone'));
      if (rec->>'assigned_to')::uuid is distinct from uid then
        insert into public.notifications(user_id, title, body, kind, link) values ((rec->>'assigned_to')::uuid, 'Task assigned to you', title || ' · ' || module_title, 'due', tg_argv[5]);
      end if;
    end if;
    -- creative requests: tell the requesting marketer when the work is submitted, approved or completed
    if rec ? 'requested_by' and rec->>'requested_by' is not null and (rec->>'requested_by')::uuid is distinct from uid
       and st_col <> '' and rec->>st_col is distinct from old_rec->>st_col then
      if rec->>st_col = 'Submitted for Review' then
        insert into public.notifications(user_id, title, body, kind, link) values ((rec->>'requested_by')::uuid, 'Creative submitted for review', title, 'creative', tg_argv[5]);
      elsif rec->>st_col = 'Approved' then
        insert into public.notifications(user_id, title, body, kind, link) values ((rec->>'requested_by')::uuid, 'Creative approved', title, 'creative', tg_argv[5]);
      elsif rec->>st_col = any(done_vals) then
        insert into public.notifications(user_id, title, body, kind, link) values ((rec->>'requested_by')::uuid, 'Creative completed', title, 'creative', tg_argv[5]);
      end if;
    end if;
    if coalesce(rec->>'output_link','') <> '' and coalesce(old_rec->>'output_link','') = '' then
      insert into public.activity_logs(module, record_id, record_title, team, user_id, action, detail) values (tg_argv[0], new.id, title, tg_argv[1], uid, 'output', 'Output link added');
    end if;
    if (rec - 'updated_at' - 'updated_by' - st_col - 'assigned_to') is distinct from (old_rec - 'updated_at' - 'updated_by' - st_col - 'assigned_to') then
      insert into public.activity_logs(module, record_id, record_title, team, user_id, action, detail) values (tg_argv[0], new.id, title, tg_argv[1], uid, 'updated', 'Record details updated');
    end if;
    ev := coalesce(ev, 'updated'); detail := coalesce(detail, 'Updated');
  else
    ev := 'deleted'; detail := 'Deleted ' || title;
    insert into public.activity_logs(module, record_id, record_title, team, user_id, action, detail) values (tg_argv[0], old.id, title, tg_argv[1], uid, ev, detail);
  end if;
  insert into public.user_logs(user_id, team, action, module_name, record_title, description, ip)
    values (uid, tg_argv[1], ev, module_title, title, detail, ip);
  return coalesce(new, old);
end $$;

-- ───────── RLS: shared tables ─────────
alter table public.teams enable row level security;
alter table public.roles enable row level security;
alter table public.profiles enable row level security;
alter table public.clients enable row level security;
alter table public.activity_logs enable row level security;
alter table public.user_logs enable row level security;
alter table public.notifications enable row level security;
alter table public.daily_motivations enable row level security;
alter table public.motivation_shown enable row level security;

create policy teams_read on public.teams for select to authenticated using (true);
create policy roles_read on public.roles for select to authenticated using (true);

create policy profiles_read on public.profiles for select to authenticated
  using (id = auth.uid() or public.is_admin() or team = public.my_team());
create policy profiles_update_self on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
create policy profiles_admin_all on public.profiles for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy clients_read on public.clients for select to authenticated using (public.my_team() is not null);
create policy clients_write on public.clients for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- timeline entries are visible to whoever can see the team that owns the module (checked via module → team map in code); keep simple: same team or admin
create policy activity_read on public.activity_logs for select to authenticated using (public.can_access_team(team));
create policy user_logs_read on public.user_logs for select to authenticated using (public.can_access_team(team));
-- no insert/update/delete policies: only SECURITY DEFINER triggers write these tables.

create policy notifications_own on public.notifications for select to authenticated using (user_id = auth.uid());
create policy notifications_mark_read on public.notifications for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy motivations_read on public.daily_motivations for select to authenticated using (public.my_team() is not null);
create policy motivations_admin on public.daily_motivations for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy shown_own on public.motivation_shown for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- ───────── realtime + storage ─────────
alter publication supabase_realtime add table public.notifications;
insert into storage.buckets (id, name, public) values ('thumbnails','thumbnails', true) on conflict do nothing;
create policy thumbs_upload on storage.objects for insert to authenticated with check (bucket_id = 'thumbnails' and public.my_team() is not null);
create policy thumbs_read on storage.objects for select using (bucket_id = 'thumbnails');
