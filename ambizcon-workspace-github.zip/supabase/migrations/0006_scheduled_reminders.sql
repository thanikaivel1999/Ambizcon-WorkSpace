-- Scheduled reminders: expiry alerts and task due/overdue alerts generated on the server, not in a browser timer.
-- Run after 0001–0005. Triggered daily by /api/cron/reminders (Vercel Cron) or by pg_cron (see README).
-- Safe to run more than once a day: reminder_log (user, key, day) de-duplicates every notification.

create or replace function public.run_reminders() returns integer
language plpgsql security definer set search_path = public as $$
declare
  tz text := coalesce((select value #>> '{}' from public.app_settings where key = 'company_timezone'), 'Asia/Kolkata');
  today date := (now() at time zone tz)::date;
  alert_days int[] := coalesce(
    (select array(select (e)::int from jsonb_array_elements_text(value) e) from public.app_settings where key = 'expiry_alert_days' and jsonb_typeof(value) = 'array'),
    array[90, 60, 30, 14, 7, 1]);
  src record; r record; admin_ids uuid[]; recipients uuid[]; uid uuid;
  d int; k text; sent int := 0; ins int;
begin
  select coalesce(array_agg(id), '{}') into admin_ids from public.profiles where status = 'active' and role = 'admin';

  -- 1. Expiry registers: (table, date column, title column, label, link)
  for src in
    select * from (values
      ('website_expiry', 'expiry_date',    'domain',     'Domain',          '/development/domain-expiry'),
      ('website_expiry', 'hosting_expiry', 'domain',     'Hosting',         '/development/domain-expiry'),
      ('ssl_expiry',     'ssl_expiry_date','website',    'SSL certificate', '/development/ssl-expiry'),
      ('dev_tools_expiry','expiry_date',   'tool_name',  'Development tool','/development/tools-expiry'),
      ('smtp_tools_expiry','expiry_date',  'smtp_tool',  'SMTP tool',       '/development/smtp-expiry'),
      ('domain_access',  'expiry_date',    'domain',     'Domain access',   '/development/domain-access')
    ) as t(tbl, col, title_col, label, link)
  loop
    for r in execute format(
      'select id, %I::text as title, %I::date as due, assigned_to from public.%I where %I is not null and coalesce(status, '''') not in (''Completed'', ''Cancelled'')',
      src.title_col, src.col, src.tbl, src.col)
    loop
      d := r.due - today;
      -- fire on each configured threshold day, and weekly (every 7th day) once expired
      if d = any (alert_days) or (d < 0 and (-d) % 7 = 1) then
        k := format('%s:%s:%s:%s', src.tbl, src.col, r.id, case when d < 0 then 'expired' else d::text end);
        recipients := admin_ids;
        if r.assigned_to is not null and not (r.assigned_to = any (recipients)) then recipients := recipients || r.assigned_to; end if;
        foreach uid in array recipients loop
          insert into public.reminder_log (user_id, reminder_key, sent_on) values (uid, k, today) on conflict do nothing;
          get diagnostics ins = row_count;
          if ins > 0 then
            insert into public.notifications (user_id, title, body, kind, link) values (
              uid,
              case when d < 0 then src.label || ' expired' else src.label || ' expires in ' || d || ' day' || case when d = 1 then '' else 's' end end,
              coalesce(r.title, 'Record') || ' — ' || case when d < 0 then 'expired ' || (-d) || ' day(s) ago (' || r.due || ')' else 'expires on ' || r.due end,
              'expiry', src.link);
            sent := sent + 1;
          end if;
        end loop;
      end if;
    end loop;
  end loop;

  -- 2. Tasks: due today (once) and overdue (once per day) for the assignee; open tasks only
  for r in
    select id, title, due_date, assigned_to, team from public.tasks
    where assigned_to is not null and due_date is not null and due_date <= today
      and status not in ('Completed', 'Cancelled', 'Approved', 'Submitted for Review')
  loop
    d := r.due_date - today;
    k := format('task:%s:%s', r.id, case when d < 0 then 'overdue' else 'due' end);
    insert into public.reminder_log (user_id, reminder_key, sent_on) values (r.assigned_to, k, today) on conflict do nothing;
    get diagnostics ins = row_count;
    if ins > 0 then
      insert into public.notifications (user_id, title, body, kind, link) values (
        r.assigned_to,
        case when d < 0 then 'Task overdue' else 'Task due today' end,
        r.title || case when d < 0 then ' was due ' || r.due_date else ' is due today' end,
        case when d < 0 then 'overdue' else 'due' end, '/tasks');
      sent := sent + 1;
    end if;
  end loop;

  -- housekeeping: the de-duplication log only needs recent days
  delete from public.reminder_log where sent_on < today - 60;
  return sent;
end $$;

-- Only the service role (the cron route) or the database scheduler may run it; never an end user or the anon key.
revoke all on function public.run_reminders() from public, anon, authenticated;
grant execute on function public.run_reminders() to service_role;

-- Optional: if the pg_cron extension is enabled on your Supabase project, schedule it there instead of Vercel Cron:
--   select cron.schedule('ambizcon-reminders', '30 0 * * *', $$select public.run_reminders()$$);   -- 00:30 UTC = 06:00 IST
