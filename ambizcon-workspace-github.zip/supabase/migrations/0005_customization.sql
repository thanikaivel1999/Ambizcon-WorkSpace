-- Customization Studio: admin-built registers (custom modules), extra fields on built-in modules, and the checks that keep them safe.
-- Hand-written. Run after 0001–0004.

create table public.custom_modules (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique check (slug ~ '^[a-z0-9][a-z0-9-]{1,38}$'),
  title text not null check (length(title) between 2 and 80),
  team text not null check (team in ('development', 'marketing', 'creative')),
  icon text not null default 'ClipboardList',
  blurb text not null default '',
  fields jsonb not null default '[]'::jsonb,   -- [{key,label,type,options?,required?}]
  archived boolean not null default false,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint custom_modules_fields_array check (jsonb_typeof(fields) = 'array' and jsonb_array_length(fields) <= 40)
);
create trigger custom_modules_updated before update on public.custom_modules for each row execute function public.set_updated_at();

create table public.custom_records (
  id uuid primary key default gen_random_uuid(),
  module_id uuid not null references public.custom_modules(id) on delete cascade,
  client_id uuid references public.clients(id) on delete set null,
  data jsonb not null default '{}'::jsonb,
  created_by uuid references public.profiles(id) on delete set null,
  updated_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint custom_records_data_object check (jsonb_typeof(data) = 'object' and pg_column_size(data) < 30000)
);
create index on public.custom_records(module_id, created_at desc);
create index on public.custom_records(client_id);
create trigger custom_records_updated before update on public.custom_records for each row execute function public.set_updated_at();

create table public.custom_field_definitions (   -- extra fields on built-in modules; values live in each table's "custom" column
  id uuid primary key default gen_random_uuid(),
  module_key text not null,
  key text not null check (key ~ '^[a-z][a-z0-9_]{1,30}$'),
  label text not null check (length(label) between 1 and 60),
  type text not null check (type in ('text', 'longtext', 'number', 'date', 'url', 'select', 'bool', 'file', 'client', 'user')),
  options jsonb not null default '[]'::jsonb,
  required boolean not null default false,
  position int not null default 0,
  archived boolean not null default false,
  created_at timestamptz not null default now(),
  unique (module_key, key)
);

-- Field-level validation for custom records, enforced in the database (the UI cannot bypass it).
create or replace function public.validate_custom_record() returns trigger
language plpgsql security definer set search_path = public as $$
declare spec jsonb; f jsonb; v jsonb; k text; t text; opts jsonb;
begin
  select fields into spec from public.custom_modules where id = new.module_id;
  if spec is null then raise exception 'Unknown custom module'; end if;
  for f in select * from jsonb_array_elements(spec) loop
    k := f->>'key'; t := f->>'type'; v := new.data->k; opts := coalesce(f->'options', '[]'::jsonb);
    if coalesce((f->>'required')::boolean, false) and (v is null or v = 'null'::jsonb or v = '""'::jsonb) and t <> 'bool' then
      raise exception '% is required', f->>'label';
    end if;
    if v is null or v = 'null'::jsonb or v = '""'::jsonb then continue; end if;
    if t = 'number' and jsonb_typeof(v) <> 'number' then raise exception '% must be a number', f->>'label'; end if;
    if t = 'bool' and jsonb_typeof(v) <> 'boolean' then raise exception '% must be yes or no', f->>'label'; end if;
    if t in ('text', 'longtext', 'date', 'url', 'select', 'file') and jsonb_typeof(v) <> 'string' then raise exception '% must be text', f->>'label'; end if;
    if t = 'date' and (v #>> '{}') !~ '^\d{4}-\d{2}-\d{2}$' then raise exception '% must be a date', f->>'label'; end if;
    if t = 'url' and (v #>> '{}') !~* '^https?://' then raise exception '% must start with http:// or https://', f->>'label'; end if;
    if t = 'select' and not (opts @> to_jsonb(v #>> '{}')) then raise exception '% has an invalid option', f->>'label'; end if;
    if t in ('text', 'select', 'url', 'file', 'date') and length(v #>> '{}') > 500 then raise exception '% is too long', f->>'label'; end if;
    if t = 'longtext' and length(v #>> '{}') > 4000 then raise exception '% is too long', f->>'label'; end if;
  end loop;
  return new;
end $$;
create trigger custom_records_validate before insert or update on public.custom_records for each row execute function public.validate_custom_record();

alter table public.custom_modules enable row level security;
alter table public.custom_records enable row level security;
alter table public.custom_field_definitions enable row level security;

create policy custom_modules_read on public.custom_modules for select to authenticated
  using (public.is_admin() or (not archived and public.module_level(team, 'custom:' || id::text) in ('read', 'write')));
create policy custom_modules_admin on public.custom_modules for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy custom_records_select on public.custom_records for select to authenticated
  using (exists (select 1 from public.custom_modules cm where cm.id = module_id and public.module_level(cm.team, 'custom:' || cm.id::text) in ('read', 'write')));
create policy custom_records_insert on public.custom_records for insert to authenticated
  with check (exists (select 1 from public.custom_modules cm where cm.id = module_id and not cm.archived and public.module_level(cm.team, 'custom:' || cm.id::text) = 'write'));
create policy custom_records_update on public.custom_records for update to authenticated
  using (exists (select 1 from public.custom_modules cm where cm.id = module_id and public.module_level(cm.team, 'custom:' || cm.id::text) = 'write'))
  with check (exists (select 1 from public.custom_modules cm where cm.id = module_id and public.module_level(cm.team, 'custom:' || cm.id::text) = 'write'));
create policy custom_records_delete on public.custom_records for delete to authenticated
  using (exists (select 1 from public.custom_modules cm where cm.id = module_id and public.module_level(cm.team, 'custom:' || cm.id::text) = 'write'));

create policy custom_fields_read on public.custom_field_definitions for select to authenticated using (public.my_team() is not null);
create policy custom_fields_admin on public.custom_field_definitions for all to authenticated using (public.is_admin()) with check (public.is_admin());

create trigger custom_modules_audit after insert or update or delete on public.custom_modules for each row execute function public.log_config_change('custom module');
create trigger custom_fields_audit after insert or update or delete on public.custom_field_definitions for each row execute function public.log_config_change('custom field');
create trigger app_settings_audit after insert or update or delete on public.app_settings for each row execute function public.log_config_change('setting');

alter publication supabase_realtime add table public.custom_records;

-- Per-user notification preferences (in-app is always on; email only when a provider is configured on the server).
create table public.notification_prefs (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  email_enabled boolean not null default false,
  kinds text[] not null default array['expiry', 'due', 'overdue', 'creative', 'completed', 'check', 'priority', 'admin', 'marketing'],
  updated_at timestamptz not null default now()
);
alter table public.notification_prefs enable row level security;
create policy notification_prefs_own on public.notification_prefs for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- De-duplication for scheduled reminders: one row per (user, reminder key), so a job can run safely more than once a day.
create table public.reminder_log (
  user_id uuid not null references public.profiles(id) on delete cascade,
  reminder_key text not null,
  sent_on date not null default current_date,
  primary key (user_id, reminder_key, sent_on)
);
alter table public.reminder_log enable row level security;   -- no policies: only the service role (cron job) touches it

-- Private bucket for uploaded files (custom "file" fields). Files are opened through short-lived signed URLs, never public links.
insert into storage.buckets (id, name, public) values ('attachments', 'attachments', false) on conflict do nothing;
create policy attachments_upload on storage.objects for insert to authenticated
  with check (bucket_id = 'attachments' and public.my_team() is not null and (storage.extension(name) = any (array['pdf','png','jpg','jpeg','webp','gif','txt','csv','doc','docx','xls','xlsx'])));
create policy attachments_read on storage.objects for select to authenticated using (bucket_id = 'attachments' and public.my_team() is not null);
