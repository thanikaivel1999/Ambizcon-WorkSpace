-- Shared client profiles, global tasks (with review workflow), comments, task history and app settings.
-- Hand-written. Run after 0001–0003.

-- ───────── clients: one shared record for every team ─────────
alter table public.clients
  add column client_type text not null default 'General Practitioner' check (client_type in ('Specialist', 'General Practitioner')),
  add column joined_on date,
  add column md_name text,
  add column location text,
  add column category text,
  add column website text check (website is null or website ~* '^https?://'),
  add column status text not null default 'active' check (status in ('active', 'inactive', 'archived')),
  add column notes text,
  add column updated_at timestamptz not null default now();
create index on public.clients(status);
create index on public.clients(location);
create trigger clients_updated before update on public.clients for each row execute function public.set_updated_at();

create table public.client_members (
  client_id uuid not null references public.clients(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  primary key (client_id, user_id)
);
create index on public.client_members(user_id);
alter table public.client_members enable row level security;
create policy client_members_read on public.client_members for select to authenticated using (public.my_team() is not null);
create policy client_members_admin on public.client_members for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- clients_read / clients_write (0001) already give every team read access and admins write access.

-- ───────── global tasks ─────────
create table public.tasks (
  id uuid primary key default gen_random_uuid(),
  title text not null check (length(title) between 1 and 300),
  description text,
  client_id uuid references public.clients(id) on delete set null,
  team text not null check (team in ('development', 'marketing', 'creative')),
  assigned_to uuid references public.profiles(id) on delete set null,
  created_by uuid references public.profiles(id) on delete set null,
  reviewer_id uuid references public.profiles(id) on delete set null,
  priority text not null default 'Medium' check (priority in ('Low', 'Medium', 'High', 'Urgent')),
  status text not null default 'New' check (status in ('New', 'Assigned', 'In Progress', 'On Hold', 'Submitted for Review', 'Changes Requested', 'Approved', 'Completed', 'Cancelled')),
  review_status text not null default 'None' check (review_status in ('None', 'Requested', 'Approved', 'Changes Requested')),
  review_rating smallint check (review_rating between 1 and 5),   -- null = not reviewed (never treated as zero)
  date_assigned date default current_date,
  due_date date,
  output_link text check (output_link is null or output_link ~* '^https?://'),
  thumbnail text,
  remarks text,
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index on public.tasks(team, status);
create index on public.tasks(assigned_to);
create index on public.tasks(reviewer_id);
create index on public.tasks(client_id);
create index on public.tasks(due_date);
create index on public.tasks(completed_at);
create trigger tasks_updated before update on public.tasks for each row execute function public.set_updated_at();

create table public.task_comments (
  id uuid primary key default gen_random_uuid(),
  task_id uuid not null references public.tasks(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade default auth.uid(),
  body text not null check (length(body) between 1 and 2000),
  created_at timestamptz not null default now()
);
create index on public.task_comments(task_id, created_at);

create table public.task_events (          -- activity history; written only by triggers
  id uuid primary key default gen_random_uuid(),
  task_id uuid not null references public.tasks(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete set null,
  action text not null,
  detail text not null,
  created_at timestamptz not null default now()
);
create index on public.task_events(task_id, created_at);

-- Workflow guard: the same rules as src/lib/taskflow.ts, enforced in the database.
create or replace function public.tasks_guard() returns trigger
language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); adm boolean := public.is_admin();
begin
  if uid is null then return new; end if;     -- service role / migrations
  if tg_op = 'INSERT' then
    new.created_by := uid;
    new.status := case when new.assigned_to is null then 'New' else 'Assigned' end;
    new.review_status := 'None'; new.review_rating := null; new.completed_at := null;
    return new;
  end if;

  if new.review_status is distinct from old.review_status then
    if new.review_status in ('Approved', 'Changes Requested') then
      if not adm and new.reviewer_id is distinct from uid then raise exception 'Only the assigned reviewer (or an admin) can approve or request changes'; end if;
      if not adm and new.assigned_to = uid then raise exception 'You cannot review your own task'; end if;
      if not adm and old.review_status <> 'Requested' then raise exception 'This task has not been submitted for review'; end if;
      new.status := case when new.review_status = 'Approved' then 'Approved' else 'Changes Requested' end;
    elsif new.review_status = 'Requested' then
      if new.reviewer_id is null then raise exception 'Choose a reviewer before requesting a review'; end if;
      new.status := 'Submitted for Review';
    elsif new.review_status = 'None' and not adm then
      raise exception 'Only an admin can reset a review';
    end if;
  elsif new.status is distinct from old.status then
    if new.status = 'Submitted for Review' then
      if new.reviewer_id is null then raise exception 'Choose a reviewer before submitting for review'; end if;
      new.review_status := 'Requested';
    elsif new.status = 'Approved' and new.review_status <> 'Approved' then
      raise exception 'A task can only be Approved by its reviewer';
    elsif new.status = 'Completed' and new.reviewer_id is not null and new.review_status <> 'Approved' then
      raise exception 'This task needs reviewer approval before it can be completed';
    end if;
  end if;

  if new.review_rating is distinct from old.review_rating and new.review_rating is not null
     and not adm and new.reviewer_id is distinct from uid then
    raise exception 'Only the reviewer can record a rating';
  end if;

  if new.status = 'Completed' and old.status <> 'Completed' then new.completed_at := now();
  elsif new.status <> 'Completed' and old.status = 'Completed' then new.completed_at := null;
  else new.completed_at := old.completed_at; end if;
  new.created_by := old.created_by;
  return new;
end $$;
create trigger tasks_guard_trg before insert or update on public.tasks for each row execute function public.tasks_guard();

create or replace function public.tasks_audit() returns trigger
language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); team_name text := initcap(new.team);
begin
  if tg_op = 'INSERT' then
    insert into public.task_events(task_id, user_id, action, detail) values (new.id, uid, 'created', 'Task created');
    if new.assigned_to is not null and new.assigned_to is distinct from uid then
      insert into public.notifications(user_id, title, body, kind, link) values (new.assigned_to, 'New task assigned', new.title, 'due', '/tasks?open=' || new.id);
    end if;
    return new;
  end if;
  if new.review_status is distinct from old.review_status then
    if new.review_status = 'Requested' then
      insert into public.task_events(task_id, user_id, action, detail) values (new.id, uid, 'review', 'Submitted for review');
      if new.reviewer_id is not null then insert into public.notifications(user_id, title, body, kind, link) values (new.reviewer_id, 'Review requested', new.title, 'due', '/tasks?open=' || new.id); end if;
    elsif new.review_status = 'Approved' then
      insert into public.task_events(task_id, user_id, action, detail) values (new.id, uid, 'approved', 'Task approved by reviewer');
      if new.assigned_to is not null then insert into public.notifications(user_id, title, body, kind, link) values (new.assigned_to, 'Task approved', new.title, 'completed', '/tasks?open=' || new.id); end if;
    elsif new.review_status = 'Changes Requested' then
      insert into public.task_events(task_id, user_id, action, detail) values (new.id, uid, 'changes', 'Reviewer requested changes');
      if new.assigned_to is not null then insert into public.notifications(user_id, title, body, kind, link) values (new.assigned_to, 'Changes requested', new.title, 'due', '/tasks?open=' || new.id); end if;
    end if;
  elsif new.status is distinct from old.status and new.status <> 'Completed' and old.status <> 'Completed' then
    insert into public.task_events(task_id, user_id, action, detail) values (new.id, uid, 'status', 'Status changed to ' || new.status);
  end if;
  if new.status = 'Completed' and old.status <> 'Completed' then
    insert into public.task_events(task_id, user_id, action, detail)
      values (new.id, uid, 'completed', case when new.review_status = 'Approved' then 'Completed (verified by review)' else 'Completed (self-reported, unverified)' end);
    perform public.notify_team('admin', team_name || ' Team completed', team_name || ' Team completed: ' || new.title, 'completed', '/tasks?open=' || new.id);
  elsif new.status <> 'Completed' and old.status = 'Completed' then
    insert into public.task_events(task_id, user_id, action, detail) values (new.id, uid, 'reopened', 'Reopened as ' || new.status);
  end if;
  if new.assigned_to is distinct from old.assigned_to and new.assigned_to is not null then
    insert into public.task_events(task_id, user_id, action, detail) values (new.id, uid, 'assigned', 'Assignee changed');
    if new.assigned_to is distinct from uid then insert into public.notifications(user_id, title, body, kind, link) values (new.assigned_to, 'Task assigned to you', new.title, 'due', '/tasks?open=' || new.id); end if;
  end if;
  return new;
end $$;
create trigger tasks_audit_trg after insert or update on public.tasks for each row execute function public.tasks_audit();

create or replace function public.task_comment_notify() returns trigger
language plpgsql security definer set search_path = public as $$
declare t public.tasks; who text;
begin
  select * into t from public.tasks where id = new.task_id;
  select name into who from public.profiles where id = new.user_id;
  insert into public.notifications(user_id, title, body, kind, link)
    select distinct x, 'New task comment', coalesce(who, 'Someone') || ': ' || left(new.body, 80), 'due', '/tasks?open=' || t.id
    from unnest(array[t.assigned_to, t.reviewer_id, t.created_by]) as x where x is not null and x <> new.user_id;
  return new;
end $$;
create trigger task_comment_notify_trg after insert on public.task_comments for each row execute function public.task_comment_notify();

alter table public.tasks enable row level security;
alter table public.task_comments enable row level security;
alter table public.task_events enable row level security;

create policy tasks_select on public.tasks for select to authenticated
  using (public.can_access_team(team) or assigned_to = auth.uid() or reviewer_id = auth.uid());
create policy tasks_insert on public.tasks for insert to authenticated with check (public.can_access_team(team));
create policy tasks_update on public.tasks for update to authenticated
  using (public.can_access_team(team) or assigned_to = auth.uid() or reviewer_id = auth.uid())
  with check (public.can_access_team(team) or assigned_to = auth.uid() or reviewer_id = auth.uid());
create policy tasks_delete on public.tasks for delete to authenticated using (public.is_admin());

create policy task_comments_select on public.task_comments for select to authenticated using (exists (select 1 from public.tasks t where t.id = task_id));
create policy task_comments_insert on public.task_comments for insert to authenticated
  with check (user_id = auth.uid() and exists (select 1 from public.tasks t where t.id = task_id));
create policy task_events_select on public.task_events for select to authenticated using (exists (select 1 from public.tasks t where t.id = task_id));
-- no insert/update/delete policy on task_events: only the SECURITY DEFINER trigger writes history.

alter publication supabase_realtime add table public.tasks;

-- ───────── app settings (scoring weights, alert schedules, animation toggles…) ─────────
create table public.app_settings (
  key text primary key,
  value jsonb not null,
  updated_by uuid references public.profiles(id) on delete set null,
  updated_at timestamptz not null default now()
);
alter table public.app_settings enable row level security;
create policy app_settings_read on public.app_settings for select to authenticated using (public.my_team() is not null);
create policy app_settings_admin on public.app_settings for all to authenticated using (public.is_admin()) with check (public.is_admin());
