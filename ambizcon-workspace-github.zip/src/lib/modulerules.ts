import type { ModuleDef } from './modules';
import type { Profile, Rec } from './types';
import { todayISO } from './utils';

/**
 * Server-side style rules for module records. The demo backend runs this on every create/update; the generated SQL trigger
 * `<table>_rules` in supabase/migrations/0002_modules.sql enforces the same rules in Postgres (see scripts/gen-sql.ts).
 *
 * Creative modules (reviewFlow):
 *  - Submitted for Review sets review_status = In review (when a reviewer is set).
 *  - Only the reviewer, or an admin, can set review_status to Approved / Changes requested; never the assignee (unless admin).
 *  - Approved review sets the status to Approved; Changes requested sets Changes Requested.
 *  - Completed requires review_status = Approved whenever a reviewer is set.
 * Any module with a completion_date column: the date is stamped when the record becomes Completed and cleared if it reopens.
 */
export type RuleResult = { ok: true; patch: Record<string, unknown>; notify: ('submitted' | 'approved' | 'completed')[] } | { ok: false; error: string };

export const isDoneValue = (m: ModuleDef, v: unknown) => (m.statusMap ? m.statusMap[String(v)] === 'Completed' : v === 'Completed');

export function applyModuleRules(m: ModuleDef, before: Rec | null, patch: Record<string, unknown>, actor: Pick<Profile, 'id' | 'team'>, today = todayISO()): RuleResult {
  const out: Record<string, unknown> = { ...patch };
  const prev: Record<string, any> = before ?? {};
  const merged: Record<string, any> = { ...prev, ...patch };
  const notify: ('submitted' | 'approved' | 'completed')[] = [];
  const admin = actor.team === 'admin';

  if (m.reviewFlow) {
    const reviewChanged = 'review_status' in patch && patch.review_status !== prev.review_status;
    if (reviewChanged && (patch.review_status === 'Approved' || patch.review_status === 'Changes requested')) {
      if (!admin && merged.reviewer !== actor.id) return { ok: false, error: 'Only the assigned reviewer (or an admin) can approve or request changes.' };
      if (!admin && merged.assigned_to === actor.id) return { ok: false, error: 'You cannot review your own work.' };
      if (patch.review_status === 'Approved') { out.status = merged.status === 'Completed' ? 'Completed' : 'Approved'; notify.push('approved'); }
      else out.status = 'Changes Requested';
    } else if (!reviewChanged && 'status' in patch && patch.status !== prev.status) {
      if (patch.status === 'Submitted for Review') {
        if (merged.reviewer) out.review_status = 'In review';
        notify.push('submitted');
      } else if (patch.status === 'Approved' && merged.review_status !== 'Approved') {
        return { ok: false, error: 'Work can only be Approved by its reviewer.' };
      }
    }
    const finalStatus = (out.status ?? merged.status) as string;
    if (finalStatus === 'Completed' && prev.status !== 'Completed') {
      const rs = (out.review_status ?? merged.review_status) as string | undefined;
      if (merged.reviewer && rs !== 'Approved') return { ok: false, error: 'This needs reviewer approval before it can be completed.' };
    }
  }

  if (m.fields.some((f) => f.key === 'completion_date') && m.statusField && (m.statusField in patch || before === null)) {
    const finalStatus = out[m.statusField] ?? merged[m.statusField];
    const done = isDoneValue(m, finalStatus);
    out.completion_date = done ? (merged.completion_date || today) : null;
    if (done && prev[m.statusField] !== finalStatus) notify.push('completed');
  }
  return { ok: true, patch: out, notify };
}
