import { effStatus, summarize, type Item, type Summary } from './stats';
import type { Status, WorkTeam } from './types';
import { TEAM_LABEL } from './access';

export const WORK_TEAMS: WorkTeam[] = ['development', 'marketing', 'creative'];

export const forTeam = (items: Item[], team: WorkTeam) => items.filter((i) => i.m.team === team);

export function byTeam(items: Item[]): ({ team: WorkTeam; name: string } & Summary)[] {
  return WORK_TEAMS.map((team) => ({ team, name: TEAM_LABEL[team], ...summarize(forTeam(items, team)) }));
}

export function statusDistribution(items: Item[]) {
  const c: Partial<Record<Status, number>> = {};
  for (const { m, rec } of items) {
    const s = effStatus(m, rec);
    if (s) c[s] = (c[s] ?? 0) + 1;
  }
  return (['Completed', 'In Progress', 'Pending', 'Overdue', 'On Hold', 'Cancelled'] as Status[]).map((name) => ({ name, value: c[name] ?? 0 })).filter((d) => d.value > 0);
}

/** Records created per month for the last `n` months, split by team. */
export function monthlyActivity(items: Item[], n = 6) {
  const now = new Date();
  const buckets = Array.from({ length: n }, (_, i) => {
    const d = new Date(now.getFullYear(), now.getMonth() - (n - 1 - i), 1);
    return { key: `${d.getFullYear()}-${d.getMonth()}`, name: d.toLocaleDateString('en-GB', { month: 'short' }), development: 0, marketing: 0, creative: 0, total: 0 };
  });
  for (const { m, rec } of items) {
    const d = new Date(rec.created_at);
    const b = buckets.find((x) => x.key === `${d.getFullYear()}-${d.getMonth()}`);
    if (b) { b[m.team]++; b.total++; }
  }
  return buckets;
}

export function byModule(items: Item[]) {
  const map = new Map<string, { name: string; completed: number; pending: number; overdue: number; total: number }>();
  for (const { m, rec } of items) {
    const s = effStatus(m, rec);
    if (!s) continue;
    const e = map.get(m.key) ?? { name: m.nav, completed: 0, pending: 0, overdue: 0, total: 0 };
    e.total++;
    if (s === 'Completed') e.completed++;
    else if (s === 'Overdue') e.overdue++;
    else if (s !== 'Cancelled') e.pending++;
    map.set(m.key, e);
  }
  return [...map.values()];
}

export function recent(items: Item[], kind: 'completed' | 'added', n = 5) {
  const list = kind === 'completed' ? items.filter(({ m, rec }) => effStatus(m, rec) === 'Completed') : items;
  return [...list].sort((a, b) => (kind === 'completed' ? b.rec.updated_at.localeCompare(a.rec.updated_at) : b.rec.created_at.localeCompare(a.rec.created_at))).slice(0, n);
}

/** Workload per person: open items assigned to them (any user-type field named assigned_to). */
export function workload(items: Item[], names: (id?: string | null) => string) {
  const map = new Map<string, { name: string; open: number; done: number }>();
  for (const { m, rec } of items) {
    const id = rec.assigned_to as string | undefined;
    if (!id) continue;
    const s = effStatus(m, rec);
    if (!s || s === 'Cancelled') continue;
    const e = map.get(id) ?? { name: names(id), open: 0, done: 0 };
    if (s === 'Completed') e.done++; else e.open++;
    map.set(id, e);
  }
  return [...map.values()].sort((a, b) => b.open + b.done - (a.open + a.done));
}
