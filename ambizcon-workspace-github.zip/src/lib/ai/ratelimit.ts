/**
 * Small sliding-window rate limiter for sensitive endpoints (AI chat, password-style actions).
 * In-memory: it limits per server instance, which is a sensible first line of defence on a single node.
 * On serverless hosts with many instances, back it with a shared store (Upstash/Redis, or a Postgres counter) behind the same signature.
 */
const hits = new Map<string, number[]>();

export function rateLimit(key: string, limit: number, windowMs: number, now = Date.now()): { ok: boolean; retryAfterSec: number } {
  const recent = (hits.get(key) ?? []).filter((t) => now - t < windowMs);
  if (recent.length >= limit) {
    hits.set(key, recent);
    return { ok: false, retryAfterSec: Math.max(1, Math.ceil((windowMs - (now - recent[0])) / 1000)) };
  }
  recent.push(now);
  hits.set(key, recent);
  if (hits.size > 5000) for (const [k, v] of hits) if (v.every((t) => now - t >= windowMs)) hits.delete(k);
  return { ok: true, retryAfterSec: 0 };
}

export const resetRateLimits = () => hits.clear();
