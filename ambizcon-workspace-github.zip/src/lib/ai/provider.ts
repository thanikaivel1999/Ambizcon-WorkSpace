/**
 * Provider-agnostic AI layer. The rest of the app only knows `AiProvider`; to change vendor, set AI_PROVIDER (and the matching
 * env vars) or add a class below. API keys are read from server environment variables only and never reach the browser.
 *
 *   AI_PROVIDER   anthropic | openai          (openai = any OpenAI-compatible chat-completions endpoint)
 *   AI_API_KEY    secret key for the provider
 *   AI_MODEL      model id (provider specific)
 *   AI_BASE_URL   optional, overrides the API base URL (Azure, gateways, local servers)
 */
export interface ChatMessage { role: 'user' | 'assistant'; content: string }
export interface CompletionRequest { system: string; messages: ChatMessage[]; maxTokens?: number; temperature?: number }
export interface Completion { text: string; model: string }

export interface AiProvider {
  readonly name: string;
  readonly model: string;
  complete(req: CompletionRequest, signal?: AbortSignal): Promise<Completion>;
}

export class AiError extends Error {
  constructor(message: string, readonly status = 502) { super(message); }
}

async function readJson(res: Response): Promise<any> {
  const text = await res.text();
  try { return JSON.parse(text); } catch { return { raw: text.slice(0, 300) }; }
}

class AnthropicProvider implements AiProvider {
  readonly name = 'anthropic';
  constructor(private key: string, readonly model: string, private base = 'https://api.anthropic.com') {}
  async complete(req: CompletionRequest, signal?: AbortSignal): Promise<Completion> {
    const res = await fetch(`${this.base}/v1/messages`, {
      method: 'POST', signal,
      headers: { 'content-type': 'application/json', 'x-api-key': this.key, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model: this.model, max_tokens: req.maxTokens ?? 1024, temperature: req.temperature ?? 0.3, system: req.system, messages: req.messages }),
    });
    const j = await readJson(res);
    if (!res.ok) throw new AiError(`AI provider error (${res.status}): ${j?.error?.message ?? j?.raw ?? 'request failed'}`, res.status === 401 ? 502 : 502);
    const text = (j.content ?? []).filter((b: any) => b.type === 'text').map((b: any) => b.text).join('\n').trim();
    if (!text) throw new AiError('The AI provider returned an empty answer.');
    return { text, model: j.model ?? this.model };
  }
}

class OpenAiCompatibleProvider implements AiProvider {
  readonly name = 'openai';
  constructor(private key: string, readonly model: string, private base = 'https://api.openai.com/v1') {}
  async complete(req: CompletionRequest, signal?: AbortSignal): Promise<Completion> {
    const res = await fetch(`${this.base.replace(/\/$/, '')}/chat/completions`, {
      method: 'POST', signal,
      headers: { 'content-type': 'application/json', authorization: `Bearer ${this.key}` },
      body: JSON.stringify({ model: this.model, max_tokens: req.maxTokens ?? 1024, temperature: req.temperature ?? 0.3, messages: [{ role: 'system', content: req.system }, ...req.messages] }),
    });
    const j = await readJson(res);
    if (!res.ok) throw new AiError(`AI provider error (${res.status}): ${j?.error?.message ?? j?.raw ?? 'request failed'}`);
    const text = String(j.choices?.[0]?.message?.content ?? '').trim();
    if (!text) throw new AiError('The AI provider returned an empty answer.');
    return { text, model: j.model ?? this.model };
  }
}

/** Returns the configured provider, or null when AI is not set up (callers must show a clear "not configured" message). */
export function getProvider(env: Record<string, string | undefined> = process.env): AiProvider | null {
  const key = env.AI_API_KEY?.trim();
  const model = env.AI_MODEL?.trim();
  const kind = (env.AI_PROVIDER ?? '').trim().toLowerCase();
  if (!key || !model || !kind) return null;
  const base = env.AI_BASE_URL?.trim() || undefined;
  if (kind === 'anthropic') return new AnthropicProvider(key, model, base);
  if (kind === 'openai') return new OpenAiCompatibleProvider(key, model, base);
  return null;
}

export const notConfiguredMessage =
  'The AI assistant is not configured yet. An administrator needs to set AI_PROVIDER, AI_API_KEY and AI_MODEL in the server environment (see README, "AI assistant"). Your recorded data is unaffected.';
