import type { SupabaseClient } from '@supabase/supabase-js';
import { modulePath } from './access';
import { MODULES } from './modules';
import type { Team } from './types';

/**
 * URL paths of other teams' modules that an admin has granted to `team` (read or write). Used by the edge middleware so route
 * protection is decided on the server; the database enforces the same grants through Row Level Security (module_level()).
 */
export async function grantedPaths(sb: SupabaseClient, team: Team): Promise<string[]> {
  const { data: perms } = await sb.from('module_permissions').select('module_key, level').eq('team', team).neq('level', 'none');
  const keys = new Set((perms ?? []).map((p: { module_key: string }) => p.module_key));
  const paths = MODULES.filter((m) => keys.has(m.key)).map(modulePath);
  const customIds = [...keys].filter((k) => k.startsWith('custom:')).map((k) => k.slice('custom:'.length));
  if (customIds.length) {
    const { data } = await sb.from('custom_modules').select('slug, team').in('id', customIds);
    paths.push(...(data ?? []).map((c: { slug: string; team: string }) => `/${c.team}/${c.slug}`));
  }
  return paths;
}
