'use client';
import { useMutation, useQueries, useQuery, useQueryClient } from '@tanstack/react-query';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useCelebrate, useCelebrateTask } from '@/components/CompletionAnimation';
import { useAuth, useToast } from '@/components/providers';
import { api } from './data';
import { modulePath } from './access';
import { levelFor, moduleFromCustom, toPermMap, withCustomFields } from './custom';
import { MODULES, type ModuleDef } from './modules';
import { computeAlerts, type Item } from './stats';
import type { AppNotification, Client, ClientInput, Profile, Rec, Task, TaskInput, Team } from './types';

export const modulesForTeam = (team: Team): ModuleDef[] => MODULES.filter((m) => !m.readonly && (team === 'admin' || m.team === team));

export function useRecords(m: ModuleDef) {
  return useQuery({ queryKey: ['records', m.key], queryFn: () => api.records.list(m) });
}

/** Loads many modules in parallel (dashboards, reports, search). */
export function useItems(mods: ModuleDef[]) {
  const results = useQueries({ queries: mods.map((m) => ({ queryKey: ['records', m.key], queryFn: () => api.records.list(m) })) });
  const loading = results.some((r) => r.isLoading);
  const error = results.find((r) => r.error)?.error as Error | undefined;
  const sig = results.map((r) => r.dataUpdatedAt).join(',');
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const items = useMemo<Item[]>(() => mods.flatMap((m, i) => (results[i].data ?? []).map((rec) => ({ m, rec }))), [sig, mods.length]);
  const refetch = useCallback(() => results.forEach((r) => r.refetch()), [results]);
  return { items, loading, error, refetch };
}

export const useUsers = () => useQuery({ queryKey: ['users'], queryFn: () => api.users.list() });
export const useClients = () => useQuery({ queryKey: ['clients'], queryFn: () => api.clients.list() });

/** id → name lookups for user and client columns. */
export function useLookups() {
  const users = useUsers().data ?? [];
  const allClients = useClients().data ?? [];
  return useMemo(() => {
    const u = new Map(users.map((x) => [x.id, x]));
    const c = new Map(allClients.map((x) => [x.id, x.name]));
    // pickers/filters offer non-archived clients; name lookups still resolve archived ones
    const clients = allClients.filter((x) => x.status !== 'archived');
    return { users, clients, allClients, user: (id?: string | null) => (id ? u.get(id)?.name ?? '—' : '—'), client: (id?: string | null) => (id ? c.get(id) ?? '—' : '—'), userById: (id?: string | null) => (id ? u.get(id) : undefined) };
  }, [users, allClients]);
}

export type Lookups = ReturnType<typeof useLookups>;

/** Create / update / delete with toasts, cache invalidation and the completion animation. */
export function useRecordActions(m: ModuleDef) {
  const qc = useQueryClient();
  const { user } = useAuth();
  const toast = useToast();
  const celebrate = useCelebrate();
  const lk = useLookups();
  const label = m.title.replace(/s$/, '');
  const titleOf = (rec: Rec) => (m.titleField === 'client_id' ? lk.client(rec.client_id) : String(rec[m.titleField] ?? label));
  const done = (m.statusField && ((v: unknown) => (m.statusMap ? m.statusMap[String(v)] === 'Completed' : v === 'Completed'))) || (() => false);

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ['records', m.key] });
    qc.invalidateQueries({ queryKey: ['notifications'] });
    if (m.key !== 'user-log') qc.invalidateQueries({ queryKey: ['records', 'user-log'] });
    qc.invalidateQueries({ queryKey: ['activity'] });
  };

  const create = useMutation({
    mutationFn: (data: Record<string, unknown>) => api.records.create(m, data, user as Profile),
    onSuccess: (rec) => {
      invalidate();
      toast.success(`${label} record created successfully.`);
      if (m.statusField && done(rec[m.statusField])) celebrate(m, rec, titleOf(rec));
    },
    onError: (e: Error) => toast.error(e.message),
  });
  const update = useMutation({
    mutationFn: ({ id, patch }: { id: string; patch: Record<string, unknown>; before?: Rec }) => api.records.update(m, id, patch, user as Profile),
    onSuccess: (rec, v) => {
      invalidate();
      const was = v.before && m.statusField ? done(v.before[m.statusField]) : false;
      const now = m.statusField ? done(rec[m.statusField]) : false;
      if (now && !was) {
        toast.success(`${label} completed.`);
        celebrate(m, rec, titleOf(rec));
      } else if ('assigned_to' in v.patch && Object.keys(v.patch).length === 1) toast.success('Assigned successfully.');
      else if (Object.keys(v.patch).length === 1 && m.fields.find((f) => f.key === Object.keys(v.patch)[0])?.type === 'url') toast.success('Output added.');
      else toast.success(`${label} record updated successfully.`);
    },
    onError: (e: Error) => toast.error(e.message),
  });
  const remove = useMutation({
    mutationFn: (id: string) => api.records.remove(m, id, user as Profile),
    onSuccess: () => {
      invalidate();
      toast.success(`${label} record deleted.`);
    },
    onError: (e: Error) => toast.error(e.message),
  });
  return { create, update, remove, titleOf };
}

/** Stored notifications (triggers / server) + alerts derived from live data, with local read-state for alerts. */
export function useNotifications() {
  const { user } = useAuth();
  const mods = useMemo(() => modulesForTeam(user?.team ?? 'development'), [user?.team]);
  const { items } = useItems(user ? mods : []);
  const stored = useQuery({ queryKey: ['notifications', user?.id], queryFn: () => api.notifications.list(user as Profile), enabled: !!user });
  const qc = useQueryClient();
  const key = `amb_read_${user?.id}`;
  const [readAlerts, setReadAlerts] = useState<Set<string>>(new Set());
  useEffect(() => {
    try { setReadAlerts(new Set(JSON.parse(localStorage.getItem(key) ?? '[]'))); } catch { /* ignore */ }
  }, [key]);
  const alerts = useMemo(() => (user ? computeAlerts(items, user.team) : []), [items, user]);
  const list: AppNotification[] = useMemo(
    () => [...(stored.data ?? []), ...alerts.map((a) => ({ ...a, read: readAlerts.has(a.id) }))].sort((a, b) => Number(a.read) - Number(b.read) || b.created_at.localeCompare(a.created_at)),
    [stored.data, alerts, readAlerts],
  );
  const markAllRead = useCallback(async () => {
    const ids = list.filter((n) => !n.read);
    const storedIds = ids.filter((n) => !n.id.startsWith('alert:')).map((n) => n.id);
    const next = new Set(readAlerts);
    ids.filter((n) => n.id.startsWith('alert:')).forEach((n) => next.add(n.id));
    setReadAlerts(next);
    try { localStorage.setItem(key, JSON.stringify([...next])); } catch { /* ignore */ }
    if (storedIds.length) await api.notifications.markRead(storedIds);
    qc.invalidateQueries({ queryKey: ['notifications'] });
  }, [list, readAlerts, key, qc]);
  const markRead = useCallback(async (n: AppNotification) => {
    if (n.id.startsWith('alert:')) {
      const next = new Set(readAlerts).add(n.id);
      setReadAlerts(next);
      try { localStorage.setItem(key, JSON.stringify([...next])); } catch { /* ignore */ }
    } else {
      await api.notifications.markRead([n.id]);
      qc.invalidateQueries({ queryKey: ['notifications'] });
    }
  }, [readAlerts, key, qc]);
  return { list, unread: list.filter((n) => !n.read).length, markAllRead, markRead, loading: stored.isLoading, storedList: stored.data ?? [] };
}

/** Admin-only client create/update (also used to archive). */
export function useClientActions() {
  const qc = useQueryClient();
  const { user } = useAuth();
  const toast = useToast();
  const done = (msg: string) => () => { qc.invalidateQueries({ queryKey: ['clients'] }); toast.success(msg); };
  const create = useMutation({ mutationFn: (i: ClientInput) => api.clients.create(i, user as Profile), onSuccess: done('Client created successfully.'), onError: (e: Error) => toast.error(e.message) });
  const update = useMutation({ mutationFn: ({ id, patch }: { id: string; patch: Partial<ClientInput> }) => api.clients.update(id, patch, user as Profile), onSuccess: done('Client updated.'), onError: (e: Error) => toast.error(e.message) });
  return { create, update, canEdit: user?.team === 'admin' };
}

export const useTasks = () => useQuery({ queryKey: ['tasks'], queryFn: () => api.tasks.list() });

/** Task mutations. The completion celebration fires only after the server confirms the update AND the saved row is Completed. */
export function useTaskActions() {
  const qc = useQueryClient();
  const { user } = useAuth();
  const toast = useToast();
  const celebrateTask = useCelebrateTask();
  const refresh = () => { qc.invalidateQueries({ queryKey: ['tasks'] }); qc.invalidateQueries({ queryKey: ['task'] }); qc.invalidateQueries({ queryKey: ['notifications'] }); };
  const create = useMutation({ mutationFn: (i: TaskInput) => api.tasks.create(i, user as Profile), onSuccess: () => { refresh(); toast.success('Task created.'); }, onError: (e: Error) => toast.error(e.message) });
  const update = useMutation({
    mutationFn: ({ id, patch }: { id: string; patch: Partial<Task>; before?: Task; note?: string }) => api.tasks.update(id, patch, user as Profile),
    onSuccess: (t, v) => {
      refresh();
      if (t.status === 'Completed' && v.before?.status !== 'Completed') { toast.success('Task completed.'); celebrateTask(t); }
      else toast.success(v.note ?? 'Task updated.');
    },
    onError: (e: Error) => toast.error(e.message),
  });
  const comment = useMutation({
    mutationFn: ({ id, body }: { id: string; body: string }) => api.tasks.addComment(id, body, user as Profile),
    onSuccess: (_c, v) => { qc.invalidateQueries({ queryKey: ['task', 'comments', v.id] }); },
    onError: (e: Error) => toast.error(e.message),
  });
  return { create, update, comment };
}

export type { Client };

/** Admin-configurable setting stored in app_settings (jsonb). Anyone signed in can read; only admins can save. */
export function useSetting<T>(key: string, fallback: T, normalize?: (raw: unknown) => T) {
  const qc = useQueryClient();
  const { user } = useAuth();
  const toast = useToast();
  const q = useQuery({ queryKey: ['settings', key], enabled: !!user, queryFn: async () => { const raw = await api.settings.get<unknown>(key); return raw == null ? fallback : normalize ? normalize(raw) : (raw as T); } });
  const save = useMutation({
    mutationFn: (v: T) => api.settings.set(key, v, user as Profile),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['settings', key] }); toast.success('Settings saved.'); },
    onError: (e: Error) => toast.error(e.message),
  });
  return { value: q.data ?? fallback, loading: !!user && q.isLoading, save, canEdit: user?.team === 'admin' };
}

// ───────── customization studio ─────────
export const useCustomModules = () => useQuery({ queryKey: ['custom-modules'], queryFn: () => api.customModules.list(), enabled: true });
export const useCustomFieldDefs = () => useQuery({ queryKey: ['custom-fields'], queryFn: () => api.customFields.list() });
export const usePermissions = () => useQuery({ queryKey: ['permissions'], queryFn: () => api.permissions.list() });

export interface DashboardLayout { hidden: string[]; order: Record<string, string[]> }
export const DEFAULT_LAYOUT: DashboardLayout = { hidden: [], order: {} };
export const normalizeLayout = (r: unknown): DashboardLayout => {
  const o = (r ?? {}) as Partial<DashboardLayout>;
  return { hidden: Array.isArray(o.hidden) ? o.hidden.filter((x) => typeof x === 'string') : [], order: o.order && typeof o.order === 'object' ? o.order : {} };
};
export const useDashboardLayout = () => useSetting<DashboardLayout>('dashboard_layout', DEFAULT_LAYOUT, normalizeLayout);

/** Built-in modules plus the registers built in the Studio that the signed-in team may open (admins see everything non-archived). */
export function useAvailableModules(team: Team | undefined) {
  const custom = useCustomModules().data;
  const perms = usePermissions().data;
  return useMemo(() => {
    if (!team) return [] as ModuleDef[];
    const pm = toPermMap(perms ?? []);
    const customDefs = (custom ?? []).filter((c) => !c.archived).map(moduleFromCustom);
    const all = [...MODULES.filter((m) => !m.readonly || m.key === 'user-log'), ...customDefs];
    return all.filter((m) => team === 'admin' || levelFor(team, m, pm) !== 'none');
  }, [team, custom, perms]);
}

/** A module with admin-added custom fields and the admin-chosen table columns applied. */
export function useModuleDef(m: ModuleDef): ModuleDef {
  const defs = useCustomFieldDefs().data;
  const cols = useSetting<Record<string, string[]>>('table_columns', {}).value;
  return useMemo(() => {
    const merged = withCustomFields(m, defs);
    const chosen = cols[m.key]?.filter((k) => merged.fields.some((f) => f.key === k) || merged.derived.some((d) => d.key === k));
    return chosen?.length ? { ...merged, list: chosen } : merged;
  }, [m, defs, cols]);
}

/** URL paths of other teams' modules this team may open (admin-granted), for the client-side route guard. */
export function useGrantedPaths(team: Team | undefined) {
  const perms = usePermissions();
  const mods = useAvailableModules(team);
  const paths = useMemo(() => (team && team !== 'admin' ? mods.filter((m) => m.team !== team).map((m) => modulePath(m)) : []), [team, mods]);
  return { paths, loading: !!team && perms.isLoading };
}
