import clsx, { type ClassValue } from 'clsx';

export const cn = (...v: ClassValue[]) => clsx(v);

export const uid = () =>
  typeof crypto !== 'undefined' && 'randomUUID' in crypto ? crypto.randomUUID() : 'id-' + Math.random().toString(36).slice(2) + Date.now().toString(36);

/** Local-date ISO (yyyy-mm-dd), not UTC, so "today" matches the user's wall clock. */
export const isoDate = (d: Date = new Date()) => {
  const z = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
  return z.toISOString().slice(0, 10);
};
export const todayISO = () => isoDate();
export const addDays = (days: number, from: Date = new Date()) => {
  const d = new Date(from);
  d.setDate(d.getDate() + days);
  return isoDate(d);
};
export const daysBetween = (aISO: string, bISO: string) =>
  Math.round((new Date(aISO + 'T00:00:00').getTime() - new Date(bISO + 'T00:00:00').getTime()) / 86400000);
export const daysUntil = (iso: string) => daysBetween(iso, todayISO());

export const fmtDate = (iso?: string | null) =>
  iso ? new Date(iso.length === 10 ? iso + 'T00:00:00' : iso).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';
export const fmtTime = (iso: string) => new Date(iso).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
export const fmtNumber = (n: unknown) => (typeof n === 'number' ? n.toLocaleString('en-IN') : n == null || n === '' ? '—' : String(n));
export const pct = (a: number, b: number) => (b ? Math.round((a / b) * 100) : 0);

export function greeting() {
  const h = new Date().getHours();
  return h < 12 ? 'Good Morning' : h < 17 ? 'Good Afternoon' : 'Good Evening';
}

export function hash(str: string) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

export const initials = (name: string) =>
  name
    .split(/\s+/)
    .map((s) => s[0])
    .slice(0, 2)
    .join('')
    .toUpperCase();

/**
 * Expiry classification used by every expiry module. The alert schedule (days before expiry) is configurable by an admin
 * (Settings, key "expiry_alert_days") and applied app-wide through setAlertDays().
 */
export type ExpiryTier = string; // 'expired' | 'ok' | `d${days}`
export const DEFAULT_ALERT_DAYS = [90, 60, 30, 14, 7, 1];
let ALERT_DAYS = [...DEFAULT_ALERT_DAYS];
export const getAlertDays = () => ALERT_DAYS;
export function normalizeAlertDays(v: unknown): number[] {
  const list = Array.isArray(v) ? v : [];
  const out = [...new Set(list.map(Number).filter((n) => Number.isInteger(n) && n >= 0 && n <= 730))].sort((a, b) => b - a);
  return out.length ? out : [...DEFAULT_ALERT_DAYS];
}
export const setAlertDays = (v: unknown) => { ALERT_DAYS = normalizeAlertDays(v); };
export const tierOrder = (): ExpiryTier[] => ['expired', ...[...ALERT_DAYS].sort((a, b) => a - b).map((d) => `d${d}`), 'ok'];

export function expiryInfo(iso?: string | null) {
  if (!iso) return null;
  const days = daysUntil(iso);
  const asc = [...ALERT_DAYS].sort((a, b) => a - b);
  const hit = asc.find((t) => days <= t);
  const tier: ExpiryTier = days < 0 ? 'expired' : hit !== undefined ? `d${hit}` : 'ok';
  const health = days < 0 ? 'Expired' : days <= 15 ? 'Critical' : days <= 60 ? 'Warning' : 'Healthy';
  return { days, tier, health: health as 'Healthy' | 'Warning' | 'Critical' | 'Expired' };
}
