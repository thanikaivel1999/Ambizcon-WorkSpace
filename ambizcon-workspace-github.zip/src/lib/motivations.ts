import type { Motivation, Team } from './types';
import { hash } from './utils';

const RAW: Record<'all' | Team, string[]> = {
  all: [
    'Small progress every day creates remarkable results.',
    'Great teams are built one honest conversation at a time.',
    'Done well beats done fast — and done well, fast beats both.',
    'Today is a fresh page. Write something you will be proud of.',
    'Consistency turns ordinary effort into extraordinary outcomes.',
    'Beyond marketing, beyond healthcare — we deliver beyond expectations.',
    'Every task completed is a promise kept to a client.',
    'Help someone on your team today. It always comes back.',
    'Focus on the next right step, not the whole staircase.',
    'Quality is a habit, not an accident.',
    'Clarity first, speed second, excellence always.',
    'Your work helps healthcare brands reach the people who need them.',
    'Celebrate the small wins; they build the big ones.',
    'Ask, learn, improve, repeat.',
    'A calm mind finishes more than a rushed one.',
    'Ownership is the quiet superpower of great teams.',
    'Make it clear, make it useful, make it count.',
    'The best way to predict tomorrow is to finish today well.',
    'Trust the process, respect the deadline.',
    'Together we ship what alone we only imagine.',
  ],
  development: [
    'Clean code today saves a long night tomorrow.',
    'Every bug fixed makes the web a little better.',
    'Consistency in commits is consistency in craft.',
    'Break the problem down until it becomes obvious.',
    'A fast, secure website is the best first impression a client can get.',
    'Read the error message — it is usually trying to help.',
    'Backups are boring until the day they are everything.',
    'Learn one new thing about your tools today.',
    'Ship small, test often, sleep well.',
    'Great developers make hard things look simple.',
    'Monitor the quiet sites too; silence is not safety.',
    'Quality is writing the test before the apology.',
    'Technology is only as good as the people it serves.',
    'Curiosity is the best debugging tool you own.',
    'Performance is a feature your clients feel but never see.',
    'Document it today and thank yourself next quarter.',
    'Renew early, worry never.',
    'Solve the root cause, not the symptom.',
    'Secure by default, resilient by design.',
    'Every green check on the daily list is trust earned.',
  ],
  marketing: [
    'Growth is the sum of a thousand consistent posts.',
    'Know your audience and the message writes itself.',
    'Strategy gives the work direction; consistency gives it power.',
    'Great communication turns attention into trust.',
    'Measure what matters, then improve what you measure.',
    'Behind every click is a person with a need.',
    'A well-timed email can change someone’s whole day.',
    'Creativity attracts. Strategy converts.',
    'Be useful before you are promotional.',
    'Your campaign is a conversation — listen to the replies.',
    'Data tells you what happened; empathy tells you why.',
    'Show up every day and the audience will notice.',
    'Healthcare marketing is about care first, clicks second.',
    'The best headline is the one that respects the reader.',
    'Test, learn, scale.',
    'Community is built in the comments, not the broadcast.',
    'One clear message beats five clever ones.',
    'Grow with your audience, not at them.',
    'A schedule kept is a brand strengthened.',
    'Every campaign is a chance to learn something new about people.',
  ],
  creative: [
    'Imagination is the first draft of every great design.',
    'Good design is invisible; great design is unforgettable.',
    'Tell the story with pictures and the words will follow.',
    'Originality begins where inspiration meets practice.',
    'Every blank canvas is an invitation.',
    'Simplicity is the ultimate sophistication in design.',
    'Make something today that did not exist yesterday.',
    'Constraints are the secret fuel of creativity.',
    'A frame, a colour, a feeling — that is all a story needs.',
    'Details turn good visuals into trusted brands.',
    'Look at the world like a designer; find beauty in structure.',
    'Iterate bravely; the third version is usually the one.',
    'Your art helps people understand care at a glance.',
    'Visual storytelling turns messages into memories.',
    'Be original, be consistent, be kind to the brief.',
    'Colour carries emotion before a word is read.',
    'Rhythm in motion, clarity in layout.',
    'Great creative work is a team sport.',
    'Trust your eye, then test with the audience.',
    'Create with purpose and the polish takes care of itself.',
  ],
  admin: [
    'Leadership is making your team successful and then stepping aside.',
    'Plan the week, protect the priorities, praise the progress.',
    'Clear goals turn busy teams into effective ones.',
    'A team that feels trusted does its best work.',
    'Progress is visible when you look for it. Look today.',
    'Collaboration across teams is where the biggest wins hide.',
    'Remove blockers and the team will move mountains.',
    'Great leaders ask better questions.',
    'Recognise effort publicly, correct privately.',
    'What gets reviewed gets improved.',
    'Delegate outcomes, not tasks.',
    'Alignment is cheaper than rework.',
    'Your steadiness sets the pace for everyone.',
    'Plan for expiry dates the way you plan for growth.',
    'Teamwork turns deadlines into milestones.',
    'Look at the whole board before moving a single piece.',
    'Make time to listen; the answers are already in the room.',
    'Momentum is built from finished work, not busy work.',
    'Culture is what the team does when nobody is watching.',
    'Lead with clarity, decide with data, close with gratitude.',
  ],
};

export const CHARACTER_FOR: Record<'all' | Team, string> = { all: 'admin', development: 'development', marketing: 'marketing', creative: 'creative', admin: 'admin' };

export const MOTIVATIONS: Motivation[] = (Object.keys(RAW) as ('all' | Team)[]).flatMap((team) =>
  RAW[team].map((message, i) => ({
    id: `mot-${team}-${String(i + 1).padStart(2, '0')}`,
    message,
    team,
    date: null,
    image: CHARACTER_FOR[team],
    active: true,
  })),
);

export interface ShownEntry {
  motivation_id: string;
  shown_on: string;
}

/**
 * Rotation:
 *  1. a message scheduled for today for this team wins,
 *  2. if today's pick was already shown, reuse it (one slogan per day),
 *  3. otherwise choose among team + all-team messages, skipping anything shown recently
 *     (the whole pool is cycled before any message repeats),
 *  4. the caller saves the pick so tomorrow's differs.
 */
export function pickMotivation(all: Motivation[], team: Team, shown: ShownEntry[], today: string, userId: string): Motivation | null {
  const active = all.filter((m) => m.active);
  const shownToday = shown.find((s) => s.shown_on === today);
  if (shownToday) {
    const prior = active.find((m) => m.id === shownToday.motivation_id);
    if (prior) return prior;
  }
  const scheduled = active.find((m) => m.date === today && (m.team === team || m.team === 'all'));
  if (scheduled) return scheduled;
  const pool = active.filter((m) => !m.date && (m.team === team || m.team === 'all'));
  if (!pool.length) return null;
  const seen = new Set(shown.map((s) => s.motivation_id));
  let fresh = pool.filter((m) => !seen.has(m.id));
  if (!fresh.length) {
    // pool exhausted: only exclude the most recent third so repeats are far apart
    const recent = new Set([...shown].sort((a, b) => b.shown_on.localeCompare(a.shown_on)).slice(0, Math.floor(pool.length / 3)).map((s) => s.motivation_id));
    fresh = pool.filter((m) => !recent.has(m.id));
  }
  // team-specific messages are preferred ~2:1 over generic ones
  const teamOnly = fresh.filter((m) => m.team === team);
  const candidates = teamOnly.length && hash(today + userId) % 3 !== 0 ? teamOnly : fresh;
  return candidates[hash(today + userId + team) % candidates.length];
}
