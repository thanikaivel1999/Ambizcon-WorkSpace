export type Team = 'development' | 'marketing' | 'creative' | 'admin';
export type WorkTeam = Exclude<Team, 'admin'>;
export type UserRole = 'admin' | 'lead' | 'member';

export const STATUSES = ['Pending', 'In Progress', 'Completed', 'On Hold', 'Overdue', 'Cancelled'] as const;
export type Status = (typeof STATUSES)[number];
export const PRIORITIES = ['Low', 'Medium', 'High', 'Urgent'] as const;
export type Priority = (typeof PRIORITIES)[number];

export interface Profile {
  id: string;
  name: string;
  email: string;
  team: Team;
  role: UserRole;
  status: 'active' | 'disabled';
  avatar_url: string | null;
  last_login: string | null;
  created_at: string;
}

export const CLIENT_TYPES = ['Specialist', 'General Practitioner'] as const;
export type ClientType = (typeof CLIENT_TYPES)[number];
export const CLIENT_STATUSES = ['active', 'inactive', 'archived'] as const;
export type ClientStatus = (typeof CLIENT_STATUSES)[number];

/** One shared client record used by every team (no per-team copies). */
export interface Client {
  id: string;
  name: string;
  client_type: ClientType;
  joined_on: string | null;
  md_name: string | null;
  location: string | null;
  category: string | null;
  website: string | null;
  status: ClientStatus;
  notes: string | null;
  /** Team members assigned to this client (profile ids). */
  assigned_ids: string[];
  created_at?: string;
}
export type ClientInput = Omit<Client, 'id' | 'created_at'>;

export type Rec = { id: string; created_at: string; updated_at: string; created_by: string | null; updated_by: string | null } & Record<string, any>;

export interface Activity {
  id: string;
  module: string;
  record_id: string;
  user_id: string | null;
  user_name?: string;
  record_title?: string;
  action: string;
  detail: string;
  created_at: string;
}

export interface AppNotification {
  id: string;
  user_id: string | null;
  team: Team | null; // broadcast to a team when user_id is null
  title: string;
  body: string;
  kind: 'expiry' | 'due' | 'overdue' | 'creative' | 'marketing' | 'completed' | 'admin' | 'priority' | 'check';
  link: string | null;
  read: boolean;
  created_at: string;
}

export interface Motivation {
  id: string;
  message: string;
  team: 'all' | Team;
  date: string | null;
  image: string | null;
  active: boolean;
}

// ───────── global tasks ─────────
export const TASK_STATUSES = ['New', 'Assigned', 'In Progress', 'On Hold', 'Submitted for Review', 'Changes Requested', 'Approved', 'Completed', 'Cancelled'] as const;
export type TaskStatus = (typeof TASK_STATUSES)[number];
export const REVIEW_STATUSES = ['None', 'Requested', 'Approved', 'Changes Requested'] as const;
export type ReviewStatus = (typeof REVIEW_STATUSES)[number];

export interface Task {
  id: string;
  title: string;
  description: string | null;
  client_id: string | null;
  team: WorkTeam;
  assigned_to: string | null;
  created_by: string | null;
  reviewer_id: string | null;
  priority: Priority;
  status: TaskStatus;
  review_status: ReviewStatus;
  /** 1–5 quality rating recorded by the reviewer on approval; null = not reviewed (never treated as 0). */
  review_rating: number | null;
  date_assigned: string | null;
  due_date: string | null;
  output_link: string | null;
  thumbnail: string | null;
  remarks: string | null;
  completed_at: string | null;
  created_at: string;
  updated_at: string;
}
export type TaskInput = Partial<Omit<Task, 'id' | 'created_at' | 'updated_at' | 'completed_at' | 'created_by'>> & { title: string; team: WorkTeam };

export interface TaskComment {
  id: string;
  task_id: string;
  user_id: string | null;
  user_name?: string;
  body: string;
  created_at: string;
}
export interface TaskEvent {
  id: string;
  task_id: string;
  user_id: string | null;
  user_name?: string;
  action: string;
  detail: string;
  created_at: string;
}

// ───────── customization studio ─────────
export const PERM_LEVELS = ['none', 'read', 'write'] as const;
export type PermLevel = (typeof PERM_LEVELS)[number];
export interface ModulePerm { team: WorkTeam; module_key: string; level: PermLevel }

export const CUSTOM_FIELD_TYPES = ['text', 'longtext', 'number', 'date', 'url', 'select', 'bool', 'file', 'client', 'user'] as const;
export type CustomFieldType = (typeof CUSTOM_FIELD_TYPES)[number];
export interface CustomFieldSpec { key: string; label: string; type: CustomFieldType; options?: string[]; required?: boolean }
export interface CustomModule { id: string; slug: string; title: string; team: WorkTeam; icon: string; blurb: string; fields: CustomFieldSpec[]; archived: boolean; created_at: string }
export type CustomModuleInput = Omit<CustomModule, 'id' | 'created_at'> & { id?: string };
export interface CustomFieldDef extends CustomFieldSpec { id: string; module_key: string; position: number; archived: boolean }
export type CustomFieldInput = Omit<CustomFieldDef, 'id'> & { id?: string };
