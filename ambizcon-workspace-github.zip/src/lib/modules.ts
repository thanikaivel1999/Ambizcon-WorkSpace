import { PRIORITIES, STATUSES, type Status, type WorkTeam } from './types';

export type FieldType =
  | 'text' | 'longtext' | 'number' | 'date' | 'time' | 'select' | 'user' | 'client'
  | 'bool' | 'url' | 'image' | 'check' | 'expiry' | 'file';

export interface Field {
  key: string;
  label: string;
  type: FieldType;
  options?: readonly string[];
  required?: boolean;
  money?: boolean;
  suffix?: string;
  /** Force into / out of the table columns (default: automatic). */
  list?: boolean;
  /** Not editable in the form (system-populated). */
  system?: boolean;
}

export interface Derived {
  key: string;
  label: string;
  fmt: 'pct' | 'money' | 'num' | 'text';
  fn: (r: Record<string, any>) => number | string;
}

export type Anim = 'ssl' | 'backup' | 'video' | 'web' | 'artwork' | 'seo' | 'marketing' | 'celebrate';
export type ExtraKey =
  | 'mailer-charts' | 'ads-chart' | 'analytics-charts' | 'calendar' | 'youtube-stats'
  | 'daily-check' | 'community-stats' | 'creative-stats' | 'backup-latest' | 'perf-compare' | 'blog-stats';

export interface ModuleDef {
  key: string;
  team: WorkTeam;
  slug: string;
  title: string;
  nav: string;
  table: string;
  icon: string;
  blurb: string;
  titleField: string;
  fields: Field[];
  derived: Derived[];
  dueField?: string;
  /** Primary expiry date (drives summaries and alerts). Every field of type 'expiry' is tracked by the Expiry Management page. */
  expiryField?: string;
  /** A custom field that acts as the record status (e.g. YouTube upload status). */
  statusField: string;
  statusLabel: string;
  statusMap?: Record<string, Status>;
  hasPriority: boolean;
  anim: Anim;
  readonly?: boolean;
  extra?: ExtraKey;
  yearField?: string;
  /** Preferred table columns; otherwise chosen automatically. */
  list?: string[];
  /** Record-creation source (creative modules accept requests from marketing). */
  acceptsRequests?: boolean;
  /** 'brief' modules are the nine client brand-brief sections: reachable from /creative/client-briefs, not from the sidebar. */
  group?: 'brief' | 'target';
  /** Set for modules built in the Customization Studio (rows live in custom_records). */
  customId?: string;
  /** Completion needs reviewer approval first (review_status = Approved) whenever a reviewer is set. */
  reviewFlow?: boolean;
  /** Shown in the record form: where secrets belong instead of in this module. */
  secretNote?: string;
  /** Cross-field validation: returns field-key → message. */
  rules?: (v: Record<string, any>) => Record<string, string | undefined>;
  /** Extra fields written when the status changes (e.g. verified-by). */
  onStatus?: (next: string, actorId: string, today: string) => Record<string, unknown>;
  /** Block a status change with a message (e.g. verifying a backup that has no link). */
  canSetStatus?: (rec: Record<string, any>, next: string) => string | null;
}

// ---- field helpers ----
const t = (key: string, label: string, o: Partial<Field> = {}): Field => ({ key, label, type: 'text', ...o });
const lt = (key: string, label: string, o: Partial<Field> = {}): Field => ({ key, label, type: 'longtext', ...o });
const n = (key: string, label: string, o: Partial<Field> = {}): Field => ({ key, label, type: 'number', ...o });
const d = (key: string, label: string, o: Partial<Field> = {}): Field => ({ key, label, type: 'date', ...o });
const s = (key: string, label: string, options: readonly string[], o: Partial<Field> = {}): Field => ({ key, label, type: 'select', options, ...o });
const u = (key: string, label: string, o: Partial<Field> = {}): Field => ({ key, label, type: 'user', ...o });
const c = (label = 'Client'): Field => ({ key: 'client_id', label, type: 'client' });
const url = (key: string, label: string): Field => ({ key, label, type: 'url' });
const b = (key: string, label: string): Field => ({ key, label, type: 'bool' });
const chk = (key: string, label: string): Field => ({ key, label, type: 'check', options: ['Pass', 'Warning', 'Fail'] });
const img = (key: string, label: string): Field => ({ key, label, type: 'image' });
const exp = (key: string, label: string): Field => ({ key, label, type: 'expiry', required: true });
const expOpt = (key: string, label: string): Field => ({ key, label, type: 'expiry' });

export const MONTH_NAMES = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'] as const;
export const DATE_CONFIDENCE = ['Confirmed', 'Estimated', 'Unknown'] as const;
export const CREATIVE_STATUSES = ['New', 'Assigned', 'In Progress', 'On Hold', 'Submitted for Review', 'Changes Requested', 'Approved', 'Completed'] as const;
export const REVIEW_OPTIONS = ['Not reviewed', 'In review', 'Approved', 'Changes requested'] as const;
export const DAILY_CHECKS: readonly [string, string][] = [
  ['loads', 'Website loads'], ['homepage', 'Homepage'], ['pages', 'Important pages'], ['forms', 'Forms'], ['mobile', 'Mobile'], ['ssl', 'SSL'],
  ['links', 'Broken links'], ['speed', 'Performance'], ['backup', 'Backup status'], ['security', 'Security / error alerts'],
];

type Std = 'full' | 'min' | 'none';
type Input = Partial<ModuleDef> & Pick<ModuleDef, 'key' | 'team' | 'slug' | 'title' | 'nav' | 'table' | 'icon' | 'blurb' | 'titleField'> & {
  fields: Field[];
  std?: Std;
  statusLabel?: string;
};

function def(m: Input): ModuleDef {
  const std = m.std ?? 'full';
  const fields = [...m.fields];
  const has = (k: string) => fields.some((f) => f.key === k);
  let dueField = m.dueField;
  const statusField = m.statusField ?? 'status';
  const hasPriority = m.hasPriority ?? std === 'full';
  if (std === 'full') {
    if (!has('assigned_to')) fields.push(u('assigned_to', 'Assigned To'));
    if (!dueField) {
      dueField = 'due_date';
      if (!has('due_date')) fields.push(d('due_date', 'Due Date'));
    }
  }
  if (hasPriority && !has('priority')) fields.push(s('priority', 'Priority', PRIORITIES));
  if (statusField === 'status' && std !== 'none' && !has('status')) fields.push(s('status', m.statusLabel ?? 'Status', STATUSES, { required: true }));
  // every register that tracks an expiry date also records how reliable that date is, where to renew and when it was last verified
  if (fields.some((f) => f.type === 'expiry')) {
    if (!has('date_confidence')) fields.push(s('date_confidence', 'Date confidence', DATE_CONFIDENCE));
    if (!has('renewal_url')) fields.push(url('renewal_url', 'Renewal link'));
    if (!has('last_verified')) fields.push(d('last_verified', 'Last verified'));
  }
  if (!has('remark') && !m.readonly) fields.push(lt('remark', 'Notes'));
  return {
    derived: [],
    anim: 'celebrate',
    ...m,
    fields,
    dueField,
    statusField,
    statusLabel: m.statusLabel ?? 'Status',
    hasPriority,
  } as ModuleDef;
}

const RENEWAL = { statusLabel: 'Renewal Status' };
const VAULT_NOTE = 'Passwords, recovery codes and API keys are never stored in this module. Keep credentials in the company password vault and record only a reference to the entry here.';
const ratio = (a: unknown, bb: unknown): number | string => (typeof a === 'number' && typeof bb === 'number' && bb > 0 ? (a / bb) * 100 : '—');
const safeDiv = (a: unknown, bb: unknown): number | string => (typeof a === 'number' && typeof bb === 'number' && bb > 0 ? a / bb : '—');

export const MODULES: ModuleDef[] = [
  // ───────── Development ─────────
  def({
    key: 'backups', team: 'development', slug: 'backups', title: 'Website Backups', nav: 'Website Backups', table: 'website_backups', icon: 'DatabaseBackup', extra: 'backup-latest',
    blurb: 'One record per backup. A link alone does not make a backup good: mark it Verified only after you have opened and checked it.', titleField: 'website', dueField: 'next_backup_date', anim: 'backup',
    statusField: 'verification', statusLabel: 'Verification', statusMap: { Unverified: 'Pending', Verified: 'Completed', Failed: 'Overdue' }, hasPriority: false,
    fields: [c(), t('website', 'Website name', { required: true }), url('website_url', 'Website URL'), d('backup_date', 'Backup date', { required: true }), s('backup_type', 'Backup type', ['Full', 'Database', 'Files', 'Other']),
      url('backup_link', 'Google Drive backup link'), s('verification', 'Verification', ['Unverified', 'Verified', 'Failed'], { required: true }), u('verified_by', 'Verified by', { system: true }),
      d('link_verified_on', 'Link last verified', { system: true }), d('next_backup_date', 'Next scheduled backup', { required: true }), u('assigned_to', 'Uploaded by')],
    list: ['website', 'client_id', 'backup_date', 'backup_type', 'backup_link', 'verification', 'next_backup_date', 'assigned_to'],
    rules: (v) => (v.verification === 'Verified' && !v.backup_link ? { backup_link: 'Add the Google Drive link before marking the backup Verified' } : {}),
    onStatus: (next, actor, today) => (next === 'Verified' ? { verified_by: actor, link_verified_on: today } : { verified_by: null, link_verified_on: null }),
    canSetStatus: (rec, next) => (next === 'Verified' && !rec.backup_link ? 'Add the backup link first: a backup cannot be verified without one.' : null),
  }),
  def({
    key: 'performance', team: 'development', slug: 'website-performance', title: 'Website Performance', nav: 'Performance', table: 'website_performance', icon: 'Gauge', extra: 'perf-compare', std: 'none', statusField: '', hasPriority: false,
    blurb: 'Monthly traffic and search results per website, with month-over-month and year-over-year comparison. Entered manually until analytics APIs are connected.', titleField: 'website', yearField: 'report_year',
    fields: [c(), t('website', 'Website', { required: true }), s('report_month', 'Reporting month', MONTH_NAMES, { required: true }), n('report_year', 'Reporting year', { required: true }), n('sessions', 'Sessions'), n('users', 'Users'),
      n('page_views', 'Page views'), n('engagement_rate', 'Engagement rate', { suffix: '%' }), n('conversions', 'Conversions'), n('organic_clicks', 'Organic clicks'), n('organic_impressions', 'Organic impressions'),
      n('avg_position', 'Average search position'), n('desktop_score', 'Web performance score', { suffix: '/100' }), n('mobile_score', 'Mobile performance score', { suffix: '/100' }), n('seo_score', 'SEO score', { suffix: '/100' }), n('best_practices_score', 'Best practices score', { suffix: '/100' }), n('accessibility_score', 'Accessibility score', { suffix: '/100' }), s('data_source', 'Source of data', ['Manual entry', 'GA4 export', 'Search Console export', 'Other report']), url('report_link', 'Report link'), u('assigned_to', 'Updated by')],
    derived: [{ key: 'period', label: 'Period', fmt: 'text', fn: (r) => (r.report_month && r.report_year ? `${String(r.report_month).slice(0, 3)} ${r.report_year}` : '—') }],
    list: ['website', 'client_id', 'period', 'desktop_score', 'mobile_score', 'seo_score', 'best_practices_score', 'accessibility_score', 'sessions', 'data_source'],
  }),
  def({
    key: 'seo', team: 'development', slug: 'seo-updates', title: 'Website SEO Updates', nav: 'SEO Updates', table: 'seo_updates', icon: 'SearchCheck',
    blurb: 'Page-level and site-level SEO work: titles, meta, headings, schema and indexing, with evidence.', titleField: 'title', anim: 'seo',
    fields: [c(), t('website', 'Website', { required: true }), url('page_url', 'Page URL'), s('seo_type', 'SEO task type', ['On-Page', 'Technical', 'Off-Page', 'Local SEO', 'Schema', 'Indexing']),
      t('title', 'Update title', { required: true }), t('keyword', 'Focus keyword'), t('meta_title', 'SEO title'), lt('meta_description', 'Meta description'), lt('heading_updates', 'Heading updates'),
      lt('image_alt', 'Image alt text'), lt('internal_links', 'Internal links'), lt('schema_changes', 'Schema / technical SEO changes'),
      s('indexing_status', 'Sitemap / indexing status', ['Not submitted', 'Submitted', 'Indexed', 'Not indexed']), d('date_assigned', 'Date assigned'), d('completion_date', 'Completion date', { system: true }),
      url('output_link', 'Evidence / output link')],
    list: ['title', 'website', 'client_id', 'seo_type', 'keyword', 'indexing_status', 'due_date', 'assigned_to'],
  }),
  def({
    key: 'blogs', team: 'development', slug: 'blogs', title: 'Blog Updates', nav: 'Blog Updates', table: 'blog_updates', icon: 'Newspaper', extra: 'blog-stats',
    blurb: 'Blog posts per client website. Only posts that are marked Published, verified and dated count as published.', titleField: 'blog_title', hasPriority: false,
    statusField: 'blog_status', statusLabel: 'Blog status', statusMap: { Planned: 'Pending', Drafting: 'In Progress', Review: 'In Progress', Published: 'Completed', Cancelled: 'Cancelled' },
    fields: [c(), t('website', 'Website'), t('blog_title', 'Blog title', { required: true }), url('blog_url', 'Blog URL'), t('category', 'Category'), u('assigned_to', 'Assigned writer / developer'),
      d('date_assigned', 'Date assigned'), d('draft_date', 'Draft date'), d('published_date', 'Publication date'), s('blog_status', 'Status', ['Planned', 'Drafting', 'Review', 'Published', 'Cancelled'], { required: true }),
      b('publish_verified', 'Publication verified'), url('output_link', 'Output link')],
    list: ['blog_title', 'client_id', 'website', 'category', 'blog_status', 'published_date', 'assigned_to'],
    rules: (v) => (v.blog_status === 'Published' && !v.published_date ? { published_date: 'Enter the publication date for a published blog' } : {}),
  }),
  def({
    key: 'website-expiry', team: 'development', slug: 'domain-expiry', title: 'Website Expiry', nav: 'Domain Expiry', table: 'website_expiry', icon: 'CalendarClock', ...RENEWAL,
    blurb: 'Domain registration and hosting expiry are tracked separately, each with automatic days-remaining.', titleField: 'domain', expiryField: 'expiry_date', hasPriority: false,
    fields: [c(), t('domain', 'Domain', { required: true }), t('website', 'Website'), t('registrar', 'Domain registrar'), exp('expiry_date', 'Domain registration expiry'), expOpt('hosting_expiry', 'Hosting expiry'),
      t('hosting_provider', 'Hosting provider'), u('assigned_to', 'Responsible employee')],
    list: ['domain', 'client_id', 'registrar', 'expiry_date', 'hosting_expiry', 'assigned_to'],
  }),
  def({
    key: 'ssl-expiry', team: 'development', slug: 'ssl-expiry', title: 'Website SSL Expiry', nav: 'SSL Expiry', table: 'ssl_expiry', icon: 'ShieldCheck', ...RENEWAL, anim: 'ssl',
    blurb: 'SSL certificates with expiry alerts. Record how each check was made: a manual check is not an automated one.', titleField: 'website', expiryField: 'ssl_expiry_date', hasPriority: false,
    fields: [c(), t('website', 'Website URL', { required: true }), s('ssl_provider', 'SSL provider', ["Let's Encrypt", 'Cloudflare', 'GoDaddy', 'DigiCert', 'Sectigo']), exp('ssl_expiry_date', 'Certificate expiry'),
      s('certificate_status', 'Certificate status', ['Valid', 'Expiring soon', 'Expired', 'Unknown']), d('last_checked', 'Last checked'), s('check_method', 'Check method', ['Manual verification', 'Automated check']),
      u('assigned_to', 'Responsible employee')],
    list: ['website', 'client_id', 'ssl_provider', 'ssl_expiry_date', 'certificate_status', 'check_method', 'assigned_to'],
  }),
  def({
    key: 'user-log', team: 'development', slug: 'user-logs', title: 'User Log', nav: 'User Log', table: 'user_logs', icon: 'ScrollText', std: 'none', readonly: true,
    blurb: 'Automatic audit trail of important actions. Entries cannot be edited or deleted.', titleField: 'description', hasPriority: false, statusField: '',
    fields: [t('user_name', 'User'), t('action', 'Action'), t('module_name', 'Record type'), t('record_title', 'Record'), t('log_date', 'Date'), t('log_time', 'Time'), t('ip', 'IP'),
      t('description', 'Change summary')],
    list: ['user_name', 'action', 'module_name', 'record_title', 'log_date', 'log_time', 'ip'],
  }),
  def({
    key: 'daily-check', team: 'development', slug: 'daily-checks', title: 'Daily Website Check', nav: 'Daily Website Check', table: 'daily_website_checks', icon: 'ListChecks', extra: 'daily-check', statusLabel: 'Overall status',
    blurb: "Today's checklist for every website: loads, key pages, forms, mobile, SSL, links, speed, backups and alerts.", titleField: 'website', dueField: 'check_date',
    fields: [t('website', 'Website', { required: true }), c(), d('check_date', 'Check date', { required: true }), u('assigned_to', 'Assigned employee'), ...DAILY_CHECKS.map(([k, l]) => chk(k, l)),
      lt('issue_description', 'Issue description'), t('follow_up', 'Follow-up task'), url('evidence_link', 'Evidence link'), u('reviewed_by', 'Reviewed by')],
    list: ['website', 'client_id', 'check_date', 'assigned_to', 'homepage', 'forms', 'mobile', 'ssl', 'links', 'speed'],
  }),
  def({
    key: 'tools-expiry', team: 'development', slug: 'tools-expiry', title: 'Development Tools Expiry', nav: 'Tools Expiry', table: 'dev_tools_expiry', icon: 'Wrench', ...RENEWAL, hasPriority: false,
    blurb: 'Plugins, themes, development tools and business software with renewal dates and prices.', titleField: 'tool_name', expiryField: 'expiry_date',
    fields: [t('tool_name', 'Tool name', { required: true }), t('vendor', 'Vendor'), s('tool_type', 'Tool type', ['Hosting', 'Plugin', 'Theme', 'Design', 'Monitoring', 'Security', 'Productivity']),
      s('license_type', 'License type', ['Subscription', 'Annual', 'Monthly', 'One-time', 'Open source']), d('purchase_date', 'Purchase date'), exp('expiry_date', 'Expiration date'),
      n('cost', 'Renewal price', { money: true }), t('account_ref', 'Account / license reference (never a password)'), u('assigned_to', 'Responsible employee')],
    list: ['tool_name', 'vendor', 'tool_type', 'license_type', 'expiry_date', 'cost', 'assigned_to'],
  }),
  def({
    key: 'smtp-expiry', team: 'development', slug: 'smtp-expiry', title: 'SMTP Tools Expiry', nav: 'SMTP Expiry', table: 'smtp_tools_expiry', icon: 'Mail', ...RENEWAL, hasPriority: false, secretNote: VAULT_NOTE,
    blurb: 'SMTP services and licences with renewal dates, cost and the last email delivery test.', titleField: 'smtp_tool', expiryField: 'expiry_date',
    fields: [t('smtp_tool', 'Service name', { required: true }), t('provider', 'Provider'), c('Associated client'), t('website', 'Website'), t('plan', 'Plan'), exp('expiry_date', 'Expiry / renewal date'),
      n('cost', 'Cost', { money: true }), s('billing_cycle', 'Billing', ['Monthly', 'Yearly']), d('last_email_test', 'Last email test date'), s('delivery_status', 'Delivery status', ['Delivered', 'Delayed', 'Failing', 'Not tested']),
      u('assigned_to', 'Responsible employee')],
    list: ['smtp_tool', 'client_id', 'provider', 'plan', 'expiry_date', 'cost', 'delivery_status', 'assigned_to'],
  }),
  def({
    key: 'google-tracker', team: 'development', slug: 'google-tracker', title: 'Google Ads & Analytics Tracker', nav: 'Google Ads & Analytics', table: 'google_tracking', icon: 'Radar', secretNote: 'Never store Google account passwords here. Use OAuth connections for future integrations.',
    blurb: 'Setup, tag installation, event verification and conversion testing for each client, with outstanding issues.', titleField: 'website',
    fields: [c(), t('website', 'Website', { required: true }), t('ads_account_ref', 'Google Ads account reference'), t('analytics_property_ref', 'Analytics property reference'), t('gtm_container_ref', 'Tag Manager container reference'),
      b('account_setup', 'Account set up'), b('tag_installed', 'Tag installed'), b('events_verified', 'Events verified'), b('conversion_tested', 'Conversion tested'),
      s('tracking_status', 'Tracking status', ['Working', 'Partial', 'Not Working', 'Not Set']), s('conversion_status', 'Conversion tracking status', ['Working', 'Partial', 'Not Working', 'Not Set']),
      d('last_verified', 'Last verification date'), url('report_link', 'Report link'), lt('issues', 'Outstanding issues')],
    list: ['website', 'client_id', 'account_setup', 'tag_installed', 'events_verified', 'conversion_tested', 'tracking_status', 'last_verified', 'assigned_to'],
  }),
  def({
    key: 'domain-access', team: 'development', slug: 'domain-access', title: 'Domain Access', nav: 'Domain Access', table: 'domain_access', icon: 'KeyRound', ...RENEWAL, hasPriority: false, secretNote: VAULT_NOTE,
    blurb: 'Who holds access to which domain. Passwords and recovery codes are never stored or shown here.', titleField: 'domain', expiryField: 'expiry_date',
    fields: [c(), t('domain', 'Domain', { required: true }), t('registrar', 'Registrar'), exp('expiry_date', 'Domain expiry date'), t('account_owner', 'Account owner'), t('access_email', 'Access email'),
      s('access_status', 'Access status', ['Full Access', 'Partial', 'No Access', 'Requested']), s('two_factor', 'Two-factor authentication', ['Enabled', 'Not enabled', 'Unknown']),
      t('vault_ref', 'Password-manager entry reference (not the password)'), u('assigned_to', 'Assigned employee')],
    list: ['domain', 'client_id', 'registrar', 'account_owner', 'access_status', 'two_factor', 'expiry_date', 'assigned_to'],
  }),

  // ───────── Marketing ─────────
  def({
    key: 'spot-calendar', team: 'marketing', slug: 'content-calendar', title: 'Spot Calendar', nav: 'Content Calendar', table: 'spot_calendar', icon: 'CalendarDays', extra: 'calendar', std: 'min', anim: 'marketing', hasPriority: false,
    blurb: 'Monthly client content plan: month, week and list views. Drag a card to another day to reschedule.', titleField: 'content_title', dueField: 'content_date',
    statusField: 'calendar_status', statusLabel: 'Status',
    statusMap: { Planned: 'Pending', 'Brief Ready': 'Pending', 'Design in Progress': 'In Progress', Review: 'In Progress', Approved: 'In Progress', Scheduled: 'In Progress', Published: 'Completed', Cancelled: 'Cancelled' },
    fields: [c(), t('campaign', 'Campaign'), t('content_title', 'Content title', { required: true }), s('content_type', 'Content type', ['Blog', 'Post', 'Reel', 'Story', 'Carousel', 'Video', 'Mailer']),
      s('platform', 'Platform', ['Instagram', 'Facebook', 'LinkedIn', 'YouTube', 'X', 'Google Business', 'Website', 'Email']), u('assigned_to', 'Assigned employee'),
      d('content_date', 'Publish date', { required: true }), { key: 'publish_time', label: 'Publish time', type: 'time' },
      s('calendar_status', 'Status', ['Planned', 'Brief Ready', 'Design in Progress', 'Review', 'Approved', 'Scheduled', 'Published', 'Cancelled'], { required: true }),
      url('creative_link', 'Creative requirement link'), lt('caption', 'Caption'), url('output_link', 'Content output link')],
    derived: [{ key: 'month', label: 'Month', fmt: 'text', fn: (r) => (r.content_date ? new Date(r.content_date + 'T00:00:00').toLocaleString('en-GB', { month: 'long', year: 'numeric' }) : '—') }],
    list: ['content_title', 'client_id', 'campaign', 'content_date', 'content_type', 'platform', 'calendar_status', 'assigned_to'],
  }),
  def({
    key: 'mailer-reports', team: 'marketing', slug: 'mailer-reports', title: 'Mailer Data Reports', nav: 'Mailer Reports', table: 'mailer_reports', icon: 'MailCheck', extra: 'mailer-charts', std: 'min', statusField: '', hasPriority: false, anim: 'marketing',
    blurb: 'Campaign statistics. Counts are provider-reported; the rates are calculated here from those counts (delivery ÷ recipients, opens and clicks ÷ delivered).', titleField: 'campaign_name', dueField: 'send_date',
    fields: [c(), t('campaign_name', 'Campaign name', { required: true }), t('subject', 'Email subject'), d('send_date', 'Send date', { required: true }), t('provider', 'Provider'), url('report_url', 'Report URL'),
      s('metrics_source', 'Counts came from', ['Provider report (imported by hand)', 'Entered by hand']), n('total_recipients', 'Recipients'), n('delivered', 'Delivered'), n('bounced', 'Bounces'), n('opened', 'Opens'),
      n('unique_opens', 'Unique opens'), n('clicked', 'Clicks'), n('unique_clicks', 'Unique clicks'), n('unsubscribed', 'Unsubscribes'), n('spam_complaints', 'Spam complaints')],
    derived: [
      { key: 'delivery_rate', label: 'Delivery rate (calc.)', fmt: 'pct', fn: (r) => ratio(r.delivered, r.total_recipients) },
      { key: 'open_rate', label: 'Open rate (calc.)', fmt: 'pct', fn: (r) => ratio(r.unique_opens, r.delivered) },
      { key: 'click_rate', label: 'Click-through rate (calc.)', fmt: 'pct', fn: (r) => ratio(r.unique_clicks, r.delivered) },
    ],
    list: ['campaign_name', 'client_id', 'send_date', 'total_recipients', 'delivered', 'unique_opens', 'unique_clicks', 'bounced'],
  }),
  def({
    key: 'google-ads', team: 'marketing', slug: 'google-ads-logs', title: 'Google Ads Daily Logs', nav: 'Google Ads', table: 'google_ads_logs', icon: 'Megaphone', extra: 'ads-chart', std: 'min', statusField: '', hasPriority: false, anim: 'marketing',
    blurb: 'Daily spend, clicks and conversions per client campaign, with the change made and the next action.', titleField: 'campaign', dueField: 'log_date',
    fields: [c(), t('campaign', 'Campaign', { required: true }), d('log_date', 'Log date', { required: true }), n('spend', 'Spend', { money: true }), n('impressions', 'Impressions'), n('clicks', 'Clicks'),
      n('conversions', 'Conversions'), n('conversion_value', 'Conversion value', { money: true }), lt('change_made', 'Change made'), lt('issue_identified', 'Issue identified'), lt('next_action', 'Next action'),
      u('assigned_to', 'Assigned employee'), url('report_link', 'Report link')],
    derived: [
      { key: 'ctr', label: 'CTR', fmt: 'pct', fn: (r) => ratio(r.clicks, r.impressions) },
      { key: 'cpc', label: 'CPC', fmt: 'money', fn: (r) => safeDiv(r.spend, r.clicks) },
      { key: 'cpa', label: 'Cost / conversion', fmt: 'money', fn: (r) => safeDiv(r.spend, r.conversions) },
      { key: 'roas', label: 'ROAS', fmt: 'num', fn: (r) => (r.conversion_value ? safeDiv(r.conversion_value, r.spend) : '—') },
    ],
    list: ['log_date', 'client_id', 'campaign', 'spend', 'clicks', 'impressions', 'conversions', 'assigned_to'],
  }),
  def({
    key: 'google-analytics', team: 'marketing', slug: 'google-analytics', title: 'Google Analytics Sheet', nav: 'Google Analytics', table: 'google_analytics', icon: 'ChartLine', extra: 'analytics-charts', std: 'min', statusField: '', hasPriority: false, anim: 'marketing',
    blurb: 'Traffic, engagement and conversions per client website.', titleField: 'website', dueField: 'report_date',
    fields: [c(), t('website', 'Website', { required: true }), d('report_date', 'Reporting date', { required: true }), n('sessions', 'Sessions'), n('users', 'Users'), n('new_users', 'New users'), n('page_views', 'Page views'),
      n('engagement_rate', 'Engagement rate', { suffix: '%' }), n('conversions', 'Conversions'), s('traffic_source', 'Traffic source', ['Organic', 'Direct', 'Social', 'Referral', 'Paid', 'Email']), t('campaign', 'Campaign'),
      url('report_link', 'Report link'), u('assigned_to', 'Updated by')],
    list: ['website', 'client_id', 'report_date', 'sessions', 'users', 'new_users', 'page_views', 'engagement_rate', 'traffic_source'],
  }),
  def({
    key: 'google-setup', team: 'marketing', slug: 'google-client-setup', title: 'Google Client Setup Tracker', nav: 'Google Client Setup', table: 'google_client_setup', icon: 'BadgeCheck', statusLabel: 'Setup status', anim: 'marketing', hasPriority: false,
    secretNote: 'Track setup and access verification only: never enter passwords or private credentials.',
    blurb: 'Google property setup and access verification for every Ambizcon client.', titleField: 'website', dueField: 'setup_date',
    fields: [c(), t('website', 'Website', { required: true }), b('analytics', 'Google Analytics'), b('search_console', 'Search Console'), b('business_profile', 'Business Profile'), b('gtm', 'Tag Manager'), b('ads', 'Google Ads'),
      b('conversion_tracking', 'Conversion tracking'), t('account_owner', 'Account owner'), s('access_verification', 'Access verification', ['Unverified', 'Verified', 'Access issue']), d('setup_date', 'Setup date'),
      u('assigned_to', 'Assigned employee'), lt('outstanding_tasks', 'Outstanding tasks'), url('evidence_link', 'Report / evidence link')],
    list: ['website', 'client_id', 'analytics', 'search_console', 'business_profile', 'gtm', 'ads', 'conversion_tracking', 'access_verification', 'assigned_to'],
  }),
  def({
    key: 'mailer-scheduler', team: 'marketing', slug: 'mailer-scheduler', title: 'Mailer Marketing Scheduler', nav: 'Mailer Scheduler', table: 'mailer_scheduler', icon: 'CalendarClock', anim: 'marketing', hasPriority: false,
    blurb: 'Plan email campaigns and request creative. The request is linked to the original creative task, so the finished artwork shows up here.', titleField: 'campaign', dueField: 'scheduled_date',
    statusField: 'campaign_status', statusLabel: 'Campaign status', statusMap: { Draft: 'Pending', Ready: 'In Progress', Scheduled: 'In Progress', Sent: 'Completed', Cancelled: 'Cancelled' },
    fields: [c(), t('campaign', 'Campaign title', { required: true }), lt('campaign_goal', 'Campaign goal'), t('audience', 'Audience'), t('subject_line', 'Subject line'), lt('content', 'Draft content'),
      d('scheduled_date', 'Scheduled date', { required: true }), { key: 'scheduled_time', label: 'Scheduled time', type: 'time' }, u('assigned_to', 'Assigned marketer'), lt('image_requirement', 'Creative requirement'),
      url('image_ref', 'Image reference'), url('output_link', 'Final creative link'), s('review_status', 'Review status', REVIEW_OPTIONS),
      s('campaign_status', 'Campaign status', ['Draft', 'Ready', 'Scheduled', 'Sent', 'Cancelled'], { required: true }), url('report_link', 'Report link'), t('creative_task_ref', 'Linked creative task', { system: true })],
    list: ['campaign', 'client_id', 'subject_line', 'scheduled_date', 'scheduled_time', 'review_status', 'campaign_status', 'assigned_to'],
  }),
  def({
    key: 'community-groups', team: 'marketing', slug: 'community-groups', title: 'Community Group Sheet', nav: 'Community Groups', table: 'community_groups', icon: 'UsersRound', std: 'min', anim: 'marketing', hasPriority: false,
    blurb: 'Community groups per client. Groups are never joined and requests never sent automatically: record what was actually done.', titleField: 'group_name', dueField: 'last_checked',
    statusField: 'request_status', statusLabel: 'Request status', statusMap: { 'Not requested': 'Pending', Pending: 'In Progress', Accepted: 'Completed', Rejected: 'Cancelled' }, extra: 'community-stats',
    fields: [c(), t('location', 'Location'), t('group_name', 'Group name', { required: true }), s('platform', 'Platform', ['Facebook', 'LinkedIn', 'Instagram', 'WhatsApp', 'Telegram', 'Reddit']),
      url('group_link', 'Group URL'), s('group_type', 'Group type', ['Public', 'Private']), n('members', 'Approx. member count'),
      s('request_status', 'Request status', ['Not requested', 'Pending', 'Accepted', 'Rejected'], { required: true }), d('request_date', 'Request date'), d('last_checked', 'Last checked'), u('assigned_to', 'Assigned employee')],
    derived: [
      { key: 'accepted', label: 'Request accepted', fmt: 'text', fn: (r) => (r.request_status === 'Accepted' ? 'Yes' : 'No') },
      { key: 'pending', label: 'Pending request', fmt: 'text', fn: (r) => (r.request_status === 'Pending' ? 'Yes' : 'No') },
    ],
    list: ['group_name', 'client_id', 'location', 'platform', 'group_type', 'members', 'request_status', 'last_checked', 'assigned_to'],
  }),
  def({
    key: 'community-tracker', team: 'marketing', slug: 'community-tracker', title: 'Community Tracker Sheet', nav: 'Community Tracker', table: 'community_tracker', icon: 'Share2', anim: 'marketing', hasPriority: false,
    statusLabel: 'Post status', blurb: 'Posts shared in community groups. Use the status filter to see posted and pending separately.', titleField: 'post_name', dueField: 'post_date',
    fields: [c(), t('community', 'Community / group'), t('post_name', 'Post name', { required: true }), t('topic', 'Topic'), s('format', 'Format', ['Image', 'Text', 'Video', 'Other']), url('post_link', 'Post URL'),
      d('post_date', 'Publication date', { required: true }), u('assigned_to', 'Assigned employee'), lt('engagement_notes', 'Engagement notes'), url('output_link', 'Output link')],
    list: ['post_name', 'client_id', 'community', 'topic', 'format', 'post_date', 'assigned_to'],
  }),
  def({
    key: 'blog-youtube', team: 'marketing', slug: 'blog-youtube', title: 'Blog & YouTube Update Sheet', nav: 'Blog & YouTube', table: 'blog_youtube_updates', icon: 'PlaySquare', anim: 'marketing', hasPriority: false,
    blurb: 'Blog and YouTube content pipeline by client.', titleField: 'content_title',
    fields: [c(), t('content_title', 'Content title', { required: true }), s('content_type', 'Content type', ['Blog', 'YouTube'], { required: true }), t('channel_site', 'Website or channel'), url('content_url', 'Content URL'),
      u('assigned_to', 'Assigned employee'), d('date_assigned', 'Date assigned'), d('publication_date', 'Publication date'), url('output_link', 'Output link')],
    list: ['content_title', 'client_id', 'content_type', 'channel_site', 'due_date', 'publication_date', 'assigned_to'],
  }),
  def({
    key: 'blog-targets', team: 'marketing', slug: 'blog-targets', title: 'Monthly Blog Targets', nav: 'Blog Targets', table: 'monthly_blog_targets', icon: 'Target', std: 'none', statusField: '', hasPriority: false, group: 'target',
    blurb: 'How many blogs each client should get per month. Counts on the Blog Counts page are calculated from the blog records.', titleField: 'client_id', yearField: 'year',
    fields: [c(), n('year', 'Year', { required: true }), s('month', 'Month', MONTH_NAMES, { required: true }), n('target', 'Monthly target', { required: true })],
    list: ['client_id', 'year', 'month', 'target'],
  }),
  def({
    key: 'youtube', team: 'marketing', slug: 'youtube-channels', title: 'YouTube Channel Setup Tracker', nav: 'YouTube Channels', table: 'youtube_channels', icon: 'Video', extra: 'youtube-stats', std: 'min', anim: 'marketing', hasPriority: false,
    blurb: 'Which clients have a YouTube channel and how far setup has got. Channels are never created automatically: record what was actually done.', titleField: 'channel_name',
    statusField: 'setup_status', statusLabel: 'Setup status', statusMap: { 'Not started': 'Pending', 'In progress': 'In Progress', Complete: 'Completed', 'Needs update': 'On Hold' },
    fields: [c(), t('channel_name', 'Channel name', { required: true }), url('channel_url', 'Channel URL'), t('channel_id', 'Channel ID'), b('channel_created', 'Channel created'), d('creation_date', 'Creation date'),
      u('assigned_to', 'Assigned employee'), s('branding_status', 'Branding status', ['Not started', 'In progress', 'Done']), s('logo_banner_status', 'Logo & banner status', ['Not started', 'In progress', 'Done']),
      s('description_status', 'Description status', ['Not started', 'In progress', 'Done']), b('first_video', 'First video published'), d('last_upload', 'Last upload date'),
      s('setup_status', 'Setup status', ['Not started', 'In progress', 'Complete', 'Needs update'], { required: true })],
    list: ['channel_name', 'client_id', 'channel_created', 'branding_status', 'logo_banner_status', 'description_status', 'first_video', 'last_upload', 'setup_status'],
  }),

  // ───────── Creative (Adhoc) ─────────
  ...([
    ['web', 'Web Requirement', 'Web Requirements', 'creative_web_requirements', 'LayoutTemplate', 'web', 'website design requests, landing pages, page updates, UI/UX changes and banners', 'web-requirements'],
    ['videos', 'Video', 'Videos', 'creative_videos', 'Clapperboard', 'video', 'video creation, editing, reels, animations and revisions', 'videos'],
    ['artworks', 'Artwork', 'Artworks', 'creative_artworks', 'Palette', 'artwork', 'social creatives, campaign banners, posters, carousels and advertisements', 'artworks'],
  ] as const).map(([key, single, plural, table, icon, anim, about, slug]) =>
    def({
      key, team: 'creative', slug, title: plural, nav: plural, table, icon, anim, acceptsRequests: true, extra: 'creative-stats', reviewFlow: true,
      blurb: `Adhoc ${single.toLowerCase()} work: ${about}. Completion needs reviewer approval.`, titleField: 'task', dueField: 'due_date',
      statusField: 'status', statusLabel: 'Status',
      statusMap: { New: 'Pending', Assigned: 'Pending', 'In Progress': 'In Progress', 'On Hold': 'On Hold', 'Submitted for Review': 'In Progress', 'Changes Requested': 'In Progress', Approved: 'In Progress', Completed: 'Completed' },
      fields: [t('task', 'Task title', { required: true }), c(), lt('description', 'Task description'), u('assigned_to', 'Assigned employee'), s('priority', 'Priority', PRIORITIES, { required: true }),
        s('status', 'Status', CREATIVE_STATUSES, { required: true }), d('date_assigned', 'Date assigned'), d('due_date', 'Due date', { required: true }), url('output_link', 'Output link'),
        img('thumbnail', 'Thumbnail / preview'), u('reviewer', 'Reviewer'), s('review_status', 'Review status', REVIEW_OPTIONS), d('completion_date', 'Completion date', { system: true }),
        t('category', 'Category'), lt('brief', 'Design brief'), t('dimensions', 'Required dimensions'), t('request_source', 'Requested from', { system: true }), u('requested_by', 'Requested by', { system: true }),
        t('source_ref', 'Source record', { system: true })],
      list: ['task', 'thumbnail', 'client_id', 'assigned_to', 'priority', 'due_date', 'review_status'],
      rules: (v) => (v.status === 'Completed' && v.reviewer && v.review_status !== 'Approved' ? { status: 'A reviewer is set, so this needs review approval before it can be completed' } : {}),
    }),
  ),

  // ───────── Creative: client brand & content brief (9 sections, each linked to a client) ─────────
  ...([
    {
      slug: 'overview', nav: 'Overview', icon: 'Building2', table: 'brief_overview', titleField: 'business_name', blurb: 'Who the client is: business, location, category and main contact.',
      fields: [c(), t('business_name', 'Clinic / business name', { required: true }), t('location', 'Location'), t('business_category', 'Business category'), url('website', 'Website URL'),
        n('years_operating', 'Years of operation'), lt('description', 'Business description'), t('main_contact', 'Main contact')],
      list: ['business_name', 'client_id', 'location', 'business_category', 'main_contact'],
    },
    {
      slug: 'audience', nav: 'Target Audience', icon: 'Users', table: 'brief_audience', titleField: 'age_group', blurb: 'Age, occupation, family profile, local demographics and booking behaviour.',
      fields: [c(), t('age_group', 'Target age group', { required: true }), t('gender', 'Gender (only where relevant to the campaign)'), t('occupation', 'Occupation'), t('income_range', 'Income range (only if appropriately collected)'),
        t('family_profile', 'Family profile'), lt('local_demographics', 'Local demographics'), lt('booking_behaviour', 'Booking behaviour'), t('audience_location', 'Audience location')],
      list: ['age_group', 'client_id', 'occupation', 'audience_location'],
    },
    {
      slug: 'expectations', nav: 'Audience Expectations', icon: 'Lightbulb', table: 'brief_expectations', titleField: 'preferred_content', blurb: 'What the audience wants to see, hear and trust.',
      fields: [c(), lt('preferred_content', 'Preferred content', { required: true }), t('communication_style', 'Communication style'), lt('concerns', 'Customer concerns'), lt('trust_factors', 'Factors that build trust'),
        lt('faqs', 'Frequently asked questions'), t('preferred_channels', 'Preferred channels')],
      list: ['preferred_content', 'client_id', 'communication_style', 'preferred_channels'],
    },
    {
      slug: 'brand', nav: 'Brand Guidelines', icon: 'Palette', table: 'brief_brand', titleField: 'brand_colours', blurb: 'Colours, typography, logo usage, tone of voice and what to avoid.',
      fields: [c(), t('brand_colours', 'Brand colours', { required: true }), t('typography', 'Typography'), url('logo_link', 'Logo files / link'), lt('logo_rules', 'Logo usage rules'), t('tone_of_voice', 'Tone of voice'),
        url('guidelines_doc', 'Brand guidelines document'), lt('recommended', 'Recommended practices'), lt('avoid', 'Things to avoid')],
      list: ['brand_colours', 'client_id', 'typography', 'tone_of_voice', 'guidelines_doc'],
    },
    {
      slug: 'services', nav: 'Services', icon: 'ClipboardList', table: 'brief_services', titleField: 'service_name', blurb: 'One record per service the client offers.',
      fields: [c(), t('service_name', 'Service name', { required: true }), lt('short_description', 'Short description'), t('target_audience', 'Target audience'), lt('key_benefits', 'Key benefits'),
        url('landing_page', 'Related landing page'), lt('content_notes', 'Content notes')],
      list: ['service_name', 'client_id', 'target_audience', 'landing_page'],
    },
    {
      slug: 'design', nav: 'Design Recommendations', icon: 'Brush', table: 'brief_design', titleField: 'visual_style', blurb: 'Layout, photography, practitioner visibility and on-image text rules.',
      fields: [c(), t('visual_style', 'Visual style', { required: true }), lt('layout_guidance', 'Layout guidance'), lt('photography_guidance', 'Authentic photography guidance'), lt('practitioner_visibility', 'Practitioner visibility requirements'),
        t('text_limits', 'On-image text limits'), lt('colour_rules', 'Brand colour rules'), url('reference_images', 'Reference images'), lt('design_notes', 'Design notes')],
      list: ['visual_style', 'client_id', 'text_limits', 'reference_images'],
    },
    {
      slug: 'content', nav: 'Content Recommendations', icon: 'FileText', table: 'brief_content', titleField: 'content_formats', blurb: 'Calls to action, captions, hashtags, keywords and suggested topics.',
      fields: [c(), t('content_formats', 'Content formats', { required: true }), lt('calls_to_action', 'Calls to action'), lt('sample_captions', 'Sample captions'), lt('hashtags', 'Hashtags'), lt('keywords', 'Keywords'),
        lt('suggested_topics', 'Suggested content topics'), lt('campaign_notes', 'Campaign notes')],
      list: ['content_formats', 'client_id', 'hashtags', 'keywords'],
    },
    {
      slug: 'campaign-performance', nav: 'Campaign Performance', icon: 'ChartLine', table: 'brief_campaign_performance', titleField: 'campaign_name', blurb: 'Campaign results. Mark whether numbers are actual platform data, manual estimates or sample data.',
      fields: [c(), t('campaign_name', 'Campaign name', { required: true }), t('reporting_period', 'Reporting period'), n('engagement_rate', 'Engagement rate', { suffix: '%' }), lt('best_posts', 'Best-performing posts'),
        lt('reels_performance', 'Reels performance'), lt('carousel_performance', 'Carousel performance'), n('reach', 'Reach'), n('impressions', 'Impressions'), lt('recommended_topics', 'Recommended topics'),
        s('metrics_source', 'Source of metrics', ['Actual (platform export)', 'Manual estimate', 'Sample data'], { required: true }), url('report_link', 'Report link')],
      list: ['campaign_name', 'client_id', 'reporting_period', 'engagement_rate', 'metrics_source'],
    },
    {
      slug: 'competitors', nav: 'Competitors', icon: 'Target', table: 'brief_competitors', titleField: 'competitor_name', blurb: 'One record per competitor: strengths and differentiation opportunities.',
      fields: [c(), t('competitor_name', 'Competitor name', { required: true }), url('website', 'Website'), lt('social_urls', 'Social media URLs'), lt('content_style', 'Content style'), lt('strengths', 'Observed strengths'),
        lt('opportunities', 'Differentiation opportunities'), lt('reference_links', 'Reference links'), d('research_date', 'Research date')],
      list: ['competitor_name', 'client_id', 'website', 'research_date'],
    },
  ]).map((b, i) =>
    def({
      key: `brief-${b.slug}`, team: 'creative', slug: `brief-${b.slug}`, title: `${String(i + 1).padStart(2, '0')} ${b.nav}`, nav: b.nav, table: b.table, icon: b.icon, blurb: b.blurb, titleField: b.titleField,
      std: 'none', statusField: '', hasPriority: false, group: 'brief', anim: 'celebrate', fields: b.fields, list: b.list,
    }),
  ),
];

export const MODULE_BY_KEY = Object.fromEntries(MODULES.map((m) => [m.key, m])) as Record<string, ModuleDef>;
export const modulesOf = (team: WorkTeam) => MODULES.filter((m) => m.team === team && !m.group);
export const BRIEF_MODULES = MODULES.filter((m) => m.group === 'brief');
export const findModule = (team: string, slug: string) => MODULES.find((m) => m.team === team && m.slug === slug);
export const fieldOf = (m: ModuleDef, key: string) => m.fields.find((f) => f.key === key);
export const hasStatus = (m: ModuleDef) => !!m.statusField;
