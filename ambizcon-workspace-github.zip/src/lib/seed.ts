import { MODULES, MONTH_NAMES, type Field, type ModuleDef } from './modules';
import { isDoneValue } from './modulerules';
import type { Activity, AppNotification, Client, Profile, Rec, Task, WorkTeam } from './types';
import { addDays, isoDate, todayISO } from './utils';

/** Deterministic PRNG so demo data is stable between reloads. */
function rng(seed: number) {
  return () => {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export const DEMO_PASSWORD = 'Ambizcon@2026';

const U = (id: string, name: string, team: Profile['team'], role: Profile['role'], daysAgo: number): Profile => ({
  id,
  name,
  email: `${name.split(' ')[0].toLowerCase()}@ambizcon.demo`,
  team,
  role,
  status: 'active',
  avatar_url: null,
  last_login: null,
  created_at: new Date(Date.now() - daysAgo * 86400000).toISOString(),
});

export const DEMO_USERS: Profile[] = [
  U('u-admin', 'Thanikaivel R', 'admin', 'admin', 400),
  U('u-karthik', 'Karthik Raman', 'development', 'lead', 380),
  U('u-divya', 'Divya Subramani', 'development', 'member', 300),
  U('u-arun', 'Arun Prakash', 'development', 'member', 210),
  U('u-meera', 'Meera Iyer', 'marketing', 'lead', 360),
  U('u-rohit', 'Rohit Sharma', 'marketing', 'member', 250),
  U('u-sneha', 'Sneha Kapoor', 'marketing', 'member', 190),
  U('u-ananya', 'Ananya Das', 'creative', 'lead', 340),
  U('u-vikram', 'Vikram Rao', 'creative', 'member', 260),
  U('u-lakshmi', 'Lakshmi Pillai', 'creative', 'member', 150),
];
/** Quick-fill accounts shown on the login page in demo mode. */
export const DEMO_LOGINS = [
  { label: 'Admin', email: 'thanikaivel@ambizcon.demo' },
  { label: 'Development', email: 'karthik@ambizcon.demo' },
  { label: 'Marketing', email: 'meera@ambizcon.demo' },
  { label: 'Creative', email: 'ananya@ambizcon.demo' },
];

const slugOf = (name: string) => name.toLowerCase().replace(/&/g, 'and').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
/** The company's real client list (names only). Type, MD, location, category and website are not known yet: fill them in from the Clients page. */
const CLIENT_NAMES = [
  'RR', 'NMCSC', 'HHMC', 'KW', 'GCG', 'TPC', 'MBM', '1GP', 'TVM', 'MLD', 'Auzskin Cosmetics', 'Dr UMED', 'YC', 'SC', 'Psychetel Australia',
  'DACC', 'CTMC', 'CSDC', 'CD', 'CANTMC', 'FP', 'IGP', 'CFP', 'NECT', 'BK Heart', 'Heart Link', 'MMSC', 'CEEDS', 'Bopple Surgery',
];
const byTeam = (t: Profile['team']) => DEMO_USERS.filter((u) => u.team === t).map((u) => u.id);
const DEV = byTeam('development'), MKT = byTeam('marketing'), CRE = byTeam('creative');
/** Demo clients are sample data only (the app labels demo mode in the UI). */
export const DEMO_CLIENTS: Client[] = CLIENT_NAMES.map((name, i) => ({
  id: `c-${i + 1}`,
  name,
  client_type: 'General Practitioner' as const, // placeholder until each client's type is confirmed
  md_name: null,
  location: null,
  category: null,
  joined_on: isoDate(new Date(Date.now() - (120 + i * 70) * 86400000)),
  website: null,
  status: 'active' as const,
  notes: null,
  assigned_ids: [DEV[i % DEV.length], MKT[i % MKT.length], CRE[i % CRE.length]],
}));
const siteOf = (c: Client) => `${slugOf(c.name).split('-').slice(0, 2).join('')}.example.com`;

const POOLS: Record<string, string[]> = {
  subject: ['Your seasonal health check offer', 'Meet our new specialist', 'Book your appointment this week', 'Wellness tips for the festive season', 'You are invited: free health camp'],
  subject_line: ['Your seasonal health check offer', 'Meet our new specialist', 'Book your appointment this week', 'Wellness tips for the festive season', 'You are invited: free health camp'],
  audience: ['Existing patients', 'Local families 30–55', 'Corporate wellness leads', 'Newsletter subscribers', 'Senior citizens'],
  category: ['Preventive care', 'Treatments', 'Lifestyle', 'Patient stories', 'Announcements'],
  vendor: ['Elementor', 'WP Media', 'Kinsta', 'Cloudflare', 'GoDaddy', 'Namecheap', 'Google', 'Zoho'],
  plan: ['Starter', 'Business', 'Pro 50k', 'Growth', 'Enterprise'],
  account_owner: ['Clinic MD office', 'Ambizcon IT', 'Practice manager', 'Previous agency'],
  hosting_provider: ['Kinsta', 'Hostinger', 'AWS Lightsail', 'GoDaddy', 'SiteGround'],
  community: ['Chennai Health Circle', 'Wellness Warriors CBE', 'Madurai Moms Community', 'Bengaluru Fitness Hub'],
  channel_site: ['Client blog', 'Official YouTube channel', 'Clinic website', 'Health hub'],
  post_name: ['Wellness myth buster', 'Doctor Q&A', 'Health quiz', 'Seasonal tips', 'Patient story', 'Clinic update'],
  campaign_goal: ['Fill December appointment slots', 'Announce the new doctor', 'Grow newsletter opens', 'Promote the health package'],
  description: ['Sample task generated for demo data.'],
  business_name: ['Sample clinic'],
  title: ['Homepage keyword refresh', 'Service page schema', 'Location page optimisation', 'Core Web Vitals fixes', 'Internal linking audit', 'Image alt text update', 'Doctor profile pages', 'FAQ rich results', 'Sitemap cleanup', 'Canonical tag fix'],
  keyword: ['best hospital near me', 'dental implants cost', 'ayurvedic treatment', 'blood test at home', 'fertility clinic', 'cardiologist consultation', 'skin clinic', 'mental wellness centre', 'online pharmacy', 'health checkup package'],
  blog_title: ['10 Signs You Need a Heart Checkup', 'Ayurveda for Seasonal Wellness', 'Dental Care Tips for Children', 'What to Expect in a Full-Body Checkup', 'Understanding Your Lab Report', 'Fertility Myths Debunked', 'Managing Stress at Work', 'Skin Care in Monsoon', 'Why Preventive Health Matters', 'Choosing the Right Specialist'],
  page: ['Home', 'About Us', 'Services', 'Contact', 'Doctors', 'Blog', 'Book Appointment', 'Health Packages', 'Gallery', 'FAQ'],
  tool_name: ['Elementor Pro', 'WP Rocket', 'Kinsta Hosting', 'Cloudflare Pro', 'Sucuri Security', 'UptimeRobot', 'Figma Team', 'GitHub Teams', 'Ahrefs', 'Hotjar'],
  provider: ['Elementor', 'WP Media', 'Kinsta', 'Cloudflare', 'GoDaddy', 'Namecheap', 'Google', 'Amazon', 'Zoho', 'Hostinger'],
  smtp_tool: ['SendGrid', 'Amazon SES', 'Mailgun', 'Brevo', 'Postmark', 'Zoho ZeptoMail', 'Mailchimp Transactional', 'SMTP2GO', 'Elastic Email', 'Mailjet'],
  registrar: ['GoDaddy', 'Namecheap', 'BigRock', 'Hostinger', 'Google Domains'],
  access_email: ['domains@ambizcon.com', 'it@ambizcon.com', 'webmaster@ambizcon.com'],
  topic: ['Winter wellness tips', 'Heart health awareness', 'Meet our doctors', 'Festival health offers', 'Diabetes care guide', 'World Health Day', 'Patient success story', 'Yoga and recovery', 'Nutrition basics', 'Vaccination reminder'],
  campaign_name: ['October Health Checkup Offer', 'Diwali Wellness Package', 'Heart Month Awareness', 'New Doctor Announcement', 'Free Dental Camp', 'Monsoon Skin Care Tips', 'Diabetes Day Special', 'Fertility Webinar Invite', 'Patient Feedback Survey', 'Pharmacy Home Delivery'],
  campaign: ['Search – Brand', 'Search – Services', 'Display Remarketing', 'Performance Max', 'Local Services', 'Search – Doctors', 'Video Awareness', 'Search – Packages', 'Discovery Leads', 'Search – Emergency'],
  email_topic: ['Seasonal health offer', 'Doctor spotlight', 'Appointment reminder', 'Wellness newsletter', 'Event invitation', 'Package launch', 'Patient story', 'Awareness day', 'Feedback request', 'Festival greetings'],
  content: ['Draft copy shared with client for approval.', 'Subject line A/B test planned.', 'Includes offer banner and CTA button.', 'Plain-text fallback required.'],
  image_requirement: ['Hero banner 600×300', 'Doctor portrait collage', 'Festival greeting header', 'Offer badge graphic', 'Infographic 600×900'],
  creative_requirement: ['Social creative', 'Banner 1200×628', 'Reel cover', 'Carousel set', 'None'],
  location: ['Chennai', 'Coimbatore', 'Madurai', 'Bengaluru', 'Hyderabad', 'Mumbai', 'Delhi NCR', 'Pune', 'Kochi', 'Trichy'],
  group_name: ['Chennai Health Circle', 'Wellness Warriors CBE', 'Madurai Moms Community', 'Bengaluru Fitness Hub', 'Hyderabad Diabetes Support', 'Mumbai Healthy Living', 'Delhi Yoga Collective', 'Pune Senior Care', 'Kochi Ayurveda Friends', 'Trichy Family Doctors'],
  name: ['Wellness myth buster', 'Doctor Q&A', 'Health quiz', 'Seasonal tips', 'Patient story', 'Clinic update', 'Offer announcement', 'Awareness poll', 'Exercise reel', 'Recipe share'],
  content_title: ['Heart Care Basics', 'Monsoon Wellness Guide', 'Dental Hygiene 101', 'Meet Our Cardiologist', 'Fertility FAQs Answered', 'Ayurveda Morning Routine', 'Diabetes Diet Plan', 'Skin Care Weekly', 'Mental Health Matters', 'Pharmacy Safety Tips'],
  video_title: ['Hospital Tour 2026', 'Meet Dr. Ramesh – Cardiology', 'Smile Makeover Stories', 'How Blood Tests Work', 'Fertility Journey Testimonial', 'Morning Ayurveda Routine', 'Skin Care Basics', 'Stress-Free Living', 'Pharmacy Home Delivery', 'Annual Health Camp Highlights'],
  task_web: ['Landing page banner set', 'Homepage hero redesign', 'Appointment form UI', 'Pricing table section', 'Service icon pack', 'Footer redesign', 'Popup design', 'Doctor card layout', 'Mobile menu mockup', '404 page illustration'],
  task_videos: ['Hospital tour reel', 'Doctor introduction video', 'Patient testimonial edit', 'Festival greeting video', 'Health tips short', 'Explainer: heart care', 'Clinic walkthrough', 'Award celebration reel', 'Webinar promo cut', 'Product demo teaser'],
  task_artworks: ['Hospital Campaign Artwork', 'Festival greeting post', 'Health awareness poster', 'Mailer header image', 'Brochure cover', 'Social carousel set', 'Doctors Day post', 'Standee design', 'Logo refresh variants', 'Newsletter banner'],
  top_page: ['/', '/services', '/doctors', '/book-appointment', '/blog/heart-health', '/packages'],
};

/** Inline SVG placeholder thumbnails in brand colours (no external assets, no tracking). */
export function thumb(label: string, hue = 0) {
  const a = ['#13798A', '#8BA277', '#95A575'][hue % 3];
  const b = ['#8BA277', '#13798A', '#13798A'][hue % 3];
  const text = label.length > 22 ? label.slice(0, 21) + '…' : label;
  const svg = `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 320 200'><defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='${a}'/><stop offset='1' stop-color='${b}'/></linearGradient></defs><rect width='320' height='200' fill='url(#g)'/><circle cx='260' cy='40' r='48' fill='white' fill-opacity='.14'/><circle cx='40' cy='170' r='60' fill='white' fill-opacity='.1'/><text x='20' y='110' font-family='sans-serif' font-size='20' font-weight='700' fill='white'>${text.replace(/&/g, '&amp;')}</text></svg>`;
  return 'data:image/svg+xml;utf8,' + encodeURIComponent(svg);
}

const EXPIRY_OFFSETS = [-12, 6, 14, 27, 44, 61, 85, 140, 220, 330];
const DUE_OFFSETS = [-5, -1, 0, 0, 1, 2, 4, 7, 12, 20];
const PAST_LOG_KEYS = new Set(['link_verified_on', 'last_email_test', 'creation_date', 'last_upload', 'request_date', 'purchase_date', 'draft_date', 'publication_date', 'backup_date', 'date_checked', 'seo_date', 'checked_date', 'last_checked', 'last_verified', 'published_date', 'upload_date', 'post_date', 'send_date', 'log_date', 'report_date', 'setup_date', 'check_date']);

const pick = <T,>(arr: readonly T[], i: number) => arr[i % arr.length];
const stamp = (daysAgo: number, hour: number, min: number) => {
  const d = new Date();
  d.setDate(d.getDate() - daysAgo);
  d.setHours(hour, min, 0, 0);
  return d > new Date() ? new Date().toISOString() : d.toISOString();
};

export interface SeedResult {
  records: Record<string, Rec[]>;
  activity: Activity[];
  notifications: AppNotification[];
}

export function buildSeed(users: Profile[], clients: Client[], idFn: () => string): SeedResult {
  const r = rng(20260101);
  const records: Record<string, Rec[]> = {};
  const activity: Activity[] = [];
  const today = todayISO();
  const teamUsers = (team: string) => users.filter((u) => u.team === team);

  for (const m of MODULES) {
    if (m.readonly || m.group === 'brief') continue; // brief sections start empty: real client briefs are entered by the Creative team
    const rows: Rec[] = [];
    const members = teamUsers(m.team);
    const count = m.key === 'daily-check' ? 12 : m.key === 'performance' ? 28 : m.key === 'blog-targets' ? 20 : 10;
    for (let i = 0; i < count; i++) {
      const client = clients[i % clients.length];
      const creator = pick(members, i);
      const rec: Record<string, any> = {};
      const ctx = { m, i, client, members, clients };
      // dates first so status can be coherent with them
      for (const f of m.fields) if (f.type === 'date' || f.type === 'expiry') rec[f.key] = genDate(f, ctx);
      for (const f of m.fields) if (!(f.key in rec)) rec[f.key] = genValue(f, ctx, r);
      overrides(m, rec, ctx, r);
      const due = m.dueField ? (rec[m.dueField] as string | undefined) : undefined;
      const createdDays = Math.floor(r() * 28);
      const createdAt = stamp(i % 7 === 0 ? 0 : createdDays, 8 + Math.floor(r() * 3), Math.floor(r() * 59));
      const base: Rec = { id: idFn(), created_at: createdAt, updated_at: createdAt, created_by: creator.id, updated_by: creator.id, ...rec };
      if (m.statusField === 'status') base.status = genStatus(due, i, r);
      postProcess(m, base, i, users, r);
      if (m.key === 'daily-check') {
        base.status = i === 1 ? 'Pending' : i === 2 ? 'In Progress' : 'Completed';
        base.check_date = i < 12 ? today : addDays(-i);
      }
      const prevStatus = m.statusField ? (base[m.statusField] as string) : null;
      activity.push({ id: idFn(), module: m.key, record_id: base.id, user_id: creator.id, user_name: creator.name, action: 'created', detail: `${creator.name} created ${m.title.toLowerCase()} record`, created_at: createdAt });
      if (prevStatus && isDoneValue(m, prevStatus)) {
        const mid = new Date(new Date(createdAt).getTime() + 2 * 3600000).toISOString();
        const end = new Date(Math.min(Date.now(), new Date(createdAt).getTime() + (4 + Math.floor(r() * 20)) * 3600000)).toISOString();
        const who = pick(members, i + 1);
        activity.push({ id: idFn(), module: m.key, record_id: base.id, user_id: who.id, user_name: who.name, action: 'status', detail: 'Status changed to In Progress', created_at: new Date(Math.min(Date.now(), +new Date(mid))).toISOString() });
        activity.push({ id: idFn(), module: m.key, record_id: base.id, user_id: who.id, user_name: who.name, action: 'completed', detail: 'Status changed to Completed', created_at: end });
        base.updated_at = end;
        base.updated_by = who.id;
      }
      rows.push(base);
    }
    records[m.key] = rows;
  }

  // a few campaigns already have their creative request linked (one creative task per campaign, never duplicated)
  const sched = records['mailer-scheduler'] ?? [];
  const arts = records['artworks'] ?? [];
  for (let k = 0; k < Math.min(3, sched.length, arts.length); k++) {
    const sc = sched[k], ar = arts[k];
    ar.requested_by = sc.assigned_to ?? users.find((u) => u.team === 'marketing')?.id ?? null;
    ar.request_source = `Marketing · Mailer: ${sc.campaign}`;
    ar.source_ref = `mailer-scheduler:${sc.id}`;
    ar.category = 'Email Marketing Creative';
    ar.dimensions = '600 × 300 px';
    ar.client_id = sc.client_id;
    sc.creative_task_ref = `artworks:${ar.id}`;
  }

  const titleById = new Map<string, string>();
  for (const m of MODULES) for (const rec of records[m.key] ?? []) titleById.set(rec.id, m.titleField === 'client_id' ? m.title : String(rec[m.titleField] ?? ''));
  for (const a of activity) a.record_title = titleById.get(a.record_id);

  const adminId = users.find((u) => u.team === 'admin')?.id ?? null;
  const art = records['artworks']?.[0];
  const notifications: AppNotification[] = [
    { id: idFn(), user_id: adminId, team: null, kind: 'completed', title: 'Creative Team completed', body: `Creative Team completed: ${art?.task ?? 'Hospital Campaign Artwork'}`, link: '/creative/adhoc/artworks', read: false, created_at: stamp(0, 9, 40) },
    { id: idFn(), user_id: null, team: 'creative', kind: 'marketing', title: 'Marketing request received', body: 'Marketing requested a mailer header image for “Diwali Wellness Package”.', link: '/creative/adhoc/artworks', read: false, created_at: stamp(0, 10, 5) },
    { id: idFn(), user_id: adminId, team: null, kind: 'admin', title: 'Weekly summary ready', body: 'Open Reports to review team performance for this week.', link: '/admin/reports', read: false, created_at: stamp(1, 18, 0) },
  ];
  return { records, activity, notifications };
}

/** Per-module coherence after raw values are generated (statuses, verification, review, completion dates, report totals). */
function postProcess(m: ModuleDef, base: Rec, i: number, users: Profile[], r: () => number) {
  const today = todayISO();
  const done = (v: unknown) => isDoneValue(m, v);
  if (m.key === 'backups') {
    base.verification = i % 6 === 0 ? 'Unverified' : i % 9 === 4 ? 'Failed' : 'Verified';
    if (base.verification === 'Verified') { base.verified_by = base.assigned_to; base.link_verified_on = base.backup_date; } else { base.verified_by = null; base.link_verified_on = null; }
  } else if (m.key === 'blogs') {
    const st = base.blog_status as string;
    base.publish_verified = st === 'Published' && i % 5 !== 3;
    if (st === 'Published') base.published_date = addDays(-(i * 3 + 2));
    else base.published_date = null;
    base.draft_date = st === 'Planned' ? null : addDays(-(i * 3 + 6));
  } else if (m.key === 'website-expiry' || m.key === 'ssl-expiry' || m.key === 'tools-expiry' || m.key === 'smtp-expiry' || m.key === 'domain-access') {
    const unknown = i === 9;
    base.date_confidence = unknown ? 'Unknown' : i % 7 === 3 ? 'Estimated' : 'Confirmed';
    if (unknown) for (const f of m.fields) if (f.type === 'expiry') base[f.key] = null;
    if (m.key === 'ssl-expiry') {
      const days = base.ssl_expiry_date ? Math.round((Date.parse(base.ssl_expiry_date) - Date.parse(today)) / 86400000) : null;
      base.certificate_status = days === null ? 'Unknown' : days < 0 ? 'Expired' : days <= 30 ? 'Expiring soon' : 'Valid';
      base.check_method = 'Manual verification';
    }
  } else if (m.key === 'blog-youtube') {
    if (base.status !== 'Completed') base.publication_date = null;
    else base.publication_date = base.publication_date ?? addDays(-(i + 1));
    base.channel_site = base.content_type === 'Blog' ? siteOf(DEMO_CLIENTS[i % DEMO_CLIENTS.length]) : `${DEMO_CLIENTS[i % DEMO_CLIENTS.length].name} Official`;
  } else if (m.key === 'youtube') {
    const created = i % 5 !== 4;
    base.channel_created = created;
    base.creation_date = created ? addDays(-(60 + i * 9)) : null;
    base.first_video = created && i % 3 !== 2;
    base.last_upload = base.first_video ? addDays(-(i * 6 + 3)) : null;
    base.setup_status = !created ? 'Not started' : i % 7 === 6 ? 'Needs update' : base.first_video ? 'Complete' : 'In progress';
    base.channel_url = created ? base.channel_url : null;
    base.channel_id = created ? base.channel_id : null;
  } else if (m.key === 'performance') {
    const site = i % 2, offset = Math.floor(i / 2); // two websites x 14 months (so year-over-year comparisons exist)
    const d = new Date(); d.setDate(1); d.setMonth(d.getMonth() - offset);
    base.client_id = DEMO_CLIENTS[site].id;
    base.website = siteOf(DEMO_CLIENTS[site]);
    base.report_month = MONTH_NAMES[d.getMonth()];
    base.report_year = d.getFullYear();
    const grow = 1 + (14 - offset) * 0.03 + r() * 0.15;
    const partial = offset === 0 ? new Date().getDate() / 30 : 1; // the running month is month-to-date
    base.sessions = Math.round((2400 + site * 1500) * grow * partial);
    base.users = Math.round(base.sessions * 0.78);
    base.page_views = Math.round(base.sessions * 2.1);
    base.organic_clicks = Math.round(base.sessions * 0.46);
    base.organic_impressions = Math.round(base.organic_clicks * (14 + r() * 8));
    base.conversions = Math.round(base.sessions * 0.021);
    base.data_source = 'Manual entry';
    const sc = (lo: number, hi: number) => Math.round(lo + r() * (hi - lo) + (14 - offset) * 0.4);
    base.desktop_score = Math.min(100, sc(70, 92)); base.mobile_score = Math.min(100, sc(55, 85)); base.seo_score = Math.min(100, sc(75, 96)); base.best_practices_score = Math.min(100, sc(70, 95)); base.accessibility_score = Math.min(100, sc(68, 94));
  } else if (m.key === 'blog-targets') {
    const d = new Date(); d.setDate(1); d.setMonth(d.getMonth() - Math.floor(i / 10));
    base.client_id = DEMO_CLIENTS[i % DEMO_CLIENTS.length].id;
    base.year = d.getFullYear();
    base.month = MONTH_NAMES[d.getMonth()];
    base.target = 3 + (i % 4);
  } else if (m.acceptsRequests) {
    const lead = users.find((u) => u.team === 'creative' && u.role === 'lead');
    const raw = String(base.status);
    base.status = raw === 'Completed' ? 'Completed' : raw === 'In Progress' ? (i % 3 === 0 ? 'Submitted for Review' : 'In Progress') : raw === 'On Hold' || raw === 'Cancelled' ? 'On Hold' : i % 2 ? 'New' : 'Assigned';
    base.reviewer = lead?.id ?? null;
    base.review_status = base.status === 'Completed' ? 'Approved' : base.status === 'Submitted for Review' ? 'In review' : 'Not reviewed';
    base.category = base.category || (i % 4 === 1 ? 'Email Marketing Creative' : ['Social post', 'Website banner', 'Campaign', 'Awareness'][i % 4]);
    base.requested_by = i % 4 === 1 ? (users.find((u) => u.team === 'marketing')?.id ?? null) : null;
    base.source_ref = '';
    base.description = base.description || 'Sample task generated for demo data.';
  }
  if (m.fields.some((f) => f.key === 'completion_date') && m.statusField) base.completion_date = done(base[m.statusField]) ? addDays(-(i % 5)) : null;
}

function genStatus(due: string | undefined, i: number, r: () => number) {
  const today = todayISO();
  const x = r();
  if (due && due < today) return x < 0.82 ? 'Completed' : x < 0.9 ? 'In Progress' : x < 0.96 ? 'Pending' : 'Cancelled';
  if (due === today) return x < 0.35 ? 'Completed' : x < 0.7 ? 'In Progress' : 'Pending';
  void i;
  return x < 0.08 ? 'On Hold' : x < 0.55 ? 'Pending' : 'In Progress';
}

type Ctx = { m: ModuleDef; i: number; client: Client; members: Profile[]; clients: Client[] };

function genDate(f: Field, { m, i }: Ctx) {
  const k = f.key;
  if (f.type === 'expiry' || /expiry|renewal/.test(k)) return addDays(pick(EXPIRY_OFFSETS, i * 3 + (m.key.length % 7) + (k.length % 4)));
  if (k === 'check_date') return todayISO();
  if (k === 'content_date') return addDays(-8 + ((i * 3) % 30));
  if (k === 'date_assigned') return addDays(-(2 + (i % 6)));
  if (PAST_LOG_KEYS.has(k)) return addDays(-((i * 2) % 21) - (k === 'send_date' || k === 'log_date' || k === 'report_date' ? 0 : 0));
  if (k === m.dueField || /due|next_backup|scheduled/.test(k)) return addDays(pick(DUE_OFFSETS, i * 3 + 1));
  return addDays(-(i + 1));
}

function genValue(f: Field, { m, i, client, members, clients }: Ctx, r: () => number): any {
  const k = f.key;
  switch (f.type) {
    case 'client': return client.id;
    case 'user': return k === 'creative_assigned_to' ? pick(members.filter((u) => u.team === 'creative').length ? members.filter((u) => u.team === 'creative') : members, i).id : pick(members, i + (k.length % 3)).id;
    case 'bool': return r() < 0.72;
    case 'check': return r() < 0.8 ? 'Pass' : r() < 0.6 ? 'Warning' : 'Fail';
    case 'select': return pick(f.options ?? [''], i + Math.floor(r() * 3));
    case 'time': return pick(['09:30', '11:00', '14:30', '16:00', '10:15'], i);
    case 'image': return thumb(String(pick(POOLS[`task_${m.key}`] ?? POOLS.blog_title, i)), i);
    case 'url': return `https://${siteOf(client)}/${k.replace(/_/g, '-')}/${i + 1}`;
    case 'number': return num(k, i, r);
    case 'longtext': return pick(POOLS[k] ?? ['—'], i) === '—' ? '' : pick(POOLS[k], i);
    case 'text': {
      if (k === 'website' || k === 'domain') return siteOf(clients[i % clients.length]);
      if (k === 'access_email') return pick(POOLS.access_email, i);
      if (k === 'task') return pick(POOLS[`task_${m.key}`], i);
      if (k === 'search_slug') return '/' + slugOf(String(pick(POOLS.page, i)));
      if (k === 'top_page') return pick(POOLS.top_page, i);
      if (k === 'request_source') return '';
      if (k === 'title') return pick(POOLS.title, i);
      if (k === 'meta_title') return `${pick(POOLS.title, i)} | ${client.name}`;
      if (k === 'ads_account_ref') return `${100 + i}-${200 + i * 3}-${7000 + i}`;
      if (k === 'analytics_property_ref') return `G-DEMO${1000 + i}`;
      if (k === 'gtm_container_ref') return `GTM-DEMO${i}${i + 3}`;
      if (k === 'vault_ref') return `Vault: domains / entry ${i + 1}`;
      if (k === 'dimensions') return pick(['600 × 300 px', '1080 × 1080 px', '1200 × 628 px', '1080 × 1920 px'], i);
      if (k === 'channel_name') return `${client.name} Official`;
      if (k === 'channel_id') return `UC-DEMO-${1000 + i}`;
      if (k === 'creative_task_ref' || k === 'source_ref') return '';
      if (POOLS[k]) return pick(POOLS[k], i);
      return f.required ? `${f.label} ${i + 1}` : '';
    }
    default: return '';
  }
}

function num(k: string, i: number, r: () => number): number {
  const between = (a: number, b: number) => Math.round(a + r() * (b - a));
  if (k === 'page_speed') return Math.round((1 + r() * 4.5) * 10) / 10;
  if (k.endsWith('_score')) return between(42, 98);
  if (k === 'cost') return between(5, 150) * 100;
  if (k === 'members') return between(80, 3200);
  if (k === 'year') return 2026;
  if (k === 'engagement_rate') return between(38, 82);
  if (k === 'organic_clicks') return between(120, 2400);
  if (k === 'organic_impressions') return between(4000, 52000);
  if (k === 'avg_position') return Math.round((4 + r() * 22) * 10) / 10;
  if (k === 'years_operating') return between(2, 30);
  if (k === 'target') return between(2, 6);
  if (k === 'spend') return between(800, 6500);
  if (k === 'users') return between(240, 3400);
  if (k === 'conversions') return between(2, 42);
  void i;
  return between(1, 500);
}

/** Cross-field consistency for report-style modules. */
function overrides(m: ModuleDef, rec: Record<string, any>, { i, clients }: Ctx, r: () => number) {
  if (m.key === 'mailer-reports') {
    const total = 800 + Math.floor(r() * 4200);
    rec.total_recipients = total;
    rec.bounced = Math.round(total * (0.01 + r() * 0.03));
    rec.delivered = total - rec.bounced;
    rec.opened = Math.round(rec.delivered * (0.18 + r() * 0.24));
    rec.clicked = Math.round(rec.delivered * (0.02 + r() * 0.06));
    rec.unsubscribed = Math.round(rec.delivered * r() * 0.01);
    rec.unique_opens = Math.round(rec.opened * (0.7 + r() * 0.2));
    rec.unique_clicks = Math.round(rec.clicked * (0.7 + r() * 0.2));
    rec.spam_complaints = Math.round(rec.delivered * r() * 0.0008);
    rec.metrics_source = 'Provider report (imported by hand)';
  } else if (m.key === 'google-ads') {
    rec.impressions = 4000 + Math.floor(r() * 36000);
    rec.clicks = Math.round(rec.impressions * (0.015 + r() * 0.05));
    rec.spend = Math.round(rec.clicks * (8 + r() * 24));
    rec.conversions = Math.round(rec.clicks * (0.03 + r() * 0.09));
    rec.conversion_value = i % 3 === 0 ? null : Math.round(rec.conversions * (900 + r() * 1600));
    rec.log_date = addDays(-i);
  } else if (m.key === 'google-analytics') {
    rec.sessions = Math.round(rec.users * (1.1 + r() * 0.5));
    rec.new_users = Math.round(rec.users * (0.55 + r() * 0.25));
    rec.page_views = Math.round(rec.sessions * (1.6 + r() * 1.4));
    rec.report_date = addDays(-i);
  } else if (m.acceptsRequests) {
    rec.thumbnail = thumb(String(rec.task), i);
    rec.request_source = i % 4 === 1 ? 'Marketing · Mailer Scheduler' : '';
    rec.date_assigned = addDays(-(2 + (i % 6)));
  }
  void isoDate;
}

// ───────── demo tasks (sample data: spread over ~4 months so performance reports have history) ─────────
const TASK_TITLES: Record<WorkTeam, string[]> = {
  development: ['Update plugin set', 'Fix mobile menu overflow', 'Migrate hosting plan', 'Install tracking tags', 'Speed optimisation pass', 'Contact form testing', 'Security hardening', 'Schema markup rollout', 'Staging to live deploy', 'Broken link clean-up'],
  marketing: ['Plan monthly content calendar', 'Set up Google Ads campaign', 'Write email newsletter', 'Community post series', 'Monthly report summary', 'Blog outline batch', 'YouTube description refresh', 'Audience research brief', 'Festival offer campaign', 'Lead follow-up sheet'],
  creative: ['Social media carousel', 'Landing page banner set', 'Reel edit and captions', 'Brand colour guide sheet', 'Doctor profile poster', 'Email header artwork', 'Video thumbnail pack', 'Awareness-day creative', 'Clinic brochure layout', 'Animated logo sting'],
};

export function buildDemoTasks(users: Profile[], clients: Client[], idFn: () => string): Task[] {
  const r = rng(777);
  const out: Task[] = [];
  const teams: WorkTeam[] = ['development', 'marketing', 'creative'];
  const dayOf = (offset: number) => addDays(offset);
  const at = (date: string, h = 10) => new Date(`${date}T${String(h).padStart(2, '0')}:00:00`).toISOString();
  const capNow = (iso: string) => (iso > new Date().toISOString() ? new Date().toISOString() : iso);
  const today = todayISO();
  for (const team of teams) {
    const members = users.filter((u) => u.team === team && u.role === 'member');
    const lead = users.find((u) => u.team === team && u.role === 'lead');
    if (!members.length) continue;
    for (let i = 0; i < 30; i++) {
      const who = members[i % members.length];
      const quality = 0.55 + 0.4 * (((i % members.length) + 1) / (members.length + 1)); // each person has a steady quality level
      const ago = i < 6 ? Math.floor(r() * 10) : 8 + Math.floor(r() * 115);
      const assigned = dayOf(-ago);
      const due = addDays(3 + Math.floor(r() * 12), new Date(assigned + 'T00:00:00'));
      const client = clients[(i * 3 + teams.indexOf(team)) % clients.length];
      const withReviewer = r() < 0.85 && !!lead;
      let status: Task['status'] = 'In Progress';
      let review: Task['review_status'] = 'None';
      let rating: number | null = null;
      let completed: string | null = null;
      const x = r();
      if (due < today) {
        if (x < 0.8) {
          status = 'Completed';
          const lateDays = r() < quality ? -Math.floor(r() * 3) : 1 + Math.floor(r() * 5);
          completed = capNow(at(addDays(lateDays, new Date(due + 'T00:00:00')), 9 + Math.floor(r() * 8)));
          if (withReviewer) {
            review = 'Approved';
            rating = Math.max(1, Math.min(5, Math.round(2.2 + quality * 3 + (r() - 0.5))));
          }
        } else if (x < 0.9) status = 'In Progress';
        else if (x < 0.95) { status = 'Changes Requested'; review = 'Changes Requested'; }
        else status = 'Cancelled';
      } else {
        status = x < 0.25 ? 'New' : x < 0.55 ? 'Assigned' : x < 0.85 ? 'In Progress' : 'Submitted for Review';
        if (status === 'Submitted for Review') review = withReviewer ? 'Requested' : 'None';
        if (status === 'Submitted for Review' && !withReviewer) status = 'In Progress';
      }
      const created = at(assigned, 9);
      out.push({
        id: idFn(), title: `${TASK_TITLES[team][i % 10]} · ${client.name.split(' ')[0]}`, description: 'Sample task generated for demo data.', client_id: client.id, team,
        assigned_to: who.id, created_by: lead?.id ?? who.id, reviewer_id: withReviewer ? lead!.id : null,
        priority: (['Low', 'Medium', 'Medium', 'High', 'Urgent'] as const)[Math.floor(r() * 5)], status, review_status: review, review_rating: rating,
        date_assigned: assigned, due_date: due, output_link: status === 'Completed' ? `https://drive.google.com/example/${i}` : null, thumbnail: null, remarks: null,
        completed_at: completed, created_at: created, updated_at: completed ?? created,
      });
    }
  }
  return out;
}
