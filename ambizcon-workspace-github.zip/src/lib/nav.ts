import type { Team } from './types';
import { MODULES, modulesOf, type ModuleDef } from './modules';
import { moduleHref, TEAM_LABEL } from './access';

export interface NavItem {
  label: string;
  href: string;
  icon: string;
}

export interface Layout { hidden: string[]; order: Record<string, string[]> }

const ADMIN_NAV: NavItem[] = [
  { label: 'Dashboard', href: '/admin', icon: 'LayoutDashboard' },
  { label: 'Admin Overview', href: '/admin/overview', icon: 'MonitorCheck' },
  { label: 'All Teams', href: '/admin/teams', icon: 'Users' },
  { label: 'Clients', href: '/clients', icon: 'Building2' },
  { label: 'Tasks', href: '/tasks', icon: 'ListChecks' },
  { label: 'Development', href: '/development', icon: 'Code2' },
  { label: 'Marketing', href: '/marketing', icon: 'Megaphone' },
  { label: 'Creative', href: '/creative', icon: 'Palette' },
  { label: 'Performance', href: '/admin/performance', icon: 'Trophy' },
  { label: 'Expiry Management', href: '/admin/expiry-management', icon: 'CalendarClock' },
  { label: 'Reports', href: '/admin/reports', icon: 'ChartPie' },
  { label: 'Employees', href: '/admin/users', icon: 'UserCog' },
  { label: 'Customization', href: '/admin/customization', icon: 'SlidersHorizontal' },
  { label: 'Audit Log', href: '/development/user-logs', icon: 'ScrollText' },
  { label: 'AI Assistant', href: '/ai-assistant', icon: 'Bot' },
  { label: 'Notifications', href: '/notifications', icon: 'Bell' },
  { label: 'Motivation', href: '/motivation', icon: 'Sparkles' },
  { label: 'Settings', href: '/settings', icon: 'Settings' },
];

/**
 * Sidebar for a team member. `modules` is every module the person may open (own team, plus any an admin granted), already
 * including admin-built registers. Admin-hidden modules are removed and admin-chosen order is applied.
 */
export function buildNav(team: Team, modules: ModuleDef[], layout: Layout = { hidden: [], order: {} }): NavItem[] {
  if (team === 'admin') return ADMIN_NAV;
  const base: NavItem[] = [{ label: 'Dashboard', href: `/${team}`, icon: 'LayoutDashboard' }, { label: 'Client List', href: '/clients', icon: 'Building2' }, { label: 'Tasks', href: '/tasks', icon: 'ListChecks' }];
  if (team === 'creative') base.push({ label: 'Adhoc', href: '/creative/adhoc', icon: 'Layers' }, { label: 'Client Briefs', href: '/creative/client-briefs', icon: 'Brush' });
  const visible = modules.filter((m) => !m.group && !layout.hidden.includes(m.key));
  const mine = visible.filter((m) => m.team === team);
  const order = layout.order[team] ?? [];
  const pos = (m: ModuleDef) => { const i = order.indexOf(m.key); return i < 0 ? 1000 + mine.indexOf(m) : i; };
  const sorted = [...mine].sort((a, b) => pos(a) - pos(b));
  const items: NavItem[] = sorted.map((m) => ({ label: m.nav, href: moduleHref(m), icon: m.icon }));
  // computed page (blog counts come from the blog records, not from typed-in numbers)
  if (team === 'marketing') {
    const at = items.findIndex((x) => x.href.endsWith('/blog-youtube'));
    items.splice(at < 0 ? items.length : at + 1, 0, { label: 'Blog Counts', href: '/marketing/blog-counts', icon: 'ChartColumn' });
  }
  const shared = visible.filter((m) => m.team !== team && !(m.readonly && m.key !== 'user-log')).map((m) => ({ label: `${m.nav} · ${TEAM_LABEL[m.team]}`, href: moduleHref(m), icon: m.icon }));
  return [...base, ...items, ...shared];
}

/** Static sidebar (built-in modules only); the app uses buildNav with live permissions and custom modules. */
export const navFor = (team: Team): NavItem[] => buildNav(team, team === 'admin' ? [] : modulesOf(team));
export const ALL_MODULES = MODULES;

export const FOOTER_NAV = (team: Team): NavItem[] => [
  ...(team === 'admin' ? [] : [{ label: 'AI Assistant', href: '/ai-assistant', icon: 'Bot' }, { label: 'Notifications', href: '/notifications', icon: 'Bell' }, { label: 'Motivation', href: '/motivation', icon: 'Sparkles' }]),
  { label: 'Profile', href: '/profile', icon: 'CircleUser' },
  ...(team === 'admin' ? [] : [{ label: 'Settings', href: '/settings', icon: 'Settings' }]),
];
