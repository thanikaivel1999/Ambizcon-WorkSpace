/**
 * Sound-ready architecture: cues are looked up by name and only play when the user has enabled sound
 * in Settings AND an audio file exists at /sounds/<cue>.mp3. Drop files into /public/sounds to activate.
 */
export type Cue = 'complete' | 'notify' | 'welcome';

export const soundEnabled = () => {
  try {
    return localStorage.getItem('amb_sound') === 'on';
  } catch {
    return false;
  }
};
export const setSoundEnabled = (on: boolean) => {
  try {
    localStorage.setItem('amb_sound', on ? 'on' : 'off');
  } catch {
    /* ignore */
  }
};

export function playCue(cue: Cue) {
  if (typeof window === 'undefined' || !soundEnabled()) return;
  const a = new Audio(`/sounds/${cue}.mp3`);
  a.volume = 0.5;
  a.play().catch(() => {});
}
