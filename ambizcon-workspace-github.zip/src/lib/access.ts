import type { Team } from './types';
import type { ModuleDef } from './modules';

export const TEAM_LABEL: Record<Team, string> = { admin: 'Admin', development: 'Development', marketing: 'Marketing', creative: 'Creative' };
export const homePath = (team: Team) => (team === 'admin' ? '/admin' : `/${team}`);
export const moduleHref = (m: ModuleDef) =>
  m.customId ? `/${m.team}/${m.slug}` : m.group === 'brief' ? `/creative/client-briefs?section=${m.slug}` : m.team === 'creative' ? `/creative/adhoc/${m.slug}` : `/${m.team}/${m.slug}`;
export const modulePath = (m: ModuleDef) => moduleHref(m).split('?')[0];

const TEAM_ROOTS = ['development', 'marketing', 'creative'];

/**
 * Single source of truth for route authorization. Used by the edge middleware (server-side)
 * and by the client guard. Database access is separately enforced by Row Level Security.
 */
export function canAccess(team: Team, pathname: string, granted: string[] = []): boolean {
  const root = pathname.split('/')[1] ?? '';
  if (root === 'admin') return team === 'admin';
  if (TEAM_ROOTS.includes(root)) {
    if (team === 'admin' || team === root) return true;
    // another team's area: only the module pages an admin has granted to this team (see Customization Studio → Access)
    const clean = pathname.replace(/\/+$/, '');
    return granted.some((g) => clean === g || clean.startsWith(g + '/'));
  }
  return true;
}
export const isCrossTeamPath = (team: Team, pathname: string) => {
  const root = pathname.split('/')[1] ?? '';
  return team !== 'admin' && TEAM_ROOTS.includes(root) && root !== team;
};
