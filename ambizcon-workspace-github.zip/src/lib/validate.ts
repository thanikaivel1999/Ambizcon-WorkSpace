import { z, type ZodTypeAny } from 'zod';
import type { Field, ModuleDef } from './modules';

const empty = (v: unknown) => v === '' || v === null || v === undefined;

function fieldSchema(f: Field): ZodTypeAny {
  let s: ZodTypeAny;
  switch (f.type) {
    case 'number':
      s = z.preprocess((v) => (empty(v) ? null : Number(v)), z.number({ error: 'Enter a number' }).min(0, 'Must be 0 or more').max(1e9).nullable());
      break;
    case 'bool':
      s = z.preprocess((v) => !!v, z.boolean());
      break;
    case 'url':
      s = z.preprocess(
        (v) => (empty(v) ? null : String(v).trim()),
        z.string().max(2000).refine((v) => /^https?:\/\//i.test(v) || v.startsWith('data:image/'), 'Must start with http:// or https://').nullable(),
      );
      break;
    case 'file':
      s = z.preprocess(
        (v) => (empty(v) ? null : String(v).trim()),
        z.string().max(2_000_000).refine((v) => /^https?:\/\//i.test(v) || v.startsWith('storage://attachments/') || v.startsWith('data:'), 'Upload a file or paste an http(s) link').nullable(),
      );
      break;
    case 'date':
    case 'expiry':
      s = z.preprocess((v) => (empty(v) ? null : v), z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Invalid date').nullable());
      break;
    case 'time':
      s = z.preprocess((v) => (empty(v) ? null : v), z.string().regex(/^\d{2}:\d{2}$/, 'Invalid time').nullable());
      break;
    case 'select':
    case 'check':
      s = z.preprocess((v) => (empty(v) ? null : v), z.string().refine((v) => !f.options || f.options.includes(v), 'Choose a valid option').nullable());
      break;
    case 'image':
      s = z.preprocess((v) => (empty(v) ? null : v), z.string().max(2_000_000).nullable());
      break;
    default:
      s = z.preprocess((v) => (empty(v) ? null : String(v).trim()), z.string().max(f.type === 'longtext' ? 4000 : 300).nullable());
  }
  if (f.required && f.type !== 'bool')
    s = s.refine((v) => !empty(v), { message: `${f.label} is required` });
  return s;
}

export function editableFields(m: ModuleDef) {
  return m.fields.filter((f) => !f.system);
}

export function validateRecord(m: ModuleDef, values: Record<string, unknown>) {
  const data: Record<string, unknown> = {};
  const errors: Record<string, string> = {};
  // an expiry marked "Unknown" must stay empty: dates are never invented
  const unknownDate = values.date_confidence === 'Unknown';
  for (const f of editableFields(m)) {
    if (f.type === 'expiry' && unknownDate) { data[f.key] = null; continue; }
    const r = fieldSchema(f).safeParse(values[f.key]);
    if (r.success) data[f.key] = r.data;
    else errors[f.key] = r.error.issues[0]?.message ?? 'Invalid value';
  }
  if (m.rules) for (const [k, msg] of Object.entries(m.rules({ ...values, ...data }))) if (msg && !errors[k]) errors[k] = msg;
  return { ok: Object.keys(errors).length === 0, data, errors };
}

export const userSchema = z.object({
  name: z.string().trim().min(2, 'Name is required').max(80),
  email: z.string().trim().toLowerCase().email('Enter a valid email'),
  team: z.enum(['admin', 'development', 'marketing', 'creative']),
  role: z.enum(['admin', 'lead', 'member']),
});
