import type { Field, FieldType, ModuleDef } from './modules';
import type { CustomFieldDef, CustomFieldSpec, CustomFieldType, CustomModule, PermLevel, Rec, WorkTeam } from './types';

/** Custom fields on built-in modules live in each row's `custom` object; in the UI they are addressed as `cf_<key>`. */
export const CF_PREFIX = 'cf_';
export const isCfKey = (k: string) => k.startsWith(CF_PREFIX);

const TYPE_MAP: Record<CustomFieldType, FieldType> = {
  text: 'text', longtext: 'longtext', number: 'number', date: 'date', url: 'url', select: 'select', bool: 'bool', file: 'file', client: 'client', user: 'user',
};

export function fieldFromSpec(spec: CustomFieldSpec, keyOf: (k: string) => string = (k) => k): Field {
  const f: Field = { key: keyOf(spec.key), label: spec.label, type: TYPE_MAP[spec.type], required: !!spec.required };
  if (spec.type === 'select') f.options = spec.options ?? [];
  return f;
}

/** A built-in module plus the active custom fields an admin added to it. */
export function withCustomFields(m: ModuleDef, defs: CustomFieldDef[] | undefined): ModuleDef {
  const mine = (defs ?? []).filter((d) => d.module_key === m.key && !d.archived).sort((a, b) => a.position - b.position);
  if (!mine.length) return m;
  const extra = mine.map((d) => fieldFromSpec(d, (k) => CF_PREFIX + k));
  // `remark` stays the last field; extra fields go before it
  const remark = m.fields.findIndex((f) => f.key === 'remark');
  const fields = remark >= 0 ? [...m.fields.slice(0, remark), ...extra, ...m.fields.slice(remark)] : [...m.fields, ...extra];
  return { ...m, fields };
}

/** A module defined in the Customization Studio, shaped like a built-in module so every list/form/filter component works unchanged. */
export function moduleFromCustom(cm: CustomModule): ModuleDef {
  const fields: Field[] = [{ key: 'client_id', label: 'Client', type: 'client' }, ...cm.fields.map((s) => fieldFromSpec(s))];
  const titleField = cm.fields.find((f) => f.type === 'text' && f.required)?.key ?? cm.fields.find((f) => f.type === 'text')?.key ?? 'client_id';
  return {
    key: `custom:${cm.id}`, team: cm.team, slug: cm.slug, title: cm.title, nav: cm.title, table: 'custom_records', icon: cm.icon, blurb: cm.blurb || `Custom register: ${cm.title}`, titleField,
    fields, derived: [], statusField: '', statusLabel: 'Status', hasPriority: false, anim: 'celebrate', customId: cm.id,
    list: ['client_id', ...cm.fields.slice(0, 6).map((f) => f.key)],
  };
}

/** Row ⇄ UI shape for built-in modules: `custom.retention` ⇄ `cf_retention`. */
export function unpackCustom(rec: Rec): Rec {
  const custom = (rec.custom ?? {}) as Record<string, unknown>;
  const out: Rec = { ...rec };
  for (const [k, v] of Object.entries(custom)) out[CF_PREFIX + k] = v;
  return out;
}
export function packCustom(data: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  const custom: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(data)) {
    if (isCfKey(k)) custom[k.slice(CF_PREFIX.length)] = v;
    else out[k] = v;
  }
  if (Object.keys(custom).length) out.custom = custom;
  return out;
}

/** Field key rules shared by the Studio and the database CHECK constraints. */
export const FIELD_KEY_RE = /^[a-z][a-z0-9_]{1,30}$/;
export const SLUG_RE = /^[a-z0-9][a-z0-9-]{1,38}$/;
export const slugify = (s: string) => s.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 39);
export const keyify = (s: string) => {
  const k = s.toLowerCase().trim().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 31);
  return /^[a-z]/.test(k) ? k : `f_${k}`.slice(0, 31);
};

// ───────── permissions ─────────
export type PermMap = Record<string, PermLevel>; // `${team}:${moduleKey}` → level
export const permKey = (team: string, moduleKey: string) => `${team}:${moduleKey}`;
export const toPermMap = (rows: { team: string; module_key: string; level: PermLevel }[]): PermMap => Object.fromEntries(rows.map((r) => [permKey(r.team, r.module_key), r.level]));

/** Effective access of a team to a module: admin always writes; an override wins; otherwise own team writes and others have none. */
export function levelFor(team: string, m: Pick<ModuleDef, 'key' | 'team'>, perms: PermMap): PermLevel {
  if (team === 'admin') return 'write';
  const o = perms[permKey(team, m.key)];
  if (o) return o;
  return m.team === (team as WorkTeam) ? 'write' : 'none';
}
