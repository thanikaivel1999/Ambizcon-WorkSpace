import type { ModuleDef } from './modules';
import { dueOf, effStatus } from './stats';
import type { Rec } from './types';
import { expiryInfo } from './utils';

export interface Filters {
  q: string;
  status: string;
  priority: string;
  assigned: string;
  client: string;
  from: string;
  to: string;
  year: string;
  tier: string;
}
export const EMPTY_FILTERS: Filters = { q: '', status: '', priority: '', assigned: '', client: '', from: '', to: '', year: '', tier: '' };
export const isFiltered = (f: Filters) => (Object.keys(f) as (keyof Filters)[]).some((k) => f[k] !== '');

interface Names {
  user(id?: string | null): string;
  client(id?: string | null): string;
}

export function searchText(m: ModuleDef, r: Rec, n: Names) {
  const parts: string[] = [n.client(r.client_id)];
  for (const f of m.fields) {
    const v = r[f.key];
    if (v == null || v === '') continue;
    if (f.type === 'user') parts.push(n.user(v));
    else if (f.type === 'text' || f.type === 'longtext' || f.type === 'select' || f.type === 'check' || f.type === 'number' || f.type === 'date') parts.push(String(v));
  }
  return parts.join(' ').toLowerCase();
}

/** Modules with their own status vocabulary (e.g. Submitted for Review) filter on the raw value; "Overdue" is always computed. */
export function matchesStatus(m: ModuleDef, r: Rec, wanted: string) {
  const eff = effStatus(m, r);
  if (wanted === 'Overdue') return eff === 'Overdue';
  const raw = m.fields.find((x) => x.key === m.statusField)?.options;
  if (raw && raw.includes(wanted)) return r[m.statusField] === wanted && eff !== 'Overdue';
  return eff === wanted;
}

export function applyFilters(m: ModuleDef, rows: Rec[], f: Filters, n: Names): Rec[] {
  const q = f.q.trim().toLowerCase();
  return rows.filter((r) => {
    if (q && !searchText(m, r, n).includes(q)) return false;
    if (f.status && !matchesStatus(m, r, f.status)) return false;
    if (f.priority && r.priority !== f.priority) return false;
    if (f.assigned && !m.fields.some((x) => x.type === 'user' && r[x.key] === f.assigned)) return false;
    if (f.client && r.client_id !== f.client) return false;
    if (f.year && String(r[m.yearField ?? 'year']) !== f.year) return false;
    if (f.tier && !m.fields.some((x) => x.type === 'expiry' && expiryInfo(r[x.key])?.tier === f.tier)) return false;
    if (f.from || f.to) {
      const d = dueOf(m, r) ?? r.created_at.slice(0, 10);
      if (f.from && d < f.from) return false;
      if (f.to && d > f.to) return false;
    }
    return true;
  });
}
