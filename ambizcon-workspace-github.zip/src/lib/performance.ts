import { isVerified } from './taskflow';
import type { Priority, Task, WorkTeam } from './types';

/**
 * Performance scoring. Pure functions over normalised work items, so the same engine can score tasks today
 * and module records later.
 *
 * Method (shown to admins on the Performance page):
 *  - On-time rate    = completed on/before due date ÷ (completed with a due date + still-open items already past due).
 *                      Open overdue work therefore counts as a miss; it is not ignored.
 *  - Quality         = mean reviewer rating (1–5) over completed items that were actually rated, scaled to 0–1.
 *                      Items with no rating are ignored, never treated as zero.
 *  - Verified rate   = completed items approved by a reviewer ÷ completed items. Self-reported completions are not verified.
 *  - Priority        = mean priority weight of completed items (Low .25 · Medium .5 · High .75 · Urgent 1). A mean, not a sum,
 *                      so doing more tasks does not raise the score.
 *  - Overdue         = 1 − open-overdue ÷ (open + completed in period). Default weight 0; raise it to penalise open overdue work.
 *  - Composite       = Σ weight × component ÷ Σ weight over the components that have data, × 100.
 *                      A person needs `minCompleted` completed items in the period to be ranked (avoids one-task winners).
 */
export interface ScoringWeights { onTime: number; quality: number; verified: number; priority: number; overdue: number; minCompleted: number }
export const DEFAULT_WEIGHTS: ScoringWeights = { onTime: 40, quality: 30, verified: 20, priority: 10, overdue: 0, minCompleted: 3 };
export const PRIORITY_WEIGHT: Record<Priority, number> = { Low: 0.25, Medium: 0.5, High: 0.75, Urgent: 1 };
export const COMPANY_TZ = 'Asia/Kolkata';

export interface WorkItem {
  id: string;
  assignee: string | null;
  team: WorkTeam;
  client_id: string | null;
  priority: Priority;
  assigned_on: string | null; // YYYY-MM-DD
  due_on: string | null;
  completed_on: string | null; // YYYY-MM-DD in the company time zone
  completed_ts: string | null;
  state: 'open' | 'done' | 'cancelled';
  verified: boolean;
  rating: number | null;
}

export interface Period { from: string; to: string; label: string }

export const dayInTz = (iso: string, tz = COMPANY_TZ) => new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date(iso));

export function taskToWorkItem(t: Task, tz = COMPANY_TZ): WorkItem {
  const done = t.status === 'Completed' && !!t.completed_at;
  return {
    id: t.id, assignee: t.assigned_to, team: t.team, client_id: t.client_id, priority: t.priority,
    assigned_on: t.date_assigned, due_on: t.due_date,
    completed_on: done ? dayInTz(t.completed_at!, tz) : null, completed_ts: done ? t.completed_at : null,
    state: done ? 'done' : t.status === 'Cancelled' ? 'cancelled' : 'open',
    verified: isVerified(t), rating: done && t.review_status === 'Approved' ? t.review_rating : null,
  };
}

const mean = (xs: number[]) => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : null);
const days = (a: string, b: string) => Math.round((Date.parse(b + 'T00:00:00Z') - Date.parse(a + 'T00:00:00Z')) / 86400000);

export interface Metrics {
  assigned: number;
  completed: number;
  pending: number;
  overdue: number;
  onTimeRate: number | null;
  avgCompletionDays: number | null;
  quality: number | null; // mean rating 1–5
  ratedCount: number;
  verifiedRate: number | null;
  verifiedCount: number;
  priorityMean: number | null;
  /** 0–100, or null when the person has too little completed work in the period to be ranked. */
  score: number | null;
  /** Which components contributed (for transparency). */
  used: Record<'onTime' | 'quality' | 'verified' | 'priority' | 'overdue', boolean>;
  eligible: boolean;
}

export function computeMetrics(items: WorkItem[], p: { from: string; to: string }, today: string, w: ScoringWeights = DEFAULT_WEIGHTS): Metrics {
  const inP = (d: string | null) => !!d && d >= p.from && d <= p.to;
  const assigned = items.filter((i) => i.state !== 'cancelled' && inP(i.assigned_on));
  const completed = items.filter((i) => i.state === 'done' && inP(i.completed_on));
  // work that was still open at the end of the period: assigned by then and not yet completed by then
  const open = items.filter((i) => !!i.assigned_on && i.assigned_on <= p.to && (i.state === 'open' || (i.state === 'done' && !!i.completed_on && i.completed_on > p.to)));
  const asOf = p.to < today ? p.to : today;
  const openOverdue = open.filter((i) => i.due_on && i.due_on < asOf);

  const withDue = completed.filter((i) => i.due_on);
  const onTimeDone = withDue.filter((i) => i.completed_on! <= i.due_on!).length;
  const dueBase = withDue.length + openOverdue.length;
  const onTimeRate = dueBase ? onTimeDone / dueBase : null;

  const spans = completed.filter((i) => i.assigned_on).map((i) => Math.max(0, days(i.assigned_on!, i.completed_on!)));
  const ratings = completed.map((i) => i.rating).filter((r): r is number => r !== null);
  const verifiedCount = completed.filter((i) => i.verified).length;
  const verifiedRate = completed.length ? verifiedCount / completed.length : null;
  const priorityMean = mean(completed.map((i) => PRIORITY_WEIGHT[i.priority]));
  const quality = mean(ratings);
  const overdueBase = open.length + completed.length;
  const overdueComp = overdueBase ? 1 - openOverdue.length / overdueBase : null;

  const comps: [keyof Metrics['used'], number, number | null][] = [
    ['onTime', w.onTime, onTimeRate],
    ['quality', w.quality, quality === null ? null : (quality - 1) / 4],
    ['verified', w.verified, verifiedRate],
    ['priority', w.priority, priorityMean],
    ['overdue', w.overdue, overdueComp],
  ];
  const used = { onTime: false, quality: false, verified: false, priority: false, overdue: false };
  let num = 0, den = 0;
  for (const [k, weight, value] of comps) if (weight > 0 && value !== null) { used[k] = true; num += weight * value; den += weight; }
  const eligible = completed.length >= w.minCompleted && den > 0;
  return {
    assigned: assigned.length, completed: completed.length, pending: open.length, overdue: openOverdue.length,
    onTimeRate, avgCompletionDays: mean(spans), quality, ratedCount: ratings.length, verifiedRate, verifiedCount, priorityMean,
    score: eligible ? Math.round((num / den) * 1000) / 10 : null, used, eligible,
  };
}

export interface Ranked<K> { key: K; metrics: Metrics }

/** Rank groups (employees or teams). Ineligible groups are listed after the ranked ones. */
export function rankBy<K extends string>(items: WorkItem[], keyOf: (i: WorkItem) => K | null, p: Period, today: string, w: ScoringWeights): Ranked<K>[] {
  const groups = new Map<K, WorkItem[]>();
  for (const i of items) {
    const k = keyOf(i);
    if (k) (groups.get(k) ?? groups.set(k, []).get(k)!).push(i);
  }
  return [...groups].map(([key, its]) => ({ key, metrics: computeMetrics(its, p, today, w) }))
    .sort((a, b) => (b.metrics.score ?? -1) - (a.metrics.score ?? -1) || b.metrics.completed - a.metrics.completed);
}

// ───────── periods ─────────
const pad = (n: number) => String(n).padStart(2, '0');
const lastDay = (y: number, m0: number) => new Date(Date.UTC(y, m0 + 1, 0)).getUTCDate();
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

export const monthPeriod = (y: number, m0: number): Period => ({ from: `${y}-${pad(m0 + 1)}-01`, to: `${y}-${pad(m0 + 1)}-${pad(lastDay(y, m0))}`, label: `${MONTHS[m0]} ${y}` });
export const quarterPeriod = (y: number, q0: number): Period => ({ from: `${y}-${pad(q0 * 3 + 1)}-01`, to: `${y}-${pad(q0 * 3 + 3)}-${pad(lastDay(y, q0 * 3 + 2))}`, label: `Q${q0 + 1} ${y}` });
export const yearPeriod = (y: number): Period => ({ from: `${y}-01-01`, to: `${y}-12-31`, label: String(y) });

/** The three most recent *completed* calendar months before `today` (the running month is never included). */
export function lastThreeCompletedMonths(today: string): Period {
  const [y, m] = today.split('-').map(Number);
  const months = [3, 2, 1].map((back) => {
    const d = new Date(Date.UTC(y, m - 1 - back, 1));
    return monthPeriod(d.getUTCFullYear(), d.getUTCMonth());
  });
  return { from: months[0].from, to: months[2].to, label: `${months[0].label} – ${months[2].label}` };
}

/** Month-by-month history ending with the latest completed month. */
export function monthlyHistory(today: string, count: number): Period[] {
  const [y, m] = today.split('-').map(Number);
  return Array.from({ length: count }, (_, i) => {
    const d = new Date(Date.UTC(y, m - 1 - (count - i), 1));
    return monthPeriod(d.getUTCFullYear(), d.getUTCMonth());
  });
}

export function normalizeWeights(w: Partial<ScoringWeights> | null | undefined): ScoringWeights {
  const out = { ...DEFAULT_WEIGHTS };
  if (!w) return out;
  for (const k of Object.keys(out) as (keyof ScoringWeights)[]) {
    const v = Number(w[k]);
    if (Number.isFinite(v) && v >= 0 && v <= 1000) out[k] = v;
  }
  return out;
}
