import { moduleHref } from './access';
import { DAILY_CHECKS, MODULE_BY_KEY, type ModuleDef } from './modules';
import type { AppNotification, Rec, Status, Team } from './types';
import { addDays, daysUntil, expiryInfo, isoDate, todayISO } from './utils';

export interface Item {
  m: ModuleDef;
  rec: Rec;
}

/** Normalized status of a record, with automatic Overdue calculation. */
export function effStatus(m: ModuleDef, rec: Rec): Status | null {
  if (!m.statusField) return null;
  const raw = rec[m.statusField] as string | undefined;
  const st = ((m.statusMap ? m.statusMap[raw ?? ''] : raw) ?? 'Pending') as Status;
  if (st === 'Completed' || st === 'Cancelled') return st;
  const due = dueOf(m, rec);
  if (due && due < todayISO() && st !== 'On Hold') return 'Overdue';
  return st;
}

export const dueOf = (m: ModuleDef, rec: Rec): string | null => (m.dueField ? (rec[m.dueField] as string) || null : null);

/** The date a record "belongs to" for Today / Week / Month bucketing. */
const dateOf = (m: ModuleDef, rec: Rec) => dueOf(m, rec) ?? rec.created_at.slice(0, 10);

export function weekRange(ref = new Date()) {
  const d = new Date(ref);
  const diff = (d.getDay() + 6) % 7; // Monday start
  const start = new Date(d);
  start.setDate(d.getDate() - diff);
  return { from: isoDate(start), to: addDays(6, start) };
}
export const monthRange = (ref = new Date()) => ({
  from: isoDate(new Date(ref.getFullYear(), ref.getMonth(), 1)),
  to: isoDate(new Date(ref.getFullYear(), ref.getMonth() + 1, 0)),
});

export interface Summary {
  total: number;
  completed: number;
  pending: number;
  inProgress: number;
  overdue: number;
  onHold: number;
  today: number;
  week: number;
  month: number;
  activityToday: number;
  progress: number;
}

export function summarize(items: Item[]): Summary {
  const s: Summary = { total: 0, completed: 0, pending: 0, inProgress: 0, overdue: 0, onHold: 0, today: 0, week: 0, month: 0, activityToday: 0, progress: 0 };
  const today = todayISO();
  const w = weekRange();
  const mo = monthRange();
  for (const { m, rec } of items) {
    const st = effStatus(m, rec);
    if (!st) continue;
    s.total++;
    if (st === 'Completed') s.completed++;
    else if (st === 'Pending') s.pending++;
    else if (st === 'In Progress') s.inProgress++;
    else if (st === 'Overdue') s.overdue++;
    else if (st === 'On Hold') s.onHold++;
    const dt = dateOf(m, rec);
    if (dt === today) s.today++;
    if (dt >= w.from && dt <= w.to) s.week++;
    if (dt >= mo.from && dt <= mo.to) s.month++;
    if (rec.updated_at.slice(0, 10) === today || rec.created_at.slice(0, 10) === today) s.activityToday++;
  }
  const active = s.total - items.filter(({ m, rec }) => effStatus(m, rec) === 'Cancelled').length;
  s.progress = active ? Math.round((s.completed / active) * 100) : 0;
  return s;
}

export const isExpiryWatched = (m: ModuleDef) => !!m.expiryField;

/** Count of today's daily-check records by outcome. */
export function dailyCheckSummary(items: Item[]) {
  const today = todayISO();
  const rows = items.filter(({ m, rec }) => m.key === 'daily-check' && rec.check_date === today).map((i) => i.rec);
  const checks = DAILY_CHECKS.map(([k]) => k);
  const failed = rows.filter((r) => checks.some((k) => r[k] === 'Fail')).length;
  const warning = rows.filter((r) => !checks.some((k) => r[k] === 'Fail') && checks.some((k) => r[k] === 'Warning')).length;
  const completed = rows.filter((r) => r.status === 'Completed' && !checks.some((k) => r[k] === 'Fail' || r[k] === 'Warning')).length;
  const pending = rows.length - failed - warning - completed;
  return { total: rows.length, completed, warning, failed, pending };
}

/** Alerts derived from live data. Stable ids so read-state can persist locally. */
export function computeAlerts(items: Item[], team: Team): AppNotification[] {
  const out: AppNotification[] = [];
  const today = todayISO();
  const mk = (kind: AppNotification['kind'], m: ModuleDef, rec: Rec, title: string, body: string): AppNotification => ({
    id: `alert:${kind}:${m.key}:${rec.id}`,
    user_id: null,
    team: null,
    kind,
    title,
    body,
    link: `${moduleHref(m)}${moduleHref(m).includes('?') ? '&' : '?'}open=${rec.id}`,
    read: false,
    created_at: rec.updated_at,
  });
  const label = (m: ModuleDef, rec: Rec) => String(rec[m.titleField] ?? m.title);
  for (const { m, rec } of items) {
    for (const f of m.fields.filter((x) => x.type === 'expiry')) {
      const info = expiryInfo(rec[f.key]);
      if (info && info.days <= 30 && rec.status !== 'Completed') {
        const when = info.days < 0 ? `expired ${-info.days} day(s) ago` : `expires in ${info.days} day(s)`;
        out.push(mk('expiry', m, rec, `${m.title}: ${label(m, rec)} (${f.label})`, `${when}`));
      }
    }
    const st = effStatus(m, rec);
    if (!st || st === 'Completed' || st === 'Cancelled') continue;
    if (st === 'Overdue' && !m.expiryField) out.push(mk('overdue', m, rec, 'Task overdue', `${label(m, rec)} · ${m.title}`));
    else if (dueOf(m, rec) === today && !m.expiryField) out.push(mk('due', m, rec, 'Task due today', `${label(m, rec)} · ${m.title}`));
    if (rec.priority === 'Urgent' && team === 'admin') out.push(mk('priority', m, rec, `${rec.priority} priority task`, `${label(m, rec)} · ${m.title}`));
    if (m.acceptsRequests && rec.request_source && daysUntil(rec.created_at.slice(0, 10)) >= -7 && st === 'Pending')
      out.push(mk('creative', m, rec, 'New creative request', `${label(m, rec)} · from ${rec.request_source}`));
  }
  for (const { m, rec } of items)
    if (m.key === 'daily-check' && rec.check_date === today && DAILY_CHECKS.some(([k]) => rec[k] === 'Fail'))
      out.push(mk('check', m, rec, 'Failed daily website check', String(rec.website)));
  const rank: Record<string, number> = { check: 0, expiry: 1, overdue: 2, priority: 3, creative: 4, due: 5 };
  const cap: Record<string, number> = { check: 6, expiry: 14, overdue: 6, priority: 5, creative: 6, due: 6 };
  const used: Record<string, number> = {};
  return out.sort((a, b) => (rank[a.kind] ?? 9) - (rank[b.kind] ?? 9)).filter((a) => (used[a.kind] = (used[a.kind] ?? 0) + 1) <= (cap[a.kind] ?? 6));
}

export const moduleOfAlert = (a: AppNotification) => MODULE_BY_KEY[a.id.split(':')[2]];
