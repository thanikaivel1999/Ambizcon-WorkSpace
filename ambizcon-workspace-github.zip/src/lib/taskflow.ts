import type { Profile, ReviewStatus, Task, TaskStatus } from './types';

/**
 * Task workflow rules. This module is the single TypeScript statement of the rules; the SQL trigger
 * `tasks_guard` in supabase/migrations/0004_clients_tasks.sql enforces the same rules in the database.
 *
 *  - Submit for review  → needs a reviewer; sets review_status = Requested.
 *  - Approve / request changes → only the reviewer (or an admin); a reviewer cannot approve their own task unless admin.
 *  - Completed → if a reviewer is set, the task must be Approved first. Without a reviewer the completion is
 *    self-reported and is NOT counted as verified.
 *  - "Approved" status can only be reached through a recorded approval.
 */
export type Actor = Pick<Profile, 'id' | 'team' | 'role'>;
export interface TransitionEvent { action: string; detail: string }
export type Transition = { ok: true; next: Partial<Task>; events: TransitionEvent[] } | { ok: false; error: string };

export const isVerified = (t: Pick<Task, 'status' | 'review_status'>) => t.status === 'Completed' && t.review_status === 'Approved';

export function applyTaskTransition(before: Task, patch: Partial<Task>, actor: Actor, now = new Date().toISOString()): Transition {
  const next: Partial<Task> = { ...patch };
  const events: TransitionEvent[] = [];
  const merged = { ...before, ...patch };
  const isAdmin = actor.team === 'admin';
  const isReviewer = !!merged.reviewer_id && merged.reviewer_id === actor.id;

  const reviewChanged = patch.review_status !== undefined && patch.review_status !== before.review_status;
  if (reviewChanged) {
    const rs = patch.review_status as ReviewStatus;
    if (rs === 'Approved' || rs === 'Changes Requested') {
      if (!isAdmin && !isReviewer) return { ok: false, error: 'Only the assigned reviewer (or an admin) can approve or request changes.' };
      if (!isAdmin && merged.assigned_to === actor.id) return { ok: false, error: 'You cannot review your own task.' };
      if (before.review_status !== 'Requested' && !isAdmin) return { ok: false, error: 'This task has not been submitted for review.' };
      if (rs === 'Approved') {
        next.status = 'Approved';
        events.push({ action: 'approved', detail: 'Task approved by reviewer' });
      } else {
        next.status = 'Changes Requested';
        events.push({ action: 'changes', detail: 'Reviewer requested changes' });
      }
    } else if (rs === 'Requested') {
      if (!merged.reviewer_id) return { ok: false, error: 'Choose a reviewer before requesting a review.' };
      next.status = 'Submitted for Review';
      events.push({ action: 'review', detail: 'Submitted for review' });
    } else if (rs === 'None') {
      if (!isAdmin) return { ok: false, error: 'Only an admin can reset a review.' };
    }
  }

  if (patch.review_rating !== undefined && patch.review_rating !== null) {
    if (!Number.isInteger(patch.review_rating) || patch.review_rating < 1 || patch.review_rating > 5) return { ok: false, error: 'Rating must be a whole number from 1 to 5.' };
    if (!isAdmin && !isReviewer) return { ok: false, error: 'Only the reviewer can record a rating.' };
  }

  const status = (next.status ?? merged.status) as TaskStatus;
  const statusChanged = patch.status !== undefined && patch.status !== before.status && !reviewChanged;
  if (statusChanged) {
    if (status === 'Submitted for Review') {
      if (!merged.reviewer_id) return { ok: false, error: 'Choose a reviewer before submitting for review.' };
      next.review_status = 'Requested';
      events.push({ action: 'review', detail: 'Submitted for review' });
    } else if (status === 'Approved' && merged.review_status !== 'Approved') {
      return { ok: false, error: 'A task can only be Approved by its reviewer.' };
    } else if (status === 'Completed') {
      if (merged.reviewer_id && merged.review_status !== 'Approved') return { ok: false, error: 'This task needs reviewer approval before it can be completed.' };
    }
  }

  const finalStatus = (next.status ?? merged.status) as TaskStatus;
  if (finalStatus === 'Completed' && before.status !== 'Completed') {
    next.completed_at = now;
    events.push({ action: 'completed', detail: merged.review_status === 'Approved' ? 'Completed (verified by review)' : 'Completed (self-reported, unverified)' });
  } else if (finalStatus !== 'Completed' && before.status === 'Completed') {
    next.completed_at = null;
    events.push({ action: 'reopened', detail: `Reopened as ${finalStatus}` });
  } else if (statusChanged && !events.length) {
    events.push({ action: 'status', detail: `Status changed to ${finalStatus}` });
  }
  if (patch.assigned_to !== undefined && patch.assigned_to !== before.assigned_to) events.push({ action: 'assigned', detail: 'Assignee changed' });
  if (!events.length && Object.keys(patch).length) events.push({ action: 'updated', detail: 'Task details updated' });
  return { ok: true, next, events };
}

export const isOverdue = (t: Pick<Task, 'status' | 'due_date'>, today: string) =>
  !!t.due_date && t.due_date < today && !['Completed', 'Approved', 'Cancelled'].includes(t.status);
