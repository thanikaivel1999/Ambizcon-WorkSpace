import { mkdir, readFile, rename, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { NextResponse } from 'next/server';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * Local JSON file store for demo mode: keeps the whole demo database in ./data/local-db.json so it survives browser
 * clears and is shared by every browser on this computer. Local use only: it is switched off on a production build
 * unless LOCAL_JSON_DB=1, it is never used when Supabase is configured, and it only answers requests addressed to localhost.
 */
const FILE = path.join(process.cwd(), 'data', 'local-db.json');
const MAX_BYTES = 25 * 1024 * 1024;

const enabled = () => !process.env.NEXT_PUBLIC_SUPABASE_URL && (process.env.NODE_ENV !== 'production' || process.env.LOCAL_JSON_DB === '1');
const local = (req: Request) => /^(localhost|127\.0\.0\.1|\[::1\])(:\d+)?$/.test(req.headers.get('host') ?? '');
const refuse = () => NextResponse.json({ error: 'Local JSON store is not available here.' }, { status: 404 });

export async function GET(req: Request) {
  if (!enabled() || !local(req)) return refuse();
  try {
    return new NextResponse(await readFile(FILE, 'utf8'), { headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' } });
  } catch {
    return new NextResponse(null, { status: 204 }); // enabled, but nothing saved yet
  }
}

export async function PUT(req: Request) {
  if (!enabled() || !local(req)) return refuse();
  const text = await req.text();
  if (text.length > MAX_BYTES) return NextResponse.json({ error: 'Data too large.' }, { status: 413 });
  try {
    const parsed = JSON.parse(text);
    if (!parsed || typeof parsed !== 'object' || !Array.isArray(parsed.users) || !Array.isArray(parsed.clients)) throw new Error('shape');
  } catch {
    return NextResponse.json({ error: 'Not a valid database file.' }, { status: 400 });
  }
  await mkdir(path.dirname(FILE), { recursive: true });
  const tmp = `${FILE}.tmp`;
  await writeFile(tmp, text, 'utf8');
  await rename(tmp, FILE); // atomic replace: a crash mid-write cannot leave a half-written file
  return NextResponse.json({ ok: true });
}
