import { NextResponse } from 'next/server';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const URL_ = process.env.NEXT_PUBLIC_SUPABASE_URL ?? '';
const ANON = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? '';
const SERVICE = process.env.SUPABASE_SERVICE_ROLE_KEY ?? '';

type Check = { name: string; ok: boolean; detail: string };

/** Connection self-test for the deployed app. Reports only pass/fail and plain-language hints; it never returns a key or a record. */
export async function GET() {
  const checks: Check[] = [];
  const add = (name: string, ok: boolean, detail: string) => checks.push({ name, ok, detail });

  add('NEXT_PUBLIC_SUPABASE_URL', /^https:\/\/[a-z0-9-]+\.supabase\.co\/?$/i.test(URL_), URL_ ? 'set' : 'MISSING: add it, then rebuild (this value is fixed at build time)');
  add('NEXT_PUBLIC_SUPABASE_ANON_KEY', ANON.length > 40, ANON ? 'set' : 'MISSING: add it, then rebuild (this value is fixed at build time)');
  add('SUPABASE_SERVICE_ROLE_KEY (server only)', SERVICE.length > 40, SERVICE ? 'set' : 'missing: user management and seeding will not work');
  add('CRON_SECRET (server only)', (process.env.CRON_SECRET ?? '').length >= 16, process.env.CRON_SECRET ? 'set' : 'missing: the daily reminder job will refuse to run');

  if (URL_ && ANON) {
    const base = URL_.replace(/\/$/, '');
    try {
      const r = await fetch(`${base}/rest/v1/profiles?select=id&limit=1`, { headers: { apikey: ANON, Authorization: `Bearer ${ANON}` }, cache: 'no-store', signal: AbortSignal.timeout(8000) });
      const body = await r.text();
      if (r.ok) add('Database + profiles table', true, 'reachable; the profiles table exists');
      else if (r.status === 401 || /invalid api key/i.test(body)) add('Database + profiles table', false, 'the anon key is wrong or belongs to a different project');
      else if (/PGRST205|Could not find the table|does not exist/i.test(body)) add('Database + profiles table', false, 'connected, but the tables are missing: run ambizcon-database-setup.sql in the Supabase SQL editor');
      else add('Database + profiles table', false, `unexpected response (HTTP ${r.status})`);
    } catch {
      add('Database + profiles table', false, 'cannot reach the Supabase URL: check it is the exact Project URL');
    }
  }

  if (URL_ && SERVICE) {
    try {
      const r = await fetch(`${URL_.replace(/\/$/, '')}/rest/v1/profiles?select=id&role=eq.admin&status=eq.active&limit=1`, { headers: { apikey: SERVICE, Authorization: `Bearer ${SERVICE}` }, cache: 'no-store', signal: AbortSignal.timeout(8000) });
      if (!r.ok) add('Service role key', false, r.status === 401 ? 'the service_role key is wrong' : `HTTP ${r.status}`);
      else {
        add('Service role key', true, 'valid');
        const rows = (await r.json()) as unknown[];
        add('An active admin exists', rows.length > 0, rows.length > 0 ? 'yes' : 'NO: create a user in Supabase, then run the "update public.profiles ... role = admin" SQL');
      }
    } catch {
      add('Service role key', false, 'cannot reach the Supabase URL');
    }
  }

  const ok = checks.every((c) => c.ok || /missing: /.test(c.detail));
  return NextResponse.json({ ok, checks }, { status: ok ? 200 : 503, headers: { 'Cache-Control': 'no-store' } });
}
