import { createServerClient } from '@supabase/ssr';
import { createClient } from '@supabase/supabase-js';
import { cookies } from 'next/headers';
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { userSchema } from '@/lib/validate';

export const runtime = 'nodejs';

const URL_ = process.env.NEXT_PUBLIC_SUPABASE_URL ?? '';
const ANON = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? '';
const SERVICE = process.env.SUPABASE_SERVICE_ROLE_KEY ?? '';

const bad = (error: string, status = 400) => NextResponse.json({ error }, { status });

const body = z.discriminatedUnion('action', [
  userSchema.extend({ action: z.literal('create'), password: z.string().min(10).max(128).optional() }),
  z.object({
    action: z.literal('update'),
    id: z.string().uuid(),
    name: userSchema.shape.name.optional(),
    team: userSchema.shape.team.optional(),
    role: userSchema.shape.role.optional(),
    status: z.enum(['active', 'disabled']).optional(),
    avatar_url: z.string().url().nullable().optional(),
  }),
  z.object({ action: z.literal('reset'), id: z.string().uuid(), email: userSchema.shape.email }),
]);

/** Admin-only user management. The caller's identity and role are verified server-side on every call. */
export async function POST(req: Request) {
  if (!URL_ || !ANON || !SERVICE) return bad('User management requires Supabase to be configured.', 501);

  const store = await cookies();
  const caller = createServerClient(URL_, ANON, { cookies: { getAll: () => store.getAll(), setAll: () => {} } });
  const { data: auth } = await caller.auth.getUser();
  if (!auth.user) return bad('Not signed in.', 401);
  const { data: me } = await caller.from('profiles').select('role,team,status').eq('id', auth.user.id).single();
  if (!me || me.status !== 'active' || me.role !== 'admin' || me.team !== 'admin') return bad('Admin access required.', 403);

  const parsed = body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return bad(parsed.error.issues[0]?.message ?? 'Invalid request.');
  const input = parsed.data;

  const admin = createClient(URL_, SERVICE, { auth: { autoRefreshToken: false, persistSession: false } });

  if (input.action === 'create') {
    const password = input.password ?? crypto.randomUUID().replace(/-/g, '') + 'Aa1!';
    const { data, error } = await admin.auth.admin.createUser({ email: input.email, password, email_confirm: true, user_metadata: { name: input.name } });
    if (error || !data.user) return bad(error?.message ?? 'Could not create user.');
    const { data: profile, error: pe } = await admin
      .from('profiles')
      .update({ name: input.name, team: input.team, role: input.role })
      .eq('id', data.user.id)
      .select()
      .single();
    if (pe) return bad(pe.message);
    // Invite flow: send the user a password-setup email so no password is ever shared in plain text.
    if (!input.password) await admin.auth.resetPasswordForEmail(input.email);
    return NextResponse.json({ profile });
  }

  if (input.action === 'update') {
    const { id, action: _a, ...patch } = input;
    if (id === auth.user.id && (patch.status === 'disabled' || (patch.team && patch.team !== 'admin') || (patch.role && patch.role !== 'admin')))
      return bad('You cannot remove your own admin access.');
    const { data: profile, error } = await admin.from('profiles').update(patch).eq('id', id).select().single();
    if (error) return bad(error.message);
    if (patch.status) await admin.auth.admin.updateUserById(id, { ban_duration: patch.status === 'disabled' ? '876000h' : 'none' });
    return NextResponse.json({ profile });
  }

  const { error } = await admin.auth.resetPasswordForEmail(input.email);
  if (error) return bad(error.message);
  return NextResponse.json({ ok: true });
}
