import { createClient } from '@supabase/supabase-js';
import { NextResponse } from 'next/server';
import { timingSafeEqual } from 'node:crypto';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const URL_ = process.env.NEXT_PUBLIC_SUPABASE_URL ?? '';
const SERVICE = process.env.SUPABASE_SERVICE_ROLE_KEY ?? '';
const SECRET = process.env.CRON_SECRET ?? '';

const same = (a: string, b: string) => {
  const x = Buffer.from(a), y = Buffer.from(b);
  return x.length === y.length && timingSafeEqual(x, y);
};

/** Daily scheduled job: creates expiry and task-due notifications in the database (public.run_reminders). Vercel Cron sends `Authorization: Bearer $CRON_SECRET`. */
export async function GET(req: Request) {
  if (!URL_ || !SERVICE || !SECRET) return NextResponse.json({ error: 'Scheduled reminders need Supabase and CRON_SECRET to be configured.' }, { status: 501 });
  const auth = req.headers.get('authorization') ?? '';
  if (!same(auth, `Bearer ${SECRET}`)) return NextResponse.json({ error: 'Unauthorised.' }, { status: 401 });

  const db = createClient(URL_, SERVICE, { auth: { persistSession: false } });
  const { data, error } = await db.rpc('run_reminders');
  if (error) return NextResponse.json({ error: 'Reminder run failed.', detail: error.message }, { status: 500 });
  return NextResponse.json({ ok: true, notificationsCreated: data, ranAt: new Date().toISOString() });
}
