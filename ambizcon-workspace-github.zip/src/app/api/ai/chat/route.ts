import { createServerClient } from '@supabase/ssr';
import { cookies } from 'next/headers';
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { buildFacts, systemPrompt } from '@/lib/ai/facts';
import { AiError, getProvider, notConfiguredMessage } from '@/lib/ai/provider';
import { rateLimit } from '@/lib/ai/ratelimit';
import { MODULES } from '@/lib/modules';
import { normalizeWeights } from '@/lib/performance';
import type { Client, Profile, Rec, Task, Team } from '@/lib/types';

export const runtime = 'nodejs';
export const maxDuration = 60;

const URL_ = process.env.NEXT_PUBLIC_SUPABASE_URL ?? '';
const ANON = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? '';
const TEAMS: Team[] = ['admin', 'development', 'marketing', 'creative'];

const json = (body: Record<string, unknown>, status = 200, headers?: HeadersInit) => NextResponse.json(body, { status, headers });

const bodySchema = z.object({
  message: z.string().trim().min(1, 'Type a question first.').max(2000, 'That question is too long (2000 characters max).'),
  history: z.array(z.object({ role: z.enum(['user', 'assistant']), content: z.string().max(4000) })).max(10).default([]),
  /** Demo mode only: the browser-held demo data snapshot. Ignored whenever Supabase is configured. */
  facts: z.string().max(30000).optional(),
});

/**
 * POST /api/ai/chat
 * Server-side only: the provider key never leaves the server. With Supabase configured, the facts are fetched with THE CALLER'S
 * session, so Row Level Security decides what the assistant may see. The assistant is read-only (it has no tools that write).
 */
export async function POST(req: Request) {
  const provider = getProvider();
  const parsed = bodySchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return json({ error: 'invalid', message: parsed.error.issues[0]?.message ?? 'Invalid request.' }, 400);
  const { message, history, facts: demoFacts } = parsed.data;

  let team: Team;
  let userKey: string;
  let facts: { text: string; sections: { title: string; count: number }[] };
  let mode: 'supabase' | 'demo';

  if (URL_ && ANON) {
    mode = 'supabase';
    const store = await cookies();
    const sb = createServerClient(URL_, ANON, { cookies: { getAll: () => store.getAll(), setAll: () => {} } });
    const { data: auth } = await sb.auth.getUser();
    if (!auth.user) return json({ error: 'unauthenticated', message: 'Please sign in again.' }, 401);
    const { data: me } = await sb.from('profiles').select('team,status').eq('id', auth.user.id).single();
    if (!me || me.status !== 'active') return json({ error: 'forbidden', message: 'Your account is not active.' }, 403);
    team = me.team as Team;
    userKey = auth.user.id;
  } else {
    mode = 'demo';
    const t = (await cookies()).get('amb_demo')?.value.split('.')[0] as Team | undefined;
    if (!t || !TEAMS.includes(t)) return json({ error: 'unauthenticated', message: 'Please sign in again.' }, 401);
    team = t;
    userKey = (await cookies()).get('amb_demo')?.value ?? 'demo';
  }

  const rl = rateLimit(`ai:${userKey}`, 12, 60_000);
  if (!rl.ok) return json({ error: 'rate_limited', message: `You are asking too quickly. Try again in ${rl.retryAfterSec}s.` }, 429, { 'Retry-After': String(rl.retryAfterSec) });

  if (!provider) return json({ error: 'not_configured', message: notConfiguredMessage }, 503);

  if (mode === 'supabase') {
    const store = await cookies();
    const sb = createServerClient(URL_, ANON, { cookies: { getAll: () => store.getAll(), setAll: () => {} } });
    const scope = MODULES.filter((m) => !m.readonly && (!m.group || m.group === 'target') && (team === 'admin' || m.team === team));
    const [profiles, clients, tasks, settings, ...recs] = await Promise.all([
      sb.from('profiles').select('id,name,team,role'),
      sb.from('clients').select('*'),
      sb.from('tasks').select('*').limit(2000),
      sb.from('app_settings').select('value').eq('key', 'scoring').maybeSingle(),
      ...scope.map((m) => sb.from(m.table).select('*').order('created_at', { ascending: false }).limit(1000)),
    ]);
    const records: Record<string, Rec[]> = {};
    scope.forEach((m, i) => (records[m.key] = (recs[i].data ?? []) as Rec[]));
    facts = buildFacts({
      team, today: new Date().toISOString().slice(0, 10), users: (profiles.data ?? []) as Pick<Profile, 'id' | 'name' | 'team' | 'role'>[], clients: (clients.data ?? []) as Client[],
      tasks: (tasks.data ?? []) as Task[], records, weights: normalizeWeights(settings.data?.value as never),
    });
  } else {
    // Demo mode is explicitly not secure: the browser holds the data, so it supplies the brief.
    const text = demoFacts ?? '';
    const sections = text.split(/^## /m).slice(1).map((blk) => { const lines = blk.split(/\r?\n/); return { title: lines[0], count: Math.max(0, lines.length - 1) }; });
    facts = { text, sections };
  }

  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 50_000);
  try {
    const out = await provider.complete({ system: systemPrompt(team, facts.text), messages: [...history, { role: 'user', content: message }], maxTokens: 1200 }, ctl.signal);
    return json({ answer: out.text, model: out.model, provider: provider.name, sections: facts.sections, mode, generatedAt: new Date().toISOString() });
  } catch (e) {
    if ((e as Error).name === 'AbortError') return json({ error: 'timeout', message: 'The AI provider took too long to answer. Please try again.' }, 504);
    if (e instanceof AiError) return json({ error: 'provider', message: e.message }, 502);
    return json({ error: 'failed', message: 'The AI request failed. Please try again.' }, 500);
  } finally {
    clearTimeout(timer);
  }
}
