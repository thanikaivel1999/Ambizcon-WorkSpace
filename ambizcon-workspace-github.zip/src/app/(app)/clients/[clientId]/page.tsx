import { ClientProfilePage } from '@/components/lazy';
export const metadata = { title: 'Client Profile' };
export default async function Page({ params }: { params: Promise<{ clientId: string }> }) {
  const { clientId } = await params;
  return <ClientProfilePage id={clientId} />;
}
