import { ClientsPage } from '@/components/lazy';
export const metadata = { title: 'Client List' };
export default function Page() { return <ClientsPage />; }
