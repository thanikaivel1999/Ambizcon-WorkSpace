import { AiAssistantPage } from '@/components/lazy';
export const metadata = { title: 'AI Assistant' };
export default function Page() { return <AiAssistantPage />; }
