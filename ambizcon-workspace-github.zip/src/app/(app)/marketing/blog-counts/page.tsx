import { BlogCountsPage } from '@/components/lazy';
export const metadata = { title: 'Blog Counts' };
export default function Page() { return <BlogCountsPage />; }
