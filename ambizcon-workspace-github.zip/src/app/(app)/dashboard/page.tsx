'use client';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
import { LoadingState } from '../../../components/ui';
import { useAuth } from '../../../components/providers';
import { homePath } from '../../../lib/access';

export default function DashboardRedirect() {
  const { user } = useAuth();
  const router = useRouter();
  useEffect(() => { if (user) router.replace(homePath(user.team)); }, [user, router]);
  return <LoadingState variant="page" />;
}
