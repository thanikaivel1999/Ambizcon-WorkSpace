import { Suspense } from 'react';
import { ModuleRoute } from '../../../../components/lazy';

export default async function Page({ params }: { params: Promise<{ team: string; module: string }> }) {
  const { team, module } = await params;
  return <Suspense><ModuleRoute team={team} slug={module} /></Suspense>;
}
