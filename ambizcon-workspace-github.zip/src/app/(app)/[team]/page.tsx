import { notFound } from 'next/navigation';
import { TeamDashboard } from '@/components/lazy';
import type { WorkTeam } from '@/lib/types';

export default async function Page({ params }: { params: Promise<{ team: string }> }) {
  const { team } = await params;
  if (!['development', 'marketing', 'creative'].includes(team)) notFound();
  return <TeamDashboard team={team as WorkTeam} />;
}
