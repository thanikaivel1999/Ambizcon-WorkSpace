import { ReportsPage } from '@/components/lazy';
export const metadata = { title: 'Reports' };
export default function Page() { return <ReportsPage />; }
