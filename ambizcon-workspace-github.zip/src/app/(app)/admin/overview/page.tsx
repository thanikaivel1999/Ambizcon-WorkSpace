import { AdminOverview } from '@/components/lazy';
export const metadata = { title: 'Admin Overview' };
export default function Page() { return <AdminOverview />; }
