import { StudioPage } from '@/components/lazy';
export const metadata = { title: 'Customization Studio' };
export default function Page() { return <StudioPage />; }
