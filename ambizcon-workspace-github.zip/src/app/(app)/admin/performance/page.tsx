import { PerformancePage } from '@/components/lazy';
export const metadata = { title: 'Performance' };
export default function Page() { return <PerformancePage />; }
