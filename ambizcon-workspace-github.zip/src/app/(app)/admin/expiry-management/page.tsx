import { ExpiryManagementPage } from '@/components/lazy';
export const metadata = { title: 'Expiry Management' };
export default function Page() { return <ExpiryManagementPage />; }
