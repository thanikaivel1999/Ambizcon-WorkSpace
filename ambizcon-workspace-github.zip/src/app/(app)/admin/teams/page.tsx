import { AdminTeams } from '@/components/lazy';
export const metadata = { title: 'All Teams' };
export default function Page() { return <AdminTeams />; }
