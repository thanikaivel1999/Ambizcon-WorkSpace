import { UsersPage } from '@/components/lazy';
export const metadata = { title: 'Users' };
export default function Page() { return <UsersPage />; }
