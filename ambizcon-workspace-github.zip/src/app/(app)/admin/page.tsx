import { AdminDashboard } from '@/components/lazy';
export const metadata = { title: 'Admin Dashboard' };
export default function Page() { return <AdminDashboard />; }
