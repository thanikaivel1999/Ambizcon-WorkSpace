import { MotivationPage } from '@/components/lazy';
export const metadata = { title: 'Motivation' };
export default function Page() { return <MotivationPage />; }
