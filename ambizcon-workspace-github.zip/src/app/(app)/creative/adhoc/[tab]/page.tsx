import { notFound } from 'next/navigation';
import { Suspense } from 'react';
import { AdhocPage } from '@/components/lazy';

export const metadata = { title: 'Creative · Adhoc' };
export default async function Page({ params }: { params: Promise<{ tab: string }> }) {
  const { tab } = await params;
  if (!['web-requirements', 'videos', 'artworks'].includes(tab)) notFound();
  return <Suspense><AdhocPage tab={tab} /></Suspense>;
}
