import { AdhocPage } from '@/components/lazy';
import { Suspense } from 'react';
export const metadata = { title: 'Creative · Adhoc' };
export default function Page() { return <Suspense><AdhocPage tab="web-requirements" /></Suspense>; }
