import { Suspense } from 'react';
import { BriefsPage } from '@/components/lazy';
export const metadata = { title: 'Client Briefs' };
export default function Page() { return <Suspense><BriefsPage /></Suspense>; }
