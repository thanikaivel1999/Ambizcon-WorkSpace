import { SettingsPage } from '@/components/lazy';
export const metadata = { title: 'Settings' };
export default function Page() { return <SettingsPage />; }
