import { NotificationsPage } from '@/components/lazy';
export const metadata = { title: 'Notifications' };
export default function Page() { return <NotificationsPage />; }
