import { Suspense } from 'react';
import { TasksPage } from '@/components/lazy';
export const metadata = { title: 'Tasks' };
export default function Page() { return <Suspense><TasksPage /></Suspense>; }
