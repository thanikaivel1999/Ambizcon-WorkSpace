import { redirect } from 'next/navigation';

// The middleware routes signed-in users to their dashboard; everyone else lands on /login.
export default function Home() {
  redirect('/login');
}
