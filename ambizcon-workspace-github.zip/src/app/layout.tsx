import type { Metadata, Viewport } from 'next';
import { Plus_Jakarta_Sans } from 'next/font/google';
import { Providers } from '@/components/providers';
import './globals.css';

const font = Plus_Jakarta_Sans({ subsets: ['latin'], variable: '--font-sans', display: 'swap' });

export const metadata: Metadata = {
  title: { default: 'Ambizcon Team Workspace', template: '%s · Ambizcon Workspace' },
  description: 'Internal Ambizcon work-management dashboard for the Development, Marketing and Creative teams.',
  icons: { icon: '/logo.png' },
  robots: { index: false, follow: false },
};
export const viewport: Viewport = { themeColor: '#13798A', width: 'device-width', initialScale: 1 };

// Sets the saved theme before first paint to avoid a light/dark flash.
const themeScript = `try{var t=localStorage.getItem('amb_theme');if(t==='dark')document.documentElement.setAttribute('data-theme','dark')}catch(e){}`;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={font.variable} suppressHydrationWarning>
      <head><script dangerouslySetInnerHTML={{ __html: themeScript }} /></head>
      <body>
        <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-3 focus:top-3 focus:z-[200] focus:rounded-lg focus:bg-primary focus:px-3 focus:py-2 focus:text-white">Skip to content</a>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
