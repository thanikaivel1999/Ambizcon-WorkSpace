import { createServerClient } from '@supabase/ssr';
import { NextResponse, type NextRequest } from 'next/server';
import { canAccess, homePath, isCrossTeamPath } from '@/lib/access';
import { grantedPaths } from '@/lib/grants';
import type { Team } from '@/lib/types';

const URL_ = process.env.NEXT_PUBLIC_SUPABASE_URL ?? '';
const ANON = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? '';
const TEAMS: Team[] = ['admin', 'development', 'marketing', 'creative'];

/**
 * Server-side route protection. Unauthenticated users are sent to /login; authenticated users
 * can only open their own team's routes (admins can open everything).
 */
export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  const go = (to: string, denied = false) => {
    const u = req.nextUrl.clone();
    u.pathname = to;
    u.search = denied ? '?denied=1' : '';
    return NextResponse.redirect(u);
  };

  let team: Team | null = null;
  let res = NextResponse.next({ request: req });
  let supabase: ReturnType<typeof createServerClient> | null = null;

  if (URL_ && ANON) {
    supabase = createServerClient(URL_, ANON, {
      cookies: {
        getAll: () => req.cookies.getAll(),
        setAll: (list) => {
          list.forEach(({ name, value }) => req.cookies.set(name, value));
          res = NextResponse.next({ request: req });
          list.forEach(({ name, value, options }) => res.cookies.set(name, value, options));
        },
      },
    });
    const { data } = await supabase.auth.getUser();
    if (data.user) {
      const { data: p } = await supabase.from('profiles').select('team,status').eq('id', data.user.id).single();
      if (p && p.status === 'active') team = p.team as Team;
    }
  } else {
    // Demo mode only (no Supabase configured): cookie format "<team>.<id>".
    const t = req.cookies.get('amb_demo')?.value.split('.')[0] as Team | undefined;
    if (t && TEAMS.includes(t)) team = t;
  }

  if (!team) return pathname === '/login' ? res : go('/login');
  if (pathname === '/login' || pathname === '/' || pathname === '/dashboard') return go(homePath(team));
  if (!canAccess(team, pathname)) {
    // another team's module: allowed only where an admin granted it (decided here, on the server, in Supabase mode)
    if (isCrossTeamPath(team, pathname)) {
      if (!supabase) return res; // demo mode only: the data lives in the browser, so the client guard decides
      if (canAccess(team, pathname, await grantedPaths(supabase, team))) return res;
    }
    return go(homePath(team), true);
  }
  return res;
}

export const config = {
  matcher: ['/((?!api|_next/static|_next/image|favicon.ico|logo.png|.*\\.(?:png|jpg|svg|webp|ico)$).*)'],
};
