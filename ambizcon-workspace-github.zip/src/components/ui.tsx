'use client';
import { animate, AnimatePresence, motion, useInView, useReducedMotion } from 'framer-motion';
import Link from 'next/link';
import { memo, useEffect, useId, useRef, useState, type ReactNode } from 'react';
import { Icon } from './Icon';
import { cn, expiryInfo, getAlertDays, initials, type ExpiryTier } from '@/lib/utils';
import type { Status } from '@/lib/types';

/* ───────── Reveal on scroll ───────── */
export function Reveal({ children, delay = 0, className, y = 22 }: { children: ReactNode; delay?: number; className?: string; y?: number }) {
  const reduce = useReducedMotion();
  return (
    <motion.div className={className} initial={reduce ? false : { opacity: 0, y }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: '-40px' }} transition={{ duration: 0.55, delay, ease: [0.22, 1, 0.36, 1] }}>
      {children}
    </motion.div>
  );
}

/* ───────── Badges ───────── */
const STATUS_STYLE: Record<Status, { cls: string; icon: string }> = {
  Pending: { cls: 'bg-secondary/20 text-secondary-700 dark:text-secondary-200 ring-secondary/40', icon: 'Clock' },
  'In Progress': { cls: 'bg-primary/15 text-primary-700 dark:text-primary-200 ring-primary/40', icon: 'Loader2' },
  Completed: { cls: 'bg-secondary-400 text-white ring-secondary-500', icon: 'CircleCheck' },
  'On Hold': { cls: 'bg-accent/25 text-muted ring-accent/50', icon: 'Pause' },
  Overdue: { cls: 'bg-primary-900 text-white ring-primary-700', icon: 'AlertTriangle' },
  Cancelled: { cls: 'bg-line/10 text-muted line-through ring-line/20', icon: 'Ban' },
};
export const StatusBadge = memo(function StatusBadge({ status, label }: { status: Status | null; label?: string }) {
  if (!status) return <span className="text-muted">—</span>;
  const s = STATUS_STYLE[status];
  return (
    <span className={cn('inline-flex items-center gap-1 whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-semibold ring-1 ring-inset', s.cls)}>
      {status === 'Overdue' ? <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-white" /> : <Icon name={s.icon} size={12} className={status === 'In Progress' ? 'animate-spin' : ''} />}
      {label ?? status}
    </span>
  );
});

const PRIORITY_STYLE: Record<string, string> = {
  Low: 'bg-surface2 text-muted ring-line/25',
  Medium: 'bg-accent/25 text-secondary-700 dark:text-accent-300 ring-accent/50',
  High: 'bg-primary/20 text-primary-700 dark:text-primary-200 ring-primary/50',
  Urgent: 'bg-primary-700 text-white ring-primary-900',
};
export function PriorityBadge({ priority }: { priority?: string | null }) {
  if (!priority) return <span className="text-muted">—</span>;
  return (
    <span className={cn('inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-xs font-semibold ring-1 ring-inset', PRIORITY_STYLE[priority])}>
      {priority === 'Urgent' && <Icon name="Flame" size={12} />}
      {priority}
    </span>
  );
}

export function ToneBadge({ value }: { value: string }) {
  const good = /^(pass|good|indexed|working|accepted|full access|optimized|yes|healthy|public)$/i.test(value);
  const bad = /^(fail|poor|not indexed|not working|rejected|no access|not set|expired)$/i.test(value);
  return (
    <span className={cn('inline-flex items-center whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-semibold ring-1 ring-inset', good ? 'bg-secondary-400/30 text-secondary-700 ring-secondary/50 dark:text-secondary-200' : bad ? 'bg-primary-900 text-white ring-primary-700' : 'bg-primary/10 text-primary-700 ring-primary/30 dark:text-primary-200')}>
      {value}
    </span>
  );
}

const TIER_STYLES = [
  'bg-primary-900 text-white ring-primary-900',
  'bg-primary-800 text-white ring-primary-900',
  'bg-primary-600 text-white ring-primary-800',
  'bg-primary/35 text-primary-800 dark:text-white ring-primary/60',
  'bg-primary/15 text-primary-700 dark:text-primary-200 ring-primary/40',
  'bg-accent/30 text-secondary-700 dark:text-accent-300 ring-accent/60',
];
const OK_STYLE = 'bg-secondary/20 text-secondary-700 dark:text-secondary-200 ring-secondary/40';
/** Label and colour for an expiry tier under the current alert schedule. Urgency is shown by shade, never by a new hue. */
export function tierStyle(tier: ExpiryTier): { cls: string; label: string } {
  const asc = [...getAlertDays()].sort((a, b) => a - b);
  if (tier === 'expired') return { cls: TIER_STYLES[0], label: 'Expired' };
  if (tier === 'ok') return { cls: OK_STYLE, label: `${asc[asc.length - 1] ?? 0}+ days` };
  const n = Number(tier.slice(1));
  const rank = Math.max(0, asc.indexOf(n));
  const slot = asc.length <= 1 ? 1 : 1 + Math.round((rank / (asc.length - 1)) * (TIER_STYLES.length - 2));
  return { cls: TIER_STYLES[Math.min(slot, TIER_STYLES.length - 1)], label: n === 0 ? 'Today' : `≤ ${n} day${n === 1 ? '' : 's'}` };
}

/** Days-remaining chip with animated warning for near-expiry or expired items. */
export function ExpiryChip({ date, detail = false }: { date?: string | null; detail?: boolean }) {
  const info = expiryInfo(date);
  if (!info) return <span className="text-muted">—</span>;
  const warn = info.tier === 'expired' || info.days <= 14;
  return (
    <span className={cn('inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-bold ring-1 ring-inset', tierStyle(info.tier).cls, warn && 'animate-pulseRing')} title={`${info.health} · ${tierStyle(info.tier).label}`}>
      {warn && (
        <motion.span animate={{ rotate: [0, -12, 12, -8, 0] }} transition={{ duration: 1.2, repeat: Infinity, repeatDelay: 1.2 }}>
          <Icon name="AlertTriangle" size={12} />
        </motion.span>
      )}
      {info.days < 0 ? `Expired ${-info.days}d ago` : info.days === 0 ? 'Expires today' : `${info.days} days`}
      {detail && <span className="font-medium opacity-80">· {info.health}</span>}
    </span>
  );
}

/* ───────── Counter / ring / stats ───────── */
export function AnimatedCounter({ value, duration = 1.3, suffix = '', decimals = 0, className }: { value: number; duration?: number; suffix?: string; decimals?: number; className?: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true });
  const reduce = useReducedMotion();
  const [text, setText] = useState((0).toFixed(decimals));
  useEffect(() => {
    if (!inView) return;
    if (reduce) return setText(value.toLocaleString('en-IN', { minimumFractionDigits: decimals, maximumFractionDigits: decimals }));
    const c = animate(0, value, { duration, ease: 'easeOut', onUpdate: (v) => setText(v.toLocaleString('en-IN', { minimumFractionDigits: decimals, maximumFractionDigits: decimals })) });
    return () => c.stop();
  }, [inView, value, duration, reduce, decimals]);
  return (
    <span ref={ref} className={cn('tabular-nums', className)}>
      {text}
      {suffix}
    </span>
  );
}

export function ProgressRing({ value, size = 88, stroke = 9, label, className, light = false }: { value: number; size?: number; stroke?: number; label?: ReactNode; className?: string; light?: boolean }) {
  const id = useId().replace(/:/g, '');
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const ref = useRef<SVGSVGElement>(null);
  const inView = useInView(ref, { once: true });
  return (
    <div className={cn('relative grid place-items-center', className)} style={{ width: size, height: size }} role="img" aria-label={`${value}% complete`}>
      <svg ref={ref} width={size} height={size} className="-rotate-90">
        <defs>
          <linearGradient id={`ring-${id}`} x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor={light ? '#ffffff' : '#13798A'} /><stop offset="1" stopColor={light ? '#e0e9d9' : '#8BA277'} /></linearGradient>
        </defs>
        <circle cx={size / 2} cy={size / 2} r={r} stroke={light ? 'rgb(255 255 255 / .25)' : 'rgb(var(--line) / .18)'} strokeWidth={stroke} fill="none" />
        <motion.circle cx={size / 2} cy={size / 2} r={r} stroke={`url(#ring-${id})`} strokeWidth={stroke} fill="none" strokeLinecap="round" strokeDasharray={c} initial={{ strokeDashoffset: c }} animate={{ strokeDashoffset: inView ? c * (1 - Math.min(100, value) / 100) : c }} transition={{ duration: 1.3, ease: 'easeOut' }} />
      </svg>
      <div className="absolute text-center font-extrabold leading-none" style={{ fontSize: size * 0.24 }}>
        {label ?? <AnimatedCounter value={value} suffix="%" />}
      </div>
    </div>
  );
}

export function StatsCard({ label, value, icon, hint, href, delay = 0, accent = 'primary' }: { label: string; value: number; icon: string; hint?: string; href?: string; delay?: number; accent?: 'primary' | 'secondary' | 'accent' | 'dark' }) {
  const reduce = useReducedMotion();
  const tone = { primary: 'from-primary to-primary-600', secondary: 'from-secondary-400 to-secondary-500', accent: 'from-accent to-secondary-400', dark: 'from-primary-800 to-primary-900' }[accent];
  const body = (
    <motion.div
      initial={reduce ? false : { opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
      whileHover={reduce ? undefined : { y: -4, rotateX: 4, rotateY: -4 }}
      style={{ transformPerspective: 800 }}
      className="panel group relative h-full overflow-hidden p-4 transition-shadow hover:shadow-lift"
    >
      <div className={cn('pointer-events-none absolute -right-6 -top-6 h-24 w-24 rounded-full bg-gradient-to-br opacity-20 blur-md transition-all group-hover:scale-125 group-hover:opacity-30', tone)} />
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <div className="truncate text-xs font-semibold uppercase tracking-wide text-muted">{label}</div>
          <div className="mt-1 text-3xl font-extrabold"><AnimatedCounter value={value} /></div>
          {hint && <div className="mt-0.5 truncate text-xs text-muted">{hint}</div>}
        </div>
        <motion.div whileHover={{ rotate: 10, scale: 1.1 }} className={cn('grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-gradient-to-br text-white shadow-md', tone)}>
          <Icon name={icon} />
        </motion.div>
      </div>
    </motion.div>
  );
  return href ? <Link href={href} className="block h-full rounded-2xl">{body}</Link> : body;
}

export function ChartCard({ title, subtitle, children, className, action }: { title: string; subtitle?: string; children: ReactNode; className?: string; action?: ReactNode }) {
  return (
    <Reveal className={cn('panel flex flex-col p-4', className)}>
      <div className="mb-3 flex items-start justify-between gap-2">
        <div>
          <h3 className="text-sm font-bold">{title}</h3>
          {subtitle && <p className="text-xs text-muted">{subtitle}</p>}
        </div>
        {action}
      </div>
      <div className="min-h-0 flex-1">{children}</div>
    </Reveal>
  );
}

export function UserAvatar({ name, size = 32, src }: { name: string; size?: number; src?: string | null }) {
  return src ? (
    // eslint-disable-next-line @next/next/no-img-element
    <img src={src} alt={name} width={size} height={size} className="rounded-full object-cover ring-2 ring-surface" style={{ width: size, height: size }} />
  ) : (
    <span title={name} aria-label={name} className="grid shrink-0 place-items-center rounded-full bg-gradient-to-br from-primary to-secondary-400 font-bold text-white ring-2 ring-surface" style={{ width: size, height: size, fontSize: size * 0.38 }}>
      {initials(name)}
    </span>
  );
}

export function PageHeader({ title, subtitle, actions, icon }: { title: string; subtitle?: string; actions?: ReactNode; icon?: string }) {
  return (
    <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
      <div className="flex items-center gap-3">
        {icon && <div className="grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-primary to-secondary-400 text-white shadow-md"><Icon name={icon} size={22} /></div>}
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight">{title}</h1>
          {subtitle && <p className="max-w-2xl text-sm text-muted">{subtitle}</p>}
        </div>
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  );
}

/* ───────── Empty / loading / error ───────── */
export function EmptyState({ title = 'No work records yet.', message = 'Create your first task to get started.', action, onAction, actionLabel = 'Create Record' }: { title?: string; message?: string; action?: boolean; onAction?: () => void; actionLabel?: string }) {
  return (
    <div className="flex flex-col items-center px-4 py-12 text-center">
      <motion.svg viewBox="0 0 160 130" className="h-36 w-44" animate={{ y: [0, -6, 0] }} transition={{ duration: 3.4, repeat: Infinity, ease: 'easeInOut' }} aria-hidden>
        <ellipse cx="80" cy="118" rx="52" ry="8" fill="#000" opacity=".12" />
        <rect x="34" y="34" width="92" height="76" rx="12" fill="#13798A" />
        <path d="M34 50h92v50a10 10 0 0 1-10 10H44a10 10 0 0 1-10-10z" fill="#8BA277" />
        <rect x="46" y="22" width="68" height="46" rx="6" fill="#fff" transform="rotate(-4 80 45)" />
        <rect x="56" y="32" width="38" height="5" rx="2.5" fill="#95A575" transform="rotate(-4 80 45)" />
        <rect x="56" y="43" width="48" height="5" rx="2.5" fill="#13798A" opacity=".5" transform="rotate(-4 80 45)" />
        <circle cx="116" cy="30" r="10" fill="#95A575" /><path d="M116 25v10m-5-5h10" stroke="#fff" strokeWidth="3" strokeLinecap="round" />
        <circle cx="64" cy="84" r="3" fill="#fff" /><circle cx="96" cy="84" r="3" fill="#fff" /><path d="M70 92q10 6 20 0" stroke="#fff" strokeWidth="3" fill="none" strokeLinecap="round" />
      </motion.svg>
      <h3 className="mt-2 text-lg font-bold">{title}</h3>
      <p className="mt-1 max-w-sm text-sm text-muted">{message}</p>
      {action && onAction && (
        <button className="btn-primary mt-4" onClick={onAction}>
          <Icon name="Plus" size={16} /> {actionLabel}
        </button>
      )}
    </div>
  );
}

export const Skeleton = ({ className }: { className?: string }) => (
  <div className={cn('relative overflow-hidden rounded-lg bg-line/10', className)}>
    <div className="absolute inset-0 -translate-x-full animate-shimmer bg-gradient-to-r from-transparent via-white/30 to-transparent dark:via-white/10" />
  </div>
);

export function LoadingState({ variant = 'cards', rows = 6 }: { variant?: 'cards' | 'table' | 'page'; rows?: number }) {
  if (variant === 'table')
    return (
      <div className="panel space-y-2 p-4" aria-busy="true" aria-label="Loading records">
        <Skeleton className="h-9 w-full" />
        {Array.from({ length: rows }).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}
      </div>
    );
  if (variant === 'page')
    return (
      <div className="space-y-5" aria-busy="true" aria-label="Loading">
        <Skeleton className="h-44 w-full rounded-2xl" />
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-28 rounded-2xl" />)}</div>
        <Skeleton className="h-72 w-full rounded-2xl" />
      </div>
    );
  return <div className="grid grid-cols-2 gap-4 lg:grid-cols-4" aria-busy="true">{Array.from({ length: rows }).map((_, i) => <Skeleton key={i} className="h-28 rounded-2xl" />)}</div>;
}

export function ErrorState({ message = 'Please try again.', onRetry }: { message?: string; onRetry?: () => void }) {
  return (
    <div role="alert" className="panel flex flex-col items-center px-4 py-10 text-center">
      <div className="grid h-14 w-14 place-items-center rounded-2xl bg-primary-900 text-white"><Icon name="AlertTriangle" size={26} /></div>
      <h3 className="mt-3 text-lg font-bold">Something went wrong.</h3>
      <p className="mt-1 max-w-sm text-sm text-muted">{message}</p>
      {onRetry && <button className="btn-primary mt-4" onClick={onRetry}><Icon name="RotateCcw" size={16} /> Retry</button>}
    </div>
  );
}

/* ───────── Modal / Drawer / Confirm ───────── */
function useDialog(open: boolean, onClose: () => void) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const prev = document.activeElement as HTMLElement | null;
    const el = ref.current;
    const first = el?.querySelector<HTMLElement>('input,select,textarea,button:not([data-close])') ?? el;
    setTimeout(() => first?.focus(), 60);
    const key = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'Tab' && el) {
        const f = [...el.querySelectorAll<HTMLElement>('a[href],button:not([disabled]),input:not([disabled]),select,textarea,[tabindex]:not([tabindex="-1"])')].filter((x) => x.offsetParent !== null);
        if (!f.length) return;
        const a = f[0], z = f[f.length - 1];
        if (e.shiftKey && document.activeElement === a) { e.preventDefault(); z.focus(); }
        else if (!e.shiftKey && document.activeElement === z) { e.preventDefault(); a.focus(); }
      }
    };
    document.addEventListener('keydown', key);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', key);
      document.body.style.overflow = '';
      prev?.focus?.();
    };
  }, [open, onClose]);
  return ref;
}

export function Modal({ open, onClose, title, children, footer, size = 'md' }: { open: boolean; onClose: () => void; title: string; children: ReactNode; footer?: ReactNode; size?: 'sm' | 'md' | 'lg' | 'xl' }) {
  const ref = useDialog(open, onClose);
  const w = { sm: 'max-w-md', md: 'max-w-2xl', lg: 'max-w-4xl', xl: 'max-w-6xl' }[size];
  return (
    <AnimatePresence>
      {open && (
        <motion.div className="fixed inset-0 z-[80] grid place-items-center bg-primary-900/50 p-3 backdrop-blur-sm" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
          <motion.div ref={ref} role="dialog" aria-modal="true" aria-label={title} tabIndex={-1} initial={{ opacity: 0, y: 30, scale: 0.97 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 20, scale: 0.97 }} transition={{ type: 'spring', stiffness: 300, damping: 28 }} className={cn('panel flex max-h-[92vh] w-full flex-col bg-surface shadow-lift outline-none', w)} style={{ background: 'rgb(var(--surface) / .96)' }}>
            <div className="flex items-center justify-between border-b border-line/15 px-5 py-3.5">
              <h2 className="text-lg font-bold">{title}</h2>
              <button data-close aria-label="Close dialog" className="rounded-lg p-1.5 text-muted transition hover:bg-primary/10 hover:text-ink" onClick={onClose}><Icon name="X" /></button>
            </div>
            <div className="overflow-y-auto px-5 py-4">{children}</div>
            {footer && <div className="flex flex-wrap justify-end gap-2 border-t border-line/15 px-5 py-3">{footer}</div>}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export function Drawer({ open, onClose, title, children, footer }: { open: boolean; onClose: () => void; title: string; children: ReactNode; footer?: ReactNode }) {
  const ref = useDialog(open, onClose);
  return (
    <AnimatePresence>
      {open && (
        <motion.div className="fixed inset-0 z-[70] bg-primary-900/40 backdrop-blur-[2px]" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
          <motion.aside ref={ref} role="dialog" aria-modal="true" aria-label={title} tabIndex={-1} initial={{ x: '100%' }} animate={{ x: 0 }} exit={{ x: '100%' }} transition={{ type: 'spring', stiffness: 280, damping: 32 }} className="absolute right-0 top-0 flex h-full w-full max-w-xl flex-col shadow-lift outline-none" style={{ background: 'rgb(var(--surface))' }}>
            <div className="flex items-center justify-between border-b border-line/15 px-5 py-3.5">
              <h2 className="truncate text-lg font-bold">{title}</h2>
              <button data-close aria-label="Close details" className="rounded-lg p-1.5 text-muted hover:bg-primary/10" onClick={onClose}><Icon name="X" /></button>
            </div>
            <div className="flex-1 overflow-y-auto px-5 py-4">{children}</div>
            {footer && <div className="flex justify-end gap-2 border-t border-line/15 px-5 py-3">{footer}</div>}
          </motion.aside>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export function ConfirmDialog({ open, title, message, confirmLabel = 'Delete', busy, onConfirm, onClose }: { open: boolean; title: string; message: string; confirmLabel?: string; busy?: boolean; onConfirm: () => void; onClose: () => void }) {
  return (
    <Modal open={open} onClose={onClose} title={title} size="sm" footer={<><button className="btn-ghost" onClick={onClose}>Cancel</button><button className="btn-danger" disabled={busy} onClick={onConfirm}>{busy && <Icon name="Loader2" className="animate-spin" size={16} />}{confirmLabel}</button></>}>
      <p className="text-sm text-muted">{message}</p>
    </Modal>
  );
}

