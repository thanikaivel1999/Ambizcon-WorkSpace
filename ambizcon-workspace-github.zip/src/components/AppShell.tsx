'use client';
import { useQueryClient } from '@tanstack/react-query';
import { AnimatePresence, motion } from 'framer-motion';
import Link from 'next/link';
import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import { Suspense, useEffect, useRef, useState, type ReactNode } from 'react';
import { CompanyLogo } from './CompanyLogo';
import { Icon } from './Icon';
import { LoadingScreen } from './LoadingScreen';
import { AiFloatingButton } from './lazy';
import { MotivationProvider, useMotivation } from './MotivationPopup';
import { NotificationPanel } from './NotificationPanel';
import { SearchBar } from './SearchBar';
import { useAuth, useTheme, useToast } from './providers';
import { UserAvatar } from './ui';
import { canAccess, homePath, TEAM_LABEL } from '@/lib/access';
import { api } from '@/lib/data';
import { useAvailableModules, useDashboardLayout, useGrantedPaths, useNotifications, useSetting } from '@/lib/hooks';
import { DEFAULT_ALERT_DAYS, normalizeAlertDays, setAlertDays } from '@/lib/utils';
import { buildNav, FOOTER_NAV, type NavItem } from '@/lib/nav';
import { playCue } from '@/lib/sound';
import { cn } from '@/lib/utils';

function NavLink({ item, active, onClick }: { item: NavItem; active: boolean; onClick?: () => void }) {
  return (
    <Link href={item.href} onClick={onClick} aria-current={active ? 'page' : undefined} className={cn('group relative flex items-center gap-3 rounded-xl px-3 py-2 text-sm font-medium transition-colors', active ? 'text-white' : 'text-ink/80 hover:bg-primary/10 hover:text-ink')}>
      {active && <motion.span layoutId="nav-pill" className="absolute inset-0 rounded-xl bg-gradient-to-r from-primary to-secondary-500 shadow-md" transition={{ type: 'spring', stiffness: 380, damping: 32 }} />}
      <Icon name={item.icon} className={cn('relative transition-transform group-hover:scale-110', active && 'text-white')} />
      <span className="relative truncate">{item.label}</span>
    </Link>
  );
}

function Sidebar({ onNavigate }: { onNavigate?: () => void }) {
  const { user, signOut } = useAuth();
  const path = usePathname();
  const modules = useAvailableModules(user?.team);
  const layout = useDashboardLayout().value;
  if (!user) return null;
  const isActive = (href: string) => (href === `/${user.team}` || href === '/admin' ? path === href : path === href || path.startsWith(href + '/') || (href === '/creative/adhoc' && path.startsWith('/creative/adhoc')));
  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center px-4 py-4"><CompanyLogo size={40} withName /></div>
      <nav aria-label="Main" className="flex-1 space-y-0.5 overflow-y-auto px-3 pb-3">
        {buildNav(user.team, modules, layout).map((n) => <NavLink key={n.href} item={n} active={isActive(n.href)} onClick={onNavigate} />)}
      </nav>
      <div className="space-y-0.5 border-t border-line/15 p-3">
        {FOOTER_NAV(user.team).map((n) => <NavLink key={n.href} item={n} active={path === n.href} onClick={onNavigate} />)}
        <button onClick={() => void signOut()} className="flex w-full items-center gap-3 rounded-xl px-3 py-2 text-sm font-medium text-ink/80 transition hover:bg-primary-900 hover:text-white">
          <Icon name="LogOut" /> Logout
        </button>
      </div>
    </div>
  );
}

function Header({ onMenu }: { onMenu: () => void }) {
  const { user, signOut } = useAuth();
  const { theme, toggle } = useTheme();
  const { unread } = useNotifications();
  const mot = useMotivation();
  const [panel, setPanel] = useState(false);
  const wrap = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const away = (e: MouseEvent) => !wrap.current?.contains(e.target as Node) && setPanel(false);
    const esc = (e: KeyboardEvent) => e.key === 'Escape' && setPanel(false);
    document.addEventListener('mousedown', away);
    document.addEventListener('keydown', esc);
    return () => { document.removeEventListener('mousedown', away); document.removeEventListener('keydown', esc); };
  }, []);
  if (!user) return null;
  return (
    <header className="glass sticky top-0 z-40 flex flex-wrap items-center gap-2 border-x-0 border-t-0 px-3 py-2.5 sm:gap-3 sm:px-5">
      <button className="btn-ghost !px-2.5 lg:hidden" onClick={onMenu} aria-label="Open menu"><Icon name="Menu" /></button>
      <Link href={homePath(user.team)} className="shrink-0" aria-label="Ambizcon home"><CompanyLogo size={34} animated={false} /></Link>
      <span className="hidden shrink-0 items-center gap-1.5 rounded-full bg-primary/10 px-3 py-1 text-xs font-bold text-primary dark:text-primary-200 md:inline-flex">
        <span className="h-1.5 w-1.5 rounded-full bg-secondary-500" /> {TEAM_LABEL[user.team]} {user.team === 'admin' ? 'Console' : 'Team'}
      </span>
      <SearchBar className="mx-auto hidden min-w-0 max-w-xl flex-1 sm:block" />
      <div className="ml-auto flex items-center gap-1 sm:ml-0 sm:gap-1.5">
        <button className="btn-ghost !px-2.5" onClick={mot.open} aria-label="Today's motivation" title="Today's motivation"><Icon name="Sparkles" /></button>
        <button className="btn-ghost !px-2.5" onClick={toggle} aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}><Icon name={theme === 'dark' ? 'Sun' : 'Moon'} /></button>
        <div ref={wrap} className="relative">
          <button className="btn-ghost relative !px-2.5" onClick={() => setPanel((p) => !p)} aria-label={`Notifications${unread ? `, ${unread} unread` : ''}`} aria-expanded={panel}>
            <Icon name="Bell" />
            {unread > 0 && <span className="absolute -right-1.5 -top-1.5 grid h-5 min-w-5 animate-pulseRing place-items-center rounded-full bg-primary px-1 text-[10px] font-bold text-white">{unread > 99 ? '99+' : unread}</span>}
          </button>
          <AnimatePresence>{panel && <NotificationPanel onClose={() => setPanel(false)} />}</AnimatePresence>
        </div>
        <Link href="/profile" className="ml-1 hidden items-center gap-2 rounded-xl px-2 py-1 transition hover:bg-primary/10 md:flex">
          <UserAvatar name={user.name} src={user.avatar_url} size={32} />
          <span className="leading-tight"><span className="block text-sm font-semibold">{user.name}</span><span className="block text-[11px] capitalize text-muted">{user.role === 'admin' ? 'Admin' : `${user.role} · ${user.team}`}</span></span>
        </Link>
        <button className="btn-ghost !px-2.5" onClick={() => void signOut()} aria-label="Logout" title="Logout"><Icon name="LogOut" /></button>
      </div>
      <div className="basis-full sm:hidden"><SearchBar /></div>
    </header>
  );
}

function Denied() {
  const sp = useSearchParams();
  const toast = useToast();
  const router = useRouter();
  const path = usePathname();
  useEffect(() => {
    if (sp.get('denied')) { toast.error("You don't have access to that area."); router.replace(path); }
  }, [sp, toast, router, path]);
  return null;
}

/** Realtime: refresh data when anything changes and toast brand-new notifications (e.g. a team completing work). */
function useRealtime() {
  const qc = useQueryClient();
  const toast = useToast();
  const { user } = useAuth();
  const { storedList } = useNotifications();
  const seen = useRef<Set<string> | null>(null);
  useEffect(() => api.subscribe((e) => {
    if (e.type === 'notification') qc.invalidateQueries({ queryKey: ['notifications'] });
    else { qc.invalidateQueries({ queryKey: e.module ? ['records', e.module] : ['records'] }); qc.invalidateQueries({ queryKey: ['activity'] }); }
  }), [qc]);
  useEffect(() => {
    if (!user) return;
    if (!seen.current) { seen.current = new Set(storedList.map((n) => n.id)); return; }
    for (const n of storedList) {
      if (seen.current.has(n.id)) continue;
      seen.current.add(n.id);
      if (!n.read) { toast.info(n.body); playCue('notify'); }
    }
  }, [storedList, toast, user]);
}

function Shell({ children }: { children: ReactNode }) {
  const { user, loading } = useAuth();
  const router = useRouter();
  const path = usePathname();
  const [menu, setMenu] = useState(false);
  useRealtime();
  // admin-configured expiry alert schedule applies app-wide before any expiry chip renders
  const alertDays = useSetting<number[]>('expiry_alert_days', DEFAULT_ALERT_DAYS, normalizeAlertDays);
  setAlertDays(alertDays.value);
  useEffect(() => { setMenu(false); }, [path]);
  const granted = useGrantedPaths(user?.team);
  useEffect(() => {
    if (!loading && !user) router.replace('/login');
    else if (user && !granted.loading && !canAccess(user.team, path, granted.paths)) router.replace(`${homePath(user.team)}?denied=1`);
  }, [loading, user, path, router, granted.loading, granted.paths]);
  if (loading || !user || granted.loading || !canAccess(user.team, path, granted.paths) || alertDays.loading) return <LoadingScreen />;
  return (
    <MotivationProvider>
      <div className="bg-mesh relative min-h-screen">
        <div aria-hidden className="pointer-events-none fixed inset-0 overflow-hidden">
          <div className="absolute -left-24 top-1/3 h-72 w-72 animate-blob rounded-full bg-secondary/15 blur-3xl" />
          <div className="absolute -right-24 bottom-0 h-80 w-80 animate-blob rounded-full bg-primary/15 blur-3xl [animation-delay:-8s]" />
        </div>
        <aside className="glass fixed inset-y-0 left-0 z-30 hidden w-64 border-y-0 border-l-0 lg:block"><Sidebar /></aside>
        <AnimatePresence>
          {menu && (
            <motion.div className="fixed inset-0 z-50 bg-primary-900/50 backdrop-blur-sm lg:hidden" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setMenu(false)}>
              <motion.aside initial={{ x: -300 }} animate={{ x: 0 }} exit={{ x: -300 }} transition={{ type: 'spring', stiffness: 300, damping: 32 }} className="absolute inset-y-0 left-0 w-72 shadow-lift" style={{ background: 'rgb(var(--surface))' }} onClick={(e) => e.stopPropagation()} aria-label="Menu">
                <button className="absolute right-3 top-3 rounded-lg p-1.5 hover:bg-primary/10" onClick={() => setMenu(false)} aria-label="Close menu"><Icon name="X" /></button>
                <Sidebar onNavigate={() => setMenu(false)} />
              </motion.aside>
            </motion.div>
          )}
        </AnimatePresence>
        <div className="relative lg:pl-64">
          <Header onMenu={() => setMenu(true)} />
          <Suspense><Denied /></Suspense>
          <motion.main key={path} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35, ease: 'easeOut' }} className="mx-auto w-full max-w-[1500px] px-3 py-5 sm:px-6 sm:py-6" id="main">
            {children}
          </motion.main>
        </div>
        <AiFloatingButton />
      </div>
    </MotivationProvider>
  );
}

export const AppShell = Shell;
