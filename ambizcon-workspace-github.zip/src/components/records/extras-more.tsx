'use client';
import { useMemo, useState } from 'react';
import { BarsChart, CH, LinesChart } from '../charts';
import { Icon } from '../Icon';
import { ChartCard, StatsCard } from '../ui';
import type { ExtraProps } from './extras';
import { MONTH_NAMES } from '@/lib/modules';
import type { Rec } from '@/lib/types';
import { cn, daysUntil, fmtDate, todayISO } from '@/lib/utils';

const groupBy = <T,>(rows: T[], key: (r: T) => string) => {
  const m = new Map<string, T[]>();
  rows.forEach((r) => m.set(key(r), [...(m.get(key(r)) ?? []), r]));
  return m;
};

/* ───────── Website backups: latest per website, history, missing and overdue flags ───────── */
const STALE_DAYS = 7;

export function BackupLatest({ rows, lk, onOpen }: ExtraProps) {
  const [openSite, setOpenSite] = useState<string | null>(null);
  const today = todayISO();
  const sites = useMemo(() => {
    const g = groupBy(rows, (r) => `${r.client_id}|${String(r.website).toLowerCase()}`);
    return [...g.values()].map((rs) => {
      const sorted = [...rs].sort((a, b) => String(b.backup_date).localeCompare(String(a.backup_date)));
      const latest = sorted[0];
      const age = latest.backup_date ? -daysUntil(latest.backup_date) : null;
      const overdue = !!latest.next_backup_date && latest.next_backup_date < today;
      return { key: `${latest.client_id}|${latest.website}`, latest, history: sorted.slice(1), age, overdue, stale: age !== null && age > STALE_DAYS };
    }).sort((a, b) => Number(b.overdue) - Number(a.overdue) || Number(b.latest.verification !== 'Verified') - Number(a.latest.verification !== 'Verified'));
  }, [rows, today]);
  const covered = new Set(rows.map((r) => r.client_id));
  const missing = lk.clients.filter((c) => c.status === 'active' && c.website && !covered.has(c.id));
  const flagged = sites.filter((s) => s.overdue || s.stale || s.latest.verification !== 'Verified').length;
  return (
    <div className="mb-4 space-y-3">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatsCard label="Websites with backups" value={sites.length} icon="DatabaseBackup" />
        <StatsCard label="Needs attention" value={flagged} icon="AlertTriangle" accent="dark" hint="Overdue, stale or unverified" />
        <StatsCard label="Verified latest" value={sites.filter((s) => s.latest.verification === 'Verified').length} icon="BadgeCheck" accent="secondary" />
        <StatsCard label="No backup recorded" value={missing.length} icon="Ban" accent="accent" hint="Active clients with a website" />
      </div>
      <div className="panel p-3 sm:p-4">
        <h2 className="mb-2 font-bold">Latest backup per website</h2>
        <ul className="divide-y divide-line/10">
          {sites.map((s) => (
            <li key={s.key} className="py-2">
              <div className="flex flex-wrap items-center gap-2">
                <button className="min-w-0 flex-1 text-left" onClick={() => setOpenSite(openSite === s.key ? null : s.key)} aria-expanded={openSite === s.key}>
                  <span className="block truncate font-semibold">{s.latest.website}</span>
                  <span className="text-xs text-muted">{lk.client(s.latest.client_id)} · {s.latest.backup_type ?? 'type not set'} · {s.latest.backup_date ? `${fmtDate(s.latest.backup_date)} (${s.age === 0 ? 'today' : `${s.age} days ago`})` : 'no date'}</span>
                </button>
                <span className={cn('rounded-full px-2 py-0.5 text-xs font-bold', s.latest.verification === 'Verified' ? 'bg-secondary-400 text-white' : s.latest.verification === 'Failed' ? 'bg-primary-900 text-white' : 'bg-accent/30 text-muted')}>{s.latest.verification ?? 'Unverified'}</span>
                {s.overdue && <span className="rounded-full bg-primary-900 px-2 py-0.5 text-xs font-bold text-white">Next backup overdue</span>}
                {s.stale && !s.overdue && <span className="rounded-full bg-primary/20 px-2 py-0.5 text-xs font-semibold text-primary-800 dark:text-primary-100">Older than {STALE_DAYS} days</span>}
                {s.latest.backup_link ? <a href={s.latest.backup_link} target="_blank" rel="noopener noreferrer" className="btn-ghost !py-1 text-xs"><Icon name="ExternalLink" size={13} />Open backup</a> : <span className="text-xs text-muted">No link</span>}
                <button className="btn-ghost !py-1 text-xs" onClick={() => onOpen(s.latest)}>Details</button>
              </div>
              {openSite === s.key && (
                <ul className="mt-2 space-y-1 rounded-xl bg-surface2 p-2 text-sm">
                  {s.history.length === 0 && <li className="px-2 text-muted">No earlier backups recorded.</li>}
                  {s.history.map((h) => (
                    <li key={h.id} className="flex flex-wrap items-center gap-2 px-2 py-1"><span className="w-28 shrink-0 text-muted">{fmtDate(h.backup_date)}</span><span>{h.backup_type ?? '—'}</span><span className="text-xs text-muted">{h.verification}</span>
                      {h.backup_link && <a href={h.backup_link} target="_blank" rel="noopener noreferrer" className="ml-auto text-xs font-semibold text-primary hover:underline dark:text-primary-200">Open</a>}</li>
                  ))}
                </ul>
              )}
            </li>
          ))}
          {sites.length === 0 && <li className="py-4 text-center text-sm text-muted">No backups recorded yet.</li>}
        </ul>
        {missing.length > 0 && <p className="mt-3 rounded-lg bg-primary/10 p-2 text-xs text-muted"><b className="text-ink">No backup recorded for:</b> {missing.map((c) => c.name).join(', ')}</p>}
      </div>
    </div>
  );
}

/* ───────── Website performance: month-over-month and year-over-year ───────── */
const METRICS: [key: string, label: string, lowerIsBetter?: boolean, suffix?: string][] = [
  ['sessions', 'Sessions'], ['users', 'Users'], ['page_views', 'Page views'], ['engagement_rate', 'Engagement rate', false, '%'], ['conversions', 'Conversions'],
  ['organic_clicks', 'Organic clicks'], ['organic_impressions', 'Organic impressions'], ['avg_position', 'Avg. search position', true],
];

const SCORES: [string, string][] = [['desktop_score', 'Web performance'], ['mobile_score', 'Mobile performance'], ['seo_score', 'SEO'], ['best_practices_score', 'Best practices'], ['accessibility_score', 'Accessibility']];
const tone = (v: number) => (v >= 90 ? 'bg-secondary-400 text-white' : v >= 50 ? 'bg-accent/40 text-ink' : 'bg-primary-900 text-white');

/** Previous vs current quality scores per website (latest two monthly reports that have scores). */
export function ScoresCompare({ rows, lk }: ExtraProps) {
  const ord = (r: Rec) => Number(r.report_year) * 12 + MONTH_NAMES.indexOf(r.report_month);
  const list = useMemo(() => [...groupBy(rows.filter((r) => SCORES.some(([k]) => r[k] != null)), (r) => `${r.client_id}|${r.website}`).values()].map((rs) => {
    const s = [...rs].sort((a, b) => ord(b) - ord(a));
    return { cur: s[0], prev: s[1] };
  }), [rows]);
  if (!list.length) return null;
  return (
    <div className="panel mb-4 overflow-hidden">
      <div className="border-b border-line/10 px-4 py-2.5"><h2 className="font-bold">Quality scores: previous vs current</h2><p className="text-xs text-muted">Latest report against the one before it. 90+ good, 50–89 needs work, below 50 poor.</p></div>
      <div className="overflow-x-auto"><table className="w-full min-w-[760px] text-sm">
        <thead><tr><th className="th">Website</th><th className="th">Report</th>{SCORES.map(([, l]) => <th key={l} className="th text-center">{l}</th>)}</tr></thead>
        <tbody>{list.flatMap(({ cur, prev }) => [cur, prev].filter(Boolean).map((r, i) => (
          <tr key={r.id} className="border-t border-line/10">
            <td className="td font-semibold">{i === 0 ? <>{r.website}<div className="text-xs font-normal text-muted">{lk.client(r.client_id)}</div></> : ''}</td>
            <td className="td">{i === 0 ? 'Current' : 'Previous'} <span className="text-xs text-muted">({String(r.report_month).slice(0, 3)} {r.report_year})</span></td>
            {SCORES.map(([k]) => { const v = r[k] == null ? null : Number(r[k]); const p = i === 0 && prev && prev[k] != null ? Number(prev[k]) : null; const d = v !== null && p !== null ? v - p : null;
              return <td key={k} className="td text-center">{v === null ? <span className="text-muted">—</span> : <span className={cn('inline-block min-w-9 rounded-full px-2 py-0.5 text-xs font-bold', tone(v))}>{v}</span>}{d !== null && <span className={cn('ml-1.5 text-xs font-semibold', d >= 0 ? 'text-secondary-700 dark:text-secondary-200' : 'text-primary-800 dark:text-primary-200')}>{d >= 0 ? '+' : ''}{d}</span>}</td>; })}
          </tr>)))}</tbody></table></div>
    </div>
  );
}

export function PerfCompare({ rows, lk, ...rest }: ExtraProps) {
  return <><ScoresCompare rows={rows} lk={lk} {...rest} /><PerfTraffic rows={rows} lk={lk} {...rest} /></>;
}

function PerfTraffic({ rows, lk }: ExtraProps) {
  const sites = useMemo(() => [...new Set(rows.map((r) => `${r.client_id}|${r.website}`))], [rows]);
  const [site, setSite] = useState('');
  const sel = site || sites[0] || '';
  const mine = rows.filter((r) => `${r.client_id}|${r.website}` === sel);
  const now = new Date();
  const curM = now.getMonth(), curY = now.getFullYear();
  const find = (y: number, m: number) => mine.find((r) => Number(r.report_year) === y && MONTH_NAMES.indexOf(r.report_month) === m);
  const prevM = curM === 0 ? 11 : curM - 1, prevMY = curM === 0 ? curY - 1 : curY;
  const cols = [
    { label: `Previous month (${MONTH_NAMES[prevM].slice(0, 3)} ${prevMY})`, rec: find(prevMY, prevM) },
    { label: `Same month last year (${MONTH_NAMES[prevM].slice(0, 3)} ${prevMY - 1})`, rec: find(prevMY - 1, prevM) },
    { label: `Current month (${MONTH_NAMES[curM].slice(0, 3)} ${curY}, month to date)`, rec: find(curY, curM) },
    { label: `Same month last year (${MONTH_NAMES[curM].slice(0, 3)} ${curY - 1})`, rec: find(curY - 1, curM) },
  ];
  const delta = (a?: Rec, bb?: Rec, k?: string, lower?: boolean) => {
    const x = a && k ? Number(a[k]) : NaN, y = bb && k ? Number(bb[k]) : NaN;
    if (!Number.isFinite(x) || !Number.isFinite(y) || y === 0) return <span className="text-muted">—</span>;
    const pct = ((x - y) / y) * 100;
    const good = lower ? pct <= 0 : pct >= 0;
    return <span className={cn('font-semibold tabular-nums', good ? 'text-secondary-700 dark:text-secondary-200' : 'text-primary-800 dark:text-primary-200')}>{pct >= 0 ? '+' : ''}{pct.toFixed(1)}%</span>;
  };
  const history = useMemo(() => [...mine].sort((a, b) => Number(a.report_year) * 12 + MONTH_NAMES.indexOf(a.report_month) - (Number(b.report_year) * 12 + MONTH_NAMES.indexOf(b.report_month)))
    .map((r) => ({ name: `${String(r.report_month).slice(0, 3)} ${String(r.report_year).slice(2)}`, sessions: Number(r.sessions) || 0, clicks: Number(r.organic_clicks) || 0 })), [mine]);
  const dayOfMonth = now.getDate(), dim = new Date(curY, curM + 1, 0).getDate();
  if (!sites.length) return null;
  const [cid, web] = sel.split('|');
  return (
    <div className="mb-4 space-y-4">
      <div className="panel p-3 sm:p-4">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <h2 className="font-bold">Comparison for {web} <span className="font-normal text-muted">· {lk.client(cid)}</span></h2>
          <select className="input !w-auto" aria-label="Website" value={sel} onChange={(e) => setSite(e.target.value)}>{sites.map((k) => { const [c, w] = k.split('|'); return <option key={k} value={k}>{w} · {lk.client(c)}</option>; })}</select>
        </div>
        <p className="mb-3 rounded-lg bg-primary/10 p-2 text-xs text-muted"><Icon name="Info" size={12} className="mr-1 inline" />
          The current month is <b className="text-ink">month-to-date</b> (day {dayOfMonth} of {dim}). It is not like-for-like with a complete previous month, so read the month-over-month change with that in mind. Monthly figures are entered by hand until Google Analytics and Search Console are connected.</p>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[820px] text-sm">
            <thead><tr><th className="th">Metric</th>{cols.map((c) => <th key={c.label} className="th whitespace-normal text-center">{c.label}</th>)}<th className="th text-center">Prev. month vs last year</th><th className="th text-center">Current vs last year</th><th className="th text-center">Current vs previous month</th></tr></thead>
            <tbody>
              {METRICS.map(([k, l, lower, suf]) => (
                <tr key={k} className="border-t border-line/10">
                  <td className="td font-semibold">{l}</td>
                  {cols.map((c) => <td key={c.label} className="td text-center tabular-nums">{c.rec && c.rec[k] != null && c.rec[k] !== '' ? `${Number(c.rec[k]).toLocaleString('en-IN')}${suf ?? ''}` : <span className="text-muted">no data</span>}</td>)}
                  <td className="td text-center">{delta(cols[0].rec, cols[1].rec, k, lower)}</td><td className="td text-center">{delta(cols[2].rec, cols[3].rec, k, lower)}</td><td className="td text-center">{delta(cols[2].rec, cols[0].rec, k, lower)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <ChartCard title="History" subtitle="Sessions and organic clicks by month"><LinesChart data={history} series={[{ key: 'sessions', name: 'Sessions', color: CH[0] }, { key: 'clicks', name: 'Organic clicks', color: CH[1] }]} area /></ChartCard>
    </div>
  );
}

/* ───────── Development blogs: counts from verified, dated, published records only ───────── */
export const isPublished = (r: Rec) => r.blog_status === 'Published' && !!r.publish_verified && !!r.published_date;

export function BlogStats({ rows, lk }: ExtraProps) {
  const now = new Date();
  const ym = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  const cur = ym(now), prev = ym(new Date(now.getFullYear(), now.getMonth() - 1, 1)), year = String(now.getFullYear());
  const pub = rows.filter(isPublished);
  const table = useMemo(() => {
    const g = groupBy(rows, (r) => r.client_id ?? '');
    return [...g.entries()].map(([cid, rs]) => {
      const p = rs.filter(isPublished);
      return { name: lk.client(cid), total: p.length, month: p.filter((r) => String(r.published_date).startsWith(cur)).length, prev: p.filter((r) => String(r.published_date).startsWith(prev)).length,
        year: p.filter((r) => String(r.published_date).startsWith(year)).length, pending: rs.filter((r) => !['Published', 'Cancelled'].includes(r.blog_status)).length, unverified: rs.filter((r) => r.blog_status === 'Published' && !isPublished(r)).length };
    }).sort((a, b) => b.total - a.total);
  }, [rows, lk, cur, prev, year]);
  const thisMonth = pub.filter((r) => String(r.published_date).startsWith(cur)).length;
  const lastMonth = pub.filter((r) => String(r.published_date).startsWith(prev)).length;
  const monthly = MONTH_NAMES.map((n, i) => ({ name: n.slice(0, 3), blogs: pub.filter((r) => String(r.published_date).startsWith(`${year}-${String(i + 1).padStart(2, '0')}`)).length }));
  return (
    <div className="mb-4 space-y-4">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatsCard label="Published (verified)" value={pub.length} icon="Newspaper" hint="Marked Published, verified and dated" />
        <StatsCard label="Published this month" value={thisMonth} icon="CalendarDays" accent="secondary" hint={`Previous month: ${lastMonth}`} />
        <StatsCard label="Published this year" value={pub.filter((r) => String(r.published_date).startsWith(year)).length} icon="ChartColumn" accent="accent" />
        <StatsCard label="Pending blogs" value={rows.filter((r) => !['Published', 'Cancelled'].includes(r.blog_status)).length} icon="Clock" accent="dark" />
      </div>
      <div className="grid gap-4 lg:grid-cols-3">
        <ChartCard title={`Blogs published per month, ${year}`} className="lg:col-span-2"><BarsChart data={monthly} series={[{ key: 'blogs', name: 'Published', color: CH[0] }]} /></ChartCard>
        <div className="panel overflow-hidden"><div className="border-b border-line/10 px-4 py-2.5 text-sm font-bold">By client</div>
          <div className="max-h-64 overflow-auto"><table className="w-full text-sm"><thead className="sticky top-0 bg-surface2/95"><tr>{['Client', 'This month', 'Prev.', 'Year', 'Total', 'Pending'].map((h) => <th key={h} className="th">{h}</th>)}</tr></thead>
            <tbody>{table.map((t) => <tr key={t.name} className="border-t border-line/10"><td className="td font-semibold">{t.name}{t.unverified > 0 && <span className="ml-1 text-[10px] font-normal text-muted" title="Marked published but not verified or not dated, so not counted">({t.unverified} unverified)</span>}</td><td className="td">{t.month}</td><td className="td">{t.prev}</td><td className="td">{t.year}</td><td className="td font-bold">{t.total}</td><td className="td">{t.pending}</td></tr>)}</tbody></table></div></div>
      </div>
    </div>
  );
}
