'use client';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { Icon } from '../Icon';
import { Drawer, EmptyState, ExpiryChip, PriorityBadge, Skeleton } from '../ui';
import { ActivityTimeline } from './ActivityTimeline';
import { fmtDerived, renderValue, StatusMenu } from './cells';
import { api } from '@/lib/data';
import type { Lookups } from '@/lib/hooks';
import type { ModuleDef } from '@/lib/modules';
import type { Rec } from '@/lib/types';
import { fmtDate } from '@/lib/utils';

interface Props {
  m: ModuleDef;
  rec: Rec | null;
  lk: Lookups;
  onClose: () => void;
  onEdit?: (r: Rec) => void;
  onDelete?: (r: Rec) => void;
  onStatus?: (r: Rec, v: string) => void;
  onImage?: (src: string, r: Rec) => void;
  extra?: (r: Rec) => React.ReactNode;
}

export function RecordDrawer({ m, rec, lk, onClose, onEdit, onDelete, onStatus, onImage, extra }: Props) {
  const act = useQuery({ queryKey: ['activity', m.key, rec?.id], queryFn: () => api.activity.forRecord(m.key, rec!.id), enabled: !!rec && !m.readonly });
  const title = rec ? (m.titleField === 'client_id' ? lk.client(rec.client_id) : String(rec[m.titleField] ?? m.title)) : '';
  const imageField = m.fields.find((f) => f.type === 'image');
  const thumb = rec && imageField ? rec[imageField.key] : null;
  const output = rec ? (rec.output_link as string | undefined) : undefined;
  return (
    <Drawer open={!!rec} onClose={onClose} title={rec ? title : m.title}
      footer={rec && !m.readonly ? (
        <>
          {onDelete && <button className="btn-ghost text-primary-800 dark:text-primary-200" onClick={() => onDelete(rec)}><Icon name="Trash2" size={16} />Delete</button>}
          {onEdit && <button className="btn-primary" onClick={() => onEdit(rec)}><Icon name="Pencil" size={16} />Edit</button>}
        </>
      ) : undefined}>
      {rec && (
        <div className="space-y-5">
          <div className="flex flex-wrap items-center gap-2">
            <span className="rounded-full bg-primary/10 px-2.5 py-0.5 text-xs font-bold text-primary dark:text-primary-200">{m.title}</span>
            {m.statusField && <StatusMenu m={m} rec={rec} disabled={m.readonly || !onStatus} onChange={(v) => onStatus?.(rec, v)} />}
            {m.hasPriority && <PriorityBadge priority={rec.priority} />}
            {m.expiryField && <ExpiryChip date={rec[m.expiryField]} detail />}
          </div>

          {thumb && (
            <motion.button initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} onClick={() => onImage?.(thumb, rec)} className="group relative block w-full overflow-hidden rounded-2xl ring-1 ring-line/25" aria-label="Open larger preview">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={thumb} alt={title} className="h-48 w-full object-cover transition duration-500 group-hover:scale-105" />
              {m.anim === 'video' && <span className="absolute inset-0 grid place-items-center bg-primary-900/30"><span className="grid h-14 w-14 place-items-center rounded-full bg-white/90 text-primary shadow-lift"><Icon name="Play" size={24} /></span></span>}
            </motion.button>
          )}
          {output && <a href={output} target="_blank" rel="noopener noreferrer" className="btn-primary w-full"><Icon name="ExternalLink" size={16} />Open Output</a>}
          {extra?.(rec)}

          <dl className="grid grid-cols-1 gap-x-4 gap-y-3 sm:grid-cols-2">
            {m.fields.filter((f) => f.type !== 'image' && f.key !== 'remark').map((f) => (
              <div key={f.key} className="min-w-0">
                <dt className="label !mb-0.5">{f.label}</dt>
                <dd className="text-sm">{renderValue(m, f, rec, lk, { onImage })}</dd>
              </div>
            ))}
            {m.derived.map((d) => (
              <div key={d.key}><dt className="label !mb-0.5">{d.label}</dt><dd className="text-sm font-semibold">{fmtDerived(d, rec)}</dd></div>
            ))}
          </dl>

          {rec.remark && (
            <div>
              <h3 className="label">Remark</h3>
              <p className="whitespace-pre-wrap rounded-xl bg-surface2 p-3 text-sm">{rec.remark}</p>
            </div>
          )}

          <div className="grid grid-cols-2 gap-3 rounded-xl bg-surface2 p-3 text-xs text-muted">
            <div><div className="font-semibold uppercase tracking-wide">Created by</div><div className="text-sm text-ink">{lk.user(rec.created_by)}</div></div>
            <div><div className="font-semibold uppercase tracking-wide">Created</div><div className="text-sm text-ink">{fmtDate(rec.created_at)}</div></div>
            <div><div className="font-semibold uppercase tracking-wide">Updated by</div><div className="text-sm text-ink">{lk.user(rec.updated_by)}</div></div>
            <div><div className="font-semibold uppercase tracking-wide">Updated</div><div className="text-sm text-ink">{fmtDate(rec.updated_at)}</div></div>
          </div>

          {!m.readonly && (
            <div>
              <h3 className="mb-2 flex items-center gap-2 text-sm font-bold"><Icon name="Activity" size={16} className="text-primary" />Activity timeline</h3>
              {act.isLoading ? <div className="space-y-2"><Skeleton className="h-10" /><Skeleton className="h-10" /></div> : act.data?.length ? <ActivityTimeline items={act.data} /> : <EmptyState title="No activity yet" message="Changes to this record will appear here." />}
            </div>
          )}
        </div>
      )}
    </Drawer>
  );
}
