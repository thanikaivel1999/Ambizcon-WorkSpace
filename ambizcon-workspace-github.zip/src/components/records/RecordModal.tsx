'use client';
import { useEffect, useId, useState } from 'react';
import { Icon } from '../Icon';
import { useToast } from '../providers';
import { ExpiryChip, Modal } from '../ui';
import { api } from '@/lib/data';
import { useSetting, type Lookups } from '@/lib/hooks';
import type { Field, ModuleDef } from '@/lib/modules';
import type { Rec } from '@/lib/types';
import { cn, todayISO } from '@/lib/utils';
import { validateRecord } from '@/lib/validate';

type Values = Record<string, any>;

export function defaultsFor(m: ModuleDef): Values {
  const v: Values = {};
  for (const f of m.fields) {
    if (f.system) continue;
    if (f.type === 'bool') v[f.key] = false;
    else if (f.type === 'select' && f.key === m.statusField) v[f.key] = f.options?.includes('Pending') ? 'Pending' : f.options?.[0] ?? '';
    else if (f.key === 'priority') v[f.key] = 'Medium';
    else if (['date_assigned', 'check_date', 'log_date', 'report_date'].includes(f.key)) v[f.key] = todayISO();
    else v[f.key] = '';
  }
  return v;
}

function recordToValues(m: ModuleDef, rec: Rec): Values {
  const v: Values = {};
  for (const f of m.fields) if (!f.system) v[f.key] = rec[f.key] ?? (f.type === 'bool' ? false : '');
  return v;
}

export function userOptions(lk: Lookups, m: ModuleDef, f: Field, current?: string) {
  const team = f.key === 'creative_assigned_to' ? 'creative' : m.team;
  return lk.users.filter((u) => (u.status === 'active' && (u.team === team || u.team === 'admin')) || u.id === current);
}

function FieldInput({ f, m, value, onChange, error, lk }: { f: Field; m: ModuleDef; value: any; onChange: (v: any) => void; error?: string; lk: Lookups }) {
  const id = useId();
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const categories = useSetting<string[]>('work_categories', []).value;
  const common = { id, 'aria-invalid': !!error, 'aria-describedby': error ? id + '-err' : undefined, className: cn('input', error && '!border-primary-900 ring-2 ring-primary-900/20') } as const;
  let control;
  switch (f.type) {
    case 'longtext':
      control = <textarea {...common} rows={3} value={value ?? ''} onChange={(e) => onChange(e.target.value)} />;
      break;
    case 'number':
      control = <input {...common} type="number" inputMode="decimal" min={0} step="any" value={value ?? ''} onChange={(e) => onChange(e.target.value)} />;
      break;
    case 'date':
    case 'expiry':
      control = (
        <div className="flex items-center gap-2">
          <input {...common} type="date" value={value ?? ''} onChange={(e) => onChange(e.target.value)} />
          {f.type === 'expiry' && value && <ExpiryChip date={value} />}
        </div>
      );
      break;
    case 'time':
      control = <input {...common} type="time" value={value ?? ''} onChange={(e) => onChange(e.target.value)} />;
      break;
    case 'select':
    case 'check':
      control = (
        <select {...common} value={value ?? ''} onChange={(e) => onChange(e.target.value)}>
          <option value="">Select…</option>
          {f.options?.map((o) => <option key={o}>{o}</option>)}
        </select>
      );
      break;
    case 'user':
      control = (
        <select {...common} value={value ?? ''} onChange={(e) => onChange(e.target.value)}>
          <option value="">Unassigned</option>
          {userOptions(lk, m, f, value).map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}
        </select>
      );
      break;
    case 'client':
      control = (
        <select {...common} value={value ?? ''} onChange={(e) => onChange(e.target.value)}>
          <option value="">Select client…</option>
          {lk.clients.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
      );
      break;
    case 'bool':
      control = (
        <label className="flex cursor-pointer items-center gap-3 py-2">
          <input id={id} type="checkbox" role="switch" className="peer sr-only" checked={!!value} onChange={(e) => onChange(e.target.checked)} />
          <span className="relative h-6 w-11 rounded-full bg-line/25 transition peer-checked:bg-primary peer-focus-visible:outline peer-focus-visible:outline-2 peer-focus-visible:outline-primary after:absolute after:left-0.5 after:top-0.5 after:h-5 after:w-5 after:rounded-full after:bg-white after:shadow after:transition peer-checked:after:translate-x-5" />
          <span className="text-sm">{value ? 'Yes' : 'No'}</span>
        </label>
      );
      break;
    case 'file':
      control = (
        <div className="flex gap-2">
          <input {...common} type="text" placeholder="https://… or upload a file" value={String(value ?? '').startsWith('data:') || String(value ?? '').startsWith('storage://') ? '(uploaded file)' : value ?? ''} onChange={(e) => onChange(e.target.value)} readOnly={String(value ?? '').startsWith('data:') || String(value ?? '').startsWith('storage://')} />
          <label className="btn-ghost shrink-0 cursor-pointer">
            {busy ? <Icon name="Loader2" className="animate-spin" size={16} /> : <Icon name="FileText" size={16} />}
            <span className="hidden sm:inline">Upload</span>
            <input type="file" accept=".pdf,.png,.jpg,.jpeg,.webp,.gif,.txt,.csv,.doc,.docx,.xls,.xlsx" className="sr-only" onChange={async (e) => {
              const file = e.target.files?.[0];
              if (!file) return;
              setBusy(true);
              try { onChange(await api.uploadFile(file)); } catch (err) { toast.error((err as Error).message); } finally { setBusy(false); e.target.value = ''; }
            }} />
          </label>
          {value && <button type="button" className="btn-ghost shrink-0" onClick={() => onChange('')} aria-label="Remove file"><Icon name="X" size={16} /></button>}
        </div>
      );
      break;
    case 'image':
      control = (
        <div className="space-y-2">
          <div className="flex gap-2">
            <input {...common} type="text" placeholder="https://… or upload" value={String(value ?? '').startsWith('data:') ? '(uploaded image)' : value ?? ''} onChange={(e) => onChange(e.target.value)} readOnly={String(value ?? '').startsWith('data:')} />
            <label className="btn-ghost shrink-0 cursor-pointer">
              {busy ? <Icon name="Loader2" className="animate-spin" size={16} /> : <Icon name="Image" size={16} />}
              <span className="hidden sm:inline">Upload</span>
              <input type="file" accept="image/png,image/jpeg,image/webp,image/gif" className="sr-only" onChange={async (e) => {
                const file = e.target.files?.[0];
                if (!file) return;
                setBusy(true);
                try { onChange(await api.uploadImage(file)); } catch (err) { toast.error((err as Error).message); } finally { setBusy(false); e.target.value = ''; }
              }} />
            </label>
            {value && <button type="button" className="btn-ghost shrink-0" onClick={() => onChange('')} aria-label="Remove image"><Icon name="X" size={16} /></button>}
          </div>
          {value && /* eslint-disable-next-line @next/next/no-img-element */ <img src={value} alt="Preview" className="h-24 rounded-lg object-cover ring-1 ring-line/25" />}
        </div>
      );
      break;
    default:
      control = (
        <>
          <input {...common} type={f.type === 'url' ? 'url' : 'text'} inputMode={f.type === 'url' ? 'url' : undefined} placeholder={f.type === 'url' ? 'https://…' : undefined} value={value ?? ''} onChange={(e) => onChange(e.target.value)} list={f.key === 'category' ? id + '-cats' : undefined} />
          {f.key === 'category' && categories.length > 0 && <datalist id={id + '-cats'}>{categories.map((c) => <option key={c} value={c} />)}</datalist>}
        </>
      );
  }
  const wide = f.type === 'longtext' || f.type === 'image' || f.type === 'file';
  return (
    <div className={cn(wide && 'sm:col-span-2')}>
      <label htmlFor={id} className="label">{f.label}{f.required && <span className="text-primary" aria-hidden> *</span>}{f.suffix && <span className="ml-1 normal-case opacity-60">({f.suffix})</span>}</label>
      {control}
      {error && <p id={id + '-err'} role="alert" className="mt-1 text-xs font-medium text-primary-800 dark:text-primary-200">{error}</p>}
    </div>
  );
}

interface Props {
  m: ModuleDef;
  open: boolean;
  onClose: () => void;
  record?: Rec | null;
  lk: Lookups;
  busy?: boolean;
  onSubmit: (data: Record<string, unknown>) => void;
  initial?: Values;
}

export function RecordModal({ m, open, onClose, record, lk, busy, onSubmit, initial }: Props) {
  const [values, setValues] = useState<Values>({});
  const [errors, setErrors] = useState<Record<string, string>>({});
  useEffect(() => {
    if (open) { setValues(record ? recordToValues(m, record) : { ...defaultsFor(m), ...initial }); setErrors({}); }
  }, [open, record, m, initial]);
  const label = m.title.replace(/s$/, '');
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const r = validateRecord(m, values);
    setErrors(r.errors);
    if (r.ok) onSubmit(r.data);
  };
  return (
    <Modal open={open} onClose={onClose} title={record ? `Edit ${label}` : `Add New ${label}`} size="lg"
      footer={<>
        <button type="button" className="btn-ghost" onClick={onClose}>Cancel</button>
        <button type="submit" form="record-form" className="btn-primary" disabled={busy}>{busy && <Icon name="Loader2" className="animate-spin" size={16} />}{record ? 'Save changes' : 'Create record'}</button>
      </>}>
      <form id="record-form" onSubmit={submit} noValidate className="grid grid-cols-1 gap-x-4 gap-y-3 sm:grid-cols-2">
        {Object.keys(errors).length > 0 && <p role="alert" className="rounded-lg bg-primary-900 px-3 py-2 text-sm font-medium text-white sm:col-span-2">Please fix the highlighted fields.</p>}
        {m.fields.filter((f) => !f.system).map((f) => (
          <FieldInput key={f.key} f={f} m={m} lk={lk} value={values[f.key]} error={errors[f.key]} onChange={(v) => setValues((s) => ({ ...s, [f.key]: v }))} />
        ))}
        {m.secretNote && <p className="rounded-lg bg-primary/10 p-3 text-xs text-muted sm:col-span-2"><Icon name="Lock" size={12} className="mr-1 inline" />{m.secretNote}</p>}
      </form>
    </Modal>
  );
}
