'use client';
import { Icon } from '../Icon';
import { Modal } from '../ui';

export interface Preview { src: string; title: string; output?: string | null; video?: boolean }

export function ImagePreview({ preview, onClose }: { preview: Preview | null; onClose: () => void }) {
  return (
    <Modal open={!!preview} onClose={onClose} title={preview?.title ?? 'Preview'} size="lg" footer={preview?.output ? <a className="btn-primary" href={preview.output} target="_blank" rel="noopener noreferrer"><Icon name="ExternalLink" size={16} />Open Output</a> : undefined}>
      {preview && (
        <div className="relative overflow-hidden rounded-xl bg-surface2">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={preview.src} alt={preview.title} className="mx-auto max-h-[65vh] w-full object-contain" />
          {preview.video && <span className="pointer-events-none absolute inset-0 grid place-items-center"><span className="grid h-16 w-16 place-items-center rounded-full bg-white/90 text-primary shadow-lift"><Icon name="Play" size={28} /></span></span>}
        </div>
      )}
    </Modal>
  );
}
