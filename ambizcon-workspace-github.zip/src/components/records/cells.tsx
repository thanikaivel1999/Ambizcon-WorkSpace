'use client';
import { useEffect, useRef, useState, type ReactNode } from 'react';
import { Icon } from '../Icon';
import { ExpiryChip, PriorityBadge, StatusBadge, ToneBadge, UserAvatar } from '../ui';
import type { Derived, Field, ModuleDef } from '@/lib/modules';
import { effStatus } from '@/lib/stats';
import { STATUSES, type Rec, type Status } from '@/lib/types';
import { api } from '@/lib/data';
import type { Lookups } from '@/lib/hooks';
import { cn, fmtDate, fmtNumber } from '@/lib/utils';

export const money = (n: number) => '₹' + Math.round(n).toLocaleString('en-IN');
export const fmtDerived = (d: Derived, r: Rec) => {
  const v = d.fn(r);
  if (typeof v === 'string') return v;
  return d.fmt === 'pct' ? `${v.toFixed(1)}%` : d.fmt === 'money' ? '₹' + v.toFixed(2) : Math.round(v).toLocaleString('en-IN');
};

export function UserChip({ id, lk }: { id?: string | null; lk: Lookups }) {
  const u = lk.userById(id);
  if (!u) return <span className="text-muted">—</span>;
  return <span className="inline-flex items-center gap-2 whitespace-nowrap"><UserAvatar name={u.name} src={u.avatar_url} size={22} />{u.name}</span>;
}

/** Opens an uploaded file (signed URL for private storage, or the link itself). */
export function FileLink({ value }: { value: string }) {
  const [busy, setBusy] = useState(false);
  const open = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!value.startsWith('storage://')) return;
    e.preventDefault();
    setBusy(true);
    try { window.open(await api.fileUrl(value), '_blank', 'noopener,noreferrer'); } finally { setBusy(false); }
  };
  const href = value.startsWith('storage://') ? '#' : value;
  return <a href={href} target="_blank" rel="noopener noreferrer" onClick={open} download={value.startsWith('data:') ? 'file' : undefined} className="inline-flex items-center gap-1 font-semibold text-primary hover:underline">{busy ? <Icon name="Loader2" className="animate-spin" size={13} /> : <Icon name="FileText" size={13} />}Open file</a>;
}

export const Check = ({ on }: { on: boolean }) =>
  on ? <span className="inline-grid h-5 w-5 place-items-center rounded-full bg-secondary-400 text-white" aria-label="Yes"><Icon name="Check" size={13} /></span> : <span className="inline-grid h-5 w-5 place-items-center rounded-full bg-line/10 text-muted" aria-label="No"><Icon name="X" size={12} /></span>;

/** Click-to-change status pill. */
export function StatusMenu({ m, rec, onChange, disabled }: { m: ModuleDef; rec: Rec; onChange: (value: string) => void; disabled?: boolean }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const away = (e: MouseEvent) => !ref.current?.contains(e.target as Node) && setOpen(false);
    const esc = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
    document.addEventListener('mousedown', away);
    document.addEventListener('keydown', esc);
    return () => { document.removeEventListener('mousedown', away); document.removeEventListener('keydown', esc); };
  }, [open]);
  const field = m.fields.find((f) => f.key === m.statusField);
  const options = (field?.options ?? STATUSES).filter((s) => s !== 'Overdue');
  const eff = effStatus(m, rec);
  const raw = rec[m.statusField] as string;
  const label = m.statusMap ? raw : undefined;
  return (
    <div ref={ref} className="relative inline-block" onClick={(e) => e.stopPropagation()}>
      <button disabled={disabled} onClick={() => setOpen((o) => !o)} aria-haspopup="listbox" aria-expanded={open} aria-label={`Change ${m.statusLabel}: currently ${raw ?? 'none'}`} className="rounded-full transition hover:brightness-110 focus-visible:outline-offset-4 disabled:cursor-default">
        <StatusBadge status={eff} label={eff === 'Overdue' ? 'Overdue' : label} />
      </button>
      {open && (
        <ul role="listbox" className="panel absolute left-0 top-8 z-30 min-w-40 overflow-hidden py-1 shadow-lift" style={{ background: 'rgb(var(--surface))' }}>
          {options.map((o) => (
            <li key={o}>
              <button role="option" aria-selected={o === raw} className={cn('flex w-full items-center gap-2 px-3 py-1.5 text-left text-sm hover:bg-primary/10', o === raw && 'font-bold')} onClick={() => { setOpen(false); if (o !== raw) onChange(o); }}>
                {m.statusMap ? <StatusBadge status={m.statusMap[o]} label={o} /> : <StatusBadge status={o as Status} />}
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export function renderValue(m: ModuleDef, f: Field, rec: Rec, lk: Lookups, opts: { onImage?: (src: string, rec: Rec) => void } = {}): ReactNode {
  const v = rec[f.key];
  switch (f.type) {
    case 'client': return lk.client(v);
    case 'user': return <UserChip id={v} lk={lk} />;
    case 'date': return fmtDate(v);
    case 'expiry': return v ? <span>{fmtDate(v)}{rec.date_confidence === 'Estimated' && <span className="ml-1 text-xs text-muted" title="Estimated date: not confirmed">(est.)</span>}</span> : <span className="text-muted" title="No date recorded">Unknown</span>;
    case 'time': return v ? new Date(`1970-01-01T${v}`).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' }) : '—';
    case 'bool': return <Check on={!!v} />;
    case 'check': return v ? <ToneBadge value={v} /> : '—';
    case 'url': return v ? <a href={v} target="_blank" rel="noopener noreferrer" onClick={(e) => e.stopPropagation()} className="inline-flex items-center gap-1 font-semibold text-primary hover:underline"><Icon name="ExternalLink" size={13} />Open</a> : <span className="text-muted">—</span>;
    case 'file': return v ? <FileLink value={String(v)} /> : <span className="text-muted">—</span>;
    case 'image': return v ? (
      <button onClick={(e) => { e.stopPropagation(); opts.onImage?.(v, rec); }} className="block overflow-hidden rounded-lg ring-1 ring-line/25 transition hover:scale-105 hover:shadow-card" aria-label="Preview image">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={v} alt="" loading="lazy" className="h-9 w-14 object-cover" />
      </button>
    ) : <span className="text-muted">—</span>;
    case 'number': return v == null ? '—' : f.money ? money(v) : f.suffix ? `${fmtNumber(v)}${f.suffix === '%' ? '%' : ' ' + f.suffix}` : fmtNumber(v);
    case 'select':
      if (f.key === 'priority') return <PriorityBadge priority={v} />;
      return v ? (/status|index|type$/i.test(f.key) && !/backup_type|seo_type|tool_type|content_type|access_type|group_type/.test(f.key) ? <ToneBadge value={v} /> : v) : '—';
    case 'longtext': return v ? <span className="line-clamp-2 max-w-[22rem]">{v}</span> : '—';
    default: return v ? <span className="block max-w-[18rem] truncate" title={String(v)}>{v}</span> : '—';
  }
}

export function renderCell(m: ModuleDef, key: string, rec: Rec, lk: Lookups, opts: Parameters<typeof renderValue>[4] = {}): ReactNode {
  const d = m.derived.find((x) => x.key === key);
  if (d) return fmtDerived(d, rec);
  if (key.startsWith('__days')) return <ExpiryChip date={rec[key.includes(':') ? key.split(':')[1] : m.expiryField!]} />;
  const f = m.fields.find((x) => x.key === key)!;
  const first = key === m.titleField;
  return <span className={cn(first && 'font-semibold')}>{renderValue(m, f, rec, lk, opts)}</span>;
}
