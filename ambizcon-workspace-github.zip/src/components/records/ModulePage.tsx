'use client';
import { motion } from 'framer-motion';
import { useSearchParams } from 'next/navigation';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { DataTable, type Column } from '../DataTable';
import { FilterBar } from '../FilterBar';
import { Icon } from '../Icon';
import { ConfirmDialog, EmptyState, ErrorState, LoadingState, PageHeader, PriorityBadge, Reveal } from '../ui';
import { renderCell, StatusMenu } from './cells';
import * as X from './extras';
import * as X2 from './extras-more';
import { ImagePreview, type Preview } from './ImagePreview';
import { RecordDrawer } from './RecordDrawer';
import { SavedViews } from './SavedViews';
import { RecordModal } from './RecordModal';
import { LinkedCreative, RequestCreativeModal } from './RequestCreative';
import { downloadCsv, toCsv } from '@/lib/csv';
import { EMPTY_FILTERS, applyFilters, isFiltered, type Filters } from '@/lib/filter';
import { useAuth, useToast } from '../providers';
import { levelFor, toPermMap } from '@/lib/custom';
import { useLookups, useModuleDef, usePermissions, useRecordActions, useRecords, type Lookups } from '@/lib/hooks';
import type { ModuleDef } from '@/lib/modules';
import { effStatus } from '@/lib/stats';
import type { Rec } from '@/lib/types';
import { cn, fmtDate, todayISO } from '@/lib/utils';

function buildColumns(m: ModuleDef, lk: Lookups, onImage: (src: string, r: Rec) => void): Column<Rec>[] {
  const keys = m.list ?? m.fields.filter((f) => f.type !== 'longtext').slice(0, 6).map((f) => f.key);
  const cols: Column<Rec>[] = [];
  const fieldCol = (key: string): Column<Rec> | null => {
    const d = m.derived.find((x) => x.key === key);
    if (d) return { key, label: d.label, render: (r) => renderCell(m, key, r, lk), sortValue: (r) => d.fn(r) };
    const f = m.fields.find((x) => x.key === key);
    if (!f) return null;
    return {
      key, label: f.label, render: (r) => renderCell(m, key, r, lk, { onImage: (s, rec) => onImage(s, rec) }),
      sortValue: f.type === 'client' ? (r) => lk.client(r.client_id) : f.type === 'user' ? (r) => lk.user(r[key]) : f.type === 'number' ? (r) => Number(r[key]) || 0 : (r) => String(r[key] ?? ''),
      card: f.type !== 'image',
    };
  };
  for (const k of keys) {
    const c = fieldCol(k);
    if (c) cols.push(c);
    if (m.fields.find((x) => x.key === k)?.type === 'expiry') cols.push({ key: `__days:${k}`, label: keys.filter((x) => m.fields.find((f) => f.key === x)?.type === 'expiry').length > 1 ? `${m.fields.find((x) => x.key === k)!.label}: days left` : 'Days Remaining', render: (r) => renderCell(m, `__days:${k}`, r, lk), sortValue: (r) => (r[k] ? new Date(r[k]).getTime() : 0) });
  }
  if (m.dueField && !keys.includes(m.dueField) && !m.expiryField) { const c = fieldCol(m.dueField); if (c) cols.push(c); }
  for (const d of m.derived) if (!keys.includes(d.key)) { const c = fieldCol(d.key); if (c) cols.push(c); }
  if (m.hasPriority && !keys.includes('priority')) cols.push({ key: 'priority', label: 'Priority', render: (r) => <PriorityBadge priority={r.priority} />, sortValue: (r) => ['Low', 'Medium', 'High', 'Urgent'].indexOf(r.priority) });
  if (m.statusField && !keys.includes(m.statusField)) cols.push({ key: m.statusField, label: m.statusLabel, render: () => null, sortValue: (r) => effStatus(m, r) ?? '' });
  return cols;
}

const EXTRAS: Partial<Record<NonNullable<ModuleDef['extra']>, (p: X.ExtraProps) => React.ReactElement | null>> = {
  'mailer-charts': X.MailerCharts, 'ads-chart': X.AdsChart, 'analytics-charts': X.AnalyticsCharts, calendar: X.SpotCalendar, 'backup-latest': X2.BackupLatest, 'perf-compare': X2.PerfCompare, 'blog-stats': X2.BlogStats,
  'youtube-stats': X.YoutubeStats, 'daily-check': X.DailyCheckExtra, 'community-stats': X.CommunityStats, 'creative-stats': X.CreativeStats,
};

export default function ModulePage({ m: baseDef, embedded = false }: { m: ModuleDef; embedded?: boolean }) {
  const m = useModuleDef(baseDef);
  const sp = useSearchParams();
  const lk = useLookups();
  const q = useRecords(m);
  const actions = useRecordActions(m);
  const rows = q.data ?? [];
  const [filters, setFilters] = useState<Filters>({ ...EMPTY_FILTERS, q: sp.get('q') ?? '', client: sp.get('client') ?? '' });
  const [openId, setOpenId] = useState<string | null>(sp.get('open'));
  const [form, setForm] = useState<{ rec: Rec | null; initial?: Record<string, unknown> } | null>(null);
  const [del, setDel] = useState<Rec | null>(null);
  const [preview, setPreview] = useState<Preview | null>(null);
  const [request, setRequest] = useState<Rec | null>(null);
  const [view, setView] = useState<'table' | 'gallery'>('table');

  const imageField = m.fields.find((f) => f.type === 'image');
  const years = useMemo(() => (m.yearField ? [...new Set(rows.map((r) => Number(r[m.yearField!])))].sort((a, b) => b - a) : []), [rows, m.yearField]);
  useEffect(() => {
    if (m.yearField && years.length && !filters.year && !sp.get('open')) setFilters((f) => (f.year ? f : { ...f, year: String(years.includes(new Date().getFullYear()) ? new Date().getFullYear() : years[0]) }));
    // only on first data load
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [years.length]);

  const filtered = useMemo(() => applyFilters(m, rows, filters, lk), [m, rows, filters, lk]);
  const openRec = openId ? rows.find((r) => r.id === openId) ?? null : null;
  const { user } = useAuth();
  const perms = usePermissions();
  const readonly = !!m.readonly || (!!user && levelFor(user.team, m, toPermMap(perms.data ?? [])) === 'read');

  const showImage = useCallback((src: string, r: Rec) => setPreview({ src, title: actions.titleOf(r), output: r.output_link, video: m.anim === 'video' }), [actions, m.anim]);
  const toast = useToast();
  const setStatus = (r: Rec, v: string) => {
    const blocked = m.canSetStatus?.(r, v);
    if (blocked) { toast.error(blocked); return; }
    const extra = m.onStatus?.(v, user?.id ?? '', todayISO()) ?? {};
    actions.update.mutate({ id: r.id, patch: { [m.statusField]: v, ...extra }, before: r });
  };
  const reschedule = (r: Rec, iso: string) => actions.update.mutate({ id: r.id, patch: { content_date: iso }, before: r });

  const columns = useMemo(() => {
    const cols = buildColumns(m, lk, showImage);
    return cols.map((c) => (c.key === m.statusField ? { ...c, render: (r: Rec) => <StatusMenu m={m} rec={r} disabled={readonly} onChange={(v) => setStatus(r, v)} /> } : c));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [m, lk, showImage]);
  // statusField may already be inside `list` (e.g. youtube upload_status): wire the menu there too
  const finalCols = useMemo(() => columns.map((c) => (c.key === m.statusField && m.list?.includes(c.key) ? { ...c, render: (r: Rec) => <StatusMenu m={m} rec={r} disabled={readonly} onChange={(v) => setStatus(r, v)} /> } : c)), // eslint-disable-next-line react-hooks/exhaustive-deps
    [columns]);

  const exportCsv = () => {
    const cols = [
      ...m.fields.filter((f) => f.type !== 'image').map((f) => ({ label: f.label, value: (r: Rec) => (f.type === 'client' ? lk.client(r.client_id) : f.type === 'user' ? lk.user(r[f.key]) : r[f.key]) })),
      ...m.derived.map((d) => ({ label: d.label, value: (r: Rec) => d.fn(r) })),
    ];
    downloadCsv(`${m.key}-${new Date().toISOString().slice(0, 10)}`, toCsv(filtered, cols));
  };

  const submit = (data: Record<string, unknown>) => {
    if (form?.rec) actions.update.mutate({ id: form.rec.id, patch: data, before: form.rec }, { onSuccess: () => setForm(null) });
    else actions.create.mutate(data, { onSuccess: () => setForm(null) });
  };

  const Extra = m.extra ? EXTRAS[m.extra] : undefined;
  const busy = actions.create.isPending || actions.update.isPending;
  const isRequestSource = m.key === 'mailer-scheduler';
  const rowActions = (r: Rec) => (
    <>
      <button className="btn-ghost !p-1.5" onClick={() => setOpenId(r.id)} aria-label={`View ${actions.titleOf(r)}`} title="View"><Icon name="Eye" size={15} /></button>
      {isRequestSource && <button className="btn-ghost !p-1.5" onClick={() => setRequest(r)} aria-label="Request creative" title="Request Creative"><Icon name="Send" size={15} /></button>}
      {!readonly && <button className="btn-ghost !p-1.5" onClick={() => setForm({ rec: r })} aria-label={`Edit ${actions.titleOf(r)}`} title="Edit"><Icon name="Pencil" size={15} /></button>}
      {!readonly && <button className="btn-ghost !p-1.5 hover:!bg-primary-900 hover:!text-white" onClick={() => setDel(r)} aria-label={`Delete ${actions.titleOf(r)}`} title="Delete"><Icon name="Trash2" size={15} /></button>}
    </>
  );

  return (
    <div>
      {!embedded && (
        <PageHeader icon={m.icon} title={m.title} subtitle={m.blurb}
          actions={<>
            {imageField && <div className="inline-flex rounded-xl bg-surface2 p-1" role="group" aria-label="View mode">{(['table', 'gallery'] as const).map((v) => <button key={v} aria-pressed={view === v} onClick={() => setView(v)} className={cn('rounded-lg px-2.5 py-1.5 text-sm font-semibold transition', view === v ? 'bg-gradient-to-r from-primary to-secondary-500 text-white' : 'text-muted')} aria-label={`${v} view`}><Icon name={v === 'table' ? 'Table2' : 'LayoutGrid'} size={16} /></button>)}</div>}
            <button className="btn-ghost" onClick={exportCsv} disabled={!filtered.length} title="Export the filtered rows as CSV"><Icon name="Download" size={16} />Export CSV</button>
            {!readonly && <button className="btn-primary" onClick={() => setForm({ rec: null, initial: filters.client ? { client_id: filters.client } : undefined })}><Icon name="Plus" size={16} />Add New Record</button>}
          </>} />
      )}
      {embedded && <div className="mb-3 flex justify-end gap-2"><button className="btn-ghost" onClick={exportCsv} disabled={!filtered.length} title="Export the filtered rows as CSV"><Icon name="Download" size={16} />Export CSV</button>
        {imageField && <div className="inline-flex rounded-xl bg-surface2 p-1" role="group" aria-label="View mode">{(['table', 'gallery'] as const).map((v) => <button key={v} aria-pressed={view === v} onClick={() => setView(v)} className={cn('rounded-lg px-2.5 py-1.5 text-sm font-semibold transition', view === v ? 'bg-gradient-to-r from-primary to-secondary-500 text-white' : 'text-muted')} aria-label={`${v} view`}><Icon name={v === 'table' ? 'Table2' : 'LayoutGrid'} size={16} /></button>)}</div>}
        {!readonly && <button className="btn-primary" onClick={() => setForm({ rec: null, initial: filters.client ? { client_id: filters.client } : undefined })}><Icon name="Plus" size={16} />Add New Record</button>}</div>}

      {q.isLoading ? <LoadingState variant="table" /> : q.error ? <ErrorState message={(q.error as Error).message} onRetry={() => q.refetch()} /> : (
        <>
          {m.expiryField && <X.ExpirySummary m={m} rows={rows} active={filters.tier} onPick={(t) => setFilters({ ...filters, tier: t })} />}
          {Extra && <Reveal><Extra m={m} rows={filtered} lk={lk} onOpen={(r) => setOpenId(r.id)} onAdd={readonly ? undefined : (initial) => setForm({ rec: null, initial })} onReschedule={readonly ? undefined : reschedule} /></Reveal>}
          <SavedViews m={m} filters={filters} onApply={setFilters} />
          <FilterBar m={m} filters={filters} onChange={setFilters} lk={lk} years={years} count={filtered.length} total={rows.length} />
          {rows.length === 0 ? (
            <div className="panel"><EmptyState action={!readonly} onAction={() => setForm({ rec: null, initial: filters.client ? { client_id: filters.client } : undefined })} /></div>
          ) : filtered.length === 0 ? (
            <div className="panel"><EmptyState title="No matching records" message="Try changing or resetting the filters." action={isFiltered(filters)} actionLabel="Reset filters" onAction={() => setFilters(EMPTY_FILTERS)} /></div>
          ) : view === 'gallery' && imageField ? (
            <Gallery m={m} rows={filtered} lk={lk} imageKey={imageField.key} onOpen={(r) => setOpenId(r.id)} onImage={showImage} onStatus={setStatus} readonly={readonly} />
          ) : (
            <DataTable rows={filtered} columns={finalCols} rowKey={(r) => r.id} caption={m.title} onRowClick={(r) => setOpenId(r.id)} actions={rowActions}
              cardBadge={m.statusField ? (r) => <StatusMenu m={m} rec={r} disabled={readonly} onChange={(v) => setStatus(r, v)} /> : undefined}
              defaultSort={m.dueField && !m.expiryField ? { key: m.dueField, dir: 'desc' } : m.expiryField ? { key: m.expiryField, dir: 'asc' } : undefined} />
          )}
        </>
      )}

      <RecordDrawer m={m} rec={openRec} lk={lk} onClose={() => setOpenId(null)} onImage={showImage}
        onEdit={readonly ? undefined : (r) => { setOpenId(null); setForm({ rec: r }); }} onDelete={readonly ? undefined : (r) => setDel(r)} onStatus={readonly ? undefined : setStatus}
        extra={isRequestSource ? (r) => <LinkedCreative rec={r} onRequest={() => setRequest(r)} /> : undefined} />
      <RecordModal m={m} lk={lk} open={!!form} record={form?.rec} initial={form?.initial} busy={busy} onClose={() => setForm(null)} onSubmit={submit} />
      <ConfirmDialog open={!!del} title="Delete record?" message={del ? `“${actions.titleOf(del)}” will be permanently deleted. This cannot be undone.` : ''} busy={actions.remove.isPending}
        onClose={() => setDel(null)} onConfirm={() => del && actions.remove.mutate(del.id, { onSuccess: () => { setDel(null); setOpenId(null); } })} />
      <ImagePreview preview={preview} onClose={() => setPreview(null)} />
      {isRequestSource && <RequestCreativeModal open={!!request} onClose={() => setRequest(null)} campaign={request} />}
    </div>
  );
}

function Gallery({ m, rows, lk, imageKey, onOpen, onImage, onStatus, readonly }: { m: ModuleDef; rows: Rec[]; lk: Lookups; imageKey: string; onOpen: (r: Rec) => void; onImage: (s: string, r: Rec) => void; onStatus: (r: Rec, v: string) => void; readonly: boolean }) {
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4">
      {rows.map((r, i) => {
        const src = r[imageKey] as string | null;
        return (
          <motion.article key={r.id} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: Math.min(i, 12) * 0.03 }} whileHover={{ y: -4 }} className="panel group overflow-hidden transition-shadow hover:shadow-lift">
            <button className="relative block aspect-[16/10] w-full overflow-hidden bg-surface2" onClick={() => (src ? onImage(src, r) : onOpen(r))} aria-label={`Preview ${r[m.titleField]}`}>
              {src ? /* eslint-disable-next-line @next/next/no-img-element */ <img src={src} alt="" loading="lazy" className="h-full w-full object-cover transition duration-500 group-hover:scale-105" /> : <span className="grid h-full place-items-center text-muted"><Icon name={m.icon} size={36} /></span>}
              {m.anim === 'video' && <span className="absolute inset-0 grid place-items-center bg-primary-900/20"><span className="grid h-12 w-12 place-items-center rounded-full bg-white/90 text-primary shadow-lift transition group-hover:scale-110"><Icon name="Play" size={22} /></span></span>}
            </button>
            <div className="space-y-2 p-3">
              <button className="line-clamp-2 text-left font-bold hover:text-primary" onClick={() => onOpen(r)}>{String(r[m.titleField])}</button>
              <div className="flex flex-wrap items-center gap-2"><StatusMenu m={m} rec={r} disabled={readonly} onChange={(v) => onStatus(r, v)} />{m.hasPriority && <PriorityBadge priority={r.priority} />}</div>
              <div className="flex items-center justify-between text-xs text-muted"><span>{lk.user(r.assigned_to)}</span><span>Due {fmtDate(r.due_date)}</span></div>
              {r.output_link && <a href={r.output_link} target="_blank" rel="noopener noreferrer" className="btn-ghost w-full !py-1.5 text-xs"><Icon name="ExternalLink" size={14} />Open Output</a>}
              {r.request_source && <div className="rounded-md bg-primary/10 px-2 py-1 text-[11px] font-semibold text-primary dark:text-primary-200">Requested: {r.request_source}</div>}
            </div>
          </motion.article>
        );
      })}
    </div>
  );
}
