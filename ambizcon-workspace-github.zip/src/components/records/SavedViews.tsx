'use client';
import { useState } from 'react';
import { Icon } from '../Icon';
import { useAuth } from '../providers';
import type { SavedView } from '../studio';
import { EMPTY_FILTERS, isFiltered, type Filters } from '@/lib/filter';
import { useSetting } from '@/lib/hooks';
import type { ModuleDef } from '@/lib/modules';

/** Saved filter combinations for a module. Everyone can apply them; admins create and delete them. */
export function SavedViews({ m, filters, onApply }: { m: ModuleDef; filters: Filters; onApply: (f: Filters) => void }) {
  const { user } = useAuth();
  const views = useSetting<SavedView[]>('saved_filters', [], (r) => (Array.isArray(r) ? (r as SavedView[]) : []));
  const mine = views.value.filter((v) => v.moduleKey === m.key);
  const [name, setName] = useState('');
  const [adding, setAdding] = useState(false);
  const admin = user?.team === 'admin';
  if (!mine.length && !admin) return null;
  const save = () => {
    const n = name.trim();
    if (!n || !isFiltered(filters)) return;
    views.save.mutate([...views.value, { id: crypto.randomUUID(), moduleKey: m.key, name: n.slice(0, 40), filters: { ...filters } }], { onSuccess: () => { setName(''); setAdding(false); } });
  };
  return (
    <div className="mb-3 flex flex-wrap items-center gap-2 text-sm" aria-label="Saved views">
      <span className="inline-flex items-center gap-1 text-xs font-semibold text-muted"><Icon name="Filter" size={13} />Saved views</span>
      {mine.map((v) => (
        <span key={v.id} className="inline-flex items-center overflow-hidden rounded-full border border-line/25 bg-surface/70">
          <button className="px-3 py-1 text-xs font-semibold hover:bg-primary/10" onClick={() => onApply({ ...EMPTY_FILTERS, ...v.filters })}>{v.name}</button>
          {admin && <button className="px-1.5 text-muted hover:text-ink" aria-label={`Delete saved view ${v.name}`} onClick={() => views.save.mutate(views.value.filter((x) => x.id !== v.id))}><Icon name="X" size={12} /></button>}
        </span>
      ))}
      {admin && (adding ? (
        <span className="inline-flex items-center gap-1"><input className="input !w-40 !py-1" placeholder="View name" aria-label="Saved view name" value={name} onChange={(e) => setName(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && save()} /><button className="btn-primary !py-1 text-xs" disabled={!name.trim() || !isFiltered(filters)} onClick={save}>Save</button><button className="btn-ghost !py-1 text-xs" onClick={() => setAdding(false)}>Cancel</button></span>
      ) : (
        <button className="btn-ghost !py-1 text-xs" disabled={!isFiltered(filters)} title={isFiltered(filters) ? 'Save the current filters as a view' : 'Set some filters first'} onClick={() => setAdding(true)}><Icon name="Plus" size={13} />Save view</button>
      ))}
    </div>
  );
}
