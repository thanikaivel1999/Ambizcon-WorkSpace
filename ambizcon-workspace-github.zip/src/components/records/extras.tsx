'use client';
import { motion } from 'framer-motion';
import { useMemo, useState } from 'react';
import { BarsChart, CH, DonutChart, LinesChart } from '../charts';
import { Icon } from '../Icon';
import { AnimatedCounter, ChartCard, ExpiryChip, Modal, StatsCard, tierStyle } from '../ui';
import { Check } from './cells';
import { useLookups, type Lookups } from '@/lib/hooks';
import { DAILY_CHECKS, type ModuleDef } from '@/lib/modules';
import { dailyCheckSummary, effStatus, summarize } from '@/lib/stats';
import type { Rec } from '@/lib/types';
import { cn, expiryInfo, fmtDate, isoDate, tierOrder, todayISO } from '@/lib/utils';

export interface ExtraProps {
  m: ModuleDef;
  rows: Rec[];
  lk: Lookups;
  onOpen: (r: Rec) => void;
  onAdd?: (initial: Record<string, unknown>) => void;
  /** Drag-and-drop rescheduling (calendar). */
  onReschedule?: (rec: Rec, iso: string) => void;
}

const useLookupsLite = () => { const lk = useLookups(); return (id?: string | null) => lk.client(id); };
const short = (s: string, n = 14) => (s.length > n ? s.slice(0, n - 1) + '…' : s);
const by = <T,>(rows: T[], key: (r: T) => string) => {
  const map = new Map<string, T[]>();
  rows.forEach((r) => { const k = key(r); map.set(k, [...(map.get(k) ?? []), r]); });
  return map;
};
const sum = (rows: Rec[], k: string) => rows.reduce((a, r) => a + (Number(r[k]) || 0), 0);
const label = (iso: string) => new Date(iso + 'T00:00:00').toLocaleDateString('en-GB', { day: '2-digit', month: 'short' });

/** Tier tiles shown above every expiry module; click to filter. */
export function ExpirySummary({ m, rows, active, onPick }: { m: ModuleDef; rows: Rec[]; active: string; onPick: (t: string) => void }) {
  const counts = useMemo(() => {
    const c: Record<string, number> = {};
    rows.forEach((r) => m.fields.filter((f) => f.type === 'expiry').forEach((f) => { const t = expiryInfo(r[f.key])?.tier; if (t) c[t] = (c[t] ?? 0) + 1; }));
    return c;
  }, [rows, m.fields]);
  return (
    <div className="mb-4 grid grid-cols-2 gap-2 sm:grid-cols-4 lg:grid-cols-8" role="group" aria-label="Expiry tiers">
      {tierOrder().map((t, i) => (
        <motion.button key={t} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }} onClick={() => onPick(active === t ? '' : t)} aria-pressed={active === t}
          className={cn('panel flex items-center justify-between gap-2 px-3 py-2 text-left transition hover:-translate-y-0.5 hover:shadow-lift', active === t && 'ring-2 ring-primary')}>
          <span className="text-xs font-semibold text-muted">{tierStyle(t).label}</span>
          <span className="text-xl font-extrabold tabular-nums">{counts[t] ?? 0}</span>
        </motion.button>
      ))}
    </div>
  );
}

export function MailerCharts({ rows }: ExtraProps) {
  const data = useMemo(() => [...rows].sort((a, b) => String(a.send_date).localeCompare(String(b.send_date))).map((r) => ({
    name: short(String(r.campaign_name), 12),
    open: r.delivered && r.unique_opens != null ? +((r.unique_opens / r.delivered) * 100).toFixed(1) : 0,
    click: r.delivered && r.unique_clicks != null ? +((r.unique_clicks / r.delivered) * 100).toFixed(1) : 0,
    delivered: r.delivered, bounced: r.bounced,
  })), [rows]);
  return (
    <div className="mb-4 grid gap-4 lg:grid-cols-3">
      <ChartCard title="Open rate" subtitle="Unique opens ÷ delivered (calculated)"><BarsChart data={data} series={[{ key: 'open', name: 'Open rate %', color: CH[0] }]} unit="%" /></ChartCard>
      <ChartCard title="Click rate" subtitle="Unique clicks ÷ delivered (calculated)"><LinesChart data={data} series={[{ key: 'click', name: 'Click rate %', color: CH[1] }]} unit="%" area /></ChartCard>
      <ChartCard title="Delivery" subtitle="Delivered vs bounced"><BarsChart data={data} series={[{ key: 'delivered', name: 'Delivered', color: CH[0] }, { key: 'bounced', name: 'Bounced', color: CH[5] }]} stacked /></ChartCard>
    </div>
  );
}

export function AdsChart({ rows }: ExtraProps) {
  const daily = useMemo(() => [...by(rows, (r) => r.log_date).entries()].sort(([a], [b]) => a.localeCompare(b)).map(([d, rs]) => ({ name: label(d), spend: sum(rs, 'spend'), clicks: sum(rs, 'clicks'), conversions: sum(rs, 'conversions') })), [rows]);
  const spend = sum(rows, 'spend'), clicks = sum(rows, 'clicks'), impr = sum(rows, 'impressions'), conv = sum(rows, 'conversions');
  return (
    <div className="mb-4 space-y-4">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatsCard label="Total spend" value={spend} icon="TrendingUp" hint="₹ in selection" />
        <StatsCard label="Clicks" value={clicks} icon="Activity" accent="secondary" hint={`CTR ${impr ? ((clicks / impr) * 100).toFixed(2) : 0}%`} />
        <StatsCard label="Conversions" value={conv} icon="BadgeCheck" accent="accent" hint={`CPC ₹${clicks ? (spend / clicks).toFixed(2) : 0}`} />
        <StatsCard label="Impressions" value={impr} icon="Eye" accent="dark" />
      </div>
      <AdsMonthly rows={rows} />
      <ChartCard title="Daily performance" subtitle="Spend, clicks and conversions per day"><LinesChart data={daily} series={[{ key: 'spend', name: 'Spend (₹)', color: CH[0] }, { key: 'clicks', name: 'Clicks', color: CH[1] }, { key: 'conversions', name: 'Conversions', color: CH[4] }]} area height={260} /></ChartCard>
    </div>
  );
}

function AdsMonthly({ rows }: { rows: Rec[] }) {
  const lk = useLookupsLite();
  const data = useMemo(() => {
    const g = by(rows, (r) => `${String(r.log_date).slice(0, 7)}|${r.client_id}`);
    return [...g.entries()].sort(([a], [b2]) => b2.localeCompare(a)).map(([k, rs]) => {
      const [month, client] = k.split('|');
      const spend = sum(rs, 'spend'), clicks = sum(rs, 'clicks'), impr = sum(rs, 'impressions'), conv = sum(rs, 'conversions'), value = sum(rs, 'conversion_value');
      return { month, client: lk(client), days: new Set(rs.map((r) => r.log_date)).size, spend, clicks, impr, conv, ctr: impr ? (clicks / impr) * 100 : null, cpa: conv ? spend / conv : null, roas: value && spend ? value / spend : null };
    });
  }, [rows, lk]);
  if (!data.length) return null;
  return (
    <div className="panel overflow-hidden">
      <div className="border-b border-line/10 px-4 py-2.5"><h3 className="text-sm font-bold">Monthly summary by client</h3><p className="text-xs text-muted">Totals of the daily logs in the current selection. ROAS only where conversion value was entered.</p></div>
      <div className="max-h-64 overflow-auto"><table className="w-full min-w-[640px] text-sm"><thead className="sticky top-0 bg-surface2/95"><tr>{['Month', 'Client', 'Days logged', 'Spend', 'Clicks', 'Conversions', 'CTR', 'Cost / conv.', 'ROAS'].map((h) => <th key={h} className="th">{h}</th>)}</tr></thead>
        <tbody>{data.map((d) => <tr key={d.month + d.client} className="border-t border-line/10"><td className="td">{d.month}</td><td className="td font-semibold">{d.client}</td><td className="td">{d.days}</td><td className="td">₹{Math.round(d.spend).toLocaleString('en-IN')}</td><td className="td">{d.clicks}</td><td className="td">{d.conv}</td><td className="td">{d.ctr === null ? '—' : d.ctr.toFixed(2) + '%'}</td><td className="td">{d.cpa === null ? '—' : '₹' + d.cpa.toFixed(0)}</td><td className="td">{d.roas === null ? '—' : d.roas.toFixed(2)}</td></tr>)}</tbody></table></div>
    </div>
  );
}

export function AnalyticsCharts({ rows, lk }: ExtraProps) {
  const daily = useMemo(() => [...by(rows, (r) => r.report_date).entries()].sort(([a], [b]) => a.localeCompare(b)).map(([d, rs]) => ({ name: label(d), users: sum(rs, 'users'), sessions: sum(rs, 'sessions') })), [rows]);
  const src = useMemo(() => [...by(rows, (r) => r.traffic_source ?? 'Other').entries()].map(([name, rs]) => ({ name, value: sum(rs, 'sessions') })), [rows]);
  const pv = useMemo(() => [...by(rows, (r) => lk.client(r.client_id)).entries()].map(([name, rs]) => ({ name: short(name, 12), views: sum(rs, 'page_views') })).sort((a, b) => b.views - a.views).slice(0, 8), [rows, lk]);
  return (
    <div className="mb-4 grid gap-4 lg:grid-cols-3">
      <ChartCard title="Users & sessions" className="lg:col-span-2"><LinesChart data={daily} series={[{ key: 'users', name: 'Users', color: CH[0] }, { key: 'sessions', name: 'Sessions', color: CH[1] }]} area /></ChartCard>
      <ChartCard title="Traffic sources" subtitle="By sessions"><DonutChart data={src} /></ChartCard>
      <ChartCard title="Page views by client" className="lg:col-span-3"><BarsChart data={pv} series={[{ key: 'views', name: 'Page views', color: CH[2] }]} height={220} /></ChartCard>
    </div>
  );
}

export function YoutubeStats({ rows, lk, onOpen }: ExtraProps) {
  const [tab, setTab] = useState<'with' | 'without' | 'progress' | 'update'>('with');
  const withCh = rows.filter((r) => r.channel_created);
  const withoutCh = rows.filter((r) => !r.channel_created);
  const progress = rows.filter((r) => r.setup_status === 'In progress');
  const update = rows.filter((r) => r.setup_status === 'Needs update');
  const lists = { with: withCh, without: withoutCh, progress, update };
  const tabs = [['with', 'Clients with channels', withCh.length], ['without', 'Clients without channels', withoutCh.length], ['progress', 'Setup in progress', progress.length], ['update', 'Channels needing updates', update.length]] as const;
  const shown = lists[tab];
  return (
    <div className="panel mb-4 p-3 sm:p-4">
      <div className="mb-3 flex flex-wrap gap-1 rounded-xl bg-surface2 p-1" role="tablist" aria-label="Channel lists">
        {tabs.map(([k, l, nn]) => <button key={k} role="tab" aria-selected={tab === k} onClick={() => setTab(k)} className={cn('rounded-lg px-3 py-1.5 text-sm font-semibold transition', tab === k ? 'bg-gradient-to-r from-primary to-secondary-500 text-white shadow' : 'text-muted hover:text-ink')}>{l} <span className="ml-1 rounded-full bg-white/25 px-1.5 text-xs">{nn}</span></button>)}
      </div>
      {shown.length === 0 ? <p className="py-4 text-center text-sm text-muted">Nothing in this list.</p> : (
        <ul className="grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
          {shown.map((r) => (
            <li key={r.id}><button onClick={() => onOpen(r)} className="flex w-full items-center gap-3 rounded-xl border border-line/15 p-3 text-left transition hover:border-primary/40 hover:bg-primary/5">
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-primary/10 text-primary dark:text-primary-200"><Icon name="Video" size={18} /></span>
              <span className="min-w-0"><span className="block truncate text-sm font-semibold">{lk.client(r.client_id)}</span><span className="block truncate text-xs text-muted">{r.channel_name} · {r.setup_status}</span></span>
            </button></li>
          ))}
        </ul>
      )}
    </div>
  );
}

export function CommunityStats({ rows }: ExtraProps) {
  const c = (s: string) => rows.filter((r) => r.request_status === s).length;
  return (
    <div className="mb-4 grid grid-cols-2 gap-3 lg:grid-cols-4">
      <StatsCard label="Accepted" value={c('Accepted')} icon="CircleCheck" accent="secondary" />
      <StatsCard label="Pending requests" value={c('Pending')} icon="Clock" accent="accent" />
      <StatsCard label="Rejected" value={c('Rejected')} icon="Ban" accent="dark" />
      <StatsCard label="People reached" value={sum(rows, 'members')} icon="UsersRound" />
    </div>
  );
}

export function CreativeStats({ m, rows }: ExtraProps) {
  const s = summarize(rows.map((rec) => ({ m, rec })));
  return (
    <div className="mb-4 grid grid-cols-2 gap-3 lg:grid-cols-5">
      <StatsCard label={`Total ${m.nav}`} value={s.total} icon={m.icon} />
      <StatsCard label="In progress" value={s.inProgress} icon="Loader2" accent="secondary" />
      <StatsCard label="Pending" value={s.pending} icon="Clock" accent="accent" />
      <StatsCard label="Completed" value={s.completed} icon="CircleCheck" accent="secondary" />
      <StatsCard label="Overdue" value={s.overdue} icon="AlertTriangle" accent="dark" />
    </div>
  );
}

/* ───────── Daily website check ───────── */
const CHECKS = DAILY_CHECKS;

export function DailyCheckCard({ rows, onOpen, href }: { rows: Rec[]; onOpen?: () => void; href?: string }) {
  const sm = dailyCheckSummary(rows.map((rec) => ({ m: { key: 'daily-check' } as ModuleDef, rec })));
  const tiles = [['Total', sm.total], ['Completed', sm.completed], ['Warning', sm.warning + sm.failed], ['Pending', sm.pending]] as const;
  const body = (
    <motion.div whileHover={{ y: -4 }} className="panel group h-full cursor-pointer p-4 transition-shadow hover:shadow-lift">
      <div className="mb-3 flex items-center justify-between">
        <div className="flex items-center gap-2"><span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-primary to-secondary-400 text-white"><Icon name="ListChecks" /></span><h3 className="font-bold">Today&apos;s Website Checks</h3></div>
        <Icon name="ArrowRight" className="text-muted transition group-hover:translate-x-1 group-hover:text-primary" />
      </div>
      <div className="grid grid-cols-4 gap-2 text-center">
        {tiles.map(([l, v], i) => <div key={l} className={cn('rounded-xl bg-surface2 py-2', l === 'Warning' && v > 0 && 'bg-primary-900 text-white')}><div className="text-2xl font-extrabold"><AnimatedCounter value={v} /></div><div className="text-[11px] font-semibold uppercase tracking-wide opacity-70">{l}</div></div>)}
      </div>
      {sm.failed > 0 && <p className="mt-2 flex items-center gap-1.5 text-xs font-semibold text-primary-800 dark:text-primary-200"><Icon name="AlertTriangle" size={13} />{sm.failed} website{sm.failed > 1 ? 's' : ''} failed a check</p>}
    </motion.div>
  );
  return href ? <a href={href} className="block h-full">{body}</a> : <div className="h-full" role="button" tabIndex={0} onClick={onOpen} onKeyDown={(e) => e.key === 'Enter' && onOpen?.()}>{body}</div>;
}

export function DailyCheckExtra({ rows, lk, onOpen }: ExtraProps) {
  const [open, setOpen] = useState(false);
  const today = rows.filter((r) => r.check_date === todayISO());
  return (
    <>
      <div className="mb-4 max-w-xl"><DailyCheckCard rows={rows} onOpen={() => setOpen(true)} /></div>
      <Modal open={open} onClose={() => setOpen(false)} title={`Today's checklist · ${fmtDate(todayISO())}`} size="xl">
        {today.length === 0 ? <p className="text-sm text-muted">No checks logged for today yet.</p> : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[640px] text-sm">
              <thead><tr><th className="th">Website</th>{CHECKS.map(([, l]) => <th key={l} className="th text-center">{l}</th>)}<th className="th">Status</th></tr></thead>
              <tbody>
                {today.map((r) => (
                  <tr key={r.id} className="cursor-pointer border-t border-line/10 hover:bg-primary/5" onClick={() => { setOpen(false); onOpen(r); }}>
                    <td className="td font-semibold">{r.website}<div className="text-xs font-normal text-muted">{lk.client(r.client_id)}</div></td>
                    {CHECKS.map(([k]) => <td key={k} className="td text-center">{r[k] === 'Pass' ? <Check on /> : r[k] === 'Warning' ? <span title="Warning" className="inline-grid h-5 w-5 place-items-center rounded-full bg-accent text-white"><Icon name="AlertTriangle" size={12} /></span> : r[k] === 'Fail' ? <span title="Failed" className="inline-grid h-5 w-5 animate-pulse place-items-center rounded-full bg-primary-900 text-white"><Icon name="X" size={12} /></span> : '—'}</td>)}
                    <td className="td">{r.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Modal>
    </>
  );
}

/* ───────── Spot calendar (Month / Week / List) ───────── */
const TYPE_TONE = ['bg-primary/20 text-primary-800 dark:text-primary-100', 'bg-secondary/30 text-secondary-700 dark:text-secondary-100', 'bg-accent/30 text-secondary-700 dark:text-accent-100'];

export function SpotCalendar({ m, rows, lk, onOpen, onAdd, onReschedule }: ExtraProps) {
  const [dragOver, setDragOver] = useState<string | null>(null);
  const [view, setView] = useState<'month' | 'week' | 'list'>('month');
  const [cur, setCur] = useState(() => new Date());
  const events = useMemo(() => by(rows, (r) => r.content_date), [rows]);
  const ev = (iso: string) => events.get(iso) ?? [];
  const month = cur.getMonth(), year = cur.getFullYear();
  const first = new Date(year, month, 1);
  const startOffset = (first.getDay() + 6) % 7;
  const days = Array.from({ length: 42 }, (_, i) => new Date(year, month, 1 - startOffset + i));
  const weekStart = new Date(cur); weekStart.setDate(cur.getDate() - ((cur.getDay() + 6) % 7));
  const week = Array.from({ length: 7 }, (_, i) => { const d = new Date(weekStart); d.setDate(weekStart.getDate() + i); return d; });
  const move = (dir: number) => setCur((c) => { const d = new Date(c); if (view === 'month') d.setMonth(d.getMonth() + dir); else d.setDate(d.getDate() + dir * 7); return d; });
  const today = todayISO();
  const chip = (r: Rec) => (
    <button key={r.id} draggable={!!onReschedule} onDragStart={(e) => { e.dataTransfer.setData('text/plain', r.id); e.dataTransfer.effectAllowed = 'move'; }} onClick={(e) => { e.stopPropagation(); onOpen(r); }} title={`${r.content_title} · ${lk.client(r.client_id)}`} className={cn('block w-full truncate rounded-md px-1.5 py-0.5 text-left text-[11px] font-semibold transition hover:brightness-95', TYPE_TONE[(['Blog', 'Post', 'Reel', 'Story', 'Carousel', 'Video', 'Mailer'].indexOf(r.content_type) + 3) % 3], effStatus(m, r) === 'Completed' && 'line-through opacity-60')}>
      {short(String(r.content_title), 22)}
    </button>
  );
  const listDays = [...events.keys()].sort();
  return (
    <div className="panel mb-4 p-3 sm:p-4">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-1">
          <button className="btn-ghost !px-2" onClick={() => move(-1)} aria-label="Previous"><Icon name="ChevronLeft" size={16} /></button>
          <button className="btn-ghost !px-3" onClick={() => setCur(new Date())}>Today</button>
          <button className="btn-ghost !px-2" onClick={() => move(1)} aria-label="Next"><Icon name="ChevronRight" size={16} /></button>
          <h2 className="ml-2 text-lg font-extrabold">{view === 'week' ? `Week of ${label(isoDate(week[0]))}` : cur.toLocaleDateString('en-GB', { month: 'long', year: 'numeric' })}</h2>
        </div>
        <div className="inline-flex rounded-xl bg-surface2 p-1" role="tablist" aria-label="Calendar view">
          {(['month', 'week', 'list'] as const).map((v) => <button key={v} role="tab" aria-selected={view === v} onClick={() => setView(v)} className={cn('rounded-lg px-3 py-1 text-sm font-semibold capitalize transition', view === v ? 'bg-gradient-to-r from-primary to-secondary-500 text-white shadow' : 'text-muted hover:text-ink')}>{v}</button>)}
        </div>
      </div>
      {view !== 'list' && (
        <div className="overflow-x-auto">
          <div className="min-w-[640px]">
            <div className="grid grid-cols-7 gap-px text-center text-[11px] font-bold uppercase tracking-wide text-muted">{['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((d) => <div key={d} className="py-1">{d}</div>)}</div>
            <div className="grid grid-cols-7 gap-px overflow-hidden rounded-xl bg-line/15">
              {(view === 'month' ? days : week).map((d) => {
                const iso = isoDate(d);
                const list = ev(iso);
                const dim = view === 'month' && d.getMonth() !== month;
                return (
                  <div key={iso} className={cn('group relative bg-surface p-1.5', view === 'month' ? 'min-h-24' : 'min-h-56', dim && 'opacity-45', dragOver === iso && 'ring-2 ring-inset ring-primary')}
                    onDragOver={(e) => { if (onReschedule) { e.preventDefault(); setDragOver(iso); } }} onDragLeave={() => setDragOver((x) => (x === iso ? null : x))}
                    onDrop={(e) => { e.preventDefault(); setDragOver(null); const id = e.dataTransfer.getData('text/plain'); const rec = rows.find((x) => x.id === id); if (rec && rec.content_date !== iso) onReschedule?.(rec, iso); }}>
                    <div className="flex items-center justify-between"><span className={cn('grid h-6 w-6 place-items-center rounded-full text-xs font-bold', iso === today && 'bg-primary text-white')}>{d.getDate()}</span>
                      {onAdd && <button aria-label={`Add content on ${iso}`} className="rounded p-0.5 text-muted opacity-0 transition hover:bg-primary/10 hover:text-primary focus:opacity-100 group-hover:opacity-100" onClick={() => onAdd({ content_date: iso })}><Icon name="Plus" size={14} /></button>}</div>
                    <div className="mt-1 space-y-1">{list.slice(0, view === 'month' ? 3 : 12).map(chip)}{view === 'month' && list.length > 3 && <div className="px-1 text-[10px] font-semibold text-muted">+{list.length - 3} more</div>}</div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
      {view === 'list' && (
        <ul className="divide-y divide-line/10">
          {listDays.length === 0 && <li className="py-6 text-center text-sm text-muted">No content scheduled.</li>}
          {listDays.map((iso) => (
            <li key={iso} className="flex gap-3 py-2.5">
              <div className={cn('w-16 shrink-0 text-center', iso === today && 'text-primary')}><div className="text-2xl font-extrabold leading-none">{new Date(iso + 'T00:00:00').getDate()}</div><div className="text-[11px] font-semibold uppercase text-muted">{new Date(iso + 'T00:00:00').toLocaleDateString('en-GB', { month: 'short', weekday: 'short' })}</div></div>
              <div className="flex-1 space-y-1">{ev(iso).map((r) => <button key={r.id} onClick={() => onOpen(r)} className="flex w-full items-center justify-between gap-2 rounded-lg bg-surface2 px-3 py-1.5 text-left text-sm transition hover:bg-primary/10"><span className="min-w-0 truncate font-semibold">{r.content_title}<span className="ml-2 font-normal text-muted">{lk.client(r.client_id)} · {r.content_type}</span></span><span className="shrink-0 text-xs text-muted">{lk.user(r.assigned_to)}</span></button>)}</div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export { ExpiryChip };
