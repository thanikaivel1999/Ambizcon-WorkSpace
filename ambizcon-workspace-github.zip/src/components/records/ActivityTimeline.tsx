'use client';
import { motion } from 'framer-motion';
import { Icon } from '../Icon';
import type { Activity } from '@/lib/types';
import { cn, fmtDate, fmtTime } from '@/lib/utils';

const ICON: Record<string, string> = { created: 'Plus', status: 'Loader2', completed: 'CircleCheck', assigned: 'UserPlus', output: 'Link2', updated: 'Pencil', deleted: 'Trash2' };

/** Vertical timeline, e.g. “10:30 AM — Thanikaivel created task”. Entries are generated automatically by the backend. */
export function ActivityTimeline({ items, showRecord = false }: { items: Activity[]; showRecord?: boolean }) {
  return (
    <ol className="relative space-y-3 border-l-2 border-line/20 pl-5">
      {items.map((a, i) => (
        <motion.li key={a.id} initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: Math.min(i, 10) * 0.04 }} className="relative">
          <span className={cn('absolute -left-[31px] top-0.5 grid h-6 w-6 place-items-center rounded-full text-white ring-4 ring-surface', a.action === 'completed' ? 'bg-secondary-500' : a.action === 'deleted' ? 'bg-primary-900' : 'bg-primary')}>
            <Icon name={ICON[a.action] ?? 'Activity'} size={12} />
          </span>
          <div className="text-xs font-semibold text-muted">{fmtTime(a.created_at)} <span className="font-normal">· {fmtDate(a.created_at)}</span></div>
          <div className="text-sm">
            {a.action === 'created' ? <><b>{a.user_name ?? 'Someone'}</b> created {showRecord ? `“${a.record_title}”` : 'this record'}</> : <>{a.detail}{a.user_name && <span className="text-muted"> · by {a.user_name}</span>}{showRecord && a.record_title && <span className="text-muted"> · {a.record_title}</span>}</>}
          </div>
        </motion.li>
      ))}
    </ol>
  );
}
