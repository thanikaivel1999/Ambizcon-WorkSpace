'use client';
import { useQueryClient } from '@tanstack/react-query';
import { useEffect, useState } from 'react';
import { Icon } from '../Icon';
import { useAuth, useToast } from '../providers';
import { Modal, PriorityBadge } from '../ui';
import { api } from '@/lib/data';
import { useLookups, useRecords } from '@/lib/hooks';
import { MODULE_BY_KEY } from '@/lib/modules';
import { PRIORITIES, type Profile, type Rec } from '@/lib/types';
import { addDays, fmtDate, todayISO } from '@/lib/utils';

const TYPES = [
  { label: 'Web Requirement', key: 'web' },
  { label: 'Video', key: 'videos' },
  { label: 'Artwork', key: 'artworks' },
] as const;
const CATEGORY = 'Email Marketing Creative';
const SCHEDULER = MODULE_BY_KEY['mailer-scheduler'];

/** "artworks:<id>" → the creative record this campaign requested. */
export const parseCreativeRef = (ref?: string | null) => {
  const [key, id] = (ref ?? '').split(':');
  return key && id && MODULE_BY_KEY[key]?.acceptsRequests ? { key, id } : null;
};

/**
 * Marketing → Creative workflow for a scheduled email campaign. Creates ONE Creative task (category "Email Marketing Creative")
 * carrying the dimensions, brief, content and deadline, and stores a link to it on the campaign. A campaign that already has
 * a linked task never creates a second one.
 */
export function RequestCreativeModal({ open, onClose, campaign }: { open: boolean; onClose: () => void; campaign: Rec | null }) {
  const { user } = useAuth() as { user: Profile };
  const toast = useToast();
  const qc = useQueryClient();
  const lk = useLookups();
  const [type, setType] = useState<string>('artworks');
  const [f, setF] = useState({ dimensions: '600 × 300 px', brief: '', priority: 'Medium', due_date: addDays(5) });
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    if (!open || !campaign) return;
    setType('artworks');
    setErr('');
    setF({ dimensions: '600 × 300 px', brief: String(campaign.image_requirement ?? ''), priority: 'Medium', due_date: campaign.scheduled_date && campaign.scheduled_date > todayISO() ? addDays(-1, new Date(campaign.scheduled_date + 'T00:00:00')) : addDays(5) });
  }, [open, campaign]);
  const lead = lk.users.find((u) => u.team === 'creative' && u.role === 'lead' && u.status === 'active');
  const existing = parseCreativeRef(campaign?.creative_task_ref);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!campaign) return;
    if (existing) return setErr('This campaign already has a creative task. Open it from the campaign record instead of creating another.');
    if (f.brief.trim().length < 5) return setErr('Describe the design brief (at least 5 characters).');
    if (!f.due_date) return setErr('Choose a deadline.');
    setBusy(true);
    try {
      const m = MODULE_BY_KEY[type];
      const created = await api.records.create(m, {
        task: `${campaign.campaign} · email creative`, client_id: campaign.client_id ?? null, description: campaign.content ? String(campaign.content) : null, category: CATEGORY, dimensions: f.dimensions.trim() || null,
        brief: f.brief.trim(), priority: f.priority, status: 'New', review_status: 'Not reviewed', date_assigned: todayISO(), due_date: f.due_date, reviewer: lead?.id ?? null,
        request_source: `Marketing · Mailer: ${campaign.campaign}`, requested_by: user.id, source_ref: `mailer-scheduler:${campaign.id}`,
      }, user);
      await api.records.update(SCHEDULER, campaign.id, { creative_task_ref: `${m.key}:${created.id}` }, user);
      qc.invalidateQueries({ queryKey: ['records', m.key] });
      qc.invalidateQueries({ queryKey: ['records', SCHEDULER.key] });
      qc.invalidateQueries({ queryKey: ['notifications'] });
      toast.success('Creative request sent and linked to this campaign.');
      onClose();
    } catch (e2) {
      toast.error((e2 as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal open={open} onClose={onClose} title="Request Creative" size="md" footer={<><button className="btn-ghost" onClick={onClose}>Cancel</button><button className="btn-primary" form="creative-request" type="submit" disabled={busy || !!existing}>{busy ? <Icon name="Loader2" className="animate-spin" size={16} /> : <Icon name="Send" size={16} />}Submit request</button></>}>
      <form id="creative-request" onSubmit={submit} className="grid gap-3 sm:grid-cols-2" noValidate>
        {campaign && <p className="rounded-lg bg-primary/10 px-3 py-2 text-sm sm:col-span-2">For campaign <b>{campaign.campaign}</b> · {lk.client(campaign.client_id)} · scheduled {fmtDate(campaign.scheduled_date)}. Category will be <b>{CATEGORY}</b>.</p>}
        {err && <p role="alert" className="rounded-lg bg-primary-900 px-3 py-2 text-sm text-white sm:col-span-2">{err}</p>}
        <div className="sm:col-span-2">
          <span className="label">Type</span>
          <div className="grid grid-cols-3 gap-2" role="radiogroup" aria-label="Creative type">
            {TYPES.map((t) => (
              <button type="button" key={t.key} role="radio" aria-checked={type === t.key} onClick={() => setType(t.key)} className={`flex flex-col items-center gap-1 rounded-xl border p-3 text-xs font-semibold transition ${type === t.key ? 'border-primary bg-primary/10 text-primary shadow-glow' : 'border-line/25 hover:bg-primary/5'}`}>
                <Icon name={MODULE_BY_KEY[t.key].icon} size={22} />{t.label}
              </button>
            ))}
          </div>
        </div>
        <div><label className="label" htmlFor="rc-dim">Required dimensions</label><input id="rc-dim" className="input" value={f.dimensions} onChange={(e) => setF({ ...f, dimensions: e.target.value })} /></div>
        <div><label className="label" htmlFor="rc-due">Deadline *</label><input id="rc-due" type="date" className="input" min={todayISO()} value={f.due_date} onChange={(e) => setF({ ...f, due_date: e.target.value })} /></div>
        <div className="sm:col-span-2"><label className="label" htmlFor="rc-brief">Design brief *</label><textarea id="rc-brief" rows={4} className="input" value={f.brief} onChange={(e) => setF({ ...f, brief: e.target.value })} placeholder="What should the creative show? Tone, offer, text, references…" /></div>
        <div><label className="label" htmlFor="rc-pr">Priority</label><select id="rc-pr" className="input" value={f.priority} onChange={(e) => setF({ ...f, priority: e.target.value })}>{PRIORITIES.map((p) => <option key={p}>{p}</option>)}</select></div>
        <div className="flex items-end text-xs text-muted">The campaign draft content is copied into the task description{lead ? `; ${lead.name} is set as reviewer` : ''}.</div>
      </form>
    </Modal>
  );
}

/** Shows the creative task linked to a campaign, with its thumbnail, status and output, or the request button when none exists. */
export function LinkedCreative({ rec, onRequest }: { rec: Rec; onRequest: () => void }) {
  const lk = useLookups();
  const ref = parseCreativeRef(rec.creative_task_ref);
  const m = ref ? MODULE_BY_KEY[ref.key] : MODULE_BY_KEY.artworks;
  const q = useRecords(m);
  if (!ref) return <button className="btn-ghost w-full" onClick={onRequest}><Icon name="Send" size={16} />Request Creative</button>;
  const task = (q.data ?? []).find((r) => r.id === ref.id);
  return (
    <div className="rounded-xl border border-line/20 p-3">
      <div className="mb-2 flex items-center justify-between"><h3 className="text-sm font-bold">Linked creative task</h3>{task && <PriorityBadge priority={task.priority} />}</div>
      {!task ? <p className="text-sm text-muted">{q.isLoading ? 'Loading…' : 'The linked creative task is not visible to you (it may have been removed).'}</p> : (
        <div className="flex gap-3">
          {task.thumbnail /* eslint-disable-next-line @next/next/no-img-element */ ? <img src={task.thumbnail} alt="" className="h-20 w-28 rounded-lg object-cover ring-1 ring-line/25" /> : <span className="grid h-20 w-28 place-items-center rounded-lg bg-surface2 text-xs text-muted">No thumbnail yet</span>}
          <div className="min-w-0 text-sm"><div className="truncate font-semibold">{task.task}</div>
            <div className="text-xs text-muted">{task.status} · review: {task.review_status ?? 'Not reviewed'} · due {fmtDate(task.due_date)}</div>
            <div className="text-xs text-muted">Designer: {lk.user(task.assigned_to)}</div>
            {task.output_link ? <a href={task.output_link} target="_blank" rel="noopener noreferrer" className="mt-1 inline-flex items-center gap-1 text-xs font-semibold text-primary hover:underline dark:text-primary-200"><Icon name="ExternalLink" size={12} />Open final creative</a> : <span className="text-xs text-muted">No output submitted yet.</span>}</div>
        </div>
      )}
    </div>
  );
}
