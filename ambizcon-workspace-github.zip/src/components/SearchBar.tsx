'use client';
import { AnimatePresence, motion } from 'framer-motion';
import { useRouter } from 'next/navigation';
import { useEffect, useMemo, useRef, useState } from 'react';
import { Icon } from './Icon';
import { useAuth } from './providers';
import { moduleHref } from '@/lib/access';
import { useAvailableModules, useItems, useLookups } from '@/lib/hooks';
import { cn } from '@/lib/utils';

interface Hit { id: string; label: string; sub: string; href: string; icon: string }

/** Global search across records, clients, websites and (for admins) users. */
export function SearchBar({ className }: { className?: string }) {
  const { user } = useAuth();
  const router = useRouter();
  const available = useAvailableModules(user?.team);
  const mods = useMemo(() => available.filter((m) => !m.readonly), [available]);
  const { items } = useItems(mods);
  const lk = useLookups();
  const [q, setQ] = useState('');
  const [open, setOpen] = useState(false);
  const [cursor, setCursor] = useState(0);
  const box = useRef<HTMLDivElement>(null);
  const input = useRef<HTMLInputElement>(null);

  const hits = useMemo<Hit[]>(() => {
    const s = q.trim().toLowerCase();
    if (s.length < 2) return [];
    const out: Hit[] = [];
    for (const { m, rec } of items) {
      const client = lk.client(rec.client_id);
      const hay = [client, ...m.fields.filter((f) => f.type === 'text' || f.type === 'select').map((f) => String(rec[f.key] ?? ''))].join(' ').toLowerCase();
      if (!hay.includes(s)) continue;
      const label = m.titleField === 'client_id' ? client : String(rec[m.titleField] ?? m.title);
      out.push({ id: rec.id, label, sub: `${m.title}${client !== '—' && m.titleField !== 'client_id' ? ' · ' + client : ''}`, href: `${moduleHref(m)}?open=${rec.id}`, icon: m.icon });
      if (out.length >= 30) break;
    }
    if (user?.team === 'admin')
      for (const u of lk.users) if ((u.name + u.email).toLowerCase().includes(s)) out.unshift({ id: u.id, label: u.name, sub: `User · ${u.team}`, href: '/admin/users', icon: 'CircleUser' });
    for (const c of lk.clients) {
      if (c.name.toLowerCase().includes(s)) out.unshift({ id: c.id, label: c.name, sub: `Client · ${c.client_type}${c.location ? ' · ' + c.location : ''}`, href: `/clients/${c.id}`, icon: 'Building2' });
    }
    return out.slice(0, 10);
  }, [q, items, lk, user?.team]);

  useEffect(() => setCursor(0), [q]);
  useEffect(() => {
    const away = (e: MouseEvent) => !box.current?.contains(e.target as Node) && setOpen(false);
    const slash = (e: KeyboardEvent) => {
      if (e.key === '/' && !(e.target instanceof HTMLInputElement) && !(e.target instanceof HTMLTextAreaElement)) { e.preventDefault(); input.current?.focus(); }
    };
    document.addEventListener('mousedown', away);
    document.addEventListener('keydown', slash);
    return () => { document.removeEventListener('mousedown', away); document.removeEventListener('keydown', slash); };
  }, []);

  const go = (h: Hit) => { setOpen(false); setQ(''); router.push(h.href); };

  return (
    <div ref={box} className={cn('relative', className)} role="search">
      <Icon name="Search" size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
      <input
        ref={input}
        className="input pl-9 pr-8"
        placeholder="Search tasks, clients, websites…  ( / )"
        aria-label="Global search"
        aria-expanded={open && hits.length > 0}
        aria-controls="global-search-results"
        value={q}
        onFocus={() => setOpen(true)}
        onChange={(e) => { setQ(e.target.value); setOpen(true); }}
        onKeyDown={(e) => {
          if (e.key === 'ArrowDown') { e.preventDefault(); setCursor((c) => Math.min(c + 1, hits.length - 1)); }
          if (e.key === 'ArrowUp') { e.preventDefault(); setCursor((c) => Math.max(c - 1, 0)); }
          if (e.key === 'Enter' && hits[cursor]) go(hits[cursor]);
          if (e.key === 'Escape') { setOpen(false); input.current?.blur(); }
        }}
      />
      <AnimatePresence>
        {open && q.trim().length >= 2 && (
          <motion.ul id="global-search-results" role="listbox" initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="panel absolute left-0 right-0 top-12 z-50 max-h-80 overflow-y-auto py-1 shadow-lift" style={{ background: 'rgb(var(--surface) / .98)' }}>
            {hits.length === 0 && <li className="px-4 py-3 text-sm text-muted">No matches for “{q}”.</li>}
            {hits.map((h, i) => (
              <li key={h.id + h.href} role="option" aria-selected={i === cursor}>
                <button className={cn('flex w-full items-center gap-3 px-3 py-2 text-left transition', i === cursor ? 'bg-primary/10' : 'hover:bg-primary/5')} onMouseEnter={() => setCursor(i)} onClick={() => go(h)}>
                  <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-primary/10 text-primary"><Icon name={h.icon} size={16} /></span>
                  <span className="min-w-0"><span className="block truncate text-sm font-semibold">{h.label}</span><span className="block truncate text-xs text-muted">{h.sub}</span></span>
                </button>
              </li>
            ))}
          </motion.ul>
        )}
      </AnimatePresence>
    </div>
  );
}
