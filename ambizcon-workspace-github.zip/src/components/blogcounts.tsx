'use client';
import { useMemo, useState } from 'react';
import { BarsChart, CH } from './charts';
import { DataTable, type Column } from './DataTable';
import { Icon } from './Icon';
import ModulePage from './records/ModulePage';
import { ChartCard, ErrorState, LoadingState, PageHeader, StatsCard } from './ui';
import { downloadCsv, toCsv } from '@/lib/csv';
import { useLookups, useRecords } from '@/lib/hooks';
import { MODULE_BY_KEY, MONTH_NAMES } from '@/lib/modules';
import type { Rec } from '@/lib/types';

interface Row { client_id: string; name: string; target: number | null; planned: number; inProgress: number; published: number; remaining: number | null; pct: number | null }

/**
 * /marketing/blog-counts. Every number is calculated from the Blog & YouTube records (content type Blog); nothing is typed in by hand
 * except the monthly target. A blog counts as published only when its status is Completed AND it has a publication date.
 */
export function BlogCountsPage() {
  const lk = useLookups();
  const blogs = useRecords(MODULE_BY_KEY['blog-youtube']);
  const targets = useRecords(MODULE_BY_KEY['blog-targets']);
  const now = new Date();
  const [year, setYear] = useState(now.getFullYear());
  const [month, setMonth] = useState(now.getMonth());
  const ym = `${year}-${String(month + 1).padStart(2, '0')}`;

  const rows = useMemo<Row[]>(() => {
    const posts = (blogs.data ?? []).filter((r) => r.content_type === 'Blog');
    return lk.clients.filter((c) => c.status === 'active').map((c) => {
      const mine = posts.filter((r) => r.client_id === c.id);
      const published = mine.filter((r) => r.status === 'Completed' && r.publication_date && String(r.publication_date).startsWith(ym)).length;
      // planned / in progress are placed in the month they are due
      const open = mine.filter((r) => !['Completed', 'Cancelled'].includes(r.status) && r.due_date && String(r.due_date).startsWith(ym));
      const planned = open.filter((r) => ['Pending', 'On Hold'].includes(r.status)).length;
      const inProgress = open.filter((r) => r.status === 'In Progress').length;
      const t = (targets.data ?? []).find((x: Rec) => x.client_id === c.id && Number(x.year) === year && x.month === MONTH_NAMES[month]);
      const target = t ? Number(t.target) : null;
      return { client_id: c.id, name: c.name, target, planned, inProgress, published, remaining: target === null ? null : Math.max(0, target - published), pct: target ? Math.min(100, Math.round((published / target) * 100)) : null };
    });
  }, [blogs.data, targets.data, lk.clients, ym, year, month]);

  if (blogs.isLoading || targets.isLoading) return <LoadingState variant="page" />;
  if (blogs.error) return <ErrorState message={(blogs.error as Error).message} onRetry={() => blogs.refetch()} />;

  const total = (k: 'planned' | 'inProgress' | 'published') => rows.reduce((a, r) => a + r[k], 0);
  const withTarget = rows.filter((r) => r.target !== null);
  const targetSum = withTarget.reduce((a, r) => a + (r.target ?? 0), 0);
  const cols: Column<Row>[] = [
    { key: 'name', label: 'Client', sortValue: (r) => r.name, render: (r) => <span className="font-semibold">{r.name}</span> },
    { key: 'month', label: 'Month', render: () => `${MONTH_NAMES[month]} ${year}`, card: false },
    { key: 'target', label: 'Monthly target', sortValue: (r) => r.target ?? -1, render: (r) => (r.target === null ? <span className="text-muted" title="No target set for this month">not set</span> : r.target) },
    { key: 'planned', label: 'Planned', sortValue: (r) => r.planned, render: (r) => r.planned },
    { key: 'prog', label: 'In progress', sortValue: (r) => r.inProgress, render: (r) => r.inProgress },
    { key: 'pub', label: 'Published', sortValue: (r) => r.published, render: (r) => <b>{r.published}</b> },
    { key: 'rem', label: 'Remaining', sortValue: (r) => r.remaining ?? -1, render: (r) => (r.remaining === null ? '—' : r.remaining) },
    { key: 'pct', label: 'Completion', sortValue: (r) => r.pct ?? -1, render: (r) => (r.pct === null ? '—' : <span className="inline-flex items-center gap-2"><span className="h-2 w-20 overflow-hidden rounded-full bg-line/15"><span className="block h-full rounded-full bg-gradient-to-r from-primary to-secondary-500" style={{ width: `${r.pct}%` }} /></span>{r.pct}%</span>) },
  ];
  const years = [year + 1, year, year - 1, year - 2];
  return (
    <div>
      <PageHeader icon="ChartColumn" title="Blog Content Monthly Count" subtitle="Calculated from the Blog & YouTube records, so counts can never drift from the real blogs. Only the monthly target is entered by hand."
        actions={<button className="btn-ghost" disabled={!rows.length} onClick={() => downloadCsv(`blog-counts-${ym}`, toCsv(rows, [
          { label: 'Client', value: (r) => r.name }, { label: 'Month', value: () => MONTH_NAMES[month] }, { label: 'Year', value: () => year }, { label: 'Planned', value: (r) => r.planned },
          { label: 'In progress', value: (r) => r.inProgress }, { label: 'Published', value: (r) => r.published }, { label: 'Remaining', value: (r) => r.remaining ?? '' }, { label: 'Monthly target', value: (r) => r.target ?? '' }, { label: 'Completion %', value: (r) => r.pct ?? '' },
        ]))}><Icon name="Download" size={16} />Export CSV</button>} />
      <div className="panel mb-4 flex flex-wrap items-center gap-2 p-3">
        <select className="input !w-auto" aria-label="Month" value={month} onChange={(e) => setMonth(Number(e.target.value))}>{MONTH_NAMES.map((n, i) => <option key={n} value={i}>{n}</option>)}</select>
        <select className="input !w-auto" aria-label="Year" value={year} onChange={(e) => setYear(Number(e.target.value))}>{years.map((y) => <option key={y}>{y}</option>)}</select>
        <span className="ml-auto text-xs text-muted">Published = status Completed with a publication date in the month. Planned and in-progress blogs are placed in the month they are due.</span>
      </div>
      <div className="mb-4 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatsCard label="Published" value={total('published')} icon="Newspaper" />
        <StatsCard label="In progress" value={total('inProgress')} icon="Loader2" accent="secondary" />
        <StatsCard label="Planned" value={total('planned')} icon="Clock" accent="accent" />
        <StatsCard label="Target met" value={targetSum ? Math.round((withTarget.reduce((a, r) => a + Math.min(r.published, r.target ?? 0), 0) / targetSum) * 100) : 0} icon="Target" accent="dark" hint={targetSum ? `of ${targetSum} targeted blogs (%)` : 'No targets set'} />
      </div>
      <div className="mb-4 grid gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2"><DataTable rows={rows} columns={cols} rowKey={(r) => r.client_id} caption="Blog counts" pageSize={10} defaultSort={{ key: 'pub', dir: 'desc' }} /></div>
        <ChartCard title="Published vs target" subtitle={`${MONTH_NAMES[month]} ${year}`}><BarsChart data={rows.filter((r) => r.target !== null || r.published > 0).map((r) => ({ name: r.name.split(' ')[0], published: r.published, target: r.target ?? 0 }))} series={[{ key: 'published', name: 'Published', color: CH[0] }, { key: 'target', name: 'Target', color: CH[2] }]} /></ChartCard>
      </div>
      <h2 className="mb-2 font-bold">Monthly targets</h2>
      <ModulePage m={MODULE_BY_KEY['blog-targets']} embedded />
    </div>
  );
}
