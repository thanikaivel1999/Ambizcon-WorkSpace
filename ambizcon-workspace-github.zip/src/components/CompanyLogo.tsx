'use client';
import { motion, useReducedMotion } from 'framer-motion';
import { cn } from '@/lib/utils';

interface Props {
  size?: number;
  /** Show the brand name beside the mark. */
  withName?: boolean;
  /** Entrance + floating + glow. Use `false` for dense UI such as the table header. */
  animated?: boolean;
  className?: string;
  nameClassName?: string;
}

/** The supplied Ambizcon logo, never stretched: the intrinsic aspect ratio (square) is preserved. */
export function CompanyLogo({ size = 40, withName = false, animated = true, className, nameClassName }: Props) {
  const reduce = useReducedMotion();
  const float = animated && !reduce;
  return (
    <div className={cn('flex items-center gap-3', className)}>
      <motion.div
        initial={animated ? { opacity: 0, scale: 0.8, y: 8 } : false}
        animate={float ? { opacity: 1, scale: 1, y: [0, -3, 0] } : { opacity: 1, scale: 1, y: 0 }}
        transition={float ? { opacity: { duration: 0.6 }, scale: { duration: 0.6 }, y: { duration: 5, repeat: Infinity, ease: 'easeInOut', delay: 0.6 } } : { duration: 0.4 }}
        className="relative shrink-0"
        style={{ width: size, height: size }}
      >
        {animated && <span aria-hidden className="absolute -inset-2 rounded-2xl bg-secondary/40 blur-xl animate-pulse" />}
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/logo.png" alt="Ambizcon Health" width={size} height={size} className="relative h-full w-full rounded-xl object-cover shadow-card ring-1 ring-white/30" />
      </motion.div>
      {withName && (
        <div className={cn('leading-tight', nameClassName)}>
          <div className="text-sm font-extrabold tracking-wide">AMBIZCON</div>
          <div className="text-[10px] font-semibold uppercase tracking-[.2em] opacity-70">Team Workspace</div>
        </div>
      )}
    </div>
  );
}
