'use client';
import { AnimatePresence, motion } from 'framer-motion';
import { usePathname } from 'next/navigation';
import { useEffect, useMemo, useRef, useState } from 'react';
import { Icon } from './Icon';
import { useAuth } from './providers';
import { PageHeader } from './ui';
import { buildFacts } from '@/lib/ai/facts';
import { api } from '@/lib/data';
import { modulesForTeam, useClients, useItems, useSetting, useTasks, useUsers } from '@/lib/hooks';
import { DEFAULT_WEIGHTS, normalizeWeights, type ScoringWeights } from '@/lib/performance';
import type { Profile, Rec, Team } from '@/lib/types';
import { cn, fmtTime, todayISO } from '@/lib/utils';

interface Msg { role: 'user' | 'assistant'; content: string; at: string; meta?: { sections: { title: string; count: number }[]; model: string; mode: string }; error?: boolean; kind?: 'not_configured' | 'error' }

const PROMPTS: Record<Team, string[]> = {
  development: ['Which websites have SSL certificates expiring in the next 30 days?', 'Summarise the status of website backups. Which are unverified?', 'List overdue maintenance tasks.', 'Draft an SEO title and meta description for a dental clinic homepage.', 'Create a daily website checklist I can follow.'],
  marketing: ['How many blogs did each client publish this month?', 'Give me content calendar ideas for next month for a cardiology clinic.', 'Suggest 5 email subject lines for a health-checkup offer.', 'Summarise Google Ads performance for the last 7 days.', 'Which clients have no YouTube channel yet?'],
  creative: ['Which Creative Team tasks are overdue?', 'Write a design brief for a festival greeting banner (1080×1080).', 'Suggest 3 social carousel ideas for World Heart Day.', 'Write a 30-second video script introducing a new specialist.', 'Which tasks are waiting for review?'],
  admin: ['Give me a summary of overall company performance.', 'Which team has the highest pending workload?', 'Which employee has the highest verified performance score over the last three completed months?', 'Which expiries need attention this month?', 'Write a short weekly status report for the leadership team.'],
};

/** Builds the recorded-facts brief in the browser. Only used in demo mode; with Supabase the server fetches under the user's own session. */
function useDemoFacts(user: Profile) {
  const mods = useMemo(() => modulesForTeam(user.team), [user.team]);
  const { items } = useItems(mods);
  const tasks = useTasks().data ?? [];
  const users = useUsers().data ?? [];
  const clients = useClients().data ?? [];
  const weights = useSetting<ScoringWeights>('scoring', DEFAULT_WEIGHTS, (r) => normalizeWeights(r as Partial<ScoringWeights>)).value;
  return () => {
    const records: Record<string, Rec[]> = {};
    for (const { m, rec } of items) (records[m.key] ??= []).push(rec);
    return buildFacts({ team: user.team, today: todayISO(), users, clients, tasks, records, weights }).text;
  };
}

export function AiChat({ compact = false }: { compact?: boolean }) {
  const { user } = useAuth() as { user: Profile };
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const end = useRef<HTMLDivElement>(null);
  const demoFacts = useDemoFacts(user);
  useEffect(() => { end.current?.scrollIntoView({ behavior: 'smooth', block: 'end' }); }, [msgs, busy]);

  const ask = async (q: string) => {
    const message = q.trim();
    if (!message || busy) return;
    const history = msgs.filter((m) => !m.error).slice(-8).map((m) => ({ role: m.role, content: m.content }));
    setMsgs((m) => [...m, { role: 'user', content: message, at: new Date().toISOString() }]);
    setText('');
    setBusy(true);
    try {
      const res = await fetch('/api/ai/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ message, history, ...(api.mode === 'demo' ? { facts: demoFacts() } : {}) }) });
      const j = await res.json().catch(() => ({}));
      if (!res.ok) setMsgs((m) => [...m, { role: 'assistant', content: j.message ?? 'The assistant could not answer right now.', at: new Date().toISOString(), error: true, kind: j.error === 'not_configured' ? 'not_configured' : 'error' }]);
      else setMsgs((m) => [...m, { role: 'assistant', content: j.answer, at: j.generatedAt ?? new Date().toISOString(), meta: { sections: j.sections ?? [], model: j.model, mode: j.mode } }]);
    } catch {
      setMsgs((m) => [...m, { role: 'assistant', content: 'Could not reach the assistant. Check your connection and try again.', at: new Date().toISOString(), error: true, kind: 'error' }]);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className={cn('flex min-h-0 flex-col', compact ? 'h-full' : 'panel h-[calc(100vh-15rem)] min-h-[28rem]')}>
      <div className="flex-1 space-y-3 overflow-y-auto p-4" aria-live="polite">
        {msgs.length === 0 && (
          <div className="mx-auto max-w-xl py-6 text-center">
            <span className="mx-auto mb-3 grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-primary to-secondary-400 text-white shadow-md"><Icon name="Bot" size={28} /></span>
            <h2 className="text-lg font-extrabold">Ask about your {user.team === 'admin' ? 'company' : user.team} records</h2>
            <p className="mt-1 text-sm text-muted">Answers come only from records you are allowed to see. Anything the assistant writes itself, like drafts and ideas, is labelled as an AI suggestion. It is read-only: it cannot change your data.</p>
            <div className="mt-4 flex flex-wrap justify-center gap-2">
              {PROMPTS[user.team].map((p) => <button key={p} className="rounded-full border border-line/25 bg-surface/70 px-3 py-1.5 text-left text-xs font-semibold transition hover:border-primary/50 hover:bg-primary/10" onClick={() => void ask(p)}>{p}</button>)}
            </div>
          </div>
        )}
        {msgs.map((m, i) => (
          <motion.div key={i} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className={cn('flex', m.role === 'user' ? 'justify-end' : 'justify-start')}>
            <div className={cn('max-w-[92%] rounded-2xl px-4 py-2.5 text-sm shadow-sm', m.role === 'user' ? 'bg-gradient-to-r from-primary to-secondary-500 text-white' : m.error ? 'border border-primary-900/40 bg-primary-900/10' : 'bg-surface2')}>
              {m.role === 'assistant' && !m.error && <div className="mb-1 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-primary dark:text-primary-200"><Icon name="Sparkles" size={12} />AI-generated answer</div>}
              {m.kind === 'not_configured' && <div className="mb-1 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide"><Icon name="Settings" size={12} />AI not configured</div>}
              <div className="whitespace-pre-wrap break-words">{m.content}</div>
              <div className={cn('mt-1.5 text-[11px]', m.role === 'user' ? 'text-white/70' : 'text-muted')}>{fmtTime(m.at)}</div>
              {m.meta && (
                <details className="mt-1.5 text-[11px] text-muted"><summary className="cursor-pointer font-semibold">Recorded data this answer was based on ({m.meta.sections.length} sets{m.meta.mode === 'demo' ? ', demo data' : ''})</summary>
                  <ul className="mt-1 list-disc pl-4">{m.meta.sections.map((s) => <li key={s.title}>{s.title} ({s.count})</li>)}</ul>
                  <p className="mt-1">Facts come from your records; wording, drafts and ideas are the AI&apos;s own. Check important figures in the source pages.</p></details>
              )}
            </div>
          </motion.div>
        ))}
        {busy && <div className="flex items-center gap-2 text-sm text-muted"><Icon name="Loader2" className="animate-spin" size={16} />Reading your records and thinking…</div>}
        <div ref={end} />
      </div>
      <form className="flex items-end gap-2 border-t border-line/15 p-3" onSubmit={(e) => { e.preventDefault(); void ask(text); }}>
        <label className="sr-only" htmlFor="ai-input">Ask the assistant</label>
        <textarea id="ai-input" rows={1} className="input max-h-32 min-h-[2.5rem] resize-none" placeholder="Ask a question or request a draft…" value={text} maxLength={2000} onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); void ask(text); } }} />
        <button className="btn-primary" disabled={busy || !text.trim()} aria-label="Send"><Icon name="Send" size={16} /></button>
      </form>
    </div>
  );
}

/** /ai-assistant */
export function AiAssistantPage() {
  const { user } = useAuth() as { user: Profile };
  return (
    <div>
      <PageHeader icon="Bot" title="AI Assistant" subtitle={`Read-only help for ${user.team === 'admin' ? 'the whole company' : `the ${user.team} team`}. It sees only the records you can see and says so when something is not recorded.`} />
      <AiChat />
    </div>
  );
}

/** Floating assistant button available on every screen. */
export function AiFloatingButton() {
  const [open, setOpen] = useState(false);
  const path = usePathname();
  useEffect(() => { setOpen(false); }, [path]);
  useEffect(() => {
    const esc = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
    window.addEventListener('keydown', esc);
    return () => window.removeEventListener('keydown', esc);
  }, []);
  if (path === '/ai-assistant') return null;
  return (
    <>
      <button onClick={() => setOpen((o) => !o)} aria-label="Open AI assistant" aria-expanded={open} className="fixed bottom-5 right-5 z-[60] grid h-14 w-14 place-items-center rounded-full bg-gradient-to-br from-primary to-secondary-500 text-white shadow-lift transition hover:scale-105 hover:shadow-glow focus-visible:outline-offset-4">
        <Icon name={open ? 'X' : 'Bot'} size={26} />
      </button>
      <AnimatePresence>
        {open && (
          <motion.section role="dialog" aria-label="AI assistant" initial={{ opacity: 0, y: 20, scale: 0.97 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 20, scale: 0.97 }}
            className="panel fixed bottom-24 right-3 z-[60] flex h-[34rem] max-h-[75vh] w-[min(26rem,calc(100vw-1.5rem))] flex-col overflow-hidden shadow-lift" style={{ background: 'rgb(var(--surface) / .97)' }}>
            <div className="flex items-center gap-2 border-b border-line/15 px-4 py-2.5"><Icon name="Bot" className="text-primary" /><h2 className="font-bold">AI Assistant</h2><span className="ml-auto text-[11px] text-muted">Read-only</span></div>
            <div className="min-h-0 flex-1"><AiChat compact /></div>
          </motion.section>
        )}
      </AnimatePresence>
    </>
  );
}
