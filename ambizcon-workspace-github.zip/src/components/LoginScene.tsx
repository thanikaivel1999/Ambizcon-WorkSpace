'use client';
import { Canvas, useFrame } from '@react-three/fiber';
import { useMemo, useRef, type MutableRefObject } from 'react';
import type { Group, Mesh } from 'three';

interface Input { scroll: MutableRefObject<number>; pointer: MutableRefObject<{ x: number; y: number }>; reduce: boolean }

function Shape({ position, speed, scale = 1, color, kind, input, depth }: { position: [number, number, number]; speed: number; scale?: number; color: string; kind: 'ico' | 'torus' | 'octa' | 'box' | 'dodeca'; input: Input; depth: number }) {
  const g = useRef<Group>(null);
  const m = useRef<Mesh>(null);
  useFrame(({ clock }) => {
    const t = clock.getElapsedTime();
    if (!g.current || !m.current) return;
    // depth-based parallax: nearer shapes (higher depth) react more to scroll / pointer
    g.current.position.y = position[1] + (input.reduce ? 0 : Math.sin(t * speed) * 0.25) + input.scroll.current * depth * 3.2;
    g.current.position.x = position[0] + input.pointer.current.x * depth * 0.5;
    if (!input.reduce) { m.current.rotation.x = t * speed * 0.4; m.current.rotation.y = t * speed * 0.55; }
  });
  return (
    <group ref={g} position={position} scale={scale}>
      <mesh ref={m}>
        {kind === 'ico' && <icosahedronGeometry args={[1, 0]} />}
        {kind === 'torus' && <torusGeometry args={[0.9, 0.3, 14, 40]} />}
        {kind === 'octa' && <octahedronGeometry args={[1, 0]} />}
        {kind === 'box' && <boxGeometry args={[1.3, 1.3, 1.3]} />}
        {kind === 'dodeca' && <dodecahedronGeometry args={[1, 0]} />}
        <meshStandardMaterial color={color} metalness={0.35} roughness={0.35} flatShading transparent opacity={0.8} />
      </mesh>
      <mesh scale={1.35}>
        {kind === 'torus' ? <torusGeometry args={[0.9, 0.3, 8, 24]} /> : <icosahedronGeometry args={[1, 0]} />}
        <meshBasicMaterial color={color} wireframe transparent opacity={0.18} />
      </mesh>
    </group>
  );
}

function Particles({ input }: { input: Input }) {
  const ref = useRef<Group>(null);
  const positions = useMemo(() => {
    const a = new Float32Array(420 * 3);
    for (let i = 0; i < a.length; i += 3) { a[i] = (Math.random() - 0.5) * 18; a[i + 1] = (Math.random() - 0.5) * 12; a[i + 2] = (Math.random() - 0.5) * 8 - 2; }
    return a;
  }, []);
  useFrame(({ clock }) => {
    if (!ref.current) return;
    ref.current.rotation.y = input.reduce ? 0 : clock.getElapsedTime() * 0.02;
    ref.current.position.y = input.scroll.current * 0.8; // slowest layer
  });
  return (
    <group ref={ref}>
      <points>
        <bufferGeometry><bufferAttribute attach="attributes-position" args={[positions, 3]} /></bufferGeometry>
        <pointsMaterial size={0.035} color="#a6bd95" transparent opacity={0.75} sizeAttenuation depthWrite={false} />
      </points>
    </group>
  );
}

function Rig({ input }: { input: Input }) {
  useFrame((state) => {
    state.camera.position.x += (input.pointer.current.x * 0.6 - state.camera.position.x) * 0.04;
    state.camera.position.y += (-input.pointer.current.y * 0.4 - input.scroll.current * 0.8 - state.camera.position.y) * 0.04;
    state.camera.lookAt(0, 0, 0);
  });
  return null;
}

export default function LoginScene(props: Input) {
  const input = props;
  return (
    <Canvas dpr={[1, 1.5]} camera={{ position: [0, 0, 7], fov: 50 }} gl={{ antialias: true, alpha: true, powerPreference: 'low-power' }} style={{ background: 'transparent' }} aria-hidden>
      <ambientLight intensity={0.7} />
      <pointLight position={[5, 5, 5]} intensity={40} color="#8BA277" />
      <pointLight position={[-6, -3, 3]} intensity={50} color="#13798A" />
      <Particles input={input} />
      <Shape kind="ico" position={[-4.2, 1.6, -1]} scale={1.1} speed={0.6} color="#13798A" input={input} depth={0.6} />
      <Shape kind="torus" position={[4.4, 2, -2]} scale={1} speed={0.5} color="#8BA277" input={input} depth={0.4} />
      <Shape kind="octa" position={[-3.4, -2.2, 0]} scale={0.8} speed={0.8} color="#95A575" input={input} depth={1} />
      <Shape kind="box" position={[3.8, -1.8, -1]} scale={0.75} speed={0.7} color="#13798A" input={input} depth={0.8} />
      <Shape kind="dodeca" position={[0.4, 3.2, -3]} scale={0.8} speed={0.4} color="#95A575" input={input} depth={0.3} />
      <Shape kind="ico" position={[6.2, -0.2, -3]} scale={0.6} speed={0.9} color="#8BA277" input={input} depth={0.5} />
      <Rig input={input} />
    </Canvas>
  );
}
