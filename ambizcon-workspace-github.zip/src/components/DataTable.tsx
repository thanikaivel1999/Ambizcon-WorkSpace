'use client';
import { motion } from 'framer-motion';
import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { Icon } from './Icon';
import { cn } from '@/lib/utils';

export interface Column<T> {
  key: string;
  label: string;
  render: (row: T) => ReactNode;
  sortValue?: (row: T) => string | number;
  className?: string;
  /** Visible in mobile cards (first column is always the card title). */
  card?: boolean;
}

export function useMediaQuery(query: string) {
  const [match, setMatch] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia(query);
    const on = () => setMatch(mq.matches);
    on();
    mq.addEventListener('change', on);
    return () => mq.removeEventListener('change', on);
  }, [query]);
  return match;
}

interface Props<T> {
  rows: T[];
  columns: Column<T>[];
  rowKey: (row: T) => string;
  onRowClick?: (row: T) => void;
  actions?: (row: T) => ReactNode;
  /** Optional cell placed in the status slot of cards (top-right). */
  cardBadge?: (row: T) => ReactNode;
  pageSize?: number;
  defaultSort?: { key: string; dir: 'asc' | 'desc' };
  caption?: string;
}

/** Desktop: sticky-header sortable table with pagination. Mobile (<768px): card list. */
export function DataTable<T>({ rows, columns, rowKey, onRowClick, actions, cardBadge, pageSize = 10, defaultSort, caption }: Props<T>) {
  const mobile = useMediaQuery('(max-width: 767px)');
  const [sort, setSort] = useState(defaultSort ?? null);
  const [page, setPage] = useState(0);
  const [size, setSize] = useState(pageSize);

  const sorted = useMemo(() => {
    if (!sort) return rows;
    const col = columns.find((c) => c.key === sort.key);
    if (!col?.sortValue) return rows;
    const f = col.sortValue;
    const dir = sort.dir === 'asc' ? 1 : -1;
    return [...rows].sort((a, b) => {
      const x = f(a), y = f(b);
      return (typeof x === 'number' && typeof y === 'number' ? x - y : String(x).localeCompare(String(y), undefined, { numeric: true })) * dir;
    });
  }, [rows, sort, columns]);

  const pages = Math.max(1, Math.ceil(sorted.length / size));
  useEffect(() => { if (page >= pages) setPage(0); }, [pages, page]);
  const slice = sorted.slice(page * size, page * size + size);
  const toggle = (c: Column<T>) => c.sortValue && setSort((s) => (s?.key === c.key ? (s.dir === 'asc' ? { key: c.key, dir: 'desc' } : null) : { key: c.key, dir: 'asc' }));

  return (
    <div className="panel overflow-hidden">
      {mobile ? (
        <ul className="divide-y divide-line/10" aria-label={caption}>
          {slice.map((row, i) => (
            <motion.li key={rowKey(row)} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }} className="p-3.5 active:bg-primary/5" onClick={() => onRowClick?.(row)}>
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0 text-base font-bold">{columns[0].render(row)}</div>
                {cardBadge?.(row)}
              </div>
              <dl className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1.5 text-xs">
                {columns.slice(1).filter((c) => c.card !== false).slice(0, 6).map((c) => (
                  <div key={c.key} className="min-w-0"><dt className="text-[10px] font-semibold uppercase tracking-wide text-muted">{c.label}</dt><dd className="truncate text-sm">{c.render(row)}</dd></div>
                ))}
              </dl>
              {actions && <div className="mt-2.5 flex justify-end gap-1" onClick={(e) => e.stopPropagation()}>{actions(row)}</div>}
            </motion.li>
          ))}
        </ul>
      ) : (
        <div className="max-h-[68vh] overflow-auto">
          <table className="w-full min-w-max border-collapse">
            {caption && <caption className="sr-only">{caption}</caption>}
            <thead className="sticky top-0 z-10 bg-surface2/95 backdrop-blur">
              <tr>
                {columns.map((c) => (
                  <th key={c.key} scope="col" className="th" aria-sort={sort?.key === c.key ? (sort.dir === 'asc' ? 'ascending' : 'descending') : undefined}>
                    {c.sortValue ? (
                      <button className="inline-flex items-center gap-1 uppercase hover:text-ink" onClick={() => toggle(c)}>
                        {c.label}
                        <Icon name={sort?.key === c.key ? (sort.dir === 'asc' ? 'ChevronUp' : 'ChevronDown') : 'ArrowUpDown'} size={12} className={sort?.key === c.key ? 'text-primary' : 'opacity-40'} />
                      </button>
                    ) : c.label}
                  </th>
                ))}
                {actions && <th className="th text-right"><span className="sr-only">Actions</span></th>}
              </tr>
            </thead>
            <tbody>
              {slice.map((row, i) => (
                <motion.tr key={rowKey(row)} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.02 }} className={cn('border-t border-line/10 transition-colors hover:bg-primary/[.06]', onRowClick && 'cursor-pointer')} onClick={() => onRowClick?.(row)}>
                  {columns.map((c) => <td key={c.key} className={cn('td', c.className)}>{c.render(row)}</td>)}
                  {actions && <td className="td text-right" onClick={(e) => e.stopPropagation()}><div className="flex justify-end gap-0.5">{actions(row)}</div></td>}
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <div className="flex flex-wrap items-center justify-between gap-2 border-t border-line/10 px-4 py-2.5 text-xs text-muted">
        <span>{sorted.length ? `${page * size + 1}–${Math.min(sorted.length, page * size + size)} of ${sorted.length}` : '0 records'}</span>
        <div className="flex items-center gap-2">
          <label className="flex items-center gap-1">Rows
            <select className="input !w-auto !py-1" value={size} onChange={(e) => { setSize(Number(e.target.value)); setPage(0); }} aria-label="Rows per page">{[10, 25, 50].map((n) => <option key={n}>{n}</option>)}</select>
          </label>
          <button className="btn-ghost !px-2 !py-1" disabled={page === 0} onClick={() => setPage((p) => p - 1)} aria-label="Previous page"><Icon name="ChevronLeft" size={14} /></button>
          <span className="tabular-nums">{page + 1} / {pages}</span>
          <button className="btn-ghost !px-2 !py-1" disabled={page >= pages - 1} onClick={() => setPage((p) => p + 1)} aria-label="Next page"><Icon name="ChevronRight" size={14} /></button>
        </div>
      </div>
    </div>
  );
}
