'use client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import Link from 'next/link';
import { useState } from 'react';
import { Icon } from './Icon';
import { MotivationCard, useMotivation } from './MotivationPopup';
import { NotificationList } from './NotificationPanel';
import { useAuth, useTheme, useToast } from './providers';
import ModulePage from './records/ModulePage';
import { ChartCard, PageHeader, Reveal, Modal, UserAvatar } from './ui';
import { TEAM_LABEL } from '@/lib/access';
import { api, isDemo } from '@/lib/data';
import { DEMO_KEY } from '@/lib/data/demo';
import { useNotifications } from '@/lib/hooks';
import { MODULE_BY_KEY } from '@/lib/modules';
import { setSoundEnabled, soundEnabled } from '@/lib/sound';
import type { Motivation, Profile, Team } from '@/lib/types';
import { cn, fmtDate } from '@/lib/utils';

export function NotificationsPage() {
  const { markAllRead, unread } = useNotifications();
  return (
    <div>
      <PageHeader icon="Bell" title="Notifications" subtitle={unread ? `${unread} unread` : 'You are all caught up.'} actions={<button className="btn-ghost" onClick={() => void markAllRead()}><Icon name="Check" size={16} />Mark all read</button>} />
      <div className="panel overflow-hidden"><NotificationList /></div>
    </div>
  );
}

export function SettingsPage() {
  const { theme, toggle } = useTheme();
  const toast = useToast();
  const [sound, setSound] = useState(soundEnabled());
  const row = 'flex items-center justify-between gap-4 py-3';
  return (
    <div className="max-w-2xl">
      <PageHeader icon="Settings" title="Settings" subtitle="Personalise how your workspace looks and feels." />
      <Reveal className="panel divide-y divide-line/10 px-5">
        <div className={row}><div><div className="font-semibold">Appearance</div><div className="text-sm text-muted">Dark teal or light natural palette.</div></div>
          <button className="btn-ghost" onClick={toggle}><Icon name={theme === 'dark' ? 'Sun' : 'Moon'} size={16} />{theme === 'dark' ? 'Light mode' : 'Dark mode'}</button></div>
        <div className={row}><div><div className="font-semibold">Sound effects</div><div className="text-sm text-muted">Plays a cue on completion if audio files exist in /public/sounds.</div></div>
          <button role="switch" aria-checked={sound} onClick={() => { setSound(!sound); setSoundEnabled(!sound); }} className={cn('relative h-6 w-11 rounded-full transition', sound ? 'bg-primary' : 'bg-line/25')} aria-label="Sound effects"><span className={cn('absolute left-0.5 top-0.5 h-5 w-5 rounded-full bg-white shadow transition', sound && 'translate-x-5')} /></button></div>
        {isDemo && (
          <div className={row}><div><div className="font-semibold">Demo data</div><div className="text-sm text-muted">Running without Supabase: data lives in this browser. Reset to the original seed data.</div></div>
            <button className="btn-ghost" onClick={() => { localStorage.removeItem(DEMO_KEY); toast.success('Demo data reset. Reloading…'); setTimeout(() => location.reload(), 600); }}><Icon name="RotateCcw" size={16} />Reset</button></div>
        )}
      </Reveal>
    </div>
  );
}

export function ProfilePage() {
  const { user } = useAuth() as { user: Profile };
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const info: [string, string][] = [['Email', user.email], ['Team', TEAM_LABEL[user.team]], ['Role', user.role], ['Status', user.status], ['Last login', user.last_login ? fmtDate(user.last_login) : '—'], ['Member since', fmtDate(user.created_at)]];
  return (
    <div className="max-w-2xl">
      <PageHeader icon="CircleUser" title="Profile" />
      <Reveal className="panel p-6">
        <div className="mb-5 flex items-center gap-4"><UserAvatar name={user.name} src={user.avatar_url} size={72} /><div><h2 className="text-xl font-extrabold">{user.name}</h2><p className="text-sm capitalize text-muted">{user.role} · {user.team}</p></div></div>
        <dl className="grid gap-4 sm:grid-cols-2">{info.map(([k, v]) => <div key={k}><dt className="label !mb-0">{k}</dt><dd className="text-sm font-medium capitalize">{k === 'Email' ? <span className="normal-case">{v}</span> : v}</dd></div>)}</dl>
        <div className="mt-6 border-t border-line/10 pt-4">
          <button className="btn-ghost" disabled={busy} onClick={async () => { setBusy(true); try { await api.auth.sendPasswordReset(user.email); toast.success(isDemo ? 'Demo mode: password reset simulated.' : 'Password reset email sent.'); } catch (e) { toast.error((e as Error).message); } finally { setBusy(false); } }}><Icon name="KeyRound" size={16} />Send password reset email</button>
          <p className="mt-2 text-xs text-muted">Your role and team are managed by an admin and cannot be changed here.</p>
        </div>
      </Reveal>
    </div>
  );
}

export function MotivationPage() {
  const { user } = useAuth() as { user: Profile };
  const { motivation } = useMotivation();
  const shown = useQuery({ queryKey: ['motivation-shown', user.id], queryFn: () => api.motivations.shown(user.id) });
  const all = useQuery({ queryKey: ['motivations'], queryFn: () => api.motivations.list() });
  const qc = useQueryClient();
  const toast = useToast();
  const [filter, setFilter] = useState<'all' | Team>('all');
  const [add, setAdd] = useState<{ message: string; team: Motivation['team'] } | null>(null);
  const byId = new Map((all.data ?? []).map((m) => [m.id, m]));
  const history = [...(shown.data ?? [])].sort((a, b) => b.shown_on.localeCompare(a.shown_on)).slice(0, 10);
  const save = async (m: Partial<Motivation> & { message: string; team: Motivation['team'] }) => {
    try { await api.motivations.save(m); qc.invalidateQueries({ queryKey: ['motivations'] }); toast.success('Motivation saved.'); setAdd(null); } catch (e) { toast.error((e as Error).message); }
  };
  const list = (all.data ?? []).filter((m) => filter === 'all' || m.team === filter);
  return (
    <div>
      <PageHeader icon="Sparkles" title="Daily Motivation" subtitle="One new message every day — never the same slogan twice in a row." />
      <div className="grid gap-4 lg:grid-cols-3">
        <Reveal className="panel p-6 lg:col-span-2">{motivation ? <MotivationCard motivation={motivation} team={user.team} compact /> : <p className="text-muted">Loading today&apos;s message…</p>}</Reveal>
        <ChartCard title="Recently shown" subtitle="Your last 10 days">
          {history.length === 0 ? <p className="text-sm text-muted">Nothing yet.</p> : <ul className="space-y-2.5">{history.map((h) => <li key={h.shown_on} className="text-sm"><span className="text-xs font-semibold text-muted">{fmtDate(h.shown_on)}</span><br />{byId.get(h.motivation_id)?.message ?? '—'}</li>)}</ul>}
        </ChartCard>
      </div>
      {user.team === 'admin' && (
        <Reveal className="panel mt-6 p-4">
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
            <h2 className="text-lg font-extrabold">Message library <span className="text-sm font-medium text-muted">({all.data?.length ?? 0})</span></h2>
            <div className="flex gap-2">
              <select className="input !w-auto" aria-label="Team filter" value={filter} onChange={(e) => setFilter(e.target.value as 'all' | Team)}><option value="all">All teams</option>{(['all', 'development', 'marketing', 'creative', 'admin'] as const).map((t) => <option key={t} value={t}>{t === 'all' ? 'All-team messages' : TEAM_LABEL[t]}</option>)}</select>
              <button className="btn-primary" onClick={() => setAdd({ message: '', team: 'all' })}><Icon name="Plus" size={16} />Add message</button>
            </div>
          </div>
          <ul className="max-h-[28rem] divide-y divide-line/10 overflow-y-auto">
            {list.map((m) => (
              <li key={m.id} className="flex items-center gap-3 py-2 text-sm">
                <span className="w-24 shrink-0 rounded-full bg-primary/10 px-2 py-0.5 text-center text-[11px] font-bold capitalize text-primary dark:text-primary-200">{m.team === 'all' ? 'All teams' : m.team}</span>
                <span className={cn('flex-1', !m.active && 'text-muted line-through')}>{m.message}</span>
                <button role="switch" aria-checked={m.active} aria-label={`Toggle ${m.message}`} onClick={() => void save({ ...m, active: !m.active })} className={cn('relative h-5 w-9 shrink-0 rounded-full transition', m.active ? 'bg-primary' : 'bg-line/25')}><span className={cn('absolute left-0.5 top-0.5 h-4 w-4 rounded-full bg-white shadow transition', m.active && 'translate-x-4')} /></button>
              </li>
            ))}
          </ul>
        </Reveal>
      )}
      <Modal open={!!add} onClose={() => setAdd(null)} title="Add motivation" size="sm" footer={<><button className="btn-ghost" onClick={() => setAdd(null)}>Cancel</button><button className="btn-primary" disabled={!add || add.message.trim().length < 10} onClick={() => add && void save({ ...add, message: add.message.trim() })}>Save</button></>}>
        {add && <div className="space-y-3"><div><label className="label" htmlFor="m-msg">Message</label><textarea id="m-msg" rows={3} className="input" value={add.message} onChange={(e) => setAdd({ ...add, message: e.target.value })} /></div>
          <div><label className="label" htmlFor="m-team">Team</label><select id="m-team" className="input" value={add.team} onChange={(e) => setAdd({ ...add, team: e.target.value as Motivation['team'] })}><option value="all">All teams</option>{(['development', 'marketing', 'creative', 'admin'] as const).map((t) => <option key={t} value={t}>{TEAM_LABEL[t]}</option>)}</select></div></div>}
      </Modal>
    </div>
  );
}

const TABS = [['web', 'Web Requirements', 'web-requirements'], ['videos', 'Videos', 'videos'], ['artworks', 'Artworks', 'artworks']] as const;
/** Creative → Adhoc with exactly three tabs. */
export function AdhocPage({ tab = 'web-requirements' }: { tab?: string }) {
  const m = MODULE_BY_KEY[(TABS.find(([, , slug]) => slug === tab) ?? TABS[0])[0]];
  return (
    <div>
      <PageHeader icon="Layers" title="Adhoc" subtitle="Requests from every team — web, video and artwork." />
      <div role="tablist" aria-label="Adhoc sections" className="mb-5 inline-flex max-w-full overflow-x-auto rounded-2xl bg-surface2 p-1">
        {TABS.map(([k, l, slug]) => (
          <Link key={k} role="tab" aria-selected={m.key === k} href={`/creative/adhoc/${slug}`} className={cn('flex items-center gap-2 whitespace-nowrap rounded-xl px-4 py-2 text-sm font-semibold transition', m.key === k ? 'bg-gradient-to-r from-primary to-secondary-500 text-white shadow' : 'text-muted hover:text-ink')}>
            <Icon name={MODULE_BY_KEY[k].icon} size={16} />{l}
          </Link>
        ))}
      </div>
      <ModulePage key={m.key} m={m} embedded />
    </div>
  );
}
