'use client';
import { useQueryClient } from '@tanstack/react-query';
import Link from 'next/link';
import { useEffect, useMemo, useState } from 'react';
import { DataTable, type Column } from './DataTable';
import { Icon } from './Icon';
import { ExpiryChip, ErrorState, LoadingState, PageHeader, Reveal, StatsCard, StatusBadge, tierStyle } from './ui';
import { moduleHref } from '@/lib/access';
import { downloadCsv, toCsv } from '@/lib/csv';
import { modulesForTeam, useItems, useLookups, useSetting } from '@/lib/hooks';
import type { ModuleDef } from '@/lib/modules';
import { effStatus } from '@/lib/stats';
import type { Rec } from '@/lib/types';
import { cn, DEFAULT_ALERT_DAYS, expiryInfo, fmtDate, getAlertDays, normalizeAlertDays, setAlertDays, tierOrder } from '@/lib/utils';

interface Row {
  id: string;
  m: ModuleDef;
  rec: Rec;
  fieldKey: string;
  asset: string;
  name: string;
  client_id: string | null;
  provider: string;
  identifier: string;
  date: string | null;
  confidence: string;
  tier: string;
  days: number | null;
  responsible: string | null;
  renewalStatus: string;
  renewalOpen: boolean;
}

const first = (rec: Rec, keys: string[]) => keys.map((k) => rec[k]).find((v) => v) ?? '';

/** /admin/expiry-management — every expiring asset from every team in one register. */
export function ExpiryManagementPage() {
  const lk = useLookups();
  const qc = useQueryClient();
  const mods = useMemo(() => modulesForTeam('admin').filter((m) => m.fields.some((f) => f.type === 'expiry')), []);
  const { items, loading, error, refetch } = useItems(mods);
  const schedule = useSetting<number[]>('expiry_alert_days', DEFAULT_ALERT_DAYS, normalizeAlertDays);
  const [q, setQ] = useState('');
  const [type, setType] = useState('');
  const [client, setClient] = useState('');
  const [who, setWho] = useState('');
  const [conf, setConf] = useState('');
  const [view, setView] = useState<'open' | 'renewed' | 'all'>('open');
  const [tier, setTier] = useState('');
  const [text, setText] = useState('');
  useEffect(() => setText(schedule.value.join(', ')), [schedule.value]);

  const rows = useMemo<Row[]>(() => items.flatMap(({ m, rec }) => m.fields.filter((f) => f.type === 'expiry').map((f) => {
    const info = expiryInfo(rec[f.key]);
    const st = effStatus(m, rec);
    const multi = m.fields.filter((x) => x.type === 'expiry').length > 1;
    return {
      id: `${rec.id}:${f.key}`, m, rec, fieldKey: f.key, asset: multi ? f.label : m.title.replace(/ Expiry$/, ''), name: String(rec[m.titleField] ?? ''), client_id: rec.client_id ?? null,
      provider: String(first(rec, ['provider', 'registrar', 'ssl_provider', 'vendor', 'hosting_provider'])), identifier: String(first(rec, ['domain', 'website', 'account_ref', 'smtp_tool'])),
      date: rec[f.key] || null, confidence: rec[f.key] ? rec.date_confidence || 'Confirmed' : 'Unknown', tier: info?.tier ?? 'unknown', days: info?.days ?? null, responsible: rec.assigned_to ?? null,
      renewalStatus: st ?? 'Pending', renewalOpen: st !== 'Completed' && st !== 'Cancelled',
    };
  })), [items]);

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    return rows.filter((r) => (view === 'all' || (view === 'open' ? r.renewalOpen : !r.renewalOpen)) && (!type || r.m.key === type) && (!client || r.client_id === client) && (!who || r.responsible === who)
      && (!conf || r.confidence === conf) && (!tier || r.tier === tier) && (!s || `${r.name} ${r.identifier} ${r.provider} ${lk.client(r.client_id)} ${r.asset}`.toLowerCase().includes(s)));
  }, [rows, q, type, client, who, conf, view, tier, lk]);

  const open = rows.filter((r) => r.renewalOpen);
  const counts = useMemo(() => { const c: Record<string, number> = {}; open.forEach((r) => (c[r.tier] = (c[r.tier] ?? 0) + 1)); return c; }, [open]);
  const unknown = open.filter((r) => r.confidence === 'Unknown' || !r.date).length;
  const estimated = open.filter((r) => r.confidence === 'Estimated').length;

  if (loading) return <LoadingState variant="page" />;
  if (error) return <ErrorState message={error.message} onRetry={refetch} />;

  const cols: Column<Row>[] = [
    { key: 'asset', label: 'Asset type', sortValue: (r) => r.asset, render: (r) => <span className="inline-flex items-center gap-2"><Icon name={r.m.icon} size={15} className="text-primary" />{r.asset}</span> },
    { key: 'name', label: 'Name', sortValue: (r) => r.name, render: (r) => <span className="font-semibold">{r.name || '—'}</span> },
    { key: 'client', label: 'Client', sortValue: (r) => lk.client(r.client_id), render: (r) => lk.client(r.client_id) },
    { key: 'prov', label: 'Provider', sortValue: (r) => r.provider, render: (r) => r.provider || '—' },
    { key: 'id', label: 'Domain / service', sortValue: (r) => r.identifier, render: (r) => r.identifier || '—' },
    { key: 'date', label: 'Expiry date', sortValue: (r) => r.date ?? '9999', render: (r) => (r.date ? <span>{fmtDate(r.date)}{r.confidence === 'Estimated' && <span className="ml-1 text-xs text-muted">(estimated)</span>}</span> : <span className="text-muted" title="No date recorded: nothing is guessed">Unknown</span>) },
    { key: 'days', label: 'Days left', sortValue: (r) => r.days ?? 99999, render: (r) => <ExpiryChip date={r.date} /> },
    { key: 'who', label: 'Responsible', sortValue: (r) => lk.user(r.responsible), render: (r) => lk.user(r.responsible) },
    { key: 'ren', label: 'Renewal', sortValue: (r) => r.renewalStatus, render: (r) => <StatusBadge status={r.renewalStatus as never} /> },
    { key: 'link', label: 'Renewal link', render: (r) => (r.rec.renewal_url ? <a href={r.rec.renewal_url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 font-semibold text-primary hover:underline dark:text-primary-200"><Icon name="ExternalLink" size={13} />Renew</a> : <span className="text-muted">—</span>) },
    { key: 'ver', label: 'Last verified', sortValue: (r) => r.rec.last_verified ?? '', render: (r) => (r.rec.last_verified ? fmtDate(r.rec.last_verified) : <span className="text-muted">never</span>) },
  ];

  const saveSchedule = () => {
    const days = normalizeAlertDays(text.split(/[\s,;]+/).filter(Boolean));
    setAlertDays(days);
    schedule.save.mutate(days, { onSuccess: () => qc.invalidateQueries() });
  };

  return (
    <div>
      <PageHeader icon="CalendarClock" title="Expiry Management" subtitle="Domains, hosting, SSL, tools, SMTP and domain access across every team. Dates are never guessed: an unknown date stays unknown."
        actions={<button className="btn-ghost" disabled={!filtered.length} onClick={() => downloadCsv('expiry-register', toCsv(filtered, [
          { label: 'Asset type', value: (r) => r.asset }, { label: 'Name', value: (r) => r.name }, { label: 'Client', value: (r) => lk.client(r.client_id) }, { label: 'Provider', value: (r) => r.provider }, { label: 'Domain / service', value: (r) => r.identifier },
          { label: 'Expiry date', value: (r) => r.date }, { label: 'Date confidence', value: (r) => r.confidence }, { label: 'Days left', value: (r) => r.days }, { label: 'Responsible', value: (r) => lk.user(r.responsible) },
          { label: 'Renewal status', value: (r) => r.renewalStatus }, { label: 'Renewal link', value: (r) => r.rec.renewal_url }, { label: 'Last verified', value: (r) => r.rec.last_verified }, { label: 'Notes', value: (r) => r.rec.remark },
        ]))}><Icon name="Download" size={16} />Export CSV</button>} />

      <div className="mb-4 grid grid-cols-2 gap-2 sm:grid-cols-4 lg:grid-cols-8" role="group" aria-label="Expiry tiers">
        {tierOrder().map((t, i) => (
          <button key={t} onClick={() => setTier(tier === t ? '' : t)} aria-pressed={tier === t} className={cn('panel flex items-center justify-between gap-2 px-3 py-2 text-left transition hover:-translate-y-0.5 hover:shadow-lift', tier === t && 'ring-2 ring-primary')} style={{ animationDelay: `${i * 40}ms` }}>
            <span className="text-xs font-semibold text-muted">{tierStyle(t).label}</span><span className="text-xl font-extrabold tabular-nums">{counts[t] ?? 0}</span>
          </button>
        ))}
      </div>
      <div className="mb-4 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatsCard label="Open items" value={open.length} icon="CalendarClock" />
        <StatsCard label="Expired" value={counts.expired ?? 0} icon="AlertTriangle" accent="dark" hint="Not renewed yet" />
        <StatsCard label="Unknown date" value={unknown} icon="Info" accent="accent" hint="Needs a real date" />
        <StatsCard label="Estimated date" value={estimated} icon="Clock" accent="secondary" hint="Confirm with provider" />
      </div>

      <div className="panel mb-4 p-3" role="search" aria-label="Filter expiry register">
        <div className="grid grid-cols-2 gap-2 md:grid-cols-4 xl:grid-cols-7">
          <div className="relative col-span-2"><Icon name="Search" size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted" /><input className="input pl-9" placeholder="Search name, domain, provider…" aria-label="Search" value={q} onChange={(e) => setQ(e.target.value)} /></div>
          <select className="input" aria-label="Status" value={view} onChange={(e) => setView(e.target.value as typeof view)}><option value="open">Not renewed yet</option><option value="renewed">Renewed / closed</option><option value="all">All</option></select>
          <select className="input" aria-label="Asset type" value={type} onChange={(e) => setType(e.target.value)}><option value="">All asset types</option>{mods.map((m) => <option key={m.key} value={m.key}>{m.title}</option>)}</select>
          <select className="input" aria-label="Client" value={client} onChange={(e) => setClient(e.target.value)}><option value="">All clients</option>{lk.clients.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
          <select className="input" aria-label="Responsible" value={who} onChange={(e) => setWho(e.target.value)}><option value="">Anyone responsible</option>{lk.users.filter((u) => u.team !== 'admin').map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}</select>
          <select className="input" aria-label="Date confidence" value={conf} onChange={(e) => setConf(e.target.value)}><option value="">Any confidence</option><option>Confirmed</option><option>Estimated</option><option>Unknown</option></select>
        </div>
        <div className="mt-2 text-xs text-muted">Showing <b className="text-ink">{filtered.length}</b> of {rows.length}{tier && <button className="ml-3 font-semibold text-primary hover:underline dark:text-primary-200" onClick={() => setTier('')}>Clear tier filter</button>}</div>
      </div>

      <DataTable rows={filtered} columns={cols} rowKey={(r) => r.id} caption="Expiry register" pageSize={10} defaultSort={{ key: 'days', dir: 'asc' }}
        actions={(r) => <Link href={`${moduleHref(r.m)}?open=${r.rec.id}`} className="btn-ghost !p-1.5" aria-label={`Open ${r.name} in ${r.m.title}`} title="Open the record"><Icon name="Eye" size={15} /></Link>} />

      <Reveal className="panel mt-4 p-4">
        <h2 className="mb-1 font-bold">Alert schedule</h2>
        <p className="mb-3 text-sm text-muted">Days before expiry at which an item moves into a tier and alerts are raised. Currently: <b className="text-ink">{getAlertDays().join(', ')}</b>.</p>
        <div className="flex flex-wrap items-center gap-2">
          <input className="input !w-72" aria-label="Alert days" value={text} onChange={(e) => setText(e.target.value)} disabled={!schedule.canEdit} placeholder="90, 60, 30, 14, 7, 1" />
          {schedule.canEdit ? <><button className="btn-primary" onClick={saveSchedule} disabled={schedule.save.isPending}>Save schedule</button><button className="btn-ghost" onClick={() => setText(DEFAULT_ALERT_DAYS.join(', '))}>Reset to defaults</button></> : <span className="text-xs text-muted">Only admins can change the schedule.</span>}
        </div>
      </Reveal>
    </div>
  );
}
