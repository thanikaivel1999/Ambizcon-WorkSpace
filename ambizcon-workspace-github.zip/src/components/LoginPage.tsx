'use client';
import { AnimatePresence, motion, useReducedMotion, useScroll, useTransform } from 'framer-motion';
import dynamic from 'next/dynamic';
import { useRouter } from 'next/navigation';
import { useEffect, useRef, useState } from 'react';
import { CompanyLogo } from './CompanyLogo';
import { Icon } from './Icon';
import { useAuth } from './providers';
import { ThreeDCharacter } from './ThreeDCharacter';
import { homePath } from '@/lib/access';
import { api, isDemo } from '@/lib/data';
import { DEMO_LOGINS, DEMO_PASSWORD } from '@/lib/seed';

const LoginScene = dynamic(() => import('./LoginScene'), { ssr: false });

const TEAMS = [
  ['development', 'Development', 'Backups, SSL, performance, SEO and daily website checks.'],
  ['marketing', 'Marketing', 'Campaigns, calendars, analytics and community growth.'],
  ['creative', 'Creative', 'Web, video and artwork — delivered on time.'],
  ['admin', 'Admin', 'One command centre for every team and metric.'],
] as const;

export function LoginPage() {
  const { user, loading, signIn } = useAuth();
  const router = useRouter();
  const reduce = !!useReducedMotion();
  const [stage, setStage] = useState(0); // 0 bg → 1 logo → 2 shapes → 3 card → 4 form active
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [show, setShow] = useState(false);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [mode, setMode] = useState<'login' | 'forgot'>('login');
  const [info, setInfo] = useState('');
  const [welcome, setWelcome] = useState<string | null>(null);
  const emailRef = useRef<HTMLInputElement>(null);

  const scroll = useRef(0);
  const pointer = useRef({ x: 0, y: 0 });
  const { scrollYProgress, scrollY } = useScroll();
  const slow = useTransform(scrollY, [0, 900], [0, -60]);
  const mid = useTransform(scrollY, [0, 900], [0, -170]);
  const glow = useTransform(scrollY, [0, 900], [0, -30]);
  const fast = useTransform(scrollY, [0, 900], [0, -260]);

  useEffect(() => {
    const t = reduce ? [0, 0, 0, 0] : [250, 1000, 1700, 2500];
    const timers = t.map((ms, i) => setTimeout(() => setStage(i + 1), ms));
    return () => timers.forEach(clearTimeout);
  }, [reduce]);
  useEffect(() => { if (stage === 4) emailRef.current?.focus(); }, [stage]);
  useEffect(() => scrollYProgress.on('change', (v) => { scroll.current = v; }), [scrollYProgress]);
  useEffect(() => {
    const move = (e: PointerEvent) => { pointer.current = { x: (e.clientX / innerWidth - 0.5) * 2, y: (e.clientY / innerHeight - 0.5) * 2 }; };
    window.addEventListener('pointermove', move, { passive: true });
    return () => window.removeEventListener('pointermove', move);
  }, []);
  useEffect(() => { if (!loading && user && !welcome) router.replace(homePath(user.team)); }, [loading, user, router, welcome]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!/^\S+@\S+\.\S+$/.test(email)) return setError('Enter a valid work email.');
    if (password.length < 6) return setError('Password must be at least 6 characters.');
    setBusy(true);
    try {
      const p = await signIn(email, password);
      setWelcome(p.name.split(' ')[0]);
      setTimeout(() => router.replace(homePath(p.team)), reduce ? 100 : 1100);
    } catch (err) {
      setError((err as Error).message);
      setBusy(false);
    }
  };
  const forgot = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(''); setInfo('');
    if (!/^\S+@\S+\.\S+$/.test(email)) return setError('Enter the email for your account.');
    setBusy(true);
    try { await api.auth.sendPasswordReset(email); setInfo('If that account exists, a reset link is on its way.'); } catch (err) { setError((err as Error).message); } finally { setBusy(false); }
  };

  return (
    <div className="relative min-h-[155vh] overflow-x-clip bg-primary-900 text-white">
      {/* background layers — each moves at a different speed (GPU transforms only) */}
      <motion.div aria-hidden initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1.2 }} className="fixed inset-0 bg-[radial-gradient(ellipse_at_20%_10%,#13798A_0%,#0c4d58_40%,#06272d_100%)]" />
      <motion.div aria-hidden style={{ y: slow }} className="pointer-events-none fixed inset-0 gpu">
        <div className="absolute -left-32 top-10 h-[28rem] w-[28rem] animate-blob rounded-full bg-secondary/25 blur-3xl" />
        <div className="absolute -right-24 bottom-0 h-[26rem] w-[26rem] animate-blob rounded-full bg-primary/40 blur-3xl [animation-delay:-9s]" />
      </motion.div>
      <motion.div aria-hidden initial={{ opacity: 0 }} animate={{ opacity: stage >= 2 ? 1 : 0 }} transition={{ duration: 1.4 }} className="pointer-events-none fixed inset-0">
        {stage >= 2 && <LoginScene scroll={scroll} pointer={pointer} reduce={reduce} />}
      </motion.div>
      <motion.div aria-hidden style={{ y: glow }} className="pointer-events-none fixed left-1/2 top-1/3 h-[34rem] w-[34rem] -translate-x-1/2 rounded-full bg-secondary/20 blur-[110px] gpu" />

      <main className="relative">
        <section className="grid min-h-screen place-items-center px-4 py-10">
          <motion.div style={{ y: mid }} className="flex w-full max-w-md flex-col items-center gpu">
            <motion.div initial={{ opacity: 0, y: 24, scale: 0.9 }} animate={stage >= 1 ? { opacity: 1, y: 0, scale: 1 } : {}} transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }} className="mb-6 flex flex-col items-center gap-3">
              <CompanyLogo size={84} />
              <motion.p initial={{ opacity: 0 }} animate={stage >= 1 ? { opacity: 1 } : {}} transition={{ delay: 0.5 }} className="text-xs font-semibold uppercase tracking-[.35em] text-white/70">Beyond Marketing · Beyond Healthcare</motion.p>
            </motion.div>

            <motion.div initial={{ opacity: 0, y: 60, rotateX: 14 }} animate={stage >= 3 ? { opacity: 1, y: 0, rotateX: 0 } : {}} transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }} style={{ transformPerspective: 1100 }} className="relative w-full">
              <div aria-hidden className="absolute -inset-px rounded-3xl bg-gradient-to-br from-white/40 via-secondary/30 to-primary/40 blur-[2px]" />
              <div className="relative rounded-3xl border border-white/20 bg-primary-900/55 p-6 shadow-lift backdrop-blur-xl sm:p-8" aria-busy={busy}>
                <AnimatePresence mode="wait">
                  {welcome ? (
                    <motion.div key="welcome" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="py-10 text-center" role="status">
                      <motion.div animate={{ rotate: 360 }} transition={{ duration: 1.1, ease: 'easeInOut' }} className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-full bg-gradient-to-br from-secondary-400 to-primary"><Icon name="Check" size={32} /></motion.div>
                      <h2 className="text-2xl font-extrabold">Welcome, {welcome}</h2>
                      <p className="mt-1 text-white/70">Opening your workspace…</p>
                    </motion.div>
                  ) : mode === 'login' ? (
                    <motion.form key="login" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onSubmit={submit} noValidate className="space-y-4">
                      <div className="text-center">
                        <h1 className="text-2xl font-extrabold">Ambizcon Team Workspace</h1>
                        <p className="mt-1 text-sm text-white/65">Sign in with your work account. Your team and access are set by your admin.</p>
                      </div>
                      <fieldset disabled={stage < 4 || busy} className="space-y-4 transition-opacity disabled:opacity-60">
                        <div>
                          <label htmlFor="email" className="mb-1 block text-xs font-semibold uppercase tracking-wide text-white/70">Email</label>
                          <input ref={emailRef} id="email" type="email" autoComplete="username" required className="input !border-white/20 !bg-white/10 !text-white placeholder:!text-white/40" placeholder="you@ambizcon.com" value={email} onChange={(e) => setEmail(e.target.value)} aria-describedby={error ? 'login-error' : undefined} />
                        </div>
                        <div>
                          <label htmlFor="password" className="mb-1 block text-xs font-semibold uppercase tracking-wide text-white/70">Password</label>
                          <div className="relative">
                            <input id="password" type={show ? 'text' : 'password'} autoComplete="current-password" required className="input !border-white/20 !bg-white/10 !pr-10 !text-white placeholder:!text-white/40" placeholder="••••••••" value={password} onChange={(e) => setPassword(e.target.value)} />
                            <button type="button" className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-1 text-white/60 hover:text-white" onClick={() => setShow((s) => !s)} aria-label={show ? 'Hide password' : 'Show password'}><Icon name={show ? 'Lock' : 'Eye'} size={16} /></button>
                          </div>
                        </div>
                        <AnimatePresence>{error && <motion.p id="login-error" role="alert" initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="rounded-lg bg-black/30 px-3 py-2 text-sm font-medium">{error}</motion.p>}</AnimatePresence>
                        <button type="submit" className="btn-primary w-full !py-3 text-base">{busy ? <Icon name="Loader2" className="animate-spin" /> : <Icon name="Lock" size={16} />}{busy ? 'Signing in…' : 'Login'}</button>
                        <button type="button" className="mx-auto block text-sm text-white/70 underline-offset-4 hover:text-white hover:underline" onClick={() => { setMode('forgot'); setError(''); }}>Forgot password?</button>
                      </fieldset>
                      {isDemo && (
                        <div className="rounded-xl border border-white/15 bg-white/5 p-3 text-xs">
                          <p className="mb-2 font-semibold text-white/80">Demo mode — pick a role to fill the form <span className="font-normal text-white/50">(password: {DEMO_PASSWORD})</span></p>
                          <div className="grid grid-cols-2 gap-2">
                            {DEMO_LOGINS.map((d) => <button key={d.label} type="button" className="rounded-lg bg-white/10 px-2 py-1.5 font-semibold transition hover:bg-white/20" onClick={() => { setEmail(d.email); setPassword(DEMO_PASSWORD); setError(''); }}>{d.label}</button>)}
                          </div>
                        </div>
                      )}
                    </motion.form>
                  ) : (
                    <motion.form key="forgot" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onSubmit={forgot} noValidate className="space-y-4">
                      <div className="text-center"><h1 className="text-2xl font-extrabold">Reset password</h1><p className="mt-1 text-sm text-white/65">We&apos;ll email you a secure reset link.</p></div>
                      <div><label htmlFor="fe" className="mb-1 block text-xs font-semibold uppercase tracking-wide text-white/70">Email</label><input id="fe" type="email" className="input !border-white/20 !bg-white/10 !text-white" value={email} onChange={(e) => setEmail(e.target.value)} /></div>
                      {error && <p role="alert" className="rounded-lg bg-black/30 px-3 py-2 text-sm">{error}</p>}
                      {info && <p role="status" className="rounded-lg bg-secondary/30 px-3 py-2 text-sm">{info}</p>}
                      <button className="btn-primary w-full" disabled={busy}>{busy && <Icon name="Loader2" className="animate-spin" />}Send reset link</button>
                      <button type="button" className="mx-auto block text-sm text-white/70 hover:text-white" onClick={() => { setMode('login'); setError(''); setInfo(''); }}>← Back to login</button>
                    </motion.form>
                  )}
                </AnimatePresence>
              </div>
            </motion.div>
            <motion.div initial={{ opacity: 0 }} animate={stage >= 4 ? { opacity: 1 } : {}} className="mt-8 flex flex-col items-center gap-1 text-xs text-white/50"><Icon name="ChevronDown" className="animate-bounce" /><span>Scroll to explore</span></motion.div>
          </motion.div>
        </section>

        <motion.section style={{ y: fast }} className="relative mx-auto max-w-6xl px-4 pb-24 gpu" aria-label="Teams">
          <h2 className="mb-8 text-center text-3xl font-extrabold">One workspace. Four teams.</h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {TEAMS.map(([k, t, d], i) => (
              <motion.div key={k} initial={{ opacity: 0, y: 40 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: '-60px' }} transition={{ delay: i * 0.1, duration: 0.6 }} className="rounded-2xl border border-white/15 bg-white/[.07] p-4 backdrop-blur">
                <ThreeDCharacter kind={k} className="mx-auto h-36 w-44" />
                <h3 className="mt-2 text-lg font-bold">{t}</h3>
                <p className="text-sm text-white/65">{d}</p>
              </motion.div>
            ))}
          </div>
        </motion.section>
      </main>
    </div>
  );
}
