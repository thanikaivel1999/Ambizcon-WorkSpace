'use client';
import Link from 'next/link';
import { useEffect, useMemo, useState } from 'react';
import { DataTable, type Column } from './DataTable';
import { Icon } from './Icon';
import { useAuth, useToast } from './providers';
import { EmptyState, ErrorState, LoadingState, Modal, PageHeader, Reveal, ToneBadge, UserAvatar } from './ui';
import { moduleHref } from '@/lib/access';
import { downloadCsv, toCsv } from '@/lib/csv';
import { useClientActions, useClients, useItems, useTasks, useUsers, modulesForTeam } from '@/lib/hooks';
import { BRIEF_MODULES } from '@/lib/modules';
import { effStatus } from '@/lib/stats';
import { CLIENT_STATUSES, CLIENT_TYPES, type Client, type ClientInput } from '@/lib/types';
import { cn, fmtDate } from '@/lib/utils';

const BLANK: ClientInput = { name: '', client_type: 'General Practitioner', joined_on: null, md_name: '', location: '', category: '', website: '', status: 'active', notes: '', assigned_ids: [] };

function ClientForm({ open, client, onClose }: { open: boolean; client: Client | null; onClose: () => void }) {
  const { create, update } = useClientActions();
  const users = useUsers().data ?? [];
  const [v, setV] = useState<ClientInput>(BLANK);
  const [err, setErr] = useState<Record<string, string>>({});
  useEffect(() => {
    if (open) { setV(client ? { ...BLANK, ...client } : BLANK); setErr({}); }
  }, [open, client]);
  const set = <K extends keyof ClientInput>(k: K, val: ClientInput[K]) => setV((s) => ({ ...s, [k]: val }));
  const busy = create.isPending || update.isPending;

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const errors: Record<string, string> = {};
    if (!v.name.trim()) errors.name = 'Client name is required';
    if (!v.joined_on) errors.joined_on = 'Joining date is required';
    if (!v.md_name?.trim()) errors.md_name = 'MD name is required';
    if (!v.location?.trim()) errors.location = 'Location is required';
    if (v.website && !/^https?:\/\//i.test(v.website)) errors.website = 'Must start with http:// or https://';
    setErr(errors);
    if (Object.keys(errors).length) return;
    const clean: ClientInput = { ...v, name: v.name.trim(), md_name: v.md_name?.trim() || null, location: v.location?.trim() || null, category: v.category?.trim() || null, website: v.website?.trim() || null, notes: v.notes?.trim() || null };
    if (client) update.mutate({ id: client.id, patch: clean }, { onSuccess: onClose });
    else create.mutate(clean, { onSuccess: onClose });
  };
  const Err = ({ k }: { k: string }) => (err[k] ? <p role="alert" className="mt-1 text-xs font-medium text-primary-800 dark:text-primary-200">{err[k]}</p> : null);
  const active = users.filter((u) => u.status === 'active' && u.team !== 'admin');
  return (
    <Modal open={open} onClose={onClose} title={client ? 'Edit client' : 'Add client'} size="lg"
      footer={<><button type="button" className="btn-ghost" onClick={onClose}>Cancel</button><button type="submit" form="client-form" className="btn-primary" disabled={busy}>{busy && <Icon name="Loader2" className="animate-spin" size={16} />}{client ? 'Save changes' : 'Create client'}</button></>}>
      <form id="client-form" onSubmit={submit} noValidate className="grid grid-cols-1 gap-x-4 gap-y-3 sm:grid-cols-2">
        <div className="sm:col-span-2"><label className="label" htmlFor="c-name">Client name *</label><input id="c-name" className="input" value={v.name} onChange={(e) => set('name', e.target.value)} /><Err k="name" /></div>
        <div><label className="label" htmlFor="c-type">Client type *</label><select id="c-type" className="input" value={v.client_type} onChange={(e) => set('client_type', e.target.value as Client['client_type'])}>{CLIENT_TYPES.map((t) => <option key={t}>{t}</option>)}</select></div>
        <div><label className="label" htmlFor="c-join">Joining date *</label><input id="c-join" type="date" className="input" value={v.joined_on ?? ''} onChange={(e) => set('joined_on', e.target.value || null)} /><Err k="joined_on" /></div>
        <div><label className="label" htmlFor="c-md">Client MD name *</label><input id="c-md" className="input" value={v.md_name ?? ''} onChange={(e) => set('md_name', e.target.value)} /><Err k="md_name" /></div>
        <div><label className="label" htmlFor="c-loc">Location *</label><input id="c-loc" className="input" value={v.location ?? ''} onChange={(e) => set('location', e.target.value)} /><Err k="location" /></div>
        <div><label className="label" htmlFor="c-cat">Business category</label><input id="c-cat" className="input" value={v.category ?? ''} onChange={(e) => set('category', e.target.value)} /></div>
        <div><label className="label" htmlFor="c-web">Website URL</label><input id="c-web" type="url" className="input" placeholder="https://…" value={v.website ?? ''} onChange={(e) => set('website', e.target.value)} /><Err k="website" /></div>
        <div><label className="label" htmlFor="c-status">Status</label><select id="c-status" className="input" value={v.status} onChange={(e) => set('status', e.target.value as Client['status'])}>{CLIENT_STATUSES.map((t) => <option key={t} className="capitalize">{t}</option>)}</select></div>
        <fieldset className="sm:col-span-2"><legend className="label">Assigned team members</legend>
          <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-2">
            {active.map((u) => (
              <label key={u.id} className="flex cursor-pointer items-center gap-2 rounded-lg px-2 py-1.5 text-sm hover:bg-primary/5">
                <input type="checkbox" checked={v.assigned_ids.includes(u.id)} onChange={(e) => set('assigned_ids', e.target.checked ? [...v.assigned_ids, u.id] : v.assigned_ids.filter((x) => x !== u.id))} />
                <span>{u.name}</span><span className="ml-auto text-xs capitalize text-muted">{u.team}</span>
              </label>
            ))}
          </div>
        </fieldset>
        <div className="sm:col-span-2"><label className="label" htmlFor="c-notes">Internal notes</label><textarea id="c-notes" rows={3} className="input" value={v.notes ?? ''} onChange={(e) => set('notes', e.target.value)} /></div>
      </form>
    </Modal>
  );
}

/** /clients — the one shared client list used by every team. */
export function ClientsPage() {
  const { user } = useAuth();
  const q = useClients();
  const users = useUsers().data ?? [];
  const { update, canEdit } = useClientActions();
  const toast = useToast();
  const [search, setSearch] = useState('');
  const [loc, setLoc] = useState('');
  const [type, setType] = useState('');
  const [status, setStatus] = useState('active');
  const [form, setForm] = useState<{ client: Client | null } | null>(null);

  const rows = q.data ?? [];
  const locations = useMemo(() => [...new Set(rows.map((c) => c.location).filter(Boolean) as string[])].sort(), [rows]);
  const filtered = useMemo(() => {
    const s = search.trim().toLowerCase();
    return rows.filter((c) => (!status || c.status === status) && (!loc || c.location === loc) && (!type || c.client_type === type)
      && (!s || [c.name, c.md_name, c.location, c.category, c.website].some((x) => x?.toLowerCase().includes(s))));
  }, [rows, search, loc, type, status]);

  const names = (ids: string[]) => ids.map((id) => users.find((u) => u.id === id)?.name).filter(Boolean) as string[];
  const columns: Column<Client>[] = [
    { key: 'name', label: 'Client', sortValue: (c) => c.name, render: (c) => <Link href={`/clients/${c.id}`} className="font-bold text-primary hover:underline dark:text-primary-200">{c.name}</Link> },
    { key: 'type', label: 'Type', sortValue: (c) => c.client_type, render: (c) => <ToneBadge value={c.client_type} /> },
    { key: 'joined', label: 'Joined', sortValue: (c) => c.joined_on ?? '', render: (c) => fmtDate(c.joined_on) },
    { key: 'md', label: 'MD', sortValue: (c) => c.md_name ?? '', render: (c) => c.md_name ?? '—' },
    { key: 'loc', label: 'Location', sortValue: (c) => c.location ?? '', render: (c) => c.location ?? '—' },
    { key: 'cat', label: 'Category', sortValue: (c) => c.category ?? '', render: (c) => c.category ?? '—' },
    { key: 'team', label: 'Team', sortValue: (c) => c.assigned_ids.length, render: (c) => { const n = names(c.assigned_ids); return n.length ? <span title={n.join(', ')}>{n.length} member{n.length > 1 ? 's' : ''}</span> : <span className="text-muted">Unassigned</span>; } },
    { key: 'status', label: 'Status', sortValue: (c) => c.status, render: (c) => <span className={cn('rounded-full px-2 py-0.5 text-xs font-semibold capitalize', c.status === 'active' ? 'bg-secondary/25 text-primary-800 dark:text-secondary-200' : 'bg-line/15 text-muted')}>{c.status}</span> },
  ];

  const exportCsv = () => {
    downloadCsv('clients', toCsv(filtered, [
      { label: 'Client', value: (c) => c.name }, { label: 'Type', value: (c) => c.client_type }, { label: 'Joined', value: (c) => c.joined_on }, { label: 'MD', value: (c) => c.md_name },
      { label: 'Location', value: (c) => c.location }, { label: 'Category', value: (c) => c.category }, { label: 'Website', value: (c) => c.website }, { label: 'Status', value: (c) => c.status },
      { label: 'Assigned', value: (c) => names(c.assigned_ids).join('; ') },
    ]));
    toast.success(`Exported ${filtered.length} clients.`);
  };

  return (
    <div>
      <PageHeader icon="Building2" title="Client List" subtitle="One shared client database for Development, Marketing and Creative."
        actions={<>
          <button className="btn-ghost" onClick={exportCsv} disabled={!filtered.length}><Icon name="Download" size={16} />Export CSV</button>
          {canEdit && <button className="btn-primary" onClick={() => setForm({ client: null })}><Icon name="Plus" size={16} />Add client</button>}
        </>} />
      <div className="panel mb-4 grid grid-cols-2 gap-2 p-3 md:grid-cols-4" role="search" aria-label="Filter clients">
        <div className="relative col-span-2"><Icon name="Search" size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted" /><input className="input pl-9" placeholder="Search clients, MD, location…" aria-label="Search clients" value={search} onChange={(e) => setSearch(e.target.value)} /></div>
        <select className="input" aria-label="Location" value={loc} onChange={(e) => setLoc(e.target.value)}><option value="">All locations</option>{locations.map((l) => <option key={l}>{l}</option>)}</select>
        <select className="input" aria-label="Client type" value={type} onChange={(e) => setType(e.target.value)}><option value="">All types</option>{CLIENT_TYPES.map((t) => <option key={t}>{t}</option>)}</select>
        <select className="input" aria-label="Status" value={status} onChange={(e) => setStatus(e.target.value)}><option value="">All statuses</option>{CLIENT_STATUSES.map((t) => <option key={t} value={t} className="capitalize">{t}</option>)}</select>
      </div>
      {q.isLoading ? <LoadingState variant="table" /> : q.error ? <ErrorState message={(q.error as Error).message} onRetry={() => q.refetch()} /> : rows.length === 0 ? (
        <div className="panel"><EmptyState title="No clients yet" message={canEdit ? 'Add the first client to link work records to it.' : 'An admin has not added any clients yet.'} action={canEdit} actionLabel="Add client" onAction={() => setForm({ client: null })} /></div>
      ) : filtered.length === 0 ? (
        <div className="panel"><EmptyState title="No matching clients" message="Try changing or clearing the filters." /></div>
      ) : (
        <DataTable rows={filtered} columns={columns} rowKey={(c) => c.id} caption="Clients" defaultSort={{ key: 'joined', dir: 'desc' }}
          actions={(c) => <>
            <Link href={`/clients/${c.id}`} className="btn-ghost !p-1.5" aria-label={`Open ${c.name}`} title="Open profile"><Icon name="Eye" size={15} /></Link>
            {canEdit && <button className="btn-ghost !p-1.5" aria-label={`Edit ${c.name}`} title="Edit" onClick={() => setForm({ client: c })}><Icon name="Pencil" size={15} /></button>}
            {canEdit && <button className="btn-ghost !p-1.5" aria-label={c.status === 'archived' ? `Restore ${c.name}` : `Archive ${c.name}`} title={c.status === 'archived' ? 'Restore' : 'Archive'} disabled={update.isPending}
              onClick={() => update.mutate({ id: c.id, patch: { status: c.status === 'archived' ? 'active' : 'archived' } })}><Icon name={c.status === 'archived' ? 'ArchiveRestore' : 'Archive'} size={15} /></button>}
          </>} />
      )}
      {!canEdit && <p className="mt-3 text-xs text-muted">Signed in as {user?.name}. Only an admin can add, edit or archive clients.</p>}
      <ClientForm open={!!form} client={form?.client ?? null} onClose={() => setForm(null)} />
    </div>
  );
}

/** /clients/[clientId] — profile with links into every record that references the client. */
export function ClientProfile({ id }: { id: string }) {
  const { user } = useAuth();
  const q = useClients();
  const users = useUsers().data ?? [];
  const { canEdit } = useClientActions();
  const mods = useMemo(() => (user ? modulesForTeam(user.team) : []), [user]);
  const { items, loading } = useItems(mods);
  const tasks = useTasks().data ?? [];
  const [edit, setEdit] = useState(false);
  const client = q.data?.find((c) => c.id === id);

  if (q.isLoading) return <LoadingState variant="page" />;
  if (!client) return <div className="panel"><EmptyState title="Client not found" message="It may have been removed, or you may not have access." /></div>;

  const mine = items.filter(({ rec }) => rec.client_id === id);
  const byModule = mods.map((m) => {
    const rows = mine.filter((i) => i.m.key === m.key);
    const open = rows.filter((i) => { const s = effStatus(m, i.rec); return s && s !== 'Completed' && s !== 'Cancelled'; }).length;
    return { m, total: rows.length, open };
  }).filter((x) => x.total > 0);
  const clientTasks = tasks.filter((t) => t.client_id === id);
  const openTasks = clientTasks.filter((t) => !['Completed', 'Cancelled'].includes(t.status));
  const team = client.assigned_ids.map((uid) => users.find((u) => u.id === uid)).filter(Boolean) as typeof users;
  const canSeeBriefs = user?.team === 'creative' || user?.team === 'admin';

  const facts: [string, string][] = [
    ['Client type', client.client_type], ['Joined', fmtDate(client.joined_on)], ['MD', client.md_name ?? '—'], ['Location', client.location ?? '—'],
    ['Business category', client.category ?? '—'], ['Status', client.status],
  ];
  return (
    <div>
      <PageHeader icon="Building2" title={client.name} subtitle={`${client.client_type} · ${client.location ?? 'Location not set'}`}
        actions={<><Link href="/clients" className="btn-ghost"><Icon name="ChevronLeft" size={16} />All clients</Link>{canEdit && <button className="btn-primary" onClick={() => setEdit(true)}><Icon name="Pencil" size={16} />Edit client</button>}</>} />
      <div className="grid gap-4 lg:grid-cols-3">
        <Reveal className="panel p-5 lg:col-span-2">
          <h2 className="mb-3 font-bold">Profile</h2>
          <dl className="grid grid-cols-2 gap-x-4 gap-y-3 sm:grid-cols-3">
            {facts.map(([k, v]) => <div key={k}><dt className="label !mb-0">{k}</dt><dd className="text-sm font-medium capitalize">{v}</dd></div>)}
            <div className="col-span-2 sm:col-span-3"><dt className="label !mb-0">Website</dt><dd className="text-sm">{client.website ? <a href={client.website} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-primary hover:underline dark:text-primary-200">{client.website}<Icon name="ExternalLink" size={13} /></a> : '—'}</dd></div>
            {client.notes && <div className="col-span-2 sm:col-span-3"><dt className="label !mb-0">Internal notes</dt><dd className="whitespace-pre-wrap text-sm">{client.notes}</dd></div>}
          </dl>
        </Reveal>
        <Reveal delay={0.05} className="panel p-5">
          <h2 className="mb-3 font-bold">Assigned team</h2>
          {team.length === 0 ? <p className="text-sm text-muted">No members assigned yet.</p> : (
            <ul className="space-y-2">{team.map((u) => <li key={u.id} className="flex items-center gap-2"><UserAvatar name={u.name} src={u.avatar_url} size={30} /><span className="text-sm font-medium">{u.name}</span><span className="ml-auto text-xs capitalize text-muted">{u.team}</span></li>)}</ul>
          )}
        </Reveal>
      </div>

      <Reveal delay={0.08} className="panel mt-4 p-5">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2"><h2 className="font-bold">Work records for this client</h2>
          <Link href={`/tasks?client=${id}`} className="btn-ghost !py-1 text-sm"><Icon name="ListChecks" size={15} />{openTasks.length} open task{openTasks.length === 1 ? '' : 's'} · {clientTasks.length} total</Link></div>
        {loading ? <LoadingState variant="cards" /> : byModule.length === 0 ? <p className="text-sm text-muted">No module records are linked to this client yet.</p> : (
          <ul className="grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
            {byModule.map(({ m, total, open }) => (
              <li key={m.key}><Link href={`${moduleHref(m)}?client=${id}`} className="flex items-center gap-3 rounded-xl border border-line/15 p-3 transition hover:border-primary/40 hover:bg-primary/5">
                <span className="grid h-9 w-9 place-items-center rounded-lg bg-primary/10 text-primary dark:text-primary-200"><Icon name={m.icon} size={18} /></span>
                <span className="min-w-0 flex-1"><span className="block truncate text-sm font-semibold">{m.title}</span><span className="text-xs text-muted">{total} record{total > 1 ? 's' : ''}{open ? ` · ${open} open` : ''}</span></span>
                <Icon name="ChevronRight" size={16} className="text-muted" />
              </Link></li>
            ))}
          </ul>
        )}
      </Reveal>

      {canSeeBriefs && (
        <Reveal delay={0.1} className="panel mt-4 p-5">
          <div className="mb-3 flex items-center justify-between"><h2 className="font-bold">Brand &amp; content brief</h2><Link href={`/creative/client-briefs?client=${id}`} className="btn-ghost !py-1 text-sm">Open full brief<Icon name="ArrowRight" size={15} /></Link></div>
          <ul className="grid gap-2 sm:grid-cols-3">{BRIEF_MODULES.map((m, i) => <li key={m.key}><Link href={`/creative/client-briefs?client=${id}&section=${m.slug}`} className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm hover:bg-primary/5"><span className="grid h-6 w-6 place-items-center rounded-full bg-primary/10 text-xs font-bold text-primary dark:text-primary-200">{String(i + 1).padStart(2, '0')}</span>{m.nav}</Link></li>)}</ul>
        </Reveal>
      )}
      <ClientForm open={edit} client={client} onClose={() => setEdit(false)} />
    </div>
  );
}
