'use client';
import { useEffect, useMemo, useState } from 'react';
import { BarsChart, CH, DonutChart, LinesChart } from './charts';
import { DataTable, type Column } from './DataTable';
import { Icon } from './Icon';
import { ChartCard, EmptyState, ErrorState, LoadingState, PageHeader, Reveal, UserAvatar } from './ui';
import { downloadCsv, toCsv } from '@/lib/csv';
import { useLookups, useSetting, useTasks } from '@/lib/hooks';
import {
  DEFAULT_WEIGHTS, lastThreeCompletedMonths, monthlyHistory, monthPeriod, normalizeWeights, quarterPeriod, rankBy, taskToWorkItem, yearPeriod, computeMetrics,
  type Metrics, type Period, type Ranked, type ScoringWeights, type WorkItem,
} from '@/lib/performance';
import type { WorkTeam } from '@/lib/types';
import { cn, todayISO } from '@/lib/utils';

const TEAMS: WorkTeam[] = ['development', 'marketing', 'creative'];
const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);
const pctText = (v: number | null) => (v === null ? '—' : `${Math.round(v * 100)}%`);
const num1 = (v: number | null, suffix = '') => (v === null ? '—' : `${(Math.round(v * 10) / 10).toFixed(1)}${suffix}`);

type Kind = 'month' | 'quarter' | 'year' | 'last3';

function previous(kind: Kind, p: Period, today: string): Period {
  const [y, m] = p.from.split('-').map(Number);
  if (kind === 'month') { const d = new Date(Date.UTC(y, m - 2, 1)); return monthPeriod(d.getUTCFullYear(), d.getUTCMonth()); }
  if (kind === 'quarter') { const q = Math.floor((m - 1) / 3); return q === 0 ? quarterPeriod(y - 1, 3) : quarterPeriod(y, q - 1); }
  if (kind === 'year') return yearPeriod(y - 1);
  const d = new Date(Date.UTC(y, m - 1, 1));
  d.setUTCMonth(d.getUTCMonth() - 3);
  const end = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 3, 0));
  void today;
  return { from: `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}-01`, to: end.toISOString().slice(0, 10), label: 'previous 3 months' };
}

function Highlight({ title, name, sub, icon, empty }: { title: string; name?: string; sub?: string; icon: string; empty: string }) {
  return (
    <Reveal className="panel flex items-center gap-3 p-4">
      <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-primary to-secondary-400 text-white shadow-md"><Icon name={icon} size={24} /></span>
      <div className="min-w-0">
        <div className="text-xs font-semibold uppercase tracking-wide text-muted">{title}</div>
        {name ? <><div className="truncate text-lg font-extrabold">{name}</div><div className="text-xs text-muted">{sub}</div></> : <div className="text-sm text-muted">{empty}</div>}
      </div>
    </Reveal>
  );
}

function WeightsEditor({ weights, onSave, saving, canEdit }: { weights: ScoringWeights; onSave: (w: ScoringWeights) => void; saving: boolean; canEdit: boolean }) {
  const [w, setW] = useState(weights);
  useEffect(() => setW(weights), [weights]);
  const fields: [keyof ScoringWeights, string, string][] = [
    ['onTime', 'On-time completion', '% weight'], ['quality', 'Quality (reviewer rating)', '% weight'], ['verified', 'Verified completion', '% weight'],
    ['priority', 'Priority / complexity', '% weight'], ['overdue', 'Open overdue work (penalty)', '% weight'], ['minCompleted', 'Minimum completed items to be ranked', 'items'],
  ];
  const total = w.onTime + w.quality + w.verified + w.priority + w.overdue;
  return (
    <div>
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {fields.map(([k, label, unit]) => (
          <label key={k} className="block"><span className="label">{label}</span>
            <div className="flex items-center gap-2"><input type="number" min={0} max={1000} className="input" disabled={!canEdit} value={w[k]} onChange={(e) => setW({ ...w, [k]: Number(e.target.value) })} /><span className="text-xs text-muted">{unit}</span></div></label>
        ))}
      </div>
      <div className="mt-3 flex flex-wrap items-center gap-3 text-sm">
        <span className="text-muted">Weights are relative: they are divided by their total ({total}) when scoring.</span>
        {canEdit && <><button className="btn-primary ml-auto" disabled={saving || total <= 0} onClick={() => onSave(normalizeWeights(w))}>{saving && <Icon name="Loader2" className="animate-spin" size={16} />}Save weights</button>
          <button className="btn-ghost" onClick={() => setW(DEFAULT_WEIGHTS)}>Reset to defaults</button></>}
        {!canEdit && <span className="text-xs text-muted">Only admins can change the formula.</span>}
      </div>
    </div>
  );
}

/** /admin/performance */
export function PerformancePage() {
  const tasks = useTasks();
  const lk = useLookups();
  const settings = useSetting<ScoringWeights>('scoring', DEFAULT_WEIGHTS, (r) => normalizeWeights(r as Partial<ScoringWeights>));
  const today = todayISO();
  const last3 = useMemo(() => lastThreeCompletedMonths(today), [today]);
  const lastMonth = last3.to.slice(0, 7);

  const [kind, setKind] = useState<Kind>('month');
  const [month, setMonth] = useState(lastMonth);
  const [year, setYear] = useState(Number(today.slice(0, 4)));
  const [quarter, setQuarter] = useState(Math.floor((Number(today.slice(5, 7)) - 1) / 3));
  const [team, setTeam] = useState<'' | WorkTeam>('');
  const [client, setClient] = useState('');
  const [pickEmp, setPickEmp] = useState('');

  const items = useMemo<WorkItem[]>(() => (tasks.data ?? []).map((t) => taskToWorkItem(t)).filter((i) => i.assignee && (!client || i.client_id === client)), [tasks.data, client]);
  const period: Period = useMemo(() => {
    if (kind === 'month') { const [y, m] = month.split('-').map(Number); return monthPeriod(y, m - 1); }
    if (kind === 'quarter') return quarterPeriod(year, quarter);
    if (kind === 'year') return yearPeriod(year);
    return last3;
  }, [kind, month, year, quarter, last3]);
  const prev = useMemo(() => previous(kind, period, today), [kind, period, today]);
  const w = settings.value;
  const isPartial = period.to >= today;

  const teamRank = useMemo(() => rankBy(items, (i) => i.team, period, today, w), [items, period, today, w]);
  const teamPrev = useMemo(() => rankBy(items, (i) => i.team, prev, today, w), [items, prev, today, w]);
  const people = useMemo<Ranked<string>[]>(() => rankBy(items.filter((i) => !team || i.team === team), (i) => i.assignee, period, today, w).filter((r) => !!lk.userById(r.key)), [items, team, period, today, w, lk]);
  const threeMonth = useMemo(() => rankBy(items, (i) => i.assignee, last3, today, w).filter((r) => !!lk.userById(r.key)), [items, last3, today, w, lk]);
  const empPrev = useMemo(() => new Map(rankBy(items, (i) => i.assignee, prev, today, w).map((r) => [r.key, r.metrics])), [items, prev, today, w]);

  if (tasks.isLoading) return <LoadingState variant="page" />;
  if (tasks.error) return <ErrorState message={(tasks.error as Error).message} onRetry={() => tasks.refetch()} />;
  if (!(tasks.data ?? []).length) return <div className="panel"><PageHeader icon="Trophy" title="Performance" /><EmptyState title="No tasks to score yet" message="Performance is calculated from tasks. Create and complete tasks to see scores." /></div>;

  const bestTeam = teamRank.find((r) => r.metrics.eligible);
  const bestPerson = people.find((r) => r.metrics.eligible);
  const bestThree = threeMonth.find((r) => r.metrics.eligible);
  const sel = pickEmp || bestPerson?.key || people[0]?.key || '';
  const histPeriods = monthlyHistory(today, 6);
  const history = histPeriods.map((p) => {
    const mine = items.filter((i) => i.assignee === sel);
    const m = computeMetrics(mine, p, today, w);
    return { name: p.label.split(' ')[0], score: m.score ?? 0, completed: m.completed, rated: m.score === null ? 0 : 1 };
  });
  const histRaw = histPeriods.map((p) => computeMetrics(items.filter((i) => i.assignee === sel), p, today, w));
  const trendTeams = monthlyHistory(today, 6).map((p) => ({ name: p.label.split(' ')[0], ...Object.fromEntries(TEAMS.map((t) => [t, computeMetrics(items.filter((i) => i.team === t), p, today, w).completed])) }));
  const workload = people.map((r) => ({ name: lk.user(r.key), value: r.metrics.pending }));

  const personCols: Column<Ranked<string>>[] = [
    { key: 'rank', label: '#', render: (r) => (r.metrics.eligible ? people.findIndex((x) => x.key === r.key) + 1 : '—'), sortValue: (r) => (r.metrics.score ?? -1) },
    { key: 'name', label: 'Employee', sortValue: (r) => lk.user(r.key), render: (r) => { const u = lk.userById(r.key)!; return <button className="flex items-center gap-2 text-left font-semibold hover:text-primary" onClick={() => setPickEmp(r.key)}><UserAvatar name={u.name} src={u.avatar_url} size={28} />{u.name}</button>; } },
    { key: 'team', label: 'Team', render: (r) => cap(lk.userById(r.key)?.team ?? ''), sortValue: (r) => lk.userById(r.key)?.team ?? '' },
    { key: 'asg', label: 'Assigned', render: (r) => r.metrics.assigned, sortValue: (r) => r.metrics.assigned },
    { key: 'done', label: 'Completed', render: (r) => r.metrics.completed, sortValue: (r) => r.metrics.completed },
    { key: 'pend', label: 'Pending', render: (r) => r.metrics.pending, sortValue: (r) => r.metrics.pending },
    { key: 'over', label: 'Overdue', render: (r) => r.metrics.overdue, sortValue: (r) => r.metrics.overdue },
    { key: 'ot', label: 'On-time', render: (r) => pctText(r.metrics.onTimeRate), sortValue: (r) => r.metrics.onTimeRate ?? -1 },
    { key: 'avg', label: 'Avg days', render: (r) => num1(r.metrics.avgCompletionDays), sortValue: (r) => r.metrics.avgCompletionDays ?? 999 },
    { key: 'q', label: 'Quality', render: (r) => (r.metrics.quality === null ? <span className="text-muted" title="No reviewed work in this period">no reviews</span> : `${num1(r.metrics.quality)} / 5 (${r.metrics.ratedCount})`), sortValue: (r) => r.metrics.quality ?? -1 },
    { key: 'ver', label: 'Verified', render: (r) => pctText(r.metrics.verifiedRate), sortValue: (r) => r.metrics.verifiedRate ?? -1 },
    { key: 'score', label: 'Score', render: (r) => (r.metrics.score === null ? <span className="text-muted" title={`Needs at least ${w.minCompleted} completed items`}>too few</span> : <b className="tabular-nums">{r.metrics.score}</b>), sortValue: (r) => r.metrics.score ?? -1 },
    { key: 'delta', label: `vs ${prev.label}`, render: (r) => { const p = empPrev.get(r.key); if (!p || p.score === null || r.metrics.score === null) return <span className="text-muted">—</span>; const d = Math.round((r.metrics.score - p.score) * 10) / 10; return <span className={cn('font-semibold', d >= 0 ? 'text-secondary-700 dark:text-secondary-200' : 'text-primary-800 dark:text-primary-200')}>{d >= 0 ? '+' : ''}{d}</span>; }, sortValue: (r) => (empPrev.get(r.key)?.score ?? 0) },
  ];

  const exportCsv = () => downloadCsv(`employee-performance-${period.label.replace(/\s/g, '-')}`, toCsv(people, [
    { label: 'Period', value: () => `${period.from} to ${period.to}` }, { label: 'Employee', value: (r) => lk.user(r.key) }, { label: 'Team', value: (r) => lk.userById(r.key)?.team },
    { label: 'Assigned', value: (r) => r.metrics.assigned }, { label: 'Completed', value: (r) => r.metrics.completed }, { label: 'Pending', value: (r) => r.metrics.pending }, { label: 'Overdue', value: (r) => r.metrics.overdue },
    { label: 'On-time rate', value: (r) => r.metrics.onTimeRate === null ? '' : Math.round(r.metrics.onTimeRate * 100) }, { label: 'Avg completion days', value: (r) => r.metrics.avgCompletionDays === null ? '' : Math.round(r.metrics.avgCompletionDays * 10) / 10 },
    { label: 'Avg quality (1-5)', value: (r) => r.metrics.quality === null ? '' : Math.round(r.metrics.quality * 10) / 10 }, { label: 'Reviewed items', value: (r) => r.metrics.ratedCount },
    { label: 'Verified rate', value: (r) => r.metrics.verifiedRate === null ? '' : Math.round(r.metrics.verifiedRate * 100) }, { label: 'Score', value: (r) => r.metrics.score ?? '' },
  ]));

  const delta = (cur: Metrics, p?: Metrics) => (p && cur.score !== null && p.score !== null ? `${cur.score - p.score >= 0 ? '+' : ''}${Math.round((cur.score - p.score) * 10) / 10} vs ${prev.label}` : `no ${prev.label} score to compare`);
  const years = [...new Set([Number(today.slice(0, 4)), Number(today.slice(0, 4)) - 1, ...(tasks.data ?? []).map((t) => Number(t.created_at.slice(0, 4)))])].sort((a, b) => b - a);

  return (
    <div>
      <PageHeader icon="Trophy" title="Performance" subtitle="Scores are calculated from recorded tasks: completion dates, due dates, reviewer ratings and verification."
        actions={<button className="btn-ghost" onClick={exportCsv} disabled={!people.length}><Icon name="Download" size={16} />Export employees CSV</button>} />

      <div className="panel mb-4 flex flex-wrap items-center gap-2 p-3" role="group" aria-label="Period and filters">
        <select className="input !w-auto" aria-label="Period type" value={kind} onChange={(e) => setKind(e.target.value as Kind)}>
          <option value="month">Month</option><option value="quarter">Quarter</option><option value="year">Year</option><option value="last3">Last 3 completed months</option>
        </select>
        {kind === 'month' && <input type="month" className="input !w-auto" aria-label="Month" value={month} max={today.slice(0, 7)} onChange={(e) => e.target.value && setMonth(e.target.value)} />}
        {kind === 'quarter' && <select className="input !w-auto" aria-label="Quarter" value={quarter} onChange={(e) => setQuarter(Number(e.target.value))}>{[0, 1, 2, 3].map((q) => <option key={q} value={q}>Q{q + 1}</option>)}</select>}
        {(kind === 'quarter' || kind === 'year') && <select className="input !w-auto" aria-label="Year" value={year} onChange={(e) => setYear(Number(e.target.value))}>{years.map((y) => <option key={y}>{y}</option>)}</select>}
        <select className="input !w-auto" aria-label="Team" value={team} onChange={(e) => setTeam(e.target.value as '' | WorkTeam)}><option value="">All teams</option>{TEAMS.map((t) => <option key={t} value={t}>{cap(t)}</option>)}</select>
        <select className="input !w-auto" aria-label="Client" value={client} onChange={(e) => setClient(e.target.value)}><option value="">All clients</option>{lk.clients.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
        <span className="ml-auto text-xs text-muted">Period: <b className="text-ink">{period.label}</b> ({period.from} → {period.to}){isPartial && ' · month-to-date: not complete yet'}</span>
      </div>

      <div className="mb-4 grid gap-4 md:grid-cols-3">
        <Highlight icon="Trophy" title={`Best team · ${period.label}`} name={bestTeam ? cap(bestTeam.key) : undefined} sub={bestTeam ? `Score ${bestTeam.metrics.score} · ${bestTeam.metrics.completed} completed` : undefined} empty="Not enough completed work in this period." />
        <Highlight icon="Medal" title={`Best employee · ${period.label}`} name={bestPerson ? lk.user(bestPerson.key) : undefined} sub={bestPerson ? `Score ${bestPerson.metrics.score} · ${cap(lk.userById(bestPerson.key)?.team ?? '')}` : undefined} empty="Not enough completed work in this period." />
        <Highlight icon="Award" title={`Best over 3 months · ${last3.label}`} name={bestThree ? lk.user(bestThree.key) : undefined} sub={bestThree ? `Score ${bestThree.metrics.score} · ${bestThree.metrics.completed} completed (${bestThree.metrics.verifiedCount} verified)` : undefined} empty="Not enough completed work in the last 3 completed months." />
      </div>

      <Reveal className="panel mb-4 overflow-hidden">
        <div className="border-b border-line/10 px-4 py-3"><h2 className="font-bold">Team performance · {period.label}</h2></div>
        <div className="overflow-x-auto"><table className="w-full min-w-[720px]"><thead className="bg-surface2/80"><tr>{['Team', 'Assigned', 'Completed', 'Pending', 'Overdue', 'On-time', 'Avg days', 'Score', `Change`].map((h) => <th key={h} className="th">{h}</th>)}</tr></thead>
          <tbody>{TEAMS.map((t) => { const r = teamRank.find((x) => x.key === t); const m = r?.metrics; return (
            <tr key={t} className="border-t border-line/10"><td className="td font-semibold">{cap(t)}</td>
              <td className="td">{m?.assigned ?? 0}</td><td className="td">{m?.completed ?? 0}</td><td className="td">{m?.pending ?? 0}</td><td className="td">{m?.overdue ?? 0}</td>
              <td className="td">{pctText(m?.onTimeRate ?? null)}</td><td className="td">{num1(m?.avgCompletionDays ?? null)}</td>
              <td className="td font-bold tabular-nums">{m?.score ?? <span className="font-normal text-muted">too few</span>}</td>
              <td className="td text-xs text-muted">{m ? delta(m, teamPrev.find((x) => x.key === t)?.metrics) : '—'}</td></tr>); })}</tbody></table></div>
      </Reveal>

      <div className="mb-4 grid gap-4 lg:grid-cols-3">
        <ChartCard title="Completed per month by team" subtitle="Last 6 calendar months" className="lg:col-span-2"><BarsChart data={trendTeams} series={TEAMS.map((t, i) => ({ key: t, name: cap(t), color: CH[i] }))} /></ChartCard>
        <ChartCard title="Open workload by employee" subtitle="Pending items assigned"><DonutChart data={workload.filter((x) => x.value > 0)} center={<div><div className="text-2xl font-extrabold">{workload.reduce((a, b) => a + b.value, 0)}</div><div className="text-xs text-muted">open</div></div>} /></ChartCard>
      </div>

      <Reveal className="mb-4">
        <div className="mb-2 flex items-center justify-between"><h2 className="font-bold">Employee performance · {period.label}</h2><span className="text-xs text-muted">Click a name for their history</span></div>
        {people.length === 0 ? <div className="panel"><EmptyState title="No employee data" message="No assigned tasks match these filters." /></div> : <DataTable rows={people} columns={personCols} rowKey={(r) => r.key} caption="Employee performance" pageSize={10} defaultSort={{ key: 'score', dir: 'desc' }} />}
      </Reveal>

      {sel && (
        <div className="mb-4 grid gap-4 lg:grid-cols-2">
          <ChartCard title={`${lk.user(sel)} · monthly score history`} subtitle="0 means too few completed items to be scored that month (not a real zero)">
            <LinesChart data={history} series={[{ key: 'score', name: 'Score', color: CH[0] }]} area />
          </ChartCard>
          <ChartCard title={`${lk.user(sel)} · completed and reviewed`} subtitle="Last 6 completed months">
            <BarsChart data={histRaw.map((m, i) => ({ name: histPeriods[i].label.split(' ')[0], completed: m.completed, verified: m.verifiedCount, reviewed: m.ratedCount }))} series={[{ key: 'completed', name: 'Completed', color: CH[0] }, { key: 'verified', name: 'Verified', color: CH[1] }, { key: 'reviewed', name: 'Reviewed', color: CH[2] }]} />
          </ChartCard>
        </div>
      )}

      <Reveal className="mb-4 panel p-4">
        <h2 className="mb-1 font-bold">Three-month ranking · {last3.label}</h2>
        <p className="mb-3 text-xs text-muted">The three most recent completed calendar months (the current month is excluded). Work in the whole window is pooled, then scored with the same formula.</p>
        <ol className="space-y-1.5">
          {threeMonth.slice(0, 8).map((r, i) => (
            <li key={r.key} className="flex items-center gap-3 rounded-xl px-3 py-2 odd:bg-surface2/60">
              <span className="grid h-7 w-7 place-items-center rounded-full bg-primary/15 text-sm font-bold text-primary dark:text-primary-200">{r.metrics.eligible ? i + 1 : '–'}</span>
              <UserAvatar name={lk.user(r.key)} size={28} /><span className="font-semibold">{lk.user(r.key)}</span><span className="text-xs capitalize text-muted">{lk.userById(r.key)?.team}</span>
              <span className="ml-auto text-sm tabular-nums">{r.metrics.score === null ? <span className="text-muted">too few completed items</span> : <><b>{r.metrics.score}</b> <span className="text-muted">· {r.metrics.completed} done · {pctText(r.metrics.onTimeRate)} on time</span></>}</span>
            </li>
          ))}
        </ol>
      </Reveal>

      <Reveal className="panel p-4">
        <h2 className="mb-1 font-bold">How scores are calculated</h2>
        <ul className="mb-4 list-disc space-y-1 pl-5 text-sm text-muted">
          <li><b className="text-ink">On-time</b>: completed on or before the due date, out of everything completed plus any open work already past due. Open overdue work counts as a miss.</li>
          <li><b className="text-ink">Quality</b>: average reviewer rating (1–5) on rated work. Unrated work is ignored, never scored as zero, and its weight is shared among the other factors.</li>
          <li><b className="text-ink">Verified</b>: completions approved by a reviewer. A completion with no reviewer, or not yet approved, is self-reported and not verified.</li>
          <li><b className="text-ink">Priority</b>: the average priority of completed work (Low 0.25, Medium 0.5, High 0.75, Urgent 1), so volume alone cannot win.</li>
          <li>People need at least {w.minCompleted} completed items in the period to be ranked.</li>
        </ul>
        <WeightsEditor weights={w} onSave={(v) => settings.save.mutate(v)} saving={settings.save.isPending} canEdit={settings.canEdit} />
      </Reveal>
    </div>
  );
}
