'use client';
import { useQueryClient } from '@tanstack/react-query';
import { useEffect, useMemo, useState } from 'react';
import { Icon } from './Icon';
import { useAuth, useToast } from './providers';
import { Modal, PageHeader, Reveal } from './ui';
import { FIELD_KEY_RE, keyify, levelFor, moduleFromCustom, permKey, SLUG_RE, slugify, toPermMap } from '@/lib/custom';
import { api } from '@/lib/data';
import { DEFAULT_LAYOUT, normalizeLayout, useCustomFieldDefs, useCustomModules, useModuleDef, usePermissions, useSetting, type DashboardLayout } from '@/lib/hooks';
import { MODULES, type ModuleDef } from '@/lib/modules';
import { CUSTOM_FIELD_TYPES, PERM_LEVELS, type CustomFieldDef, type CustomFieldSpec, type CustomFieldType, type CustomModule, type PermLevel, type Profile, type WorkTeam } from '@/lib/types';
import { cn } from '@/lib/utils';

const TEAMS: WorkTeam[] = ['development', 'marketing', 'creative'];
const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);
const ICONS = ['ClipboardList', 'Layers', 'FileText', 'Users', 'Building2', 'Wrench', 'Globe', 'Mail', 'Newspaper', 'Star', 'Target', 'Handshake', 'Lightbulb', 'Palette', 'Video', 'KeyRound'];
const TYPE_LABEL: Record<CustomFieldType, string> = { text: 'Text', longtext: 'Long text', number: 'Number', date: 'Date', url: 'URL', select: 'Dropdown', bool: 'Checkbox', file: 'File', client: 'Client (relation)', user: 'Employee (relation)' };

const TABS = [
  ['modules', 'Modules & dashboards'], ['fields', 'Custom fields'], ['registers', 'Custom registers'], ['columns', 'Table columns'], ['access', 'Team access'], ['cards', 'Dashboard cards'], ['lists', 'Lists & saved views'], ['effects', 'Animations'],
] as const;
type Tab = (typeof TABS)[number][0];

const allBuiltIn = MODULES.filter((m) => !m.readonly || m.key === 'user-log');

/** /admin/customization — configure the workspace without touching source code. Authorization and audit controls cannot be customised away. */
export function StudioPage() {
  const [tab, setTab] = useState<Tab>('modules');
  const customModules = useCustomModules();
  const mods = useMemo(() => [...allBuiltIn, ...(customModules.data ?? []).map(moduleFromCustom)], [customModules.data]);
  return (
    <div>
      <PageHeader icon="SlidersHorizontal" title="Customization Studio" subtitle="Add fields and registers, choose what each team sees, build dashboard cards. Every change is written to the audit log. Permissions and audit trails always stay enforced by the database." />
      <div className="mb-4 flex gap-1 overflow-x-auto rounded-2xl bg-surface2 p-1" role="tablist" aria-label="Studio sections">
        {TABS.map(([k, l]) => <button key={k} role="tab" aria-selected={tab === k} onClick={() => setTab(k)} className={cn('whitespace-nowrap rounded-xl px-3.5 py-2 text-sm font-semibold transition', tab === k ? 'bg-gradient-to-r from-primary to-secondary-500 text-white shadow' : 'text-muted hover:text-ink')}>{l}</button>)}
      </div>
      <Reveal key={tab}>
        {tab === 'modules' && <ModulesTab mods={mods} />}
        {tab === 'fields' && <FieldsTab />}
        {tab === 'registers' && <RegistersTab />}
        {tab === 'columns' && <ColumnsTab mods={mods} />}
        {tab === 'access' && <AccessTab mods={mods} />}
        {tab === 'cards' && <CardsTab mods={mods} />}
        {tab === 'lists' && <ListsTab mods={mods} />}
        {tab === 'effects' && <EffectsTab />}
      </Reveal>
    </div>
  );
}

/* ───────── Modules & dashboards: hide, reorder, archive ───────── */
function ModulesTab({ mods }: { mods: ModuleDef[] }) {
  const layout = useSetting<DashboardLayout>('dashboard_layout', DEFAULT_LAYOUT, normalizeLayout);
  const custom = useCustomModules();
  const { user } = useAuth() as { user: Profile };
  const qc = useQueryClient();
  const toast = useToast();
  const [draft, setDraft] = useState(layout.value);
  useEffect(() => setDraft(layout.value), [layout.value]);
  const orderOf = (team: WorkTeam) => {
    const list = mods.filter((m) => m.team === team && !m.group && !m.readonly);
    const ord = draft.order[team] ?? [];
    return [...list].sort((a, b) => (ord.indexOf(a.key) < 0 ? 1000 + list.indexOf(a) : ord.indexOf(a.key)) - (ord.indexOf(b.key) < 0 ? 1000 + list.indexOf(b) : ord.indexOf(b.key)));
  };
  const move = (team: WorkTeam, key: string, dir: -1 | 1) => {
    const keys = orderOf(team).map((m) => m.key);
    const i = keys.indexOf(key), j = i + dir;
    if (j < 0 || j >= keys.length) return;
    [keys[i], keys[j]] = [keys[j], keys[i]];
    setDraft({ ...draft, order: { ...draft.order, [team]: keys } });
  };
  const toggle = (key: string) => setDraft({ ...draft, hidden: draft.hidden.includes(key) ? draft.hidden.filter((k) => k !== key) : [...draft.hidden, key] });
  const archive = async (cm: CustomModule) => {
    try { await api.customModules.save({ ...cm, archived: !cm.archived }, user); await qc.invalidateQueries({ queryKey: ['custom-modules'] }); toast.success(cm.archived ? 'Register restored.' : 'Register archived.'); } catch (e) { toast.error((e as Error).message); }
  };
  const dirty = JSON.stringify(draft) !== JSON.stringify(layout.value);
  return (
    <div className="space-y-4">
      <div className="grid gap-4 lg:grid-cols-3">
        {TEAMS.map((t) => (
          <section key={t} className="panel p-4" aria-label={`${cap(t)} modules`}>
            <h2 className="mb-2 font-bold">{cap(t)}</h2>
            <ul className="space-y-1">
              {orderOf(t).map((m, i, arr) => (
                <li key={m.key} className="flex items-center gap-2 rounded-lg px-2 py-1.5 odd:bg-surface2/60">
                  <Icon name={m.icon} size={15} className="text-primary" />
                  <span className={cn('min-w-0 flex-1 truncate text-sm', draft.hidden.includes(m.key) && 'text-muted line-through')}>{m.nav}{m.customId && <span className="ml-1 rounded bg-secondary/25 px-1 text-[10px] font-bold uppercase">custom</span>}</span>
                  <button className="btn-ghost !p-1" aria-label={`Move ${m.nav} up`} disabled={i === 0} onClick={() => move(t, m.key, -1)}><Icon name="ChevronUp" size={14} /></button>
                  <button className="btn-ghost !p-1" aria-label={`Move ${m.nav} down`} disabled={i === arr.length - 1} onClick={() => move(t, m.key, 1)}><Icon name="ChevronDown" size={14} /></button>
                  <label className="flex cursor-pointer items-center gap-1 text-xs"><input type="checkbox" checked={!draft.hidden.includes(m.key)} onChange={() => toggle(m.key)} aria-label={`Show ${m.nav}`} />Show</label>
                </li>
              ))}
            </ul>
          </section>
        ))}
      </div>
      <div className="flex flex-wrap items-center gap-3">
        <button className="btn-primary" disabled={!dirty || layout.save.isPending} onClick={() => layout.save.mutate(draft)}>Save layout</button>
        <button className="btn-ghost" disabled={!dirty} onClick={() => setDraft(layout.value)}>Discard changes</button>
        <span className="text-xs text-muted">Hiding a module removes it from the sidebar and dashboard. It does not delete data or change who may open it (see Team access).</span>
      </div>
      {(custom.data ?? []).length > 0 && (
        <section className="panel p-4"><h2 className="mb-2 font-bold">Custom registers</h2>
          <ul className="divide-y divide-line/10">{(custom.data ?? []).map((cm) => <li key={cm.id} className="flex items-center gap-3 py-2 text-sm"><Icon name={cm.icon} size={16} className="text-primary" /><span className="font-semibold">{cm.title}</span><span className="text-xs text-muted">{cap(cm.team)} · /{cm.team}/{cm.slug}</span>{cm.archived && <span className="rounded bg-line/15 px-1.5 text-xs">archived</span>}<button className="btn-ghost ml-auto !py-1 text-xs" onClick={() => void archive(cm)}>{cm.archived ? 'Restore' : 'Archive'}</button></li>)}</ul></section>
      )}
    </div>
  );
}

/* ───────── shared field editor ───────── */
function FieldEditor({ spec, onChange, onRemove, fixedKey }: { spec: CustomFieldSpec; onChange: (s: CustomFieldSpec) => void; onRemove?: () => void; fixedKey?: boolean }) {
  return (
    <div className="grid gap-2 rounded-xl border border-line/15 p-3 sm:grid-cols-12">
      <label className="sm:col-span-4"><span className="label">Label</span><input className="input" value={spec.label} maxLength={60} onChange={(e) => onChange({ ...spec, label: e.target.value, key: fixedKey ? spec.key : keyify(e.target.value) })} /></label>
      <label className="sm:col-span-3"><span className="label">Type</span><select className="input" value={spec.type} onChange={(e) => onChange({ ...spec, type: e.target.value as CustomFieldType })}>{CUSTOM_FIELD_TYPES.map((t) => <option key={t} value={t}>{TYPE_LABEL[t]}</option>)}</select></label>
      <label className="sm:col-span-3"><span className="label">Key</span><input className="input" value={spec.key} disabled={fixedKey} onChange={(e) => onChange({ ...spec, key: e.target.value })} /></label>
      <label className="flex items-end gap-2 pb-2 text-sm sm:col-span-1"><input type="checkbox" checked={!!spec.required} onChange={(e) => onChange({ ...spec, required: e.target.checked })} />Required</label>
      {onRemove && <div className="flex items-end sm:col-span-1"><button className="btn-ghost !p-2" onClick={onRemove} aria-label={`Remove field ${spec.label}`}><Icon name="Trash2" size={15} /></button></div>}
      {spec.type === 'select' && <label className="sm:col-span-12"><span className="label">Options (one per line)</span><textarea className="input" rows={3} value={(spec.options ?? []).join('\n')} onChange={(e) => onChange({ ...spec, options: e.target.value.split('\n').map((x) => x.trim()).filter(Boolean) })} /></label>}
    </div>
  );
}
const validateSpec = (s: CustomFieldSpec) => (!s.label.trim() ? 'Every field needs a label.' : !FIELD_KEY_RE.test(s.key) ? `"${s.key}" is not a valid key: use lowercase letters, numbers and underscores, starting with a letter.` : s.type === 'select' && !(s.options ?? []).length ? `Add options for "${s.label}".` : null);

/* ───────── Custom fields on built-in modules ───────── */
function FieldsTab() {
  const defs = useCustomFieldDefs();
  const qc = useQueryClient();
  const toast = useToast();
  const { user } = useAuth() as { user: Profile };
  const [moduleKey, setModuleKey] = useState(allBuiltIn[0].key);
  const [draft, setDraft] = useState<CustomFieldSpec | null>(null);
  const mine = (defs.data ?? []).filter((d) => d.module_key === moduleKey);
  const refresh = () => qc.invalidateQueries({ queryKey: ['custom-fields'] });
  const add = async () => {
    if (!draft) return;
    const err = validateSpec(draft);
    if (err) return toast.error(err);
    try {
      await api.customFields.save({ ...draft, module_key: moduleKey, options: draft.options ?? [], required: !!draft.required, position: mine.length, archived: false }, user);
      setDraft(null); await refresh(); toast.success('Field added. It now appears in the form, details and CSV export.');
    } catch (e) { toast.error((e as Error).message); }
  };
  const patch = async (d: CustomFieldDef, p: Partial<CustomFieldDef>) => { try { await api.customFields.save({ ...d, ...p }, user); await refresh(); } catch (e) { toast.error((e as Error).message); } };
  const remove = async (d: CustomFieldDef) => { try { await api.customFields.remove(d.id, user); await refresh(); toast.success('Field removed. Values already entered stay stored with each record.'); } catch (e) { toast.error((e as Error).message); } };
  return (
    <div className="panel p-4">
      <div className="mb-3 flex flex-wrap items-center gap-3">
        <label className="flex items-center gap-2 text-sm font-semibold">Module<select className="input !w-72" value={moduleKey} onChange={(e) => { setModuleKey(e.target.value); setDraft(null); }}>{TEAMS.map((t) => <optgroup key={t} label={cap(t)}>{allBuiltIn.filter((m) => m.team === t).map((m) => <option key={m.key} value={m.key}>{m.title}</option>)}</optgroup>)}</select></label>
        <button className="btn-primary" onClick={() => setDraft({ key: '', label: '', type: 'text' })}><Icon name="Plus" size={16} />Add field</button>
      </div>
      {draft && (
        <div className="mb-4 space-y-2"><FieldEditor spec={draft} onChange={setDraft} /><div className="flex gap-2"><button className="btn-primary" onClick={() => void add()}>Save field</button><button className="btn-ghost" onClick={() => setDraft(null)}>Cancel</button></div></div>
      )}
      {mine.length === 0 ? <p className="text-sm text-muted">No custom fields on this module yet.</p> : (
        <ul className="divide-y divide-line/10">
          {mine.map((d) => (
            <li key={d.id} className="flex flex-wrap items-center gap-3 py-2 text-sm">
              <span className={cn('font-semibold', d.archived && 'text-muted line-through')}>{d.label}</span>
              <span className="rounded bg-primary/10 px-1.5 text-xs">{TYPE_LABEL[d.type]}</span><code className="text-xs text-muted">cf_{d.key}</code>{d.required && <span className="text-xs text-muted">required</span>}
              <button className="btn-ghost ml-auto !py-1 text-xs" onClick={() => void patch(d, { archived: !d.archived })}>{d.archived ? 'Restore' : 'Archive'}</button>
              <button className="btn-ghost !py-1 text-xs" onClick={() => void remove(d)}>Delete</button>
            </li>
          ))}
        </ul>
      )}
      <p className="mt-3 text-xs text-muted">Archiving hides a field from forms but keeps its data. Required custom fields apply to new and edited records.</p>
    </div>
  );
}

/* ───────── Custom registers (custom modules) ───────── */
const BLANK_MODULE = { title: '', slug: '', team: 'development' as WorkTeam, icon: 'ClipboardList', blurb: '', fields: [{ key: 'name', label: 'Name', type: 'text' as CustomFieldType, required: true }] as CustomFieldSpec[], archived: false };
function RegistersTab() {
  const custom = useCustomModules();
  const qc = useQueryClient();
  const toast = useToast();
  const { user } = useAuth() as { user: Profile };
  const [edit, setEdit] = useState<(typeof BLANK_MODULE & { id?: string }) | null>(null);
  const [busy, setBusy] = useState(false);
  const save = async () => {
    if (!edit) return;
    if (edit.title.trim().length < 2) return toast.error('Give the register a title.');
    if (!SLUG_RE.test(edit.slug)) return toast.error('The URL name must be 2–39 lowercase letters, numbers or dashes.');
    if (MODULES.some((m) => m.team === edit.team && m.slug === edit.slug)) return toast.error('A built-in page already uses this URL name for that team.');
    if (!edit.fields.length) return toast.error('Add at least one field.');
    const keys = new Set<string>();
    for (const f of edit.fields) { const err = validateSpec(f); if (err) return toast.error(err); if (keys.has(f.key) || f.key === 'client_id') return toast.error(`Field key "${f.key}" is used twice or reserved.`); keys.add(f.key); }
    setBusy(true);
    try { await api.customModules.save({ ...edit, title: edit.title.trim() }, user); await qc.invalidateQueries({ queryKey: ['custom-modules'] }); setEdit(null); toast.success('Register saved. It now appears in the sidebar for that team.'); }
    catch (e) { toast.error((e as Error).message); } finally { setBusy(false); }
  };
  return (
    <div className="space-y-4">
      <div className="panel p-4">
        <div className="mb-3 flex items-center justify-between"><h2 className="font-bold">Custom registers</h2><button className="btn-primary" onClick={() => setEdit({ ...BLANK_MODULE })}><Icon name="Plus" size={16} />New register</button></div>
        <p className="mb-3 text-sm text-muted">A register is a list of records you design yourself (for example a vendor list or a campaign checklist). It gets a page, search, filters, CSV export and the same permissions as any other module.</p>
        {(custom.data ?? []).length === 0 ? <p className="text-sm text-muted">No custom registers yet.</p> : (
          <ul className="divide-y divide-line/10">{(custom.data ?? []).map((cm) => <li key={cm.id} className="flex items-center gap-3 py-2 text-sm"><Icon name={cm.icon} size={16} className="text-primary" /><span className="font-semibold">{cm.title}</span><span className="text-xs text-muted">{cap(cm.team)} · {cm.fields.length} fields</span>{cm.archived && <span className="rounded bg-line/15 px-1.5 text-xs">archived</span>}<button className="btn-ghost ml-auto !py-1 text-xs" onClick={() => setEdit({ ...cm })}>Edit</button></li>)}</ul>
        )}
      </div>
      <Modal open={!!edit} onClose={() => setEdit(null)} title={edit?.id ? 'Edit register' : 'New register'} size="xl" footer={<><button className="btn-ghost" onClick={() => setEdit(null)}>Cancel</button><button className="btn-primary" disabled={busy} onClick={() => void save()}>{busy && <Icon name="Loader2" className="animate-spin" size={16} />}Save register</button></>}>
        {edit && (
          <div className="space-y-3">
            <div className="grid gap-3 sm:grid-cols-2">
              <label><span className="label">Title</span><input className="input" value={edit.title} maxLength={80} onChange={(e) => setEdit({ ...edit, title: e.target.value, slug: edit.id ? edit.slug : slugify(e.target.value) })} /></label>
              <label><span className="label">URL name</span><input className="input" value={edit.slug} disabled={!!edit.id} onChange={(e) => setEdit({ ...edit, slug: e.target.value })} /></label>
              <label><span className="label">Team</span><select className="input" value={edit.team} disabled={!!edit.id} onChange={(e) => setEdit({ ...edit, team: e.target.value as WorkTeam })}>{TEAMS.map((t) => <option key={t} value={t}>{cap(t)}</option>)}</select></label>
              <label><span className="label">Icon</span><select className="input" value={edit.icon} onChange={(e) => setEdit({ ...edit, icon: e.target.value })}>{ICONS.map((i) => <option key={i}>{i}</option>)}</select></label>
              <label className="sm:col-span-2"><span className="label">Description</span><input className="input" value={edit.blurb} maxLength={200} onChange={(e) => setEdit({ ...edit, blurb: e.target.value })} /></label>
              {edit.id && <label className="flex items-center gap-2 text-sm sm:col-span-2"><input type="checkbox" checked={edit.archived} onChange={(e) => setEdit({ ...edit, archived: e.target.checked })} />Archived (hidden everywhere, data kept)</label>}
            </div>
            <h3 className="font-bold">Fields</h3>
            {edit.fields.map((f, i) => <FieldEditor key={i} spec={f} fixedKey={!!edit.id && i < (custom.data?.find((x) => x.id === edit.id)?.fields.length ?? 0)} onChange={(s) => setEdit({ ...edit, fields: edit.fields.map((x, j) => (j === i ? s : x)) })} onRemove={edit.fields.length > 1 && !edit.id ? () => setEdit({ ...edit, fields: edit.fields.filter((_, j) => j !== i) }) : undefined} />)}
            {edit.fields.length < 40 && <button className="btn-ghost" onClick={() => setEdit({ ...edit, fields: [...edit.fields, { key: '', label: '', type: 'text' }] })}><Icon name="Plus" size={16} />Add field</button>}
            {edit.id && <p className="text-xs text-muted">Existing fields keep their key and cannot be removed once records exist; you can add more fields at any time.</p>}
            <p className="text-xs text-muted">Every register also has a Client field, and the database validates required fields, numbers, dates, links and dropdown options on every save.</p>
          </div>
        )}
      </Modal>
    </div>
  );
}

/* ───────── Table columns ───────── */
function ColumnPicker({ base }: { base: ModuleDef }) {
  const m = useModuleDef(base);
  const cols = useSetting<Record<string, string[]>>('table_columns', {});
  const saved = cols.value[m.key];
  const [sel, setSel] = useState<string[]>([]);
  useEffect(() => setSel(saved ?? m.list ?? []), [saved, m.list]);
  const all = [...m.fields.filter((f) => f.type !== 'longtext' || true).map((f) => ({ key: f.key, label: f.label })), ...m.derived.map((d) => ({ key: d.key, label: `${d.label} (calculated)` }))];
  const toggle = (k: string) => setSel((s) => (s.includes(k) ? s.filter((x) => x !== k) : [...s, k]));
  const move = (k: string, dir: -1 | 1) => setSel((s) => { const i = s.indexOf(k), j = i + dir; if (i < 0 || j < 0 || j >= s.length) return s; const n = [...s]; [n[i], n[j]] = [n[j], n[i]]; return n; });
  return (
    <div>
      <div className="grid gap-1 sm:grid-cols-2 lg:grid-cols-3">
        {all.map((f) => <label key={f.key} className="flex cursor-pointer items-center gap-2 rounded-lg px-2 py-1 text-sm hover:bg-primary/5"><input type="checkbox" checked={sel.includes(f.key)} onChange={() => toggle(f.key)} />{f.label}</label>)}
      </div>
      <div className="mt-3"><span className="label">Column order</span>
        <ol className="flex flex-wrap gap-1.5">{sel.map((k) => <li key={k} className="inline-flex items-center gap-1 rounded-full bg-primary/10 px-2 py-0.5 text-xs font-semibold"><button aria-label={`Move ${k} left`} onClick={() => move(k, -1)}><Icon name="ChevronLeft" size={12} /></button>{all.find((f) => f.key === k)?.label ?? k}<button aria-label={`Move ${k} right`} onClick={() => move(k, 1)}><Icon name="ChevronRight" size={12} /></button></li>)}</ol></div>
      <div className="mt-3 flex gap-2">
        <button className="btn-primary" disabled={!sel.length || cols.save.isPending} onClick={() => cols.save.mutate({ ...cols.value, [m.key]: sel })}>Save columns</button>
        <button className="btn-ghost" disabled={!saved} onClick={() => { const { [m.key]: _drop, ...rest } = cols.value; void _drop; cols.save.mutate(rest); }}>Reset to default</button>
      </div>
    </div>
  );
}
function ColumnsTab({ mods }: { mods: ModuleDef[] }) {
  const [key, setKey] = useState(mods[0].key);
  const m = mods.find((x) => x.key === key) ?? mods[0];
  return (
    <div className="panel p-4">
      <label className="mb-3 flex items-center gap-2 text-sm font-semibold">Module<select className="input !w-72" value={m.key} onChange={(e) => setKey(e.target.value)}>{mods.filter((x) => !x.readonly && !x.group).map((x) => <option key={x.key} value={x.key}>{x.title}</option>)}</select></label>
      <ColumnPicker key={m.key} base={m} />
    </div>
  );
}

/* ───────── Team access matrix ───────── */
function AccessTab({ mods }: { mods: ModuleDef[] }) {
  const perms = usePermissions();
  const qc = useQueryClient();
  const toast = useToast();
  const { user } = useAuth() as { user: Profile };
  const pm = toPermMap(perms.data ?? []);
  const set = async (team: WorkTeam, m: ModuleDef, level: PermLevel) => {
    const def: PermLevel = m.team === team ? 'write' : 'none';
    try { await api.permissions.set(team, m.key, level === def ? null : level, user); await qc.invalidateQueries({ queryKey: ['permissions'] }); toast.success(`${cap(team)} access to ${m.title}: ${level}.`); } catch (e) { toast.error((e as Error).message); }
  };
  const rows = mods.filter((m) => !m.group && (!m.readonly || m.key === 'user-log'));
  return (
    <div className="panel overflow-hidden">
      <div className="border-b border-line/10 p-4"><h2 className="font-bold">Who can open what</h2>
        <p className="text-sm text-muted">By default a team has full access to its own modules and none to the others. Grant another team read-only or edit access for cross-team collaboration. Admins always have full access. Rules apply on the server and in the database, not just in the menu.</p></div>
      <div className="max-h-[65vh] overflow-auto"><table className="w-full min-w-[560px] text-sm"><thead className="sticky top-0 bg-surface2/95"><tr><th className="th">Module</th><th className="th">Owner</th>{TEAMS.map((t) => <th key={t} className="th">{cap(t)}</th>)}</tr></thead>
        <tbody>{rows.map((m) => (
          <tr key={m.key} className="border-t border-line/10"><td className="td font-semibold">{m.title}</td><td className="td text-muted">{cap(m.team)}</td>
            {TEAMS.map((t) => <td key={t} className="td"><select className={cn('input !py-1', pm[permKey(t, m.key)] && 'ring-1 ring-primary/50')} aria-label={`${cap(t)} access to ${m.title}`} value={levelFor(t, m, pm)} onChange={(e) => void set(t, m, e.target.value as PermLevel)}>{PERM_LEVELS.map((l) => <option key={l} value={l}>{l === 'none' ? 'No access' : l === 'read' ? 'Read only' : 'Read & edit'}</option>)}</select></td>)}</tr>
        ))}</tbody></table></div>
    </div>
  );
}

/* ───────── Dashboard cards ───────── */
export interface CustomCard { id: string; title: string; scope: 'all' | 'admin' | WorkTeam; moduleKey: string; metric: 'count' | 'open' | 'overdue' | 'completed' | 'sum' | 'avg'; field?: string; icon: string }
function CardsTab({ mods }: { mods: ModuleDef[] }) {
  const cards = useSetting<CustomCard[]>('custom_cards', [], (r) => (Array.isArray(r) ? (r as CustomCard[]) : []));
  const [draft, setDraft] = useState<CustomCard | null>(null);
  const m = mods.find((x) => x.key === draft?.moduleKey);
  const numeric = m?.fields.filter((f) => f.type === 'number') ?? [];
  const add = () => {
    if (!draft) return;
    if (!draft.title.trim()) return;
    if ((draft.metric === 'sum' || draft.metric === 'avg') && !draft.field) return;
    cards.save.mutate([...cards.value, { ...draft, title: draft.title.trim(), id: crypto.randomUUID() }], { onSuccess: () => setDraft(null) });
  };
  return (
    <div className="panel p-4">
      <div className="mb-3 flex items-center justify-between"><h2 className="font-bold">Custom dashboard cards</h2><button className="btn-primary" onClick={() => setDraft({ id: '', title: '', scope: 'all', moduleKey: mods[0].key, metric: 'count', icon: 'ChartColumn' })}><Icon name="Plus" size={16} />New card</button></div>
      <p className="mb-3 text-sm text-muted">A card shows one number calculated from a module&apos;s records, on the dashboards you choose. Numbers are always calculated from recorded data.</p>
      {draft && (
        <div className="mb-4 grid gap-3 rounded-xl border border-line/15 p-3 sm:grid-cols-2 lg:grid-cols-3">
          <label className="lg:col-span-2"><span className="label">Title</span><input className="input" maxLength={40} value={draft.title} onChange={(e) => setDraft({ ...draft, title: e.target.value })} /></label>
          <label><span className="label">Show on</span><select className="input" value={draft.scope} onChange={(e) => setDraft({ ...draft, scope: e.target.value as CustomCard['scope'] })}><option value="all">All dashboards</option><option value="admin">Admin dashboard</option>{TEAMS.map((t) => <option key={t} value={t}>{cap(t)} dashboard</option>)}</select></label>
          <label><span className="label">Module</span><select className="input" value={draft.moduleKey} onChange={(e) => setDraft({ ...draft, moduleKey: e.target.value, field: undefined })}>{mods.filter((x) => !x.readonly && !x.group).map((x) => <option key={x.key} value={x.key}>{x.title}</option>)}</select></label>
          <label><span className="label">Metric</span><select className="input" value={draft.metric} onChange={(e) => setDraft({ ...draft, metric: e.target.value as CustomCard['metric'] })}><option value="count">All records</option><option value="open">Open records</option><option value="overdue">Overdue records</option><option value="completed">Completed records</option><option value="sum">Sum of a number field</option><option value="avg">Average of a number field</option></select></label>
          {(draft.metric === 'sum' || draft.metric === 'avg') && <label><span className="label">Number field</span><select className="input" value={draft.field ?? ''} onChange={(e) => setDraft({ ...draft, field: e.target.value })}><option value="">Choose…</option>{numeric.map((f) => <option key={f.key} value={f.key}>{f.label}</option>)}</select></label>}
          <div className="flex items-end gap-2 sm:col-span-2 lg:col-span-3"><button className="btn-primary" onClick={add}>Save card</button><button className="btn-ghost" onClick={() => setDraft(null)}>Cancel</button></div>
        </div>
      )}
      {cards.value.length === 0 ? <p className="text-sm text-muted">No custom cards yet.</p> : (
        <ul className="divide-y divide-line/10">{cards.value.map((c) => <li key={c.id} className="flex flex-wrap items-center gap-3 py-2 text-sm"><span className="font-semibold">{c.title}</span><span className="text-xs text-muted">{c.metric} · {mods.find((x) => x.key === c.moduleKey)?.title ?? c.moduleKey} · {c.scope}</span><button className="btn-ghost ml-auto !py-1 text-xs" onClick={() => cards.save.mutate(cards.value.filter((x) => x.id !== c.id))}>Delete</button></li>)}</ul>
      )}
    </div>
  );
}

/* ───────── Lists, categories and saved views ───────── */
export interface SavedView { id: string; moduleKey: string; name: string; filters: Record<string, string> }
function ListsTab({ mods }: { mods: ModuleDef[] }) {
  const cats = useSetting<string[]>('work_categories', [], (r) => (Array.isArray(r) ? (r as string[]) : []));
  const views = useSetting<SavedView[]>('saved_filters', [], (r) => (Array.isArray(r) ? (r as SavedView[]) : []));
  const [text, setText] = useState('');
  useEffect(() => setText(cats.value.join('\n')), [cats.value]);
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <section className="panel p-4">
        <h2 className="mb-1 font-bold">Work categories</h2>
        <p className="mb-2 text-sm text-muted">Suggested values for every &quot;Category&quot; field (blogs, creative tasks). People can still type something else.</p>
        <textarea className="input" rows={8} aria-label="Work categories, one per line" value={text} onChange={(e) => setText(e.target.value)} />
        <button className="btn-primary mt-2" disabled={cats.save.isPending} onClick={() => cats.save.mutate([...new Set(text.split('\n').map((x) => x.trim()).filter(Boolean))].slice(0, 60))}>Save categories</button>
      </section>
      <section className="panel p-4">
        <h2 className="mb-1 font-bold">Saved views</h2>
        <p className="mb-2 text-sm text-muted">Filter combinations saved from any module page (use <b>Save view</b> above its filters). Everyone on that team can pick them.</p>
        {views.value.length === 0 ? <p className="text-sm text-muted">No saved views yet.</p> : (
          <ul className="divide-y divide-line/10">{views.value.map((v) => <li key={v.id} className="flex items-center gap-3 py-2 text-sm"><span className="font-semibold">{v.name}</span><span className="text-xs text-muted">{mods.find((m) => m.key === v.moduleKey)?.title ?? v.moduleKey}</span><button className="btn-ghost ml-auto !py-1 text-xs" onClick={() => views.save.mutate(views.value.filter((x) => x.id !== v.id))}>Delete</button></li>)}</ul>
        )}
        <div className="mt-4 rounded-xl bg-surface2 p-3 text-xs text-muted"><b className="text-ink">Statuses and priorities.</b> Task statuses (New → Completed) and priorities (Low → Urgent) are fixed because the review workflow and reports depend on them. Module-specific status lists are defined in each module.</div>
      </section>
    </div>
  );
}

/* ───────── Animations ───────── */
export const ANIMATION_KEYS: [string, string][] = [['ssl', 'SSL renewal completed'], ['backup', 'Website backup verified'], ['seo', 'SEO update completed'], ['web', 'Web requirement completed'], ['video', 'Video completed'], ['artwork', 'Artwork approved'], ['marketing', 'Marketing work completed (blog, campaign, channel)'], ['celebrate', 'Other tasks completed']];
function EffectsTab() {
  const eff = useSetting<Record<string, boolean>>('animations', {}, (r) => (r && typeof r === 'object' ? (r as Record<string, boolean>) : {}));
  return (
    <div className="panel max-w-2xl p-4">
      <h2 className="mb-1 font-bold">Success animations</h2>
      <p className="mb-3 text-sm text-muted">Each animation plays only after the server confirms the work was saved in its final state. Turn off the ones you do not want.</p>
      <ul className="divide-y divide-line/10">
        {ANIMATION_KEYS.map(([k, l]) => {
          const on = eff.value[k] !== false;
          return <li key={k} className="flex items-center justify-between gap-3 py-2.5"><span className="text-sm font-semibold">{l}</span>
            <button role="switch" aria-checked={on} aria-label={l} onClick={() => eff.save.mutate({ ...eff.value, [k]: !on })} className={cn('relative h-6 w-11 rounded-full transition', on ? 'bg-primary' : 'bg-line/25')}><span className={cn('absolute left-0.5 top-0.5 h-5 w-5 rounded-full bg-white shadow transition', on && 'translate-x-5')} /></button></li>;
        })}
      </ul>
    </div>
  );
}
