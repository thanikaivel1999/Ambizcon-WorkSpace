'use client';
import { motion, useScroll, useTransform } from 'framer-motion';
import { useRef } from 'react';
import { ProgressRing, AnimatedCounter } from './ui';
import { ThreeDCharacter, type CharacterKind } from './ThreeDCharacter';
import { TEAM_LABEL } from '@/lib/access';
import { greeting } from '@/lib/utils';

const TAGLINE: Record<CharacterKind, string> = {
  development: "Let's build something great today.",
  marketing: "Let's grow something remarkable today.",
  creative: "Let's create something unforgettable today.",
  admin: "Let's lead the team to a great day.",
};

interface Props {
  team: CharacterKind;
  name: string;
  current: number;
  completed: number;
  progress: number;
  children?: React.ReactNode;
}

/** Dashboard hero: greeting, date, live task numbers, progress ring and the floating team character. */
export function TeamHero({ team, name, current, completed, progress, children }: Props) {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start start', 'end start'] });
  const charY = useTransform(scrollYProgress, [0, 1], [0, 40]);
  const blobY = useTransform(scrollYProgress, [0, 1], [0, -30]);
  return (
    <section ref={ref} className="relative mb-6 overflow-hidden rounded-3xl bg-gradient-to-br from-primary-700 via-primary to-secondary-500 p-5 text-white shadow-lift sm:p-8" aria-label={`${TEAM_LABEL[team]} overview`}>
      <motion.div style={{ y: blobY }} aria-hidden className="pointer-events-none absolute -right-20 -top-24 h-80 w-80 rounded-full bg-white/10 blur-2xl" />
      <div aria-hidden className="pointer-events-none absolute -bottom-24 left-1/3 h-64 w-64 rounded-full bg-secondary-300/30 blur-3xl" />
      <div className="relative grid items-center gap-4 md:grid-cols-[1fr_auto]">
        <div>
          <motion.p initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="text-sm font-semibold text-white/80">
            {new Date().toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
          </motion.p>
          <motion.h1 initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.08 }} className="mt-1 text-3xl font-extrabold leading-tight sm:text-4xl">
            {greeting()}, {TEAM_LABEL[team]} {team === 'admin' ? '' : 'Team'}
          </motion.h1>
          <motion.p initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.16 }} className="mt-1 text-white/90">{TAGLINE[team]} <span className="text-white/70">Welcome back, {name.split(' ')[0]}.</span></motion.p>
          <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.24 }} className="mt-5 flex flex-wrap items-center gap-5">
            <ProgressRing value={progress} size={92} stroke={10} light label={<span className="text-white"><AnimatedCounter value={progress} suffix="%" /></span>} />
            <div className="grid grid-cols-2 gap-x-8 gap-y-1">
              <div><div className="text-3xl font-extrabold"><AnimatedCounter value={current} /></div><div className="text-xs font-semibold uppercase tracking-wide text-white/75">Current tasks</div></div>
              <div><div className="text-3xl font-extrabold"><AnimatedCounter value={completed} /></div><div className="text-xs font-semibold uppercase tracking-wide text-white/75">Completed</div></div>
            </div>
          </motion.div>
          {children && <div className="mt-5 flex flex-wrap gap-2">{children}</div>}
        </div>
        <motion.div style={{ y: charY }} className="mx-auto h-48 w-56 sm:h-64 sm:w-72 md:h-72 md:w-80">
          <ThreeDCharacter kind={team} className="h-full w-full" />
        </motion.div>
      </div>
    </section>
  );
}
