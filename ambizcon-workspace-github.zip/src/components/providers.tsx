'use client';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { AnimatePresence, motion } from 'framer-motion';
import { useRouter } from 'next/navigation';
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { CompletionProvider } from './CompletionAnimation';
import { Icon } from './Icon';
import { api, isDemo } from '@/lib/data';
import { syncLocalFile } from '@/lib/data/demo';
import type { Profile } from '@/lib/types';
import { cn, uid } from '@/lib/utils';

/* ───────── Toasts ───────── */
type ToastKind = 'success' | 'error' | 'info';
interface ToastItem { id: string; msg: string; kind: ToastKind }
interface ToastApi { success(msg: string): void; error(msg: string): void; info(msg: string): void }
const ToastCtx = createContext<ToastApi>({ success() {}, error() {}, info() {} });
export const useToast = () => useContext(ToastCtx);

function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([]);
  const push = useCallback((kind: ToastKind, msg: string) => {
    const id = uid();
    setItems((l) => [...l.slice(-3), { id, msg, kind }]);
    setTimeout(() => setItems((l) => l.filter((t) => t.id !== id)), kind === 'error' ? 6000 : 3800);
  }, []);
  const value = useMemo<ToastApi>(() => ({ success: (m) => push('success', m), error: (m) => push('error', m), info: (m) => push('info', m) }), [push]);
  return (
    <ToastCtx.Provider value={value}>
      {children}
      <div className="pointer-events-none fixed bottom-4 right-4 z-[100] flex w-[min(92vw,22rem)] flex-col gap-2" role="status" aria-live="polite">
        <AnimatePresence>
          {items.map((t) => (
            <motion.div key={t.id} layout initial={{ opacity: 0, x: 40, scale: 0.95 }} animate={{ opacity: 1, x: 0, scale: 1 }} exit={{ opacity: 0, x: 40 }} className={cn('pointer-events-auto flex items-start gap-2.5 rounded-xl p-3 text-sm font-medium shadow-lift ring-1', t.kind === 'error' ? 'bg-primary-900 text-white ring-primary-700' : 'bg-surface text-ink ring-line/25')} style={t.kind !== 'error' ? { background: 'rgb(var(--surface))' } : undefined}>
              <span className={cn('mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full text-white', t.kind === 'success' ? 'bg-secondary-500' : t.kind === 'error' ? 'bg-white/20' : 'bg-primary')}>
                <Icon name={t.kind === 'success' ? 'Check' : t.kind === 'error' ? 'AlertTriangle' : 'Info'} size={12} />
              </span>
              <span className="flex-1">{t.msg}</span>
              <button aria-label="Dismiss" className="opacity-60 hover:opacity-100" onClick={() => setItems((l) => l.filter((x) => x.id !== t.id))}><Icon name="X" size={14} /></button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </ToastCtx.Provider>
  );
}

/* ───────── Theme ───────── */
const ThemeCtx = createContext<{ theme: 'light' | 'dark'; toggle(): void }>({ theme: 'light', toggle() {} });
export const useTheme = () => useContext(ThemeCtx);
function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  useEffect(() => {
    const t = document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
    setTheme(t);
  }, []);
  const toggle = useCallback(() => {
    setTheme((t) => {
      const n = t === 'dark' ? 'light' : 'dark';
      document.documentElement.setAttribute('data-theme', n);
      try { localStorage.setItem('amb_theme', n); } catch { /* ignore */ }
      return n;
    });
  }, []);
  return <ThemeCtx.Provider value={{ theme, toggle }}>{children}</ThemeCtx.Provider>;
}

/* ───────── Auth ───────── */
interface AuthState { user: Profile | null; loading: boolean; signIn(email: string, pw: string): Promise<Profile>; signOut(): Promise<void>; refresh(): Promise<void> }
const AuthCtx = createContext<AuthState>(null as unknown as AuthState);
export const useAuth = () => useContext(AuthCtx);

let fileSynced = false; // the local JSON file is read once per page load, before the first session check
function AuthProvider({ children, qc }: { children: ReactNode; qc: QueryClient }) {
  const [user, setUser] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();
  const refresh = useCallback(async () => {
    try { if (isDemo && !fileSynced) { fileSynced = true; await syncLocalFile(); } setUser(await api.auth.session()); } catch { setUser(null); } finally { setLoading(false); }
  }, []);
  useEffect(() => { void refresh(); }, [refresh]);
  const signIn = useCallback(async (email: string, pw: string) => {
    const p = await api.auth.signIn(email, pw);
    setUser(p);
    return p;
  }, []);
  const signOut = useCallback(async () => {
    await api.auth.signOut();
    qc.clear();
    setUser(null);
    router.replace('/login');
  }, [qc, router]);
  const value = useMemo(() => ({ user, loading, signIn, signOut, refresh }), [user, loading, signIn, signOut, refresh]);
  return <AuthCtx.Provider value={value}>{children}</AuthCtx.Provider>;
}

export function Providers({ children }: { children: ReactNode }) {
  const qcRef = useRef<QueryClient>(null);
  if (!qcRef.current) qcRef.current = new QueryClient({ defaultOptions: { queries: { staleTime: 20_000, refetchOnWindowFocus: false, retry: 1 } } });
  const qc = qcRef.current;
  return (
    <QueryClientProvider client={qc}>
      <ThemeProvider>
        <ToastProvider>
          <AuthProvider qc={qc}>
            <CompletionProvider>{children}</CompletionProvider>
          </AuthProvider>
        </ToastProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}
