'use client';
import { useQueryClient } from '@tanstack/react-query';
import Link from 'next/link';
import { useMemo, useState } from 'react';
import { BarsChart, CH, DonutChart, LinesChart } from './charts';
import { DataTable, type Column } from './DataTable';
import { Icon } from './Icon';
import { useToast } from './providers';
import { TeamCard } from './TeamCard';
import { AnimatedCounter, ChartCard, ConfirmDialog, ErrorState, LoadingState, Modal, PageHeader, ProgressRing, Reveal, StatsCard, UserAvatar } from './ui';
import { moduleHref, TEAM_LABEL } from '@/lib/access';
import { byModule, byTeam, forTeam, monthlyActivity, recent, statusDistribution, workload, WORK_TEAMS } from '@/lib/analytics';
import { api } from '@/lib/data';
import { ReportCenter } from './reports';
import { modulesForTeam, useItems, useLookups, useSetting, useTasks, useUsers } from '@/lib/hooks';
import { DEFAULT_WEIGHTS, normalizeWeights, type ScoringWeights } from '@/lib/performance';
import { MODULE_BY_KEY } from '@/lib/modules';
import { dueOf, effStatus, monthRange, summarize, weekRange, type Item } from '@/lib/stats';
import type { Profile, Team, WorkTeam } from '@/lib/types';
import { addDays, cn, expiryInfo, fmtDate, fmtTime, todayISO } from '@/lib/utils';
import { userSchema } from '@/lib/validate';
import { ExpiryWatch } from './dashboards';

/* ───────── Admin Overview (all teams on one screen) ───────── */
type Range = 'today' | 'yesterday' | 'week' | 'month' | 'custom';
const rangeOf = (r: Range, from: string, to: string) => {
  const t = todayISO();
  if (r === 'today') return { from: t, to: t };
  if (r === 'yesterday') { const y = addDays(-1); return { from: y, to: y }; }
  if (r === 'week') return weekRange();
  if (r === 'month') return monthRange();
  return { from: from || '0000-01-01', to: to || '9999-12-31' };
};
const inRange = ({ m, rec }: Item, f: string, t: string) => {
  const d = dueOf(m, rec);
  return (d && d >= f && d <= t) || (rec.created_at.slice(0, 10) >= f && rec.created_at.slice(0, 10) <= t) || (rec.updated_at.slice(0, 10) >= f && rec.updated_at.slice(0, 10) <= t);
};

export function AdminOverview() {
  const lk = useLookups();
  const mods = useMemo(() => modulesForTeam('admin'), []);
  const { items, loading, error, refetch } = useItems(mods);
  const [range, setRange] = useState<Range>('today');
  const [cf, setCf] = useState(''), [ct, setCt] = useState('');
  const [team, setTeam] = useState<'all' | WorkTeam>('all');
  const [status, setStatus] = useState('all');
  const { from, to } = rangeOf(range, cf, ct);
  if (loading) return <LoadingState variant="page" />;
  if (error) return <ErrorState message={error.message} onRetry={refetch} />;
  const teams = WORK_TEAMS.filter((t) => team === 'all' || t === team);
  const chip = (active: boolean) => cn('rounded-lg px-3 py-1.5 text-sm font-semibold transition', active ? 'bg-gradient-to-r from-primary to-secondary-500 text-white shadow' : 'text-muted hover:text-ink');
  return (
    <div>
      <PageHeader icon="MonitorCheck" title="Admin Overview" subtitle="Every team on one screen — updates live as work is completed." />
      <div className="panel mb-5 space-y-3 p-3">
        <div className="flex flex-wrap items-center gap-2">
          <div className="inline-flex flex-wrap rounded-xl bg-surface2 p-1" role="group" aria-label="Date range">
            {([['today', 'Today'], ['yesterday', 'Yesterday'], ['week', 'This Week'], ['month', 'This Month'], ['custom', 'Custom Date']] as const).map(([k, l]) => <button key={k} className={chip(range === k)} aria-pressed={range === k} onClick={() => setRange(k)}>{l}</button>)}
          </div>
          {range === 'custom' && <><input type="date" aria-label="From" className="input !w-auto" value={cf} onChange={(e) => setCf(e.target.value)} /><span className="text-muted">to</span><input type="date" aria-label="To" className="input !w-auto" value={ct} onChange={(e) => setCt(e.target.value)} /></>}
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div className="inline-flex rounded-xl bg-surface2 p-1" role="group" aria-label="Team">
            {(['all', ...WORK_TEAMS] as const).map((t) => <button key={t} className={chip(team === t)} aria-pressed={team === t} onClick={() => setTeam(t)}>{t === 'all' ? 'All' : TEAM_LABEL[t]}</button>)}
          </div>
          <select className="input !w-auto" aria-label="Status" value={status} onChange={(e) => setStatus(e.target.value)}>
            {['all', 'Pending', 'In Progress', 'Completed', 'Overdue'].map((s) => <option key={s} value={s}>{s === 'all' ? 'All statuses' : s}</option>)}
          </select>
          <span className="ml-auto text-xs text-muted">{fmtDate(from === '0000-01-01' ? null : from)} → {fmtDate(to === '9999-12-31' ? null : to)}</span>
        </div>
      </div>
      <div className={cn('grid gap-4', team === 'all' ? 'xl:grid-cols-3' : 'max-w-3xl')}>
        {teams.map((t, i) => {
          const all = forTeam(items, t);
          const scoped = all.filter((x) => inRange(x, from, to) && (status === 'all' || effStatus(x.m, x.rec) === status));
          const s = summarize(scoped);
          const todayN = summarize(all).today;
          const done = recent(scoped, 'completed', 3);
          const added = recent(scoped, 'added', 3);
          const latest = recent(all, 'added', 1).concat(recent(all, 'completed', 1)).sort((a, b) => b.rec.updated_at.localeCompare(a.rec.updated_at))[0];
          const activeIds = [...new Set(scoped.map((x) => x.rec.updated_by).filter(Boolean))] as string[];
          return (
            <Reveal key={t} delay={i * 0.08}>
              <section className="panel h-full p-4" aria-label={`${TEAM_LABEL[t]} team`}>
                <div className="mb-3 flex items-center justify-between">
                  <div><h2 className="text-lg font-extrabold">{TEAM_LABEL[t]}</h2><Link href={`/${t}`} className="text-xs font-semibold text-primary hover:underline">Open dashboard →</Link></div>
                  <ProgressRing value={s.progress} size={64} stroke={7} />
                </div>
                <div className="mb-4 grid grid-cols-4 gap-2 text-center">
                  {([["Today's", todayN], ['Done', s.completed], ['Pending', s.pending + s.inProgress], ['Overdue', s.overdue]] as const).map(([l, v]) => (
                    <div key={l} className={cn('rounded-xl py-2', l === 'Overdue' && v > 0 ? 'bg-primary-900 text-white' : 'bg-surface2')}><div className="text-xl font-extrabold"><AnimatedCounter value={v} /></div><div className="text-[10px] font-semibold uppercase tracking-wide opacity-70">{l}</div></div>
                  ))}
                </div>
                <MiniList title="Recently completed" icon="CircleCheck" rows={done} lk={lk} />
                <MiniList title="Recently added" icon="Plus" rows={added} lk={lk} />
                <div className="mt-3 border-t border-line/10 pt-3">
                  <div className="label">Team members active</div>
                  {activeIds.length ? <div className="flex -space-x-2">{activeIds.slice(0, 6).map((id) => <UserAvatar key={id} name={lk.user(id)} size={30} />)}{activeIds.length > 6 && <span className="grid h-[30px] w-[30px] place-items-center rounded-full bg-surface2 text-xs font-bold ring-2 ring-surface">+{activeIds.length - 6}</span>}</div> : <p className="text-xs text-muted">No activity in this range.</p>}
                  {latest && <p className="mt-3 text-xs text-muted"><b className="text-ink">Latest update:</b> {String(latest.rec[latest.m.titleField === 'client_id' ? 'remark' : latest.m.titleField] ?? latest.m.title)} · {lk.user(latest.rec.updated_by)} · {fmtTime(latest.rec.updated_at)}</p>}
                </div>
              </section>
            </Reveal>
          );
        })}
      </div>
    </div>
  );
}

function MiniList({ title, icon, rows, lk }: { title: string; icon: string; rows: Item[]; lk: ReturnType<typeof useLookups> }) {
  return (
    <div className="mb-2">
      <div className="label flex items-center gap-1"><Icon name={icon} size={12} />{title}</div>
      {rows.length === 0 ? <p className="py-1 text-xs text-muted">Nothing in this range.</p> : (
        <ul className="space-y-1">
          {rows.map(({ m, rec }) => <li key={rec.id}><Link href={`${moduleHref(m)}?open=${rec.id}`} className="flex items-center justify-between gap-2 rounded-lg px-2 py-1 text-sm transition hover:bg-primary/10"><span className="truncate font-medium">{m.titleField === 'client_id' ? lk.client(rec.client_id) : String(rec[m.titleField])}</span><span className="shrink-0 text-[11px] text-muted">{m.nav}</span></Link></li>)}
        </ul>
      )}
    </div>
  );
}

/* ───────── All Teams ───────── */
export function AdminTeams() {
  const mods = useMemo(() => modulesForTeam('admin'), []);
  const { items, loading, error, refetch } = useItems(mods);
  const users = useUsers().data ?? [];
  if (loading) return <LoadingState variant="page" />;
  if (error) return <ErrorState message={error.message} onRetry={refetch} />;
  const teams = byTeam(items);
  return (
    <div>
      <PageHeader icon="Users" title="All Teams" subtitle="Development, Marketing and Creative at a glance." />
      <div className="grid gap-4 lg:grid-cols-3">
        {WORK_TEAMS.map((t, i) => (
          <div key={t} className="space-y-4">
            <TeamCard team={t} s={teams[i]} delay={i * 0.1} />
            <Reveal className="panel p-4">
              <h3 className="mb-2 text-sm font-bold">Members</h3>
              <ul className="space-y-2">{users.filter((u) => u.team === t).map((u) => <li key={u.id} className="flex items-center gap-2 text-sm"><UserAvatar name={u.name} size={28} /><span className="font-medium">{u.name}</span><span className="ml-auto rounded-full bg-primary/10 px-2 py-0.5 text-[11px] font-semibold capitalize text-primary dark:text-primary-200">{u.role}</span></li>)}</ul>
            </Reveal>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ───────── User management ───────── */
export function UsersPage() {
  const q = useUsers();
  const qc = useQueryClient();
  const toast = useToast();
  const [edit, setEdit] = useState<Partial<Profile> | null>(null);
  const [confirm, setConfirm] = useState<Profile | null>(null);
  const [busy, setBusy] = useState(false);
  const [errs, setErrs] = useState<Record<string, string>>({});
  const refresh = () => qc.invalidateQueries({ queryKey: ['users'] });

  const save = async () => {
    const r = userSchema.safeParse(edit);
    if (!r.success) return setErrs(Object.fromEntries(r.error.issues.map((i) => [String(i.path[0]), i.message])));
    setErrs({});
    setBusy(true);
    try {
      if (edit?.id) await api.users.update(edit.id, { name: r.data.name, team: r.data.team, role: r.data.role });
      else await api.users.create(r.data);
      toast.success(edit?.id ? 'User updated successfully.' : 'User added successfully.');
      setEdit(null);
      refresh();
    } catch (e) { toast.error((e as Error).message); } finally { setBusy(false); }
  };
  const toggle = async (u: Profile) => {
    try { await api.users.update(u.id, { status: u.status === 'active' ? 'disabled' : 'active' }); toast.success(u.status === 'active' ? `${u.name} disabled.` : `${u.name} re-enabled.`); refresh(); }
    catch (e) { toast.error((e as Error).message); } finally { setConfirm(null); }
  };
  const reset = async (u: Profile) => { try { toast.success((await api.users.resetPassword(u.id, u.email)) ?? 'Password reset email sent.'); } catch (e) { toast.error((e as Error).message); } };

  const cols: Column<Profile>[] = [
    { key: 'name', label: 'Name', sortValue: (u) => u.name, render: (u) => <span className="inline-flex items-center gap-2 font-semibold"><UserAvatar name={u.name} src={u.avatar_url} size={30} />{u.name}</span> },
    { key: 'email', label: 'Email', sortValue: (u) => u.email, render: (u) => u.email },
    { key: 'team', label: 'Team', sortValue: (u) => u.team, render: (u) => <span className="rounded-full bg-primary/10 px-2.5 py-0.5 text-xs font-bold capitalize text-primary dark:text-primary-200">{u.team}</span> },
    { key: 'role', label: 'Role', sortValue: (u) => u.role, render: (u) => <span className="capitalize">{u.role}</span> },
    { key: 'status', label: 'Status', sortValue: (u) => u.status, render: (u) => <span className={cn('rounded-full px-2.5 py-0.5 text-xs font-bold ring-1 ring-inset', u.status === 'active' ? 'bg-secondary-400/30 text-secondary-700 ring-secondary/50 dark:text-secondary-200' : 'bg-line/10 text-muted ring-line/25')}>{u.status === 'active' ? 'Active' : 'Disabled'}</span> },
    { key: 'last', label: 'Last Login', sortValue: (u) => u.last_login ?? '', render: (u) => (u.last_login ? `${fmtDate(u.last_login)} ${fmtTime(u.last_login)}` : 'Never') },
    { key: 'created', label: 'Created', sortValue: (u) => u.created_at, render: (u) => fmtDate(u.created_at) },
  ];
  const fld = (k: string) => errs[k] && <p role="alert" className="mt-1 text-xs font-medium text-primary-800 dark:text-primary-200">{errs[k]}</p>;
  return (
    <div>
      <PageHeader icon="UserCog" title="Users" subtitle="Add people, change teams, disable access and reset passwords." actions={<button className="btn-primary" onClick={() => { setErrs({}); setEdit({ name: '', email: '', team: 'development', role: 'member' }); }}><Icon name="UserPlus" size={16} />Add user</button>} />
      {q.isLoading ? <LoadingState variant="table" /> : q.error ? <ErrorState message={(q.error as Error).message} onRetry={() => q.refetch()} /> : (
        <DataTable rows={q.data ?? []} columns={cols} rowKey={(u) => u.id} caption="Users" defaultSort={{ key: 'name', dir: 'asc' }}
          cardBadge={(u) => <span className="rounded-full bg-primary/10 px-2 py-0.5 text-[11px] font-bold capitalize text-primary">{u.team}</span>}
          actions={(u) => <>
            <button className="btn-ghost !p-1.5" aria-label={`Edit ${u.name}`} title="Edit / change team" onClick={() => { setErrs({}); setEdit(u); }}><Icon name="Pencil" size={15} /></button>
            <button className="btn-ghost !p-1.5" aria-label={`Reset password for ${u.name}`} title="Reset password" onClick={() => void reset(u)}><Icon name="KeyRound" size={15} /></button>
            <button className="btn-ghost !p-1.5" aria-label={u.status === 'active' ? `Disable ${u.name}` : `Enable ${u.name}`} title={u.status === 'active' ? 'Disable' : 'Enable'} onClick={() => (u.status === 'active' ? setConfirm(u) : void toggle(u))}><Icon name={u.status === 'active' ? 'Ban' : 'CircleCheck'} size={15} /></button>
          </>} />
      )}
      <Modal open={!!edit} onClose={() => setEdit(null)} title={edit?.id ? 'Edit user' : 'Add user'} size="md" footer={<><button className="btn-ghost" onClick={() => setEdit(null)}>Cancel</button><button className="btn-primary" disabled={busy} onClick={() => void save()}>{busy && <Icon name="Loader2" className="animate-spin" size={16} />}{edit?.id ? 'Save changes' : 'Add user'}</button></>}>
        {edit && (
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="sm:col-span-2"><label className="label" htmlFor="u-name">Name</label><input id="u-name" className="input" value={edit.name ?? ''} onChange={(e) => setEdit({ ...edit, name: e.target.value })} />{fld('name')}</div>
            <div className="sm:col-span-2"><label className="label" htmlFor="u-email">Email</label><input id="u-email" type="email" className="input" disabled={!!edit.id} value={edit.email ?? ''} onChange={(e) => setEdit({ ...edit, email: e.target.value })} />{fld('email')}</div>
            <div><label className="label" htmlFor="u-team">Team</label><select id="u-team" className="input" value={edit.team} onChange={(e) => setEdit({ ...edit, team: e.target.value as Team, role: e.target.value === 'admin' ? 'admin' : edit.role === 'admin' ? 'member' : edit.role })}>{(['admin', 'development', 'marketing', 'creative'] as Team[]).map((t) => <option key={t} value={t}>{TEAM_LABEL[t]}</option>)}</select></div>
            <div><label className="label" htmlFor="u-role">Role</label><select id="u-role" className="input" value={edit.role} onChange={(e) => setEdit({ ...edit, role: e.target.value as Profile['role'] })}>{(edit.team === 'admin' ? ['admin'] : ['lead', 'member']).map((r) => <option key={r} className="capitalize">{r}</option>)}</select></div>
            {!edit.id && <p className="rounded-lg bg-primary/10 p-3 text-xs text-muted sm:col-span-2">The new user receives an email to set their own password. Passwords are never shown or stored in plain text.</p>}
          </div>
        )}
      </Modal>
      <ConfirmDialog open={!!confirm} title="Disable user?" message={confirm ? `${confirm.name} will no longer be able to sign in. You can re-enable the account at any time.` : ''} confirmLabel="Disable" onClose={() => setConfirm(null)} onConfirm={() => confirm && void toggle(confirm)} />
    </div>
  );
}

/* ───────── Reports ───────── */
const TIER_COLORS: Record<string, string> = { Healthy: CH[1], Warning: CH[2], Critical: CH[0], Expired: CH[5] };
function healthCounts(items: Item[], key: string) {
  const c: Record<string, number> = { Healthy: 0, Warning: 0, Critical: 0, Expired: 0 };
  items.filter((x) => x.m.key === key).forEach(({ m, rec }) => { const i = expiryInfo(rec[m.expiryField!]); if (i) c[i.health]++; });
  return Object.entries(c).map(([name, value]) => ({ name, value, color: TIER_COLORS[name] })).filter((d) => d.value);
}

export function ReportsPage() {
  const lk = useLookups();
  const mods = useMemo(() => modulesForTeam('admin'), []);
  const { items, loading, error, refetch } = useItems(mods);
  const tasks = useTasks().data ?? [];
  const weights = useSetting<ScoringWeights>('scoring', DEFAULT_WEIGHTS, (r) => normalizeWeights(r as Partial<ScoringWeights>)).value;
  const [tab, setTab] = useState<'tables' | 'charts'>('tables');
  if (loading) return <LoadingState variant="page" />;
  if (error) return <ErrorState message={error.message} onRetry={refetch} />;
  const teams = byTeam(items);
  const s = summarize(items);
  const monthly = monthlyActivity(items, 6);
  const overdue = byModule(items).filter((x) => x.overdue > 0).sort((a, b) => b.overdue - a.overdue);
  const marketing = items.filter((x) => x.m.key === 'mailer-reports').map((x) => x.rec).sort((a, b) => String(a.send_date).localeCompare(String(b.send_date))).map((r) => ({ name: String(r.campaign_name).slice(0, 10), open: r.delivered && r.unique_opens != null ? +((r.unique_opens / r.delivered) * 100).toFixed(1) : 0, click: r.delivered && r.unique_clicks != null ? +((r.unique_clicks / r.delivered) * 100).toFixed(1) : 0 }));
  const creative = ['web', 'videos', 'artworks'].map((k) => { const x = summarize(items.filter((i) => i.m.key === k)); return { name: MODULE_BY_KEY[k].nav, completed: x.completed, active: x.inProgress + x.pending, overdue: x.overdue }; });
  const backups = statusDistribution(items.filter((x) => x.m.key === 'backups'));
  const load = workload(items, lk.user).slice(0, 10);
  const overdueRows = items.filter(({ m, rec }) => effStatus(m, rec) === 'Overdue' && !m.expiryField).sort((a, b) => String(dueOf(a.m, a.rec)).localeCompare(String(dueOf(b.m, b.rec)))).slice(0, 8);
  return (
    <div>
      <PageHeader icon="ChartPie" title="Reports" subtitle="Pick a report and date range, then export it as CSV, or switch to the overview charts." actions={<button className="btn-ghost" onClick={() => window.print()}><Icon name="Download" size={16} />Print / PDF</button>} />
      <div className="mb-4 inline-flex rounded-xl bg-surface2 p-1" role="tablist" aria-label="Report view">
        {([['tables', 'Report tables'], ['charts', 'Overview charts']] as const).map(([k, l]) => <button key={k} role="tab" aria-selected={tab === k} onClick={() => setTab(k)} className={cn('rounded-lg px-4 py-1.5 text-sm font-semibold transition', tab === k ? 'bg-gradient-to-r from-primary to-secondary-500 text-white shadow' : 'text-muted hover:text-ink')}>{l}</button>)}
      </div>
      {tab === 'tables' && <ReportCenter items={items} tasks={tasks} lk={lk} weights={weights} />}
      {tab === 'charts' && <>
      <div className="mb-5 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatsCard label="Overall completion" value={s.progress} icon="Trophy" hint="% of active work" />
        <StatsCard label="Completed" value={s.completed} icon="CircleCheck" accent="secondary" />
        <StatsCard label="Open work" value={s.pending + s.inProgress} icon="Clock" accent="accent" />
        <StatsCard label="Overdue" value={s.overdue} icon="AlertTriangle" accent="dark" />
      </div>
      <div className="grid gap-4 lg:grid-cols-3">
        <ChartCard title="Team performance" subtitle="Completion by team" className="lg:col-span-2"><BarsChart data={teams} series={[{ key: 'completed', name: 'Completed', color: CH[1] }, { key: 'inProgress', name: 'In progress', color: CH[0] }, { key: 'pending', name: 'Pending', color: CH[2] }, { key: 'overdue', name: 'Overdue', color: CH[5] }]} stacked /></ChartCard>
        <ChartCard title="Task completion" subtitle="All statuses"><DonutChart data={statusDistribution(items).map((d) => ({ ...d, color: ({ Completed: CH[1], 'In Progress': CH[0], Pending: CH[2], Overdue: CH[5], 'On Hold': CH[6], Cancelled: '#cfe0dc' } as Record<string, string>)[d.name] }))} /></ChartCard>
        <ChartCard title="Overdue tasks" subtitle="By module" className="lg:col-span-2"><BarsChart data={overdue} series={[{ key: 'overdue', name: 'Overdue', color: CH[5] }]} /></ChartCard>
        <ChartCard title="Monthly work" subtitle="Records created per team"><LinesChart data={monthly} area series={[{ key: 'development', name: 'Development', color: CH[0] }, { key: 'marketing', name: 'Marketing', color: CH[1] }, { key: 'creative', name: 'Creative', color: CH[2] }]} /></ChartCard>
        <ChartCard title="Website expiry" subtitle="Health of domains"><DonutChart data={healthCounts(items, 'website-expiry')} height={200} /></ChartCard>
        <ChartCard title="SSL expiry" subtitle="Certificate health"><DonutChart data={healthCounts(items, 'ssl-expiry')} height={200} /></ChartCard>
        <ChartCard title="Backup status"><DonutChart data={backups.map((d) => ({ ...d, color: ({ Completed: CH[1], 'In Progress': CH[0], Pending: CH[2], Overdue: CH[5], 'On Hold': CH[6], Cancelled: '#cfe0dc' } as Record<string, string>)[d.name] }))} height={200} /></ChartCard>
        <ChartCard title="Marketing performance" subtitle="Open & click rate per campaign" className="lg:col-span-2"><LinesChart data={marketing} unit="%" area series={[{ key: 'open', name: 'Open %', color: CH[0] }, { key: 'click', name: 'Click %', color: CH[1] }]} /></ChartCard>
        <ChartCard title="Creative production"><BarsChart data={creative} stacked series={[{ key: 'completed', name: 'Completed', color: CH[1] }, { key: 'active', name: 'In pipeline', color: CH[0] }, { key: 'overdue', name: 'Overdue', color: CH[5] }]} /></ChartCard>
        <ChartCard title="Employee workload" subtitle="Assigned work: open vs done" className="lg:col-span-2"><BarsChart data={load.map((l) => ({ ...l, name: l.name.split(' ')[0] }))} series={[{ key: 'open', name: 'Open', color: CH[0] }, { key: 'done', name: 'Done', color: CH[1] }]} stacked /></ChartCard>
        <ExpiryWatch items={items} limit={6} />
        <ChartCard title="Oldest overdue tasks" className="lg:col-span-3">
          {overdueRows.length === 0 ? <p className="py-4 text-center text-sm text-muted">No overdue tasks 🎉</p> : (
            <ul className="divide-y divide-line/10">{overdueRows.map(({ m, rec }) => <li key={rec.id}><Link href={`${moduleHref(m)}?open=${rec.id}`} className="flex items-center justify-between gap-3 py-2 text-sm hover:translate-x-0.5"><span className="truncate font-semibold">{m.titleField === 'client_id' ? lk.client(rec.client_id) : String(rec[m.titleField])}<span className="ml-2 font-normal text-muted">{m.nav}</span></span><span className="shrink-0 text-xs text-muted">Due {fmtDate(dueOf(m, rec))} · {lk.user(rec.assigned_to)}</span></Link></li>)}</ul>
          )}
        </ChartCard>
      </div>
      </>}
    </div>
  );
}
