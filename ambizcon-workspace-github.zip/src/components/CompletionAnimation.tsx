'use client';
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { useQuery } from '@tanstack/react-query';
import { createContext, useCallback, useContext, useEffect, useId, useMemo, useRef, useState, type ReactNode } from 'react';
import { CompanyLogo } from './CompanyLogo';
import { Person, type CharacterKind } from './ThreeDCharacter';
import { useAuth } from './providers';
import { api } from '@/lib/data';
import type { Anim, ModuleDef } from '@/lib/modules';
import { playCue } from '@/lib/sound';
import type { Rec, Task } from '@/lib/types';

const C = { P: '#13798A', S: '#8BA277', A: '#95A575', D: '#0c4d58', DD: '#06272d' };

const COPY: Record<Anim, string> = {
  ssl: 'SSL Updated Successfully!',
  backup: 'Backup Completed Successfully!',
  video: 'Video Completed Successfully!',
  web: 'Web Requirement Completed!',
  artwork: 'Artwork Completed Successfully!',
  seo: 'SEO Update Completed!',
  marketing: 'Marketing Task Completed!',
  celebrate: 'Great Work!',
};

const draw = (delay = 0.5) => ({ initial: { pathLength: 0 }, animate: { pathLength: 1 }, transition: { duration: 0.6, delay, ease: 'easeOut' as const } });

function CheckBadge({ x = 150, y = 46, r = 22 }: { x?: number; y?: number; r?: number }) {
  return (
    <motion.g initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: 'spring', stiffness: 260, damping: 14, delay: 0.35 }} style={{ transformBox: 'fill-box', transformOrigin: 'center' }}>
      <circle cx={x} cy={y} r={r} fill={C.S} stroke="#fff" strokeWidth="4" />
      <motion.path d={`M${x - r * 0.42} ${y + 1} l${r * 0.28} ${r * 0.3} ${r * 0.58}-${r * 0.62}`} stroke="#fff" strokeWidth="5" fill="none" strokeLinecap="round" strokeLinejoin="round" {...draw(0.65)} />
    </motion.g>
  );
}

function Hover({ children, amp = 5 }: { children: ReactNode; amp?: number }) {
  return (
    <motion.g animate={{ y: [0, -amp, 0] }} transition={{ duration: 2.4, repeat: Infinity, ease: 'easeInOut' }}>
      {children}
    </motion.g>
  );
}

function Scene({ anim, team, uid }: { anim: Anim; team: CharacterKind; uid: string }) {
  const grad = (n: string) => `url(#${n}-${uid})`;
  return (
    <svg viewBox="0 0 200 200" className="h-full w-full overflow-visible" aria-hidden>
      <defs>
        <linearGradient id={`a-${uid}`} x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor={C.P} /><stop offset="1" stopColor={C.D} /></linearGradient>
        <linearGradient id={`b-${uid}`} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#fff" /><stop offset="1" stopColor="#d4e6e2" /></linearGradient>
        <linearGradient id={`c-${uid}`} x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor={C.S} /><stop offset="1" stopColor={C.P} /></linearGradient>
      </defs>
      <ellipse cx="100" cy="184" rx="70" ry="9" fill="#000" opacity=".16" />
      {anim === 'ssl' && (
        <Hover>
          <path d="M100 22 164 46v52c0 40-28 66-64 80-36-14-64-40-64-80V46z" fill={grad('a')} />
          <path d="M100 34 152 53v45c0 32-22 54-52 66-30-12-52-34-52-66V53z" fill={grad('c')} opacity=".55" />
          <motion.path d="M68 100l24 24 42-48" stroke="#fff" strokeWidth="14" fill="none" strokeLinecap="round" strokeLinejoin="round" {...draw(0.4)} />
          <circle cx="164" cy="40" r="5" fill={C.A} /><circle cx="34" cy="64" r="4" fill={C.S} />
        </Hover>
      )}
      {anim === 'backup' && (
        <Hover>
          <path d="M52 112h96a28 28 0 0 0 4-56 40 40 0 0 0-76-8 34 34 0 0 0-24 64z" fill={grad('b')} />
          <motion.g animate={{ y: [4, -4, 4] }} transition={{ duration: 1.6, repeat: Infinity }}><path d="M100 98V62m-12 12 12-14 12 14" stroke={C.P} strokeWidth="7" fill="none" strokeLinecap="round" strokeLinejoin="round" /></motion.g>
          {[0, 1, 2].map((i) => (
            <g key={i}><path d={`M64 ${128 + i * 16}v10c0 5 16 8 36 8s36-3 36-8v-10`} fill={i % 2 ? C.S : C.P} /><ellipse cx="100" cy={128 + i * 16} rx="36" ry="8" fill={i % 2 ? '#a9c093' : '#2f8c9c'} /></g>
          ))}
        </Hover>
      )}
      {anim === 'video' && (
        <Hover>
          <circle cx="62" cy="64" r="20" fill={C.S} /><circle cx="108" cy="58" r="24" fill={C.P} /><circle cx="108" cy="58" r="8" fill="#fff" opacity=".7" /><circle cx="62" cy="64" r="7" fill="#fff" opacity=".7" />
          <rect x="34" y="82" width="104" height="72" rx="14" fill={grad('a')} />
          <circle cx="86" cy="118" r="24" fill={C.DD} /><circle cx="86" cy="118" r="14" fill="#6fc0cc" /><circle cx="80" cy="112" r="4" fill="#fff" opacity=".8" />
          <path d="M138 104 172 86v64l-34-18z" fill={C.S} />
        </Hover>
      )}
      {anim === 'web' && (
        <Hover>
          <rect x="34" y="40" width="132" height="94" rx="9" fill={grad('a')} />
          <rect x="42" y="48" width="116" height="78" rx="5" fill="#fff" />
          <rect x="42" y="48" width="116" height="14" rx="5" fill="#d4e6e2" />
          {[0, 1, 2].map((i) => <circle key={i} cx={50 + i * 9} cy="55" r="2.6" fill={[C.P, C.S, C.A][i]} />)}
          <rect x="50" y="70" width="52" height="8" rx="3" fill={C.P} /><rect x="50" y="84" width="36" height="5" rx="2" fill={C.S} /><rect x="50" y="94" width="44" height="5" rx="2" fill={C.A} />
          <rect x="112" y="70" width="38" height="46" rx="5" fill={C.S} opacity=".8" />
          <path d="M20 142h160l-12 16H32z" fill={grad('c')} />
        </Hover>
      )}
      {anim === 'artwork' && (
        <Hover>
          <path d="M72 128 58 176m70-48 14 48M100 128v48" stroke={C.D} strokeWidth="6" strokeLinecap="round" />
          <rect x="46" y="34" width="108" height="96" rx="7" fill="#fff" stroke={C.D} strokeWidth="5" />
          <circle cx="82" cy="68" r="16" fill={C.S} /><path d="M70 118 104 62l34 56z" fill={C.P} opacity=".9" /><path d="M54 106c20-16 38 12 56-2s26-10 36 0v14H54z" fill={C.A} />
          <ellipse cx="156" cy="150" rx="30" ry="22" fill="#fff" stroke={C.D} strokeWidth="4" />
          {[[144, 144, C.P], [158, 138, C.S], [170, 148, C.A], [150, 158, C.D]].map(([x, y, f], i) => <circle key={i} cx={x as number} cy={y as number} r="5" fill={f as string} />)}
        </Hover>
      )}
      {anim === 'seo' && (
        <Hover>
          <circle cx="90" cy="86" r="48" fill="#fff" stroke={grad('a')} strokeWidth="14" />
          <path d="M126 122l38 38" stroke={C.D} strokeWidth="16" strokeLinecap="round" />
          {[18, 30, 24, 40].map((h, i) => (
            <motion.rect key={i} x={66 + i * 16} width="10" rx="3" fill={i % 2 ? C.S : C.P} initial={{ height: 0, y: 108 }} animate={{ height: h, y: 108 - h }} transition={{ delay: 0.3 + i * 0.1, duration: 0.6 }} />
          ))}
          <path d="M64 90 84 74l14 8 22-20" stroke={C.D} strokeWidth="4" fill="none" strokeLinecap="round" strokeLinejoin="round" />
          <text x="150" y="60" fontSize="22" fontWeight="800" fill={C.D}>#1</text>
        </Hover>
      )}
      {anim === 'marketing' && (
        <Hover>
          <path d="M40 92 112 56v88L40 108z" fill={grad('a')} /><rect x="26" y="88" width="24" height="26" rx="7" fill={C.S} /><path d="M52 114l10 34h16l-8-30z" fill={C.D} />
          <path d="M126 76c14 10 14 36 0 48M140 64c22 16 22 56 0 72" stroke={C.S} strokeWidth="6" fill="none" strokeLinecap="round" />
          {[0, 1, 2].map((i) => <motion.rect key={i} x={118 + i * 18} width="12" rx="3" fill={[C.P, C.S, C.A][i]} initial={{ height: 0, y: 168 }} animate={{ height: 22 + i * 14, y: 168 - 22 - i * 14 }} transition={{ delay: 0.4 + i * 0.12 }} />)}
          <text x="44" y="60" fontSize="18" fill={C.A}>★</text>
        </Hover>
      )}
      {anim === 'celebrate' && (
        <>
          <rect x="62" y="134" width="76" height="40" rx="9" fill={grad('a')} />
          <motion.g animate={{ y: [0, -22, 0] }} transition={{ duration: 0.9, repeat: Infinity, ease: 'easeOut' }}>
            <g transform="translate(14 -28) scale(.76)"><Person kind={team} uid={uid} standing armsUp /></g>
          </motion.g>
        </>
      )}
      <CheckBadge />
    </svg>
  );
}

const COLORS = [C.P, C.S, C.A, '#ffffff', '#6fc0cc'];
function Confetti() {
  const pieces = useMemo(
    () => Array.from({ length: 46 }, (_, i) => ({ id: i, x: (Math.random() - 0.5) * 520, y: 120 + Math.random() * 260, r: Math.random() * 720 - 360, d: Math.random() * 0.5, c: COLORS[i % COLORS.length], round: i % 3 === 0, w: 6 + Math.random() * 7 })),
    [],
  );
  return (
    <div aria-hidden className="pointer-events-none absolute left-1/2 top-1/3 h-0 w-0">
      {pieces.map((p) => (
        <motion.span
          key={p.id}
          className="absolute block"
          style={{ width: p.w, height: p.round ? p.w : p.w * 0.45, background: p.c, borderRadius: p.round ? 999 : 2 }}
          initial={{ x: 0, y: 0, opacity: 1, rotate: 0, scale: 0.6 }}
          animate={{ x: p.x, y: [-120 - Math.random() * 80, p.y], opacity: [1, 1, 0], rotate: p.r, scale: 1 }}
          transition={{ duration: 2.4, delay: p.d, ease: 'easeOut' }}
        />
      ))}
    </div>
  );
}

export function CompletionAnimation({ anim, team, title, subtitle, onClose, duration = 4200 }: { anim: Anim; team: CharacterKind; title?: string; subtitle?: string; onClose: () => void; duration?: number }) {
  const uid = useId().replace(/:/g, '');
  const reduce = useReducedMotion();
  useEffect(() => {
    playCue('complete');
    const t = setTimeout(onClose, duration);
    const esc = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', esc);
    return () => {
      clearTimeout(t);
      window.removeEventListener('keydown', esc);
    };
  }, [onClose, duration]);
  return (
    <motion.div className="fixed inset-0 z-[90] grid place-items-center bg-primary-900/55 p-4 backdrop-blur-sm" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose} role="alertdialog" aria-live="assertive" aria-label={title ?? COPY[anim]}>
      {!reduce && <Confetti />}
      <motion.div
        initial={{ scale: 0.7, y: 40, opacity: 0, rotateX: 18 }}
        animate={{ scale: 1, y: 0, opacity: 1, rotateX: 0 }}
        exit={{ scale: 0.9, y: 20, opacity: 0 }}
        transition={{ type: 'spring', stiffness: 220, damping: 20 }}
        className="relative w-full max-w-sm overflow-hidden rounded-3xl bg-gradient-to-b from-surface to-surface2 p-6 pt-4 text-center shadow-lift ring-1 ring-white/20"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="pointer-events-none absolute -top-16 left-1/2 h-48 w-48 -translate-x-1/2 rounded-full bg-secondary/30 blur-3xl" />
        <div className="mx-auto h-44 w-44"><Scene anim={anim} team={team} uid={uid} /></div>
        <h2 className="mt-1 text-2xl font-extrabold text-primary">{title ?? COPY[anim]}</h2>
        <p className="mt-1 text-sm font-medium text-ink">Task completed successfully.</p>
        {subtitle && <p className="mt-1 truncate text-xs text-muted">{subtitle}</p>}
        <div className="mt-4 flex justify-center opacity-80"><CompanyLogo size={26} animated={false} /></div>
        <motion.div className="absolute bottom-0 left-0 h-1 bg-gradient-to-r from-primary to-secondary" initial={{ width: '100%' }} animate={{ width: 0 }} transition={{ duration: duration / 1000, ease: 'linear' }} />
      </motion.div>
    </motion.div>
  );
}

type Celebrate = (m: ModuleDef, rec: Rec, title: string) => void;
const Ctx = createContext<Celebrate>(() => {});
export const useCelebrate = () => useContext(Ctx);
const TaskCtx = createContext<(t: Task) => void>(() => {});
/** Celebrate a global task. Call only after the server has confirmed the task is saved as Completed. */
export const useCelebrateTask = () => useContext(TaskCtx);

/** Reusable provider: any status change to Completed calls celebrate(module, record). */
export function CompletionProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<{ anim: Anim; team: CharacterKind; subtitle: string; key: number } | null>(null);
  const { user } = useAuth();
  // admins can switch individual animations off in the Customization Studio (setting "animations", default: all on)
  const prefs = useQuery({ queryKey: ['settings', 'animations'], enabled: !!user, queryFn: async () => { const r = await api.settings.get<Record<string, boolean>>('animations'); return r && typeof r === 'object' ? r : {}; } });
  const enabled = useRef<Record<string, boolean>>({});
  enabled.current = prefs.data ?? {};
  const celebrate = useCallback<Celebrate>((m, _rec, title) => { if (enabled.current[m.anim] !== false) setState({ anim: m.anim, team: m.team, subtitle: title, key: Date.now() }); }, []);
  const celebrateTask = useCallback((t: Task) => { const anim: Anim = t.team === 'marketing' ? 'marketing' : 'celebrate'; if (enabled.current[anim] !== false) setState({ anim, team: t.team, subtitle: t.title, key: Date.now() }); }, []);
  const close = useCallback(() => setState(null), []);
  return (
    <Ctx.Provider value={celebrate}>
      <TaskCtx.Provider value={celebrateTask}>
        {children}
        <AnimatePresence>{state && <CompletionAnimation key={state.key} anim={state.anim} team={state.team} subtitle={state.subtitle} onClose={close} />}</AnimatePresence>
      </TaskCtx.Provider>
    </Ctx.Provider>
  );
}
