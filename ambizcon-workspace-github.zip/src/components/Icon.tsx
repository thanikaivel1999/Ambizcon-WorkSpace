import {
  Activity, AlertTriangle, ArrowRight, ArrowUpDown, BadgeCheck, Ban, Bell, Calendar, CalendarClock, CalendarDays, Camera, ChartColumn, ChartLine, ChartPie, Check, ChevronDown, ChevronLeft,
  ChevronRight, ChevronUp, CircleAlert, CircleCheck, CircleUser, Clapperboard, Clock, ClipboardList, Code2, DatabaseBackup, Download, ExternalLink, Eye, Filter, Flame, Gauge, Globe, Image as ImageIcon,
  Inbox, Info, KeyRound, Layers, LayoutDashboard, LayoutGrid, LayoutTemplate, Link2, ListChecks, Loader2, Lock, LogOut, Mail, MailCheck, Megaphone, Menu, MonitorCheck, Moon, Newspaper, Palette, Pause,
  Pencil, Play, PlaySquare, Plus, Radar, RotateCcw, Rocket, ScrollText, Search, SearchCheck, Send, Settings, Share2, ShieldAlert, ShieldCheck, Sparkles, Sun, Table2, Trash2, TrendingUp, Trophy,
  UserCog, UserPlus, Users, UsersRound, Video, Volume2, Wrench, X, Archive, ArchiveRestore, Award, BookOpen, Bot, Building2, FileText, MessageSquare, Medal, Star, Target, SlidersHorizontal, Brush, Handshake, Hourglass, Lightbulb, Bug, PanelsTopLeft, Wand2, type LucideIcon,
} from 'lucide-react';

const MAP: Record<string, LucideIcon> = {
  Activity, AlertTriangle, ArrowRight, ArrowUpDown, BadgeCheck, Ban, Bell, Calendar, CalendarClock, CalendarDays, Camera, ChartColumn, ChartLine, ChartPie, Check, ChevronDown, ChevronLeft,
  ChevronRight, ChevronUp, CircleAlert, CircleCheck, CircleUser, Clapperboard, Clock, ClipboardList, Code2, DatabaseBackup, Download, ExternalLink, Eye, Filter, Flame, Gauge, Globe, Image: ImageIcon,
  Inbox, Info, KeyRound, Layers, LayoutDashboard, LayoutGrid, LayoutTemplate, Link2, ListChecks, Loader2, Lock, LogOut, Mail, MailCheck, Megaphone, Menu, MonitorCheck, Moon, Newspaper, Palette, Pause,
  Pencil, Play, PlaySquare, Plus, Radar, RotateCcw, Rocket, ScrollText, Search, SearchCheck, Send, Settings, Share2, ShieldAlert, ShieldCheck, Sparkles, Sun, Table2, Trash2, TrendingUp, Trophy,
  UserCog, UserPlus, Users, UsersRound, Video, Volume2, Wrench, X, Archive, ArchiveRestore, Award, BookOpen, Bot, Building2, FileText, MessageSquare, Medal, Star, Target, SlidersHorizontal, Brush, Handshake, Hourglass, Lightbulb, Bug, PanelsTopLeft, Wand2,
};

export function Icon({ name, className, size = 18 }: { name: string; className?: string; size?: number }) {
  const C = MAP[name] ?? Activity;
  return <C className={className} size={size} aria-hidden strokeWidth={2} />;
}
