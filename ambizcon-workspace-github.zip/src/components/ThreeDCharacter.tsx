'use client';
import { motion, useMotionValue, useReducedMotion, useSpring } from 'framer-motion';
import { memo, useId, type ReactNode } from 'react';
import { cn } from '@/lib/utils';

export type CharacterKind = 'development' | 'marketing' | 'creative' | 'admin';

const C = { P: '#13798A', S: '#8BA277', A: '#95A575', D: '#0c4d58', DD: '#06272d', L: '#e8f4f6' };

export function Float({ children, x = 0, y = 0, amp = 7, dur = 4, delay = 0, rotate = 0 }: { children: ReactNode; x?: number; y?: number; amp?: number; dur?: number; delay?: number; rotate?: number }) {
  const reduce = useReducedMotion();
  return (
    <g transform={`translate(${x} ${y})`}>
      <motion.g animate={reduce ? undefined : { y: [0, -amp, 0], rotate: rotate ? [-rotate, rotate, -rotate] : 0 }} transition={{ duration: dur, repeat: Infinity, ease: 'easeInOut', delay }} style={{ transformBox: 'fill-box', transformOrigin: 'center' }}>
        {children}
      </motion.g>
    </g>
  );
}

const PALETTE: Record<CharacterKind, { shirt: string; shirt2: string; hair: string; skin: string }> = {
  development: { shirt: C.P, shirt2: C.D, hair: '#2a1d16', skin: '#f0c7a4' },
  marketing: { shirt: C.S, shirt2: '#5b6f4c', hair: '#4a2b1c', skin: '#e9b896' },
  creative: { shirt: C.A, shirt2: '#667350', hair: '#171717', skin: '#d9a47e' },
  admin: { shirt: C.D, shirt2: C.DD, hair: '#2f3a3d', skin: '#f2cfae' },
};

/** Seated or standing person shared by all four characters and the celebration scene. */
export function Person({ kind, uid, armsUp = false, standing = false }: { kind: CharacterKind; uid: string; armsUp?: boolean; standing?: boolean }) {
  const p = PALETTE[kind];
  const g = (n: string) => `${n}-${uid}`;
  const top = standing ? 110 : 140;
  return (
    <g>
      <defs>
        <linearGradient id={g('shirt')} x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor={p.shirt} /><stop offset="1" stopColor={p.shirt2} /></linearGradient>
        <radialGradient id={g('skin')} cx=".35" cy=".3" r=".9"><stop offset="0" stopColor={p.skin} /><stop offset="1" stopColor="#c58f68" /></radialGradient>
      </defs>
      {/* torso */}
      <path d={`M${standing ? 105 : 80} ${top + 112} Q${standing ? 105 : 80} ${top + 56} ${standing ? 135 : 120} ${top + 44} L${standing ? 175 : 160} ${top + 44} Q${standing ? 205 : 200} ${top + 56} ${standing ? 205 : 200} ${top + 112}Z`} fill={`url(#${g('shirt')})`} />
      {kind === 'admin' && <path d={`M${standing ? 155 : 140} ${top + 46} l-7 16 7 40 7 -40z`} fill={C.A} />}
      <rect x={standing ? 148 : 133} y={top + 22} width="14" height="26" rx="6" fill={`url(#${g('skin')})`} />
      {/* head */}
      <circle cx={standing ? 155 : 140} cy={top} r="34" fill={`url(#${g('skin')})`} />
      <path d={`M${(standing ? 155 : 140) - 36} ${top - 4} Q${(standing ? 155 : 140) - 34} ${top - 40} ${standing ? 155 : 140} ${top - 38} Q${(standing ? 155 : 140) + 34} ${top - 40} ${(standing ? 155 : 140) + 36} ${top - 4} Q${(standing ? 155 : 140) + 20} ${top - 24} ${standing ? 155 : 140} ${top - 22} Q${(standing ? 155 : 140) - 20} ${top - 24} ${(standing ? 155 : 140) - 36} ${top - 4}Z`} fill={p.hair} />
      <circle cx={(standing ? 155 : 140) - 12} cy={top + 3} r="3.2" fill="#1c1c1c" />
      <circle cx={(standing ? 155 : 140) + 12} cy={top + 3} r="3.2" fill="#1c1c1c" />
      <path d={`M${(standing ? 155 : 140) - 9} ${top + 15} Q${standing ? 155 : 140} ${top + 24} ${(standing ? 155 : 140) + 9} ${top + 15}`} stroke="#7a3f2c" strokeWidth="3" fill="none" strokeLinecap="round" />
      <circle cx={(standing ? 155 : 140) - 21} cy={top + 12} r="5" fill="#e59a8a" opacity=".35" />
      <circle cx={(standing ? 155 : 140) + 21} cy={top + 12} r="5" fill="#e59a8a" opacity=".35" />
      {armsUp && (
        <>
          <path d={`M110 ${top + 58} Q80 ${top + 10} 88 ${top - 38}`} stroke={p.shirt2} strokeWidth="18" strokeLinecap="round" fill="none" />
          <path d={`M200 ${top + 58} Q230 ${top + 10} 222 ${top - 38}`} stroke={p.shirt2} strokeWidth="18" strokeLinecap="round" fill="none" />
          <circle cx="88" cy={top - 42} r="10" fill={`url(#${g('skin')})`} />
          <circle cx="222" cy={top - 42} r="10" fill={`url(#${g('skin')})`} />
        </>
      )}
    </g>
  );
}

function Desk({ id }: { id: string }) {
  return (
    <g>
      <defs>
        <linearGradient id={`desk-${id}`} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#f4f8f6" /><stop offset="1" stopColor="#c9dcd8" /></linearGradient>
        <linearGradient id={`deskf-${id}`} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor={C.P} /><stop offset="1" stopColor={C.DD} /></linearGradient>
      </defs>
      <rect x="40" y="252" width="270" height="14" rx="6" fill={`url(#desk-${id})`} />
      <rect x="50" y="266" width="250" height="26" rx="4" fill={`url(#deskf-${id})`} />
    </g>
  );
}

function Arms({ id, kind }: { id: string; kind: CharacterKind }) {
  const p = PALETTE[kind];
  return (
    <g>
      <path d="M100 212 Q96 244 168 248" stroke={p.shirt2} strokeWidth="17" strokeLinecap="round" fill="none" />
      <path d="M182 212 Q196 240 200 248" stroke={p.shirt2} strokeWidth="17" strokeLinecap="round" fill="none" />
      <circle cx="172" cy="248" r="9" fill={`url(#skin-${id})`} />
      <circle cx="202" cy="248" r="9" fill={`url(#skin-${id})`} />
    </g>
  );
}

const Screen = ({ x, y, w, h, children }: { x: number; y: number; w: number; h: number; children?: ReactNode }) => (
  <g>
    <rect x={x} y={y} width={w} height={h} rx="7" fill={C.DD} stroke="#cfe4e0" strokeWidth="3" />
    {children}
    <rect x={x + w / 2 - 14} y={y + h} width="28" height="6" fill="#cfe4e0" />
  </g>
);

function DevProps() {
  return (
    <>
      <Screen x={215} y={186} w={92} h={64}>
        {[0, 1, 2, 3, 4].map((i) => (
          <rect key={i} x={224 + (i % 2) * 8} y={196 + i * 10} width={[48, 34, 56, 26, 40][i]} height="4" rx="2" fill={[C.S, C.A, '#6fc0cc', C.S, '#cfe4e0'][i]} />
        ))}
      </Screen>
      <Float x={28} y={50} amp={8} dur={4.2}><rect width="64" height="44" rx="12" fill="#fff" opacity=".95" /><text x="32" y="29" textAnchor="middle" fontSize="19" fontWeight="800" fill={C.P} fontFamily="monospace">{'</>'}</text></Float>
      <Float x={268} y={44} amp={6} dur={5} delay={0.4}><path d="M14 40h44a14 14 0 0 0 2-28 20 20 0 0 0-38-4 16 16 0 0 0-8 32z" fill="#fff" opacity=".95" /><path d="M36 20v18m-7-7 7-7 7 7" stroke={C.P} strokeWidth="3.5" fill="none" strokeLinecap="round" strokeLinejoin="round" /></Float>
      <Float x={14} y={150} amp={6} dur={4.6} delay={0.8}><ellipse cx="22" cy="10" rx="22" ry="8" fill={C.S} /><path d="M0 10v30c0 4.5 10 8 22 8s22-3.5 22-8V10" fill={C.A} /><ellipse cx="22" cy="10" rx="22" ry="8" fill="#fff" opacity=".35" /></Float>
      <Float x={302} y={130} amp={5} dur={3.8} rotate={8}><circle cx="16" cy="16" r="15" fill="#fff" opacity=".95" /><circle cx="16" cy="16" r="6" fill={C.P} /><path d="M16 0v7m0 18v7M0 16h7m18 0h7" stroke={C.P} strokeWidth="4" /></Float>
    </>
  );
}
function MarketingProps() {
  return (
    <>
      <rect x="215" y="150" width="104" height="100" rx="10" fill="#fff" opacity=".96" />
      {[26, 44, 36, 62, 78].map((h, i) => (
        <motion.rect key={i} x={228 + i * 17} width="11" rx="3" fill={i % 2 ? C.S : C.P} initial={{ height: 0, y: 236 }} animate={{ height: h, y: 236 - h }} transition={{ delay: 0.3 + i * 0.12, duration: 0.8 }} />
      ))}
      <path d="M226 200 L246 188 L264 194 L284 168 L306 160" stroke={C.D} strokeWidth="3" fill="none" strokeLinecap="round" strokeLinejoin="round" />
      <Float x={22} y={56} amp={8} dur={4.4} rotate={5}><path d="M6 26 44 8v50L6 40z" fill={C.A} /><rect x="0" y="24" width="14" height="18" rx="4" fill={C.P} /><path d="M52 18c8 6 8 22 0 30" stroke="#fff" strokeWidth="4" fill="none" strokeLinecap="round" /></Float>
      <Float x={250} y={44} amp={6} dur={5} delay={0.5}><rect width="66" height="40" rx="12" fill="#fff" opacity=".95" /><path d="M20 12l8 9 14-12" stroke={C.P} strokeWidth="4" fill="none" strokeLinecap="round" strokeLinejoin="round" /><text x="48" y="28" fontSize="16" fill={C.S}>♥</text></Float>
      <Float x={8} y={150} amp={6} dur={3.9} delay={0.9}><circle cx="24" cy="24" r="22" fill="#fff" opacity=".95" /><text x="24" y="31" textAnchor="middle" fontSize="22" fontWeight="800" fill={C.P}>@</text></Float>
    </>
  );
}
function CreativeProps() {
  return (
    <>
      <Screen x={212} y={170} w={100} h={80}>
        <circle cx="250" cy="200" r="16" fill={C.S} />
        <rect x="262" y="206" width="40" height="30" rx="6" fill={C.P} />
        <path d="M222 238 l22-24 16 18 12-10 22 16z" fill={C.A} />
      </Screen>
      <Float x={18} y={48} amp={8} dur={4.3} rotate={6}><path d="M30 2C12 2 0 14 0 28c0 12 10 20 22 20 6 0 8-5 5-9-3-5 1-9 7-9h10c9 0 14-6 14-13C58 12 46 2 30 2z" fill="#fff" opacity=".96" /><circle cx="16" cy="22" r="5" fill={C.P} /><circle cx="30" cy="14" r="5" fill={C.S} /><circle cx="44" cy="20" r="5" fill={C.A} /></Float>
      <Float x={266} y={40} amp={6} dur={4.8} delay={0.4}><rect width="58" height="40" rx="9" fill="#fff" opacity=".96" /><circle cx="29" cy="21" r="12" fill={C.D} /><circle cx="29" cy="21" r="6" fill="#6fc0cc" /><rect x="8" y="-5" width="16" height="8" rx="3" fill="#fff" /></Float>
      <Float x={12} y={150} amp={6} dur={3.8} delay={0.7}><circle cx="24" cy="24" r="22" fill="#fff" opacity=".96" /><path d="M19 14l16 10-16 10z" fill={C.P} /></Float>
      <Float x={300} y={124} amp={5} dur={4.1} rotate={10}><path d="M6 40 34 8l8 8-28 32-12 4z" fill={C.A} /></Float>
    </>
  );
}
function AdminProps() {
  return (
    <>
      <rect x="206" y="146" width="120" height="104" rx="10" fill="#fff" opacity=".96" />
      {[0, 1].map((i) => (
        <g key={i}>
          <circle cx={240 + i * 52} cy="186" r="19" stroke="#dbe9e5" strokeWidth="7" fill="none" />
          <motion.circle cx={240 + i * 52} cy="186" r="19" stroke={i ? C.S : C.P} strokeWidth="7" fill="none" strokeLinecap="round" strokeDasharray="120" initial={{ strokeDashoffset: 120 }} animate={{ strokeDashoffset: i ? 40 : 22 }} transition={{ duration: 1.4, delay: 0.3 }} transform={`rotate(-90 ${240 + i * 52} 186)`} />
        </g>
      ))}
      {[0, 1, 2, 3].map((i) => (
        <rect key={i} x={222 + i * 24} y={232 - [10, 16, 12, 22][i]} width="14" height={[10, 16, 12, 22][i]} rx="3" fill={i % 2 ? C.S : C.A} />
      ))}
      <Float x={22} y={52} amp={7} dur={4.4}>{[0, 1, 2].map((i) => <circle key={i} cx={14 + i * 18} cy={i % 2 ? 22 : 12} r="13" fill={[C.P, C.S, C.A][i]} stroke="#fff" strokeWidth="3" />)}</Float>
      <Float x={258} y={30} amp={6} dur={4.9} delay={0.5}><path d="M12 6h26v14a13 13 0 0 1-26 0zM2 8h10v8a8 8 0 0 1-8-4zM38 8h10v4a8 8 0 0 1-8 4zM25 33v8m-9 0h18" fill="#fff" stroke="#fff" strokeWidth="3" strokeLinejoin="round" opacity=".96" /><path d="M12 6h26v14a13 13 0 0 1-26 0z" fill={C.A} /></Float>
      <Float x={10} y={150} amp={6} dur={4} delay={0.9}><rect width="48" height="40" rx="9" fill="#fff" opacity=".96" /><path d="M8 28l9-9 8 6 15-14" stroke={C.P} strokeWidth="4" fill="none" strokeLinecap="round" strokeLinejoin="round" /></Float>
    </>
  );
}

export const CharacterArt = memo(function CharacterArt({ kind }: { kind: CharacterKind }) {
  const id = useId().replace(/:/g, '');
  const Props = { development: DevProps, marketing: MarketingProps, creative: CreativeProps, admin: AdminProps }[kind];
  return (
    <svg viewBox="0 0 340 310" className="h-full w-full overflow-visible" role="img" aria-label={`${kind} team illustration`}>
      <defs>
        <radialGradient id={`stage-${id}`} cx=".5" cy=".5" r=".6"><stop offset="0" stopColor={C.S} stopOpacity=".55" /><stop offset="1" stopColor={C.P} stopOpacity="0" /></radialGradient>
      </defs>
      <ellipse cx="175" cy="296" rx="150" ry="16" fill={`url(#stage-${id})`} />
      <ellipse cx="175" cy="300" rx="110" ry="8" fill="#000" opacity=".16" />
      <motion.g animate={{ y: [0, -3, 0] }} transition={{ duration: 3.2, repeat: Infinity, ease: 'easeInOut' }}>
        <Person kind={kind} uid={id} />
      </motion.g>
      <Desk id={id} />
      <Arms id={id} kind={kind} />
      <Props />
    </svg>
  );
});

/** Floating team character with subtle pointer-driven 3D tilt. */
export function ThreeDCharacter({ kind, className, tilt = true }: { kind: CharacterKind; className?: string; tilt?: boolean }) {
  const reduce = useReducedMotion();
  const rx = useMotionValue(0);
  const ry = useMotionValue(0);
  const srx = useSpring(rx, { stiffness: 120, damping: 14 });
  const sry = useSpring(ry, { stiffness: 120, damping: 14 });
  return (
    <div
      className={cn('scene-3d', className)}
      onPointerMove={(e) => {
        if (!tilt || reduce || e.pointerType === 'touch') return;
        const r = e.currentTarget.getBoundingClientRect();
        ry.set(((e.clientX - r.left) / r.width - 0.5) * 16);
        rx.set(-((e.clientY - r.top) / r.height - 0.5) * 12);
      }}
      onPointerLeave={() => {
        rx.set(0);
        ry.set(0);
      }}
    >
      <motion.div className="h-full w-full gpu" style={{ rotateX: srx, rotateY: sry, filter: 'drop-shadow(0 14px 18px rgb(9 58 67 / .22))', transformStyle: 'preserve-3d' }}>
        <CharacterArt kind={kind} />
      </motion.div>
    </div>
  );
}
