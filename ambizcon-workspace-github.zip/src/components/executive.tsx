'use client';
import { useMemo } from 'react';
import { StatsCard } from './ui';
import { useClients, useSetting, useTasks, useUsers } from '@/lib/hooks';
import { DEFAULT_WEIGHTS, normalizeWeights, rankBy, taskToWorkItem, monthPeriod, type ScoringWeights } from '@/lib/performance';
import { effStatus, type Item } from '@/lib/stats';
import { isOverdue } from '@/lib/taskflow';
import { expiryInfo, todayISO } from '@/lib/utils';

const WINDOW = 30;

/** Executive overview cards for the admin dashboard. Everything is computed from recorded data; nothing is typed in. */
export function ExecutiveOverview({ items }: { items: Item[] }) {
  const clients = useClients().data ?? [];
  const users = useUsers().data ?? [];
  const tasks = useTasks().data ?? [];
  const weights = useSetting<ScoringWeights>('scoring', DEFAULT_WEIGHTS, (r) => normalizeWeights(r as Partial<ScoringWeights>)).value;
  const today = todayISO();
  const ym = today.slice(0, 7);

  const k = useMemo(() => {
    // module records (backups, SEO, creative work…) and the shared task list count together
    let open = 0, pending = 0, progress = 0, overdue = 0, doneMonth = 0;
    for (const { m, rec } of items) {
      const st = effStatus(m, rec);
      if (!st || st === 'Cancelled') continue;
      if (st === 'Completed') { if (String(rec.updated_at).startsWith(ym)) doneMonth++; continue; }
      open++;
      if (st === 'Pending') pending++; else if (st === 'In Progress') progress++; else if (st === 'Overdue' && !m.expiryField) overdue++;
    }
    for (const t of tasks) {
      if (t.status === 'Cancelled') continue;
      if (t.status === 'Completed') { if (String(t.completed_at ?? '').startsWith(ym)) doneMonth++; continue; }
      open++;
      if (isOverdue(t, today)) overdue++; else if (['New', 'Assigned'].includes(t.status)) pending++; else progress++;
    }
    const expiring = (keys: string[]) => items.filter(({ m, rec }) => keys.includes(m.key) && effStatus(m, rec) !== 'Completed').reduce((a, { m, rec }) => a + m.fields.filter((f) => f.type === 'expiry').filter((f) => { const i = expiryInfo(rec[f.key]); return i && i.days <= WINDOW; }).length, 0);
    const domainHosting = expiring(['website-expiry']);
    const ssl = expiring(['ssl-expiry']);
    const tools = expiring(['tools-expiry']);
    const smtp = expiring(['smtp-expiry']);

    const seo = items.filter((x) => x.m.key === 'seo');
    const seoOpen = seo.filter((x) => { const s = effStatus(x.m, x.rec); return s && s !== 'Completed' && s !== 'Cancelled'; }).length;
    const seoDoneMonth = seo.filter((x) => effStatus(x.m, x.rec) === 'Completed' && String(x.rec.completion_date ?? x.rec.updated_at).startsWith(ym)).length;
    const perf = items.filter((x) => x.m.key === 'performance');
    const monthName = new Date().toLocaleString('en-US', { month: 'long' });
    const sitesWithPerf = new Set(perf.filter((x) => x.rec.report_month === monthName && String(x.rec.report_year) === today.slice(0, 4)).map((x) => `${x.rec.client_id}`)).size;

    // active clients with a website that have no daily check logged today
    const checkedToday = new Set(items.filter((x) => x.m.key === 'daily-check' && x.rec.check_date === today).map((x) => x.rec.client_id));
    const sites = clients.filter((c) => c.status === 'active' && c.website);
    const missingChecks = sites.filter((c) => !checkedToday.has(c.id)).length;
    return { open, pending, progress, overdue, doneMonth, domainHosting, ssl, tools, smtp, seoOpen, seoDoneMonth, sitesWithPerf, sites: sites.length, missingChecks };
  }, [items, tasks, clients, today, ym]);

  const perf = useMemo(() => {
    const [y, m] = today.split('-').map(Number);
    const d = new Date(Date.UTC(y, m - 2, 1));
    const p = monthPeriod(d.getUTCFullYear(), d.getUTCMonth());
    const teams = rankBy(tasks.map((t) => taskToWorkItem(t)).filter((x) => x.assignee), (x) => x.team, p, today, weights).filter((r) => r.metrics.score !== null);
    const avg = teams.length ? Math.round(teams.reduce((a, r) => a + (r.metrics.score ?? 0), 0) / teams.length) : null;
    return { avg, label: p.label };
  }, [tasks, weights, today]);

  const activeEmployees = users.filter((u) => u.status === 'active' && u.team !== 'admin').length;
  return (
    <section aria-labelledby="exec-h" className="mb-6">
      <h2 id="exec-h" className="mb-3 text-lg font-extrabold">Executive overview</h2>
      <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
        <StatsCard label="Active clients" value={clients.filter((c) => c.status === 'active').length} icon="Building2" href="/clients" />
        <StatsCard label="Active employees" value={activeEmployees} icon="Users" accent="secondary" href="/admin/users" />
        <StatsCard label="Open tasks" value={k.open} icon="ClipboardList" accent="accent" href="/tasks" hint="Modules + task list" />
        <StatsCard label="Pending" value={k.pending} icon="Clock" accent="accent" href="/tasks" />
        <StatsCard label="In progress" value={k.progress} icon="Loader2" href="/tasks" />
        <StatsCard label="Overdue" value={k.overdue} icon="AlertTriangle" accent="dark" href="/tasks" />
        <StatsCard label="Completed this month" value={k.doneMonth} icon="CircleCheck" accent="secondary" hint="Completed work is listed in reports" />
        <StatsCard label="Team performance" value={perf.avg ?? 0} icon="Trophy" accent="primary" href="/admin/performance" hint={perf.avg === null ? `Not enough completed work in ${perf.label}` : `Average team score, ${perf.label}`} />
        <StatsCard label={`Domain & hosting expiring (${WINDOW}d)`} value={k.domainHosting} icon="Globe" accent="dark" href="/admin/expiry-management" />
        <StatsCard label={`SSL expiring (${WINDOW}d)`} value={k.ssl} icon="ShieldCheck" accent="dark" href="/admin/expiry-management" />
        <StatsCard label={`Tools expiring (${WINDOW}d)`} value={k.tools} icon="Wrench" accent="accent" href="/admin/expiry-management" />
        <StatsCard label={`SMTP expiring (${WINDOW}d)`} value={k.smtp} icon="Mail" accent="accent" href="/admin/expiry-management" />
        <StatsCard label="SEO updates open" value={k.seoOpen} icon="SearchCheck" href="/development/seo-updates" hint={`${k.seoDoneMonth} completed this month`} />
        <StatsCard label="Performance reports this month" value={k.sitesWithPerf} icon="Gauge" accent="secondary" href="/development/website-performance" hint={`of ${k.sites} client websites`} />
        <StatsCard label="Daily checks missing today" value={k.missingChecks} icon="ListChecks" accent="dark" href="/development/daily-checks" hint={`of ${k.sites} client websites`} />
      </div>
      <p className="mt-2 text-xs text-muted">Counts combine module records and the shared task list. Daily checks are matched to clients with a website; if a website has no check logged today it is counted as missing.</p>
    </section>
  );
}
