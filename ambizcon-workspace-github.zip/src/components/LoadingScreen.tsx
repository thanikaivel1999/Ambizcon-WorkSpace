'use client';
import { motion } from 'framer-motion';
import { CompanyLogo } from './CompanyLogo';

export function LoadingScreen({ label = 'Loading your workspace…' }: { label?: string }) {
  return (
    <div className="bg-mesh grid min-h-screen place-items-center" role="status" aria-live="polite">
      <div className="flex flex-col items-center gap-5">
        <div className="relative grid h-28 w-28 place-items-center">
          <motion.span className="absolute inset-0 rounded-full border-2 border-primary/30 border-t-primary" animate={{ rotate: 360 }} transition={{ duration: 1.2, repeat: Infinity, ease: 'linear' }} />
          <CompanyLogo size={64} />
        </div>
        <p className="text-sm font-medium text-muted">{label}</p>
      </div>
    </div>
  );
}
