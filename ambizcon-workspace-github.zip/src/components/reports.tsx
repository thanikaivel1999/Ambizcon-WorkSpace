'use client';
import { useMemo, useState } from 'react';
import { Icon } from './Icon';
import { EmptyState } from './ui';
import { downloadCsv, toCsv } from '@/lib/csv';
import type { Lookups } from '@/lib/hooks';
import type { ModuleDef } from '@/lib/modules';
import { computeMetrics, DEFAULT_WEIGHTS, lastThreeCompletedMonths, rankBy, taskToWorkItem, type ScoringWeights } from '@/lib/performance';
import { dueOf, effStatus, monthRange, weekRange, type Item } from '@/lib/stats';
import { isOverdue } from '@/lib/taskflow';
import type { Rec, Task } from '@/lib/types';
import { addDays, expiryInfo, isoDate, todayISO } from '@/lib/utils';

type Cell = string | number | null;
interface Table { columns: string[]; rows: Cell[][]; note?: string }
interface Ctx { items: Item[]; tasks: Task[]; lk: Lookups; weights: ScoringWeights; from: string; to: string; today: string }
interface ReportDef { key: string; title: string; build: (c: Ctx) => Table }

const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);
const pct = (v: number | null) => (v === null ? '' : `${Math.round(v * 100)}%`);
const num1 = (v: number | null) => (v === null ? '' : Math.round(v * 10) / 10);
const inRange = (d: string | null | undefined, c: Ctx) => !!d && String(d).slice(0, 10) >= c.from && String(d).slice(0, 10) <= c.to;
const title = (m: ModuleDef, r: Rec, lk: Lookups) => (m.titleField === 'client_id' ? lk.client(r.client_id) : String(r[m.titleField] ?? m.title));
const workItems = (c: Ctx) => c.items.filter(({ m, rec }) => m.statusField && !m.readonly);

const REPORTS: ReportDef[] = [
  {
    key: 'work', title: 'Daily / weekly work status',
    build: (c) => {
      const mod = workItems(c).filter(({ m, rec }) => inRange(dueOf(m, rec) ?? rec.created_at, c) || inRange(rec.updated_at, c)).map(({ m, rec }) => [cap(m.team), m.title, title(m, rec, c.lk), c.lk.client(rec.client_id), c.lk.user(rec.assigned_to), effStatus(m, rec), dueOf(m, rec), 'Module record'] as Cell[]);
      const tk = c.tasks.filter((t) => inRange(t.due_date, c) || inRange(t.updated_at, c)).map((t) => [cap(t.team), 'Task', t.title, c.lk.client(t.client_id), c.lk.user(t.assigned_to), isOverdue(t, c.today) ? 'Overdue' : t.status, t.due_date, 'Task list'] as Cell[]);
      return { columns: ['Team', 'Module', 'Title', 'Client', 'Assigned to', 'Status', 'Due', 'Source'], rows: [...mod, ...tk] };
    },
  },
  {
    key: 'team-perf', title: 'Monthly team performance',
    build: (c) => {
      const items = c.tasks.map((t) => taskToWorkItem(t)).filter((x) => x.assignee);
      const r = rankBy(items, (x) => x.team, { from: c.from, to: c.to, label: '' }, c.today, c.weights);
      return { columns: ['Team', 'Assigned', 'Completed', 'Pending', 'Overdue', 'On-time rate', 'Avg completion days', 'Score'], rows: r.map(({ key, metrics: m }) => [cap(key), m.assigned, m.completed, m.pending, m.overdue, pct(m.onTimeRate), num1(m.avgCompletionDays), m.score ?? 'too few completed items']), note: 'Calculated from the shared task list for the selected dates.' };
    },
  },
  {
    key: 'emp-perf', title: 'Employee performance',
    build: (c) => {
      const items = c.tasks.map((t) => taskToWorkItem(t)).filter((x) => x.assignee);
      const r = rankBy(items, (x) => x.assignee, { from: c.from, to: c.to, label: '' }, c.today, c.weights);
      return { columns: ['Employee', 'Team', 'Assigned', 'Completed', 'Pending', 'Overdue', 'On-time rate', 'Avg days', 'Avg quality (1–5)', 'Verified rate', 'Score'], rows: r.map(({ key, metrics: m }) => [c.lk.user(key), cap(c.lk.userById(key)?.team ?? ''), m.assigned, m.completed, m.pending, m.overdue, pct(m.onTimeRate), num1(m.avgCompletionDays), m.quality === null ? 'no reviews' : num1(m.quality), pct(m.verifiedRate), m.score ?? 'too few completed items']) };
    },
  },
  {
    key: 'rank3', title: 'Three-month employee ranking',
    build: (c) => {
      const p = lastThreeCompletedMonths(c.today);
      const items = c.tasks.map((t) => taskToWorkItem(t)).filter((x) => x.assignee);
      const r = rankBy(items, (x) => x.assignee, p, c.today, c.weights);
      return { columns: ['Rank', 'Employee', 'Team', 'Completed', 'On-time rate', 'Verified', 'Score'], rows: r.map(({ key, metrics: m }, i) => [m.eligible ? i + 1 : '', c.lk.user(key), cap(c.lk.userById(key)?.team ?? ''), m.completed, pct(m.onTimeRate), m.verifiedCount, m.score ?? 'too few completed items']), note: `Fixed window: ${p.label} (${p.from} to ${p.to}). The date filter does not apply to this report.` };
    },
  },
  {
    key: 'pending', title: 'Pending and overdue tasks',
    build: (c) => {
      const mod = workItems(c).filter(({ m, rec }) => { const s = effStatus(m, rec); return s && s !== 'Completed' && s !== 'Cancelled' && !m.expiryField; }).map(({ m, rec }) => [cap(m.team), m.title, title(m, rec, c.lk), c.lk.client(rec.client_id), c.lk.user(rec.assigned_to), effStatus(m, rec), dueOf(m, rec), (rec.priority as string) ?? ''] as Cell[]);
      const tk = c.tasks.filter((t) => !['Completed', 'Cancelled'].includes(t.status)).map((t) => [cap(t.team), 'Task', t.title, c.lk.client(t.client_id), c.lk.user(t.assigned_to), isOverdue(t, c.today) ? 'Overdue' : t.status, t.due_date, t.priority] as Cell[]);
      const rows = [...mod, ...tk].sort((a, b) => Number(b[5] === 'Overdue') - Number(a[5] === 'Overdue') || String(a[6] ?? '9').localeCompare(String(b[6] ?? '9')));
      return { columns: ['Team', 'Module', 'Title', 'Client', 'Assigned to', 'Status', 'Due', 'Priority'], rows, note: 'All open work as of today; the date filter does not apply.' };
    },
  },
  {
    key: 'backups', title: 'Website backup status',
    build: (c) => {
      const latest = new Map<string, Rec>();
      c.items.filter((x) => x.m.key === 'backups').forEach(({ rec }) => { const k = `${rec.client_id}|${rec.website}`; const p = latest.get(k); if (!p || String(rec.backup_date) > String(p.backup_date)) latest.set(k, rec); });
      return { columns: ['Website', 'Client', 'Latest backup', 'Type', 'Verification', 'Verified by', 'Next scheduled', 'Next backup overdue'], rows: [...latest.values()].map((r) => [r.website, c.lk.client(r.client_id), r.backup_date, r.backup_type, r.verification, c.lk.user(r.verified_by), r.next_backup_date, r.next_backup_date && r.next_backup_date < c.today ? 'Yes' : 'No']), note: 'Only "Verified" backups have been checked by a person.' };
    },
  },
  {
    key: 'seo', title: 'Website SEO updates',
    build: (c) => ({ columns: ['Date assigned', 'Website', 'Page', 'Client', 'Task type', 'Focus keyword', 'Indexing', 'Status', 'Assigned to', 'Completed'], rows: c.items.filter((x) => x.m.key === 'seo' && (inRange(x.rec.date_assigned ?? x.rec.created_at, c) || inRange(x.rec.completion_date, c))).map(({ m, rec }) => [rec.date_assigned, rec.website, rec.page_url, c.lk.client(rec.client_id), rec.seo_type, rec.keyword, rec.indexing_status, effStatus(m, rec), c.lk.user(rec.assigned_to), rec.completion_date]) }),
  },
  {
    key: 'blogs', title: 'Blog publication counts',
    build: (c) => {
      const published = c.items.filter((x) => x.m.key === 'blogs' && x.rec.blog_status === 'Published' && x.rec.publish_verified && inRange(x.rec.published_date, c));
      const mk = c.items.filter((x) => x.m.key === 'blog-youtube' && x.rec.content_type === 'Blog' && x.rec.status === 'Completed' && inRange(x.rec.publication_date, c));
      const ids = new Set([...published, ...mk].map((x) => x.rec.client_id));
      return { columns: ['Client', 'Development tracker (verified published)', 'Marketing sheet (completed blogs)'], rows: [...ids].map((id) => [c.lk.client(id), published.filter((x) => x.rec.client_id === id).length, mk.filter((x) => x.rec.client_id === id).length]), note: 'A blog counts only when it is marked Published, verified and has a publication date in the range.' };
    },
  },
  {
    key: 'perf-compare', title: 'Website performance comparison',
    build: (c) => {
      const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
      const g = new Map<string, Rec[]>();
      c.items.filter((x) => x.m.key === 'performance').forEach(({ rec }) => g.set(`${rec.client_id}|${rec.website}`, [...(g.get(`${rec.client_id}|${rec.website}`) ?? []), rec]));
      const ch = (a?: number, b?: number) => (a !== undefined && b !== undefined && b > 0 ? `${(((a - b) / b) * 100).toFixed(1)}%` : '');
      const rows: Cell[][] = [];
      for (const [k, rs] of g) {
        const sorted = [...rs].sort((a, b) => Number(b.report_year) * 12 + MONTHS.indexOf(b.report_month) - (Number(a.report_year) * 12 + MONTHS.indexOf(a.report_month)));
        const cur = sorted[0]; if (!cur) continue;
        const idx = Number(cur.report_year) * 12 + MONTHS.indexOf(cur.report_month);
        const prev = sorted.find((r) => Number(r.report_year) * 12 + MONTHS.indexOf(r.report_month) === idx - 1);
        const yoy = sorted.find((r) => Number(r.report_year) * 12 + MONTHS.indexOf(r.report_month) === idx - 12);
        rows.push([cur.website, c.lk.client(cur.client_id), `${cur.report_month} ${cur.report_year}`, cur.sessions, prev ? Number(prev.sessions) : '', ch(Number(cur.sessions), prev ? Number(prev.sessions) : undefined), yoy ? Number(yoy.sessions) : '', ch(Number(cur.sessions), yoy ? Number(yoy.sessions) : undefined), cur.organic_clicks]);
        void k;
      }
      return { columns: ['Website', 'Client', 'Latest month', 'Sessions', 'Previous month', 'Month-over-month', 'Same month last year', 'Year-over-year', 'Organic clicks'], rows, note: 'Compares the latest entered month with the previous month and the same month a year earlier. If the latest month is still running it is month-to-date and not like-for-like.' };
    },
  },
  {
    key: 'domain-ssl', title: 'Domain and SSL expiry',
    build: (c) => expiryRows(c, ['website-expiry', 'ssl-expiry', 'domain-access']),
  },
  { key: 'tool-smtp', title: 'Tool and SMTP expiry', build: (c) => expiryRows(c, ['tools-expiry', 'smtp-expiry']) },
  {
    key: 'clients', title: 'Client activity',
    build: (c) => ({
      columns: ['Client', 'Type', 'Location', 'Open module records', 'Open tasks', 'Completed in range', 'Last activity'],
      rows: c.lk.clients.filter((x) => x.status === 'active').map((cl) => {
        const mine = c.items.filter((x) => x.rec.client_id === cl.id);
        const open = mine.filter(({ m, rec }) => { const s = effStatus(m, rec); return s && s !== 'Completed' && s !== 'Cancelled' && !m.expiryField; }).length;
        const done = mine.filter(({ m, rec }) => effStatus(m, rec) === 'Completed' && inRange(rec.updated_at, c)).length + c.tasks.filter((t) => t.client_id === cl.id && t.status === 'Completed' && inRange(t.completed_at, c)).length;
        const t = c.tasks.filter((x) => x.client_id === cl.id);
        const last = [...mine.map((x) => x.rec.updated_at), ...t.map((x) => x.updated_at)].sort().at(-1);
        return [cl.name, cl.client_type, cl.location, open, t.filter((x) => !['Completed', 'Cancelled'].includes(x.status)).length, done, last ? String(last).slice(0, 10) : ''];
      }),
    }),
  },
  {
    key: 'deliverables', title: 'Marketing and creative deliverables',
    build: (c) => {
      const cr = c.items.filter((x) => x.m.team === 'creative' && x.m.acceptsRequests && x.rec.status === 'Completed' && inRange(x.rec.completion_date ?? x.rec.updated_at, c)).map(({ m, rec }) => ['Creative', m.title, rec.task, c.lk.client(rec.client_id), c.lk.user(rec.assigned_to), rec.completion_date ?? String(rec.updated_at).slice(0, 10), rec.output_link ?? ''] as Cell[]);
      const mk = c.items.filter((x) => x.m.key === 'spot-calendar' && x.rec.calendar_status === 'Published' && inRange(x.rec.content_date, c)).map(({ rec }) => ['Marketing', 'Content calendar', rec.content_title, c.lk.client(rec.client_id), c.lk.user(rec.assigned_to), rec.content_date, rec.output_link ?? ''] as Cell[]);
      const em = c.items.filter((x) => x.m.key === 'mailer-scheduler' && x.rec.campaign_status === 'Sent' && inRange(x.rec.scheduled_date, c)).map(({ rec }) => ['Marketing', 'Email campaign sent', rec.campaign, c.lk.client(rec.client_id), c.lk.user(rec.assigned_to), rec.scheduled_date, rec.output_link ?? ''] as Cell[]);
      return { columns: ['Team', 'Type', 'Title', 'Client', 'Owner', 'Date', 'Output link'], rows: [...cr, ...mk, ...em] };
    },
  },
];

function expiryRows(c: Ctx, keys: string[]): Table {
  const rows: Cell[][] = [];
  for (const { m, rec } of c.items.filter((x) => keys.includes(x.m.key))) for (const f of m.fields.filter((x) => x.type === 'expiry')) {
    const info = expiryInfo(rec[f.key]);
    rows.push([m.title, f.label, String(rec[m.titleField] ?? ''), c.lk.client(rec.client_id), rec[f.key] ?? 'Unknown', rec.date_confidence ?? (rec[f.key] ? 'Confirmed' : 'Unknown'), info ? info.days : '', c.lk.user(rec.assigned_to), effStatus(m, rec), rec.renewal_url ?? '']);
  }
  rows.sort((a, b) => Number(a[6] === '' ? 99999 : a[6]) - Number(b[6] === '' ? 99999 : b[6]));
  return { columns: ['Register', 'Date', 'Name', 'Client', 'Expiry', 'Confidence', 'Days left', 'Responsible', 'Renewal status', 'Renewal link'], rows, note: 'All dates as recorded. Unknown dates are shown as Unknown, never guessed. The date filter does not apply.' };
}

type Preset = 'today' | 'week' | 'month' | 'last-month' | 'custom';
function presetRange(p: Preset): { from: string; to: string } {
  const now = new Date();
  if (p === 'today') return { from: todayISO(), to: todayISO() };
  if (p === 'week') return weekRange();
  if (p === 'month') return monthRange();
  if (p === 'last-month') return monthRange(new Date(now.getFullYear(), now.getMonth() - 1, 1));
  return { from: addDays(-30), to: isoDate() };
}

export function ReportCenter({ items, tasks, lk, weights = DEFAULT_WEIGHTS }: { items: Item[]; tasks: Task[]; lk: Lookups; weights?: ScoringWeights }) {
  const [key, setKey] = useState(REPORTS[0].key);
  const [preset, setPreset] = useState<Preset>('month');
  const [custom, setCustom] = useState(presetRange('custom'));
  const range = preset === 'custom' ? custom : presetRange(preset);
  const today = todayISO();
  const def = REPORTS.find((r) => r.key === key)!;
  const table = useMemo(() => def.build({ items, tasks, lk, weights, from: range.from, to: range.to, today }), [def, items, tasks, lk, weights, range.from, range.to, today]);
  return (
    <div className="panel p-4">
      <div className="mb-3 flex flex-wrap items-center gap-2" role="group" aria-label="Report options">
        <select className="input !w-auto" aria-label="Report" value={key} onChange={(e) => setKey(e.target.value)}>{REPORTS.map((r) => <option key={r.key} value={r.key}>{r.title}</option>)}</select>
        <select className="input !w-auto" aria-label="Date range" value={preset} onChange={(e) => setPreset(e.target.value as Preset)}>
          <option value="today">Today</option><option value="week">This week</option><option value="month">This month</option><option value="last-month">Last month</option><option value="custom">Custom range</option>
        </select>
        {preset === 'custom' && <><input type="date" className="input !w-auto" aria-label="From" value={custom.from} onChange={(e) => setCustom({ ...custom, from: e.target.value })} /><input type="date" className="input !w-auto" aria-label="To" value={custom.to} onChange={(e) => setCustom({ ...custom, to: e.target.value })} /></>}
        <span className="text-xs text-muted">{range.from} → {range.to}</span>
        <button className="btn-ghost ml-auto" disabled={!table.rows.length} onClick={() => downloadCsv(`${def.key}-${range.from}-to-${range.to}`, toCsv(table.rows, table.columns.map((label, i) => ({ label, value: (r: Cell[]) => r[i] }))))}><Icon name="Download" size={16} />Export CSV</button>
      </div>
      {table.note && <p className="mb-2 rounded-lg bg-primary/10 p-2 text-xs text-muted">{table.note}</p>}
      {table.rows.length === 0 ? <EmptyState title="Nothing to report" message="No records match this report and date range." /> : (
        <div className="max-h-[60vh] overflow-auto rounded-xl border border-line/10">
          <table className="w-full min-w-max text-sm">
            <thead className="sticky top-0 bg-surface2/95 backdrop-blur"><tr>{table.columns.map((h) => <th key={h} className="th">{h}</th>)}</tr></thead>
            <tbody>{table.rows.map((r, i) => <tr key={i} className="border-t border-line/10 hover:bg-primary/5">{r.map((v, j) => <td key={j} className="td">{v === null || v === '' ? <span className="text-muted">—</span> : String(v).startsWith('http') ? <a href={String(v)} target="_blank" rel="noopener noreferrer" className="font-semibold text-primary hover:underline dark:text-primary-200">Open</a> : String(v)}</td>)}</tr>)}</tbody>
          </table>
        </div>
      )}
      <p className="mt-2 text-xs text-muted">{table.rows.length} row{table.rows.length === 1 ? '' : 's'}</p>
    </div>
  );
}
