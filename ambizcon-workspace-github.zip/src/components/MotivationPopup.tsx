'use client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { CompanyLogo } from './CompanyLogo';
import { useAuth } from './providers';
import { ThreeDCharacter, type CharacterKind } from './ThreeDCharacter';
import { Modal } from './ui';
import { api } from '@/lib/data';
import { pickMotivation } from '@/lib/motivations';
import { TEAM_LABEL } from '@/lib/access';
import { todayISO } from '@/lib/utils';
import type { Motivation } from '@/lib/types';
import { playCue } from '@/lib/sound';

const SUB: Record<string, string> = {
  development: 'Build it clean, ship it safe.',
  marketing: 'Make every message meaningful.',
  creative: 'Make something worth remembering.',
  admin: 'Lead the day with clarity.',
};

interface Ctx { motivation: Motivation | null; open(): void }
const MotCtx = createContext<Ctx>({ motivation: null, open() {} });
export const useMotivation = () => useContext(MotCtx);

/** Picks today's slogan, shows it once on first visit of the day, and exposes it for re-opening. */
export function MotivationProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const handled = useRef<string | null>(null);
  const all = useQuery({ queryKey: ['motivations'], queryFn: () => api.motivations.list(), enabled: !!user });
  const shown = useQuery({ queryKey: ['motivation-shown', user?.id], queryFn: () => api.motivations.shown(user!.id), enabled: !!user });
  const today = todayISO();
  const motivation = useMemo(() => (user && all.data && shown.data ? pickMotivation(all.data, user.team, shown.data, today, user.id) : null), [user, all.data, shown.data, today]);
  const firstToday = !!shown.data && !shown.data.some((s) => s.shown_on === today);

  useEffect(() => {
    if (!user || !motivation || !firstToday || handled.current === user.id + today) return;
    handled.current = user.id + today;
    setOpen(true);
    playCue('welcome');
    api.motivations.markShown(user.id, motivation.id, today).then(() => qc.invalidateQueries({ queryKey: ['motivation-shown'] })).catch(() => {});
  }, [user, motivation, firstToday, today, qc]);

  const openIt = useCallback(() => setOpen(true), []);
  return (
    <MotCtx.Provider value={{ motivation, open: openIt }}>
      {children}
      {user && motivation && <MotivationModal open={open} onClose={() => setOpen(false)} motivation={motivation} team={user.team} name={user.name} />}
    </MotCtx.Provider>
  );
}

export function MotivationCard({ motivation, team, compact = false }: { motivation: Motivation; team: string; compact?: boolean }) {
  const kind = (motivation.image ?? team) as CharacterKind;
  return (
    <div className={compact ? 'flex flex-col items-center gap-3 text-center sm:flex-row sm:text-left' : 'flex flex-col items-center text-center'}>
      <ThreeDCharacter kind={kind} className={compact ? 'h-40 w-44 shrink-0' : 'mx-auto h-52 w-60'} />
      <div>
        <motion.blockquote initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="text-xl font-extrabold leading-snug sm:text-2xl">
          “{motivation.message}”
        </motion.blockquote>
        <div className="mt-2 text-sm font-bold uppercase tracking-widest text-primary">{TEAM_LABEL[team as keyof typeof TEAM_LABEL]} Team</div>
        <p className="mt-1 text-sm text-muted">{SUB[team]}</p>
      </div>
    </div>
  );
}

function MotivationModal({ open, onClose, motivation, team, name }: { open: boolean; onClose: () => void; motivation: Motivation; team: string; name: string }) {
  return (
    <Modal open={open} onClose={onClose} title="Today's motivation" size="md" footer={<button className="btn-primary px-6" onClick={onClose}>Let&apos;s Get Started</button>}>
      <div className="relative">
        <div className="pointer-events-none absolute -top-10 left-1/2 h-48 w-48 -translate-x-1/2 rounded-full bg-secondary/25 blur-3xl" />
        <div className="relative mb-3 flex items-center justify-between text-xs text-muted">
          <CompanyLogo size={28} animated={false} />
          <span>{new Date().toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' })}</span>
        </div>
        <p className="relative mb-1 text-center text-sm text-muted">Hello, {name.split(' ')[0]}</p>
        <MotivationCard motivation={motivation} team={team} />
      </div>
    </Modal>
  );
}
