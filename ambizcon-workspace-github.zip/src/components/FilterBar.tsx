'use client';
import { Icon } from './Icon';
import { TEAM_LABEL } from '@/lib/access';
import { EMPTY_FILTERS, isFiltered, type Filters } from '@/lib/filter';
import type { Lookups } from '@/lib/hooks';
import type { ModuleDef } from '@/lib/modules';
import { PRIORITIES, STATUSES } from '@/lib/types';

interface Props {
  m: ModuleDef;
  filters: Filters;
  onChange: (f: Filters) => void;
  lk: Lookups;
  years?: number[];
  count: number;
  total: number;
}

export function FilterBar({ m, filters, onChange, lk, years = [], count, total }: Props) {
  const set = (patch: Partial<Filters>) => onChange({ ...filters, ...patch });
  const hasUser = m.fields.some((f) => f.type === 'user');
  const hasClient = m.fields.some((f) => f.type === 'client');
  return (
    <div className="panel mb-4 p-3" role="search" aria-label={`Filter ${m.title}`}>
      <div className="grid grid-cols-2 gap-2 md:grid-cols-4 xl:grid-cols-8">
        <div className="relative col-span-2 xl:col-span-2">
          <Icon name="Search" size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
          <input className="input pl-9" placeholder={`Search ${m.title.toLowerCase()}…`} aria-label="Search records" value={filters.q} onChange={(e) => set({ q: e.target.value })} />
        </div>
        {m.statusField && (
          <select className="input" aria-label="Status" value={filters.status} onChange={(e) => set({ status: e.target.value })}>
            <option value="">All {m.statusLabel.toLowerCase()} values</option>
            {[...(m.fields.find((x) => x.key === m.statusField)?.options ?? (m.statusMap ? Array.from(new Set(Object.values(m.statusMap))) : STATUSES)), 'Overdue'].filter((v, i, a) => a.indexOf(v) === i).map((s) => <option key={s}>{s}</option>)}
          </select>
        )}
        {m.hasPriority && (
          <select className="input" aria-label="Priority" value={filters.priority} onChange={(e) => set({ priority: e.target.value })}>
            <option value="">All priorities</option>
            {PRIORITIES.map((p) => <option key={p}>{p}</option>)}
          </select>
        )}
        {hasUser && (
          <select className="input" aria-label="Assigned person" value={filters.assigned} onChange={(e) => set({ assigned: e.target.value })}>
            <option value="">All people</option>
            {lk.users.filter((u) => u.status === 'active' && (u.team === m.team || u.team === 'admin')).map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}
          </select>
        )}
        {hasClient && (
          <select className="input" aria-label="Client" value={filters.client} onChange={(e) => set({ client: e.target.value })}>
            <option value="">All clients</option>
            {lk.clients.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        )}
        {m.yearField && (
          <select className="input" aria-label="Year" value={filters.year} onChange={(e) => set({ year: e.target.value })}>
            <option value="">All years</option>
            {years.map((y) => <option key={y}>{y}</option>)}
          </select>
        )}
        <label className="flex items-center gap-1.5 text-xs text-muted"><span className="sr-only">From date</span><input type="date" className="input" aria-label="From date" title={m.dueField ? 'From (due / key date)' : 'From (created)'} value={filters.from} onChange={(e) => set({ from: e.target.value })} /></label>
        <label className="flex items-center gap-1.5 text-xs text-muted"><span className="sr-only">To date</span><input type="date" className="input" aria-label="To date" title="To" value={filters.to} onChange={(e) => set({ to: e.target.value })} /></label>
      </div>
      <div className="mt-2 flex flex-wrap items-center justify-between gap-2 text-xs text-muted">
        <span className="inline-flex items-center gap-2">
          <span className="rounded-full bg-primary/10 px-2 py-0.5 font-semibold text-primary dark:text-primary-200">Team: {TEAM_LABEL[m.team]}</span>
          Showing <b className="text-ink">{count}</b> of {total}
        </span>
        <button className="btn-ghost !px-2.5 !py-1 text-xs" disabled={!isFiltered(filters)} onClick={() => onChange(EMPTY_FILTERS)}><Icon name="RotateCcw" size={13} /> Reset filters</button>
      </div>
    </div>
  );
}
