'use client';
import { Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Legend, Line, LineChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';

/** Brand-derived series palette: primary, secondary, accent plus tints/shades of the same hues. */
export const CH = ['#13798A', '#8BA277', '#95A575', '#5fa9b8', '#46563b', '#0c4d58', '#b9c6a1'];

const tip = { contentStyle: { background: 'rgb(var(--surface))', border: '1px solid rgb(var(--line) / .25)', borderRadius: 12, color: 'rgb(var(--ink))', fontSize: 12, boxShadow: '0 12px 30px -10px rgb(0 0 0 / .3)' }, cursor: { fill: 'rgb(var(--primary) / .08)' } };
const axis = { tick: { fill: 'currentColor', fontSize: 11 }, axisLine: false, tickLine: false } as const;

export interface Series { key: string; name: string; color?: string }

function Box({ height, children }: { height: number; children: React.ReactElement }) {
  return <div className="w-full text-muted" style={{ height }}><ResponsiveContainer width="100%" height="100%">{children}</ResponsiveContainer></div>;
}

export function BarsChart({ data, series, xKey = 'name', height = 240, stacked = false, unit = '' }: { data: any[]; series: Series[]; xKey?: string; height?: number; stacked?: boolean; unit?: string }) {
  return (
    <Box height={height}>
      <BarChart data={data} margin={{ top: 6, right: 6, left: -18, bottom: 0 }}>
        <CartesianGrid stroke="currentColor" strokeOpacity={0.12} vertical={false} />
        <XAxis dataKey={xKey} {...axis} interval="preserveStartEnd" />
        <YAxis {...axis} unit={unit} />
        <Tooltip {...tip} />
        {series.length > 1 && <Legend iconType="circle" wrapperStyle={{ fontSize: 11 }} />}
        {series.map((s, i) => <Bar key={s.key} dataKey={s.key} name={s.name} fill={s.color ?? CH[i % CH.length]} stackId={stacked ? 'a' : undefined} radius={stacked ? 0 : [6, 6, 0, 0]} animationDuration={900} />)}
      </BarChart>
    </Box>
  );
}

export function LinesChart({ data, series, xKey = 'name', height = 240, area = false, unit = '' }: { data: any[]; series: Series[]; xKey?: string; height?: number; area?: boolean; unit?: string }) {
  const C = area ? AreaChart : LineChart;
  return (
    <Box height={height}>
      <C data={data} margin={{ top: 6, right: 6, left: -18, bottom: 0 }}>
        <defs>
          {series.map((s, i) => (
            <linearGradient key={s.key} id={`g-${s.key}`} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor={s.color ?? CH[i % CH.length]} stopOpacity=".45" /><stop offset="1" stopColor={s.color ?? CH[i % CH.length]} stopOpacity="0" /></linearGradient>
          ))}
        </defs>
        <CartesianGrid stroke="currentColor" strokeOpacity={0.12} vertical={false} />
        <XAxis dataKey={xKey} {...axis} interval="preserveStartEnd" />
        <YAxis {...axis} unit={unit} />
        <Tooltip {...tip} />
        {series.length > 1 && <Legend iconType="circle" wrapperStyle={{ fontSize: 11 }} />}
        {series.map((s, i) => area
          ? <Area key={s.key} type="monotone" dataKey={s.key} name={s.name} stroke={s.color ?? CH[i % CH.length]} strokeWidth={2.5} fill={`url(#g-${s.key})`} animationDuration={1100} />
          : <Line key={s.key} type="monotone" dataKey={s.key} name={s.name} stroke={s.color ?? CH[i % CH.length]} strokeWidth={2.5} dot={{ r: 3 }} activeDot={{ r: 5 }} animationDuration={1100} />)}
      </C>
    </Box>
  );
}

export function DonutChart({ data, height = 220, center }: { data: { name: string; value: number; color?: string }[]; height?: number; center?: React.ReactNode }) {
  const total = data.reduce((a, d) => a + d.value, 0);
  return (
    <div className="relative" style={{ height }}>
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie data={total ? data : [{ name: 'None', value: 1 }]} dataKey="value" nameKey="name" innerRadius="62%" outerRadius="88%" paddingAngle={total ? 3 : 0} stroke="none" animationDuration={1000}>
            {(total ? data : [{ name: 'None', value: 1, color: '#cfe0dc' }]).map((d, i) => <Cell key={d.name} fill={(d as any).color ?? CH[i % CH.length]} />)}
          </Pie>
          <Tooltip {...tip} />
          <Legend iconType="circle" wrapperStyle={{ fontSize: 11 }} />
        </PieChart>
      </ResponsiveContainer>
      {center && <div className="pointer-events-none absolute inset-0 grid place-items-center pb-6 text-center">{center}</div>}
    </div>
  );
}
