'use client';
import { motion, useReducedMotion } from 'framer-motion';
import Link from 'next/link';
import { Icon } from './Icon';
import { ThreeDCharacter } from './ThreeDCharacter';
import { AnimatedCounter, ProgressRing } from './ui';
import { TEAM_LABEL } from '@/lib/access';
import type { Summary } from '@/lib/stats';
import type { WorkTeam } from '@/lib/types';

const ACCENT: Record<WorkTeam, string> = { development: 'from-primary to-primary-600', marketing: 'from-secondary-400 to-secondary-500', creative: 'from-accent to-secondary-400' };

/** Large admin team card: floating character, progress ring, numbers and a deep link. */
export function TeamCard({ team, s, delay = 0 }: { team: WorkTeam; s: Summary; delay?: number }) {
  const reduce = useReducedMotion();
  const stat = (label: string, v: number, hot = false) => (
    <div className={hot && v > 0 ? 'rounded-xl bg-primary-900 px-2 py-1.5 text-white' : 'rounded-xl bg-surface2 px-2 py-1.5'}>
      <div className="text-lg font-extrabold leading-none"><AnimatedCounter value={v} /></div>
      <div className="mt-0.5 text-[10px] font-semibold uppercase tracking-wide opacity-70">{label}</div>
    </div>
  );
  return (
    <motion.article initial={reduce ? false : { opacity: 0, y: 36 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.6, delay }} whileHover={reduce ? undefined : { y: -8, rotateX: 3, rotateY: -3 }} style={{ transformPerspective: 1000 }} className="panel group relative overflow-hidden p-5 transition-shadow duration-300 hover:shadow-glow">
      <div className={`pointer-events-none absolute -right-16 -top-16 h-56 w-56 rounded-full bg-gradient-to-br ${ACCENT[team]} opacity-25 blur-2xl transition-opacity duration-500 group-hover:opacity-45`} />
      <div className="relative flex items-start justify-between gap-3">
        <div>
          <h3 className="text-xl font-extrabold">{TEAM_LABEL[team]} Team</h3>
          <p className="text-xs text-muted">{s.activityToday} updates today</p>
        </div>
        <ProgressRing value={s.progress} size={64} stroke={7} />
      </div>
      <ThreeDCharacter kind={team} className="relative mx-auto -my-1 h-44 w-52 sm:h-48 sm:w-56" />
      <div className="relative grid grid-cols-4 gap-2 text-center">
        {stat('Total', s.total)}{stat('Done', s.completed)}{stat('Pending', s.pending + s.inProgress)}{stat('Overdue', s.overdue, true)}
      </div>
      <Link href={`/${team}`} className="btn-primary relative mt-4 w-full">View {TEAM_LABEL[team]} <Icon name="ArrowRight" size={16} className="transition group-hover:translate-x-1" /></Link>
    </motion.article>
  );
}
