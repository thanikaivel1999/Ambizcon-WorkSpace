'use client';
import { useQuery } from '@tanstack/react-query';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { useEffect, useMemo, useState } from 'react';
import { DataTable, type Column } from './DataTable';
import { Icon } from './Icon';
import { useAuth, useToast } from './providers';
import { Drawer, EmptyState, ErrorState, LoadingState, Modal, PageHeader, PriorityBadge, UserAvatar } from './ui';
import { api } from '@/lib/data';
import { downloadCsv, toCsv } from '@/lib/csv';
import { useLookups, useTaskActions, useTasks } from '@/lib/hooks';
import { isOverdue, isVerified } from '@/lib/taskflow';
import { PRIORITIES, TASK_STATUSES, type Profile, type Task, type TaskInput, type TaskStatus, type WorkTeam } from '@/lib/types';
import { cn, fmtDate, fmtTime, todayISO } from '@/lib/utils';

const STATUS_CLS: Record<TaskStatus, string> = {
  New: 'bg-surface2 text-muted ring-line/25',
  Assigned: 'bg-secondary/20 text-secondary-700 dark:text-secondary-200 ring-secondary/40',
  'In Progress': 'bg-primary/15 text-primary-700 dark:text-primary-200 ring-primary/40',
  'On Hold': 'bg-accent/25 text-muted ring-accent/50',
  'Submitted for Review': 'bg-primary/30 text-primary-800 dark:text-white ring-primary/60',
  'Changes Requested': 'bg-primary-700 text-white ring-primary-900',
  Approved: 'bg-secondary-500 text-white ring-secondary-600',
  Completed: 'bg-secondary-400 text-white ring-secondary-500',
  Cancelled: 'bg-line/10 text-muted line-through ring-line/20',
};
export function TaskStatusBadge({ status, overdue }: { status: TaskStatus; overdue?: boolean }) {
  return (
    <span className="inline-flex items-center gap-1.5">
      <span className={cn('inline-flex items-center whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-semibold ring-1 ring-inset', STATUS_CLS[status])}>{status}</span>
      {overdue && <span className="inline-flex items-center gap-1 rounded-full bg-primary-900 px-2 py-0.5 text-[11px] font-bold text-white"><span className="h-1.5 w-1.5 animate-pulse rounded-full bg-white" />Overdue</span>}
    </span>
  );
}

const TEAMS: WorkTeam[] = ['development', 'marketing', 'creative'];
const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);
const BLANK = { title: '', description: '', client_id: '', team: 'development' as WorkTeam, assigned_to: '', reviewer_id: '', priority: 'Medium', date_assigned: todayISO(), due_date: '', output_link: '', thumbnail: '', remarks: '' };

function TaskForm({ open, task, onClose }: { open: boolean; task: Task | null; onClose: () => void }) {
  const { user } = useAuth() as { user: Profile };
  const lk = useLookups();
  const { create, update } = useTaskActions();
  const toast = useToast();
  const [v, setV] = useState<Record<string, string>>(BLANK);
  const [err, setErr] = useState<Record<string, string>>({});
  const [busyImg, setBusyImg] = useState(false);
  useEffect(() => {
    if (!open) return;
    setErr({});
    setV(task
      ? { ...BLANK, ...Object.fromEntries(Object.entries(task).map(([k, x]) => [k, x == null ? '' : String(x)])) }
      : { ...BLANK, team: user.team === 'admin' ? 'development' : (user.team as WorkTeam), assigned_to: '' });
  }, [open, task, user.team]);
  const set = (k: string, val: string) => setV((s) => ({ ...s, [k]: val }));
  const team = v.team as WorkTeam;
  const people = lk.users.filter((u) => u.status === 'active' && (u.team === team || u.team === 'admin'));
  const busy = create.isPending || update.isPending;

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const errors: Record<string, string> = {};
    if (!v.title.trim()) errors.title = 'Task title is required';
    if (v.title.length > 300) errors.title = 'Title is too long (300 max)';
    if (v.output_link && !/^https?:\/\//i.test(v.output_link)) errors.output_link = 'Must start with http:// or https://';
    if (v.due_date && v.date_assigned && v.due_date < v.date_assigned) errors.due_date = 'Due date cannot be before the assigned date';
    if (v.reviewer_id && v.reviewer_id === v.assigned_to) errors.reviewer_id = 'The reviewer must be a different person than the assignee';
    setErr(errors);
    if (Object.keys(errors).length) return;
    const nul = (s: string) => (s.trim() ? s.trim() : null);
    const data = {
      title: v.title.trim(), description: nul(v.description), client_id: nul(v.client_id), assigned_to: nul(v.assigned_to), reviewer_id: nul(v.reviewer_id),
      priority: v.priority as Task['priority'], date_assigned: nul(v.date_assigned), due_date: nul(v.due_date), output_link: nul(v.output_link), thumbnail: nul(v.thumbnail), remarks: nul(v.remarks),
    };
    if (task) update.mutate({ id: task.id, patch: data, before: task, note: 'Task updated.' }, { onSuccess: onClose });
    else create.mutate({ ...data, team } as TaskInput, { onSuccess: onClose });
  };
  const Err = ({ k }: { k: string }) => (err[k] ? <p role="alert" className="mt-1 text-xs font-medium text-primary-800 dark:text-primary-200">{err[k]}</p> : null);
  return (
    <Modal open={open} onClose={onClose} title={task ? 'Edit task' : 'New task'} size="lg"
      footer={<><button type="button" className="btn-ghost" onClick={onClose}>Cancel</button><button type="submit" form="task-form" className="btn-primary" disabled={busy}>{busy && <Icon name="Loader2" className="animate-spin" size={16} />}{task ? 'Save changes' : 'Create task'}</button></>}>
      <form id="task-form" onSubmit={submit} noValidate className="grid grid-cols-1 gap-x-4 gap-y-3 sm:grid-cols-2">
        <div className="sm:col-span-2"><label className="label" htmlFor="t-title">Task title *</label><input id="t-title" className="input" value={v.title} onChange={(e) => set('title', e.target.value)} /><Err k="title" /></div>
        <div className="sm:col-span-2"><label className="label" htmlFor="t-desc">Description</label><textarea id="t-desc" rows={3} className="input" value={v.description} onChange={(e) => set('description', e.target.value)} /></div>
        <div><label className="label" htmlFor="t-client">Client</label><select id="t-client" className="input" value={v.client_id} onChange={(e) => set('client_id', e.target.value)}><option value="">No client</option>{lk.clients.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></div>
        <div><label className="label" htmlFor="t-team">Team</label>
          {user.team === 'admin' && !task ? <select id="t-team" className="input" value={v.team} onChange={(e) => setV((s) => ({ ...s, team: e.target.value, assigned_to: '', reviewer_id: '' }))}>{TEAMS.map((t) => <option key={t} value={t}>{cap(t)}</option>)}</select> : <input id="t-team" className="input" value={cap(task?.team ?? team)} readOnly />}</div>
        <div><label className="label" htmlFor="t-asg">Assigned employee</label><select id="t-asg" className="input" value={v.assigned_to} onChange={(e) => set('assigned_to', e.target.value)}><option value="">Unassigned</option>{people.map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}</select></div>
        <div><label className="label" htmlFor="t-rev">Reviewer</label><select id="t-rev" className="input" value={v.reviewer_id} onChange={(e) => set('reviewer_id', e.target.value)}><option value="">No reviewer (completion will be unverified)</option>{people.filter((u) => u.id !== v.assigned_to).map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}</select><Err k="reviewer_id" /></div>
        <div><label className="label" htmlFor="t-pri">Priority</label><select id="t-pri" className="input" value={v.priority} onChange={(e) => set('priority', e.target.value)}>{PRIORITIES.map((p) => <option key={p}>{p}</option>)}</select></div>
        <div><label className="label" htmlFor="t-da">Date assigned</label><input id="t-da" type="date" className="input" value={v.date_assigned} onChange={(e) => set('date_assigned', e.target.value)} /></div>
        <div><label className="label" htmlFor="t-due">Due date</label><input id="t-due" type="date" className="input" value={v.due_date} onChange={(e) => set('due_date', e.target.value)} /><Err k="due_date" /></div>
        <div><label className="label" htmlFor="t-out">Output link</label><input id="t-out" type="url" className="input" placeholder="https://…" value={v.output_link} onChange={(e) => set('output_link', e.target.value)} /><Err k="output_link" /></div>
        <div className="sm:col-span-2"><label className="label">Thumbnail</label>
          <div className="flex items-center gap-2">
            {v.thumbnail && /* eslint-disable-next-line @next/next/no-img-element */ <img src={v.thumbnail} alt="Thumbnail preview" className="h-14 w-20 rounded-lg object-cover ring-1 ring-line/25" />}
            <label className="btn-ghost cursor-pointer">{busyImg ? <Icon name="Loader2" className="animate-spin" size={16} /> : <Icon name="Image" size={16} />}Upload image
              <input type="file" accept="image/png,image/jpeg,image/webp,image/gif" className="sr-only" onChange={async (e) => {
                const f = e.target.files?.[0]; if (!f) return;
                setBusyImg(true);
                try { set('thumbnail', await api.uploadImage(f)); } catch (x) { toast.error((x as Error).message); } finally { setBusyImg(false); e.target.value = ''; }
              }} /></label>
            {v.thumbnail && <button type="button" className="btn-ghost" onClick={() => set('thumbnail', '')}>Remove</button>}
          </div></div>
        <div className="sm:col-span-2"><label className="label" htmlFor="t-rem">Remarks</label><textarea id="t-rem" rows={2} className="input" value={v.remarks} onChange={(e) => set('remarks', e.target.value)} /></div>
      </form>
    </Modal>
  );
}

function TaskDrawer({ task, onClose, onEdit }: { task: Task | null; onClose: () => void; onEdit: (t: Task) => void }) {
  const { user } = useAuth() as { user: Profile };
  const lk = useLookups();
  const { update, comment } = useTaskActions();
  const [text, setText] = useState('');
  const [rating, setRating] = useState('4');
  const id = task?.id;
  const comments = useQuery({ queryKey: ['task', 'comments', id], queryFn: () => api.tasks.comments(id!), enabled: !!id });
  const events = useQuery({ queryKey: ['task', 'events', id], queryFn: () => api.tasks.events(id!), enabled: !!id });
  useEffect(() => { setText(''); }, [id]);
  if (!task) return <Drawer open={false} onClose={onClose} title="Task">{null}</Drawer>;

  const isAdmin = user.team === 'admin';
  const isAssignee = task.assigned_to === user.id;
  const isReviewer = task.reviewer_id === user.id;
  const canWork = isAdmin || isAssignee || user.team === task.team;
  const canReview = (isAdmin || (isReviewer && !isAssignee)) && task.review_status === 'Requested';
  const closed = task.status === 'Completed' || task.status === 'Cancelled';
  const overdue = isOverdue(task, todayISO());
  const act = (patch: Partial<Task>, note: string) => update.mutate({ id: task.id, patch, before: task, note });
  const needsApproval = !!task.reviewer_id && task.review_status !== 'Approved';
  const verified = isVerified(task);

  const row = (k: string, val: React.ReactNode) => <div className="flex justify-between gap-3 border-b border-line/10 py-1.5 text-sm"><dt className="text-muted">{k}</dt><dd className="text-right font-medium">{val}</dd></div>;
  return (
    <Drawer open onClose={onClose} title={task.title}
      footer={canWork && !closed ? <button className="btn-ghost" onClick={() => onEdit(task)}><Icon name="Pencil" size={16} />Edit task</button> : undefined}>
      <div className="mb-3 flex flex-wrap items-center gap-2"><TaskStatusBadge status={task.status} overdue={overdue} /><PriorityBadge priority={task.priority} />
        {verified && <span className="inline-flex items-center gap-1 rounded-full bg-secondary/25 px-2 py-0.5 text-xs font-bold text-secondary-700 dark:text-secondary-200"><Icon name="BadgeCheck" size={13} />Verified</span>}
        {task.status === 'Completed' && !verified && <span className="rounded-full bg-accent/25 px-2 py-0.5 text-xs font-semibold text-muted" title="Completed without reviewer approval, so it does not count as verified in performance scoring.">Unverified</span>}
      </div>
      {task.thumbnail && /* eslint-disable-next-line @next/next/no-img-element */ <img src={task.thumbnail} alt="" className="mb-3 max-h-48 w-full rounded-xl object-cover ring-1 ring-line/20" />}
      {task.description && <p className="mb-3 whitespace-pre-wrap text-sm">{task.description}</p>}
      <dl>
        {row('Client', task.client_id ? <Link href={`/clients/${task.client_id}`} className="text-primary hover:underline dark:text-primary-200">{lk.client(task.client_id)}</Link> : '—')}
        {row('Team', cap(task.team))}{row('Assigned to', lk.user(task.assigned_to))}{row('Reviewer', lk.user(task.reviewer_id))}{row('Created by', lk.user(task.created_by))}
        {row('Date assigned', fmtDate(task.date_assigned))}{row('Due date', fmtDate(task.due_date))}{row('Review', task.review_status + (task.review_rating ? ` · ${task.review_rating}/5` : ''))}
        {row('Completed', task.completed_at ? `${fmtDate(task.completed_at)} ${fmtTime(task.completed_at)}` : '—')}
        {row('Output', task.output_link ? <a href={task.output_link} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-primary hover:underline dark:text-primary-200">Open<Icon name="ExternalLink" size={13} /></a> : '—')}
        {task.remarks && row('Remarks', task.remarks)}
      </dl>

      {canWork && !closed && (
        <section className="mt-4 rounded-xl bg-surface2 p-3" aria-label="Workflow actions">
          <h3 className="mb-2 text-xs font-bold uppercase tracking-wide text-muted">Actions</h3>
          <div className="flex flex-wrap items-center gap-2">
            <select className="input !w-auto" aria-label="Change status" value={task.status} disabled={update.isPending}
              onChange={(e) => act({ status: e.target.value as TaskStatus }, 'Status updated.')}>
              {TASK_STATUSES.filter((s) => !['Approved', 'Submitted for Review', 'Changes Requested', 'Completed'].includes(s) || s === task.status).map((s) => <option key={s}>{s}</option>)}
            </select>
            {task.reviewer_id && !['Requested', 'Approved'].includes(task.review_status) && (
              <button className="btn-ghost" disabled={update.isPending} onClick={() => act({ review_status: 'Requested' }, 'Submitted for review. The reviewer has been notified.')}><Icon name="Send" size={15} />Submit for review</button>
            )}
            {!needsApproval && task.status !== 'Completed' && (
              <button className="btn-primary" disabled={update.isPending} onClick={() => act({ status: 'Completed' }, 'Task completed.')}><Icon name="CircleCheck" size={15} />Mark completed</button>
            )}
            {needsApproval && <span className="text-xs text-muted">{task.review_status === 'Requested' ? 'Waiting for the reviewer to approve.' : 'Needs reviewer approval before it can be completed.'}</span>}
          </div>
          {!task.reviewer_id && <p className="mt-2 text-xs text-muted">No reviewer is set, so completing this task will be recorded as self-reported (unverified).</p>}
        </section>
      )}
      {canReview && !closed && (
        <section className="mt-3 rounded-xl border border-primary/30 bg-primary/5 p-3" aria-label="Review">
          <h3 className="mb-2 text-xs font-bold uppercase tracking-wide text-primary dark:text-primary-200">Review this task</h3>
          <div className="flex flex-wrap items-center gap-2">
            <label className="flex items-center gap-1 text-sm">Quality<select className="input !w-auto" value={rating} onChange={(e) => setRating(e.target.value)} aria-label="Quality rating">{[5, 4, 3, 2, 1].map((n) => <option key={n} value={n}>{n} / 5</option>)}</select></label>
            <button className="btn-primary" disabled={update.isPending} onClick={() => act({ review_status: 'Approved', review_rating: Number(rating) }, 'Task approved.')}><Icon name="Check" size={15} />Approve</button>
            <button className="btn-ghost" disabled={update.isPending} onClick={() => act({ review_status: 'Changes Requested' }, 'Changes requested. The assignee has been notified.')}><Icon name="RotateCcw" size={15} />Request changes</button>
          </div>
        </section>
      )}

      <section className="mt-5" aria-label="Comments">
        <h3 className="mb-2 font-bold">Comments</h3>
        {comments.isLoading ? <LoadingState variant="cards" rows={2} /> : (comments.data ?? []).length === 0 ? <p className="text-sm text-muted">No comments yet.</p> : (
          <ul className="space-y-2">{comments.data!.map((c) => <li key={c.id} className="flex gap-2"><UserAvatar name={c.user_name ?? '?'} size={28} /><div className="min-w-0 rounded-xl bg-surface2 px-3 py-2"><div className="text-xs text-muted"><b className="text-ink">{c.user_name}</b> · {fmtDate(c.created_at)} {fmtTime(c.created_at)}</div><p className="whitespace-pre-wrap break-words text-sm">{c.body}</p></div></li>)}</ul>
        )}
        <form className="mt-3 flex gap-2" onSubmit={(e) => { e.preventDefault(); if (text.trim()) comment.mutate({ id: task.id, body: text }, { onSuccess: () => setText('') }); }}>
          <input className="input" placeholder="Add a comment…" aria-label="Add a comment" maxLength={2000} value={text} onChange={(e) => setText(e.target.value)} />
          <button className="btn-primary" disabled={!text.trim() || comment.isPending}>Post</button>
        </form>
      </section>

      <section className="mt-5" aria-label="History">
        <h3 className="mb-2 font-bold">Activity history</h3>
        <ol className="space-y-1.5 border-l-2 border-primary/20 pl-4">
          {(events.data ?? []).map((e) => <li key={e.id} className="relative text-sm"><span className="absolute -left-[22px] top-1.5 h-2.5 w-2.5 rounded-full bg-primary" /><span className="font-medium">{e.detail}</span> <span className="text-xs text-muted">· {e.user_name ?? 'System'} · {fmtDate(e.created_at)} {fmtTime(e.created_at)}</span></li>)}
        </ol>
      </section>
    </Drawer>
  );
}

/** /tasks — the shared task model for all teams. */
export function TasksPage() {
  const { user } = useAuth() as { user: Profile };
  const sp = useSearchParams();
  const lk = useLookups();
  const q = useTasks();
  const [search, setSearch] = useState('');
  const [view, setView] = useState<'open' | 'completed' | 'all'>('open');
  const [team, setTeam] = useState(user.team === 'admin' ? '' : user.team);
  const [status, setStatus] = useState('');
  const [priority, setPriority] = useState('');
  const [assignee, setAssignee] = useState('');
  const [client, setClient] = useState(sp.get('client') ?? '');
  const [mine, setMine] = useState(false);
  const [overdueOnly, setOverdueOnly] = useState(false);
  const [openId, setOpenId] = useState<string | null>(sp.get('open'));
  const [form, setForm] = useState<{ task: Task | null } | null>(null);
  const today = todayISO();

  const rows = q.data ?? [];
  const filtered = useMemo(() => {
    const s = search.trim().toLowerCase();
    return rows.filter((t) => {
      const closed = t.status === 'Completed' || t.status === 'Cancelled';
      if (view === 'open' && closed) return false;
      if (view === 'completed' && t.status !== 'Completed') return false;
      if (team && t.team !== team) return false;
      if (status && t.status !== status) return false;
      if (priority && t.priority !== priority) return false;
      if (assignee && t.assigned_to !== assignee) return false;
      if (client && t.client_id !== client) return false;
      if (mine && t.assigned_to !== user.id && t.reviewer_id !== user.id) return false;
      if (overdueOnly && !isOverdue(t, today)) return false;
      return !s || `${t.title} ${t.description ?? ''} ${lk.client(t.client_id)} ${lk.user(t.assigned_to)}`.toLowerCase().includes(s);
    });
  }, [rows, search, view, team, status, priority, assignee, client, mine, overdueOnly, lk, today, user.id]);

  const open = openId ? rows.find((t) => t.id === openId) ?? null : null;
  const counts = useMemo(() => ({
    open: rows.filter((t) => !['Completed', 'Cancelled'].includes(t.status)).length,
    overdue: rows.filter((t) => isOverdue(t, today)).length,
    review: rows.filter((t) => t.status === 'Submitted for Review').length,
    done: rows.filter((t) => t.status === 'Completed').length,
  }), [rows, today]);

  const columns: Column<Task>[] = [
    { key: 'title', label: 'Task', sortValue: (t) => t.title, render: (t) => <span className="font-semibold">{t.title}</span> },
    { key: 'client', label: 'Client', sortValue: (t) => lk.client(t.client_id), render: (t) => lk.client(t.client_id) },
    { key: 'team', label: 'Team', sortValue: (t) => t.team, render: (t) => cap(t.team) },
    { key: 'asg', label: 'Assigned', sortValue: (t) => lk.user(t.assigned_to), render: (t) => lk.user(t.assigned_to) },
    { key: 'pri', label: 'Priority', sortValue: (t) => PRIORITIES.indexOf(t.priority), render: (t) => <PriorityBadge priority={t.priority} /> },
    { key: 'status', label: 'Status', sortValue: (t) => t.status, render: (t) => <TaskStatusBadge status={t.status} overdue={isOverdue(t, today)} /> },
    { key: 'review', label: 'Review', sortValue: (t) => t.review_status, render: (t) => (t.review_status === 'None' ? <span className="text-muted">—</span> : <span className="text-sm">{t.review_status}</span>) },
    { key: 'due', label: 'Due', sortValue: (t) => t.due_date ?? '9999', render: (t) => fmtDate(t.due_date) },
  ];

  const exportCsv = () => downloadCsv('tasks', toCsv(filtered, [
    { label: 'Title', value: (t) => t.title }, { label: 'Client', value: (t) => lk.client(t.client_id) }, { label: 'Team', value: (t) => t.team }, { label: 'Assigned to', value: (t) => lk.user(t.assigned_to) },
    { label: 'Reviewer', value: (t) => lk.user(t.reviewer_id) }, { label: 'Priority', value: (t) => t.priority }, { label: 'Status', value: (t) => t.status }, { label: 'Review status', value: (t) => t.review_status },
    { label: 'Rating', value: (t) => t.review_rating }, { label: 'Date assigned', value: (t) => t.date_assigned }, { label: 'Due date', value: (t) => t.due_date }, { label: 'Completed at', value: (t) => t.completed_at },
    { label: 'Verified', value: (t) => (isVerified(t) ? 'Yes' : 'No') }, { label: 'Output link', value: (t) => t.output_link },
  ]));

  const stat = (label: string, n: number, onClick?: () => void) => <button className="panel px-4 py-3 text-left transition hover:-translate-y-0.5 hover:shadow-lift" onClick={onClick}><div className="text-2xl font-extrabold tabular-nums">{n}</div><div className="text-xs font-semibold uppercase tracking-wide text-muted">{label}</div></button>;
  return (
    <div>
      <PageHeader icon="ListChecks" title="Tasks" subtitle="Create, assign, review and complete work across all teams."
        actions={<><button className="btn-ghost" onClick={exportCsv} disabled={!filtered.length}><Icon name="Download" size={16} />Export CSV</button><button className="btn-primary" onClick={() => setForm({ task: null })}><Icon name="Plus" size={16} />New task</button></>} />
      <div className="mb-4 grid grid-cols-2 gap-3 md:grid-cols-4">
        {stat('Open', counts.open, () => { setView('open'); setOverdueOnly(false); })}
        {stat('Overdue', counts.overdue, () => { setView('open'); setOverdueOnly(true); })}
        {stat('Awaiting review', counts.review, () => { setView('open'); setStatus('Submitted for Review'); })}
        {stat('Completed', counts.done, () => { setView('completed'); setOverdueOnly(false); setStatus(''); })}
      </div>
      <div className="panel mb-4 p-3" role="search" aria-label="Filter tasks">
        <div className="grid grid-cols-2 gap-2 md:grid-cols-4 xl:grid-cols-8">
          <div className="relative col-span-2"><Icon name="Search" size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted" /><input className="input pl-9" placeholder="Search tasks…" aria-label="Search tasks" value={search} onChange={(e) => setSearch(e.target.value)} /></div>
          <select className="input" aria-label="View" value={view} onChange={(e) => setView(e.target.value as typeof view)}><option value="open">Open work</option><option value="completed">Completed</option><option value="all">All tasks</option></select>
          {user.team === 'admin' && <select className="input" aria-label="Team" value={team} onChange={(e) => setTeam(e.target.value)}><option value="">All teams</option>{TEAMS.map((t) => <option key={t} value={t}>{cap(t)}</option>)}</select>}
          <select className="input" aria-label="Status" value={status} onChange={(e) => setStatus(e.target.value)}><option value="">Any status</option>{TASK_STATUSES.map((s) => <option key={s}>{s}</option>)}</select>
          <select className="input" aria-label="Priority" value={priority} onChange={(e) => setPriority(e.target.value)}><option value="">Any priority</option>{PRIORITIES.map((p) => <option key={p}>{p}</option>)}</select>
          <select className="input" aria-label="Employee" value={assignee} onChange={(e) => setAssignee(e.target.value)}><option value="">All employees</option>{lk.users.filter((u) => u.status === 'active' && u.team !== 'admin' && (!team || u.team === team)).map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}</select>
          <select className="input" aria-label="Client" value={client} onChange={(e) => setClient(e.target.value)}><option value="">All clients</option>{lk.clients.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
        </div>
        <div className="mt-2 flex flex-wrap items-center gap-4 text-sm">
          <label className="flex cursor-pointer items-center gap-2"><input type="checkbox" checked={mine} onChange={(e) => setMine(e.target.checked)} />Assigned to me / reviewing</label>
          <label className="flex cursor-pointer items-center gap-2"><input type="checkbox" checked={overdueOnly} onChange={(e) => setOverdueOnly(e.target.checked)} />Overdue only</label>
          <span className="ml-auto text-xs text-muted">Showing <b className="text-ink">{filtered.length}</b> of {rows.length}</span>
        </div>
      </div>
      {q.isLoading ? <LoadingState variant="table" /> : q.error ? <ErrorState message={(q.error as Error).message} onRetry={() => q.refetch()} /> : rows.length === 0 ? (
        <div className="panel"><EmptyState title="No tasks yet" message="Create the first task to start tracking work." action actionLabel="New task" onAction={() => setForm({ task: null })} /></div>
      ) : filtered.length === 0 ? (
        <div className="panel"><EmptyState title="No matching tasks" message={view === 'open' ? 'There is no open work matching these filters. Completed tasks are in the Completed view.' : 'Try changing the filters.'} /></div>
      ) : (
        <DataTable rows={filtered} columns={columns} rowKey={(t) => t.id} caption="Tasks" onRowClick={(t) => setOpenId(t.id)} defaultSort={{ key: 'due', dir: 'asc' }}
          cardBadge={(t) => <TaskStatusBadge status={t.status} overdue={isOverdue(t, today)} />}
          actions={(t) => <button className="btn-ghost !p-1.5" aria-label={`Open ${t.title}`} onClick={() => setOpenId(t.id)}><Icon name="Eye" size={15} /></button>} />
      )}
      <TaskDrawer task={open} onClose={() => setOpenId(null)} onEdit={(t) => { setOpenId(null); setForm({ task: t }); }} />
      <TaskForm open={!!form} task={form?.task ?? null} onClose={() => setForm(null)} />
    </div>
  );
}
