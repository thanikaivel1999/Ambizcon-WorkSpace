'use client';
import dynamic from 'next/dynamic';
import { LoadingState } from './ui';
import { moduleFromCustom } from '@/lib/custom';
import { useCustomModules } from '@/lib/hooks';
import { findModule } from '@/lib/modules';

// Heavy, chart-bearing screens are code-split so the shell and login stay light.
// (next/dynamic options must be inline object literals.)
export const AdminDashboard = dynamic(() => import('./dashboards').then((m) => m.AdminDashboard), { ssr: false, loading: () => <LoadingState variant="page" /> });
export const TeamDashboard = dynamic(() => import('./dashboards').then((m) => m.TeamDashboard), { ssr: false, loading: () => <LoadingState variant="page" /> });
export const AdminOverview = dynamic(() => import('./admin').then((m) => m.AdminOverview), { ssr: false, loading: () => <LoadingState variant="page" /> });
export const AdminTeams = dynamic(() => import('./admin').then((m) => m.AdminTeams), { ssr: false, loading: () => <LoadingState variant="page" /> });
export const UsersPage = dynamic(() => import('./admin').then((m) => m.UsersPage), { ssr: false, loading: () => <LoadingState variant="table" /> });
export const ReportsPage = dynamic(() => import('./admin').then((m) => m.ReportsPage), { ssr: false, loading: () => <LoadingState variant="page" /> });
export const AdhocPage = dynamic(() => import('./pages').then((m) => m.AdhocPage), { ssr: false, loading: () => <LoadingState variant="table" /> });
export const NotificationsPage = dynamic(() => import('./pages').then((m) => m.NotificationsPage), { ssr: false, loading: () => <LoadingState variant="table" /> });
export const MotivationPage = dynamic(() => import('./pages').then((m) => m.MotivationPage), { ssr: false, loading: () => <LoadingState variant="page" /> });
export const SettingsPage = dynamic(() => import('./pages').then((m) => m.SettingsPage), { ssr: false, loading: () => <LoadingState variant="table" /> });
export const ProfilePage = dynamic(() => import('./pages').then((m) => m.ProfilePage), { ssr: false, loading: () => <LoadingState variant="table" /> });

const ModulePageInner = dynamic(() => import('./records/ModulePage'), { ssr: false, loading: () => <LoadingState variant="table" /> });
/** Resolves the module on the client: module definitions contain functions and cannot cross the server/client boundary. */
export function ModuleRoute({ team, slug }: { team: string; slug: string }) {
  const custom = useCustomModules();
  const m = findModule(team, slug) ?? (custom.data ?? []).filter((c) => c.team === team && c.slug === slug && !c.archived).map(moduleFromCustom)[0];
  if (!m) return custom.isLoading ? <LoadingState variant="table" /> : <div className="panel"><div className="px-4 py-12 text-center"><h2 className="text-lg font-bold">Page not found</h2><p className="mt-1 text-sm text-muted">This module does not exist or has been archived.</p></div></div>;
  return <ModulePageInner key={m.key} m={m} />;
}

export const ClientsPage = dynamic(() => import('./clients').then((m) => m.ClientsPage), { ssr: false, loading: () => <LoadingState variant="table" /> });
export const ClientProfilePage = dynamic(() => import('./clients').then((m) => m.ClientProfile), { ssr: false, loading: () => <LoadingState variant="page" /> });
export const BriefsPage = dynamic(() => import('./briefs').then((m) => m.BriefsPage), { ssr: false, loading: () => <LoadingState variant="table" /> });
export const TasksPage = dynamic(() => import('./tasks').then((m) => m.TasksPage), { ssr: false, loading: () => <LoadingState variant="table" /> });

export const PerformancePage = dynamic(() => import('./performance').then((m) => m.PerformancePage), { ssr: false, loading: () => <LoadingState variant="page" /> });

export const BlogCountsPage = dynamic(() => import('./blogcounts').then((m) => m.BlogCountsPage), { ssr: false, loading: () => <LoadingState variant="page" /> });

export const ExpiryManagementPage = dynamic(() => import('./expiry').then((m) => m.ExpiryManagementPage), { ssr: false, loading: () => <LoadingState variant="page" /> });

export const AiAssistantPage = dynamic(() => import('./ai').then((m) => m.AiAssistantPage), { ssr: false, loading: () => <LoadingState variant="page" /> });
export const AiFloatingButton = dynamic(() => import('./ai').then((m) => m.AiFloatingButton), { ssr: false });

export const StudioPage = dynamic(() => import('./studio').then((m) => m.StudioPage), { ssr: false, loading: () => <LoadingState variant="page" /> });
