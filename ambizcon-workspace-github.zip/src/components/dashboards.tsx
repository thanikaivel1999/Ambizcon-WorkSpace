'use client';
import { useQuery } from '@tanstack/react-query';
import Link from 'next/link';
import { useMemo, useState } from 'react';
import { BarsChart, CH, DonutChart, LinesChart } from './charts';
import { Icon } from './Icon';
import { useAuth } from './providers';
import { ActivityTimeline } from './records/ActivityTimeline';
import { DailyCheckCard } from './records/extras';
import { CustomCards } from './customcards';
import { ExecutiveOverview } from './executive';
import { TeamCard } from './TeamCard';
import { TeamHero } from './TeamHero';
import { ChartCard, EmptyState, ErrorState, ExpiryChip, LoadingState, Reveal, StatsCard } from './ui';
import { moduleHref } from '@/lib/access';
import { byModule, byTeam, monthlyActivity, recent, statusDistribution, WORK_TEAMS } from '@/lib/analytics';
import { api } from '@/lib/data';
import { modulesForTeam, useAvailableModules, useDashboardLayout, useItems, useLookups } from '@/lib/hooks';
import { MODULE_BY_KEY, modulesOf } from '@/lib/modules';
import { effStatus, summarize, type Item } from '@/lib/stats';
import type { Profile, WorkTeam } from '@/lib/types';
import { daysUntil, fmtDate } from '@/lib/utils';

function StatGrid({ s, extra }: { s: ReturnType<typeof summarize>; extra?: React.ReactNode }) {
  const cards: [string, number, string, 'primary' | 'secondary' | 'accent' | 'dark', string?][] = [
    ['Total Tasks', s.total, 'ClipboardList', 'primary'], ['Completed', s.completed, 'CircleCheck', 'secondary'], ['Pending', s.pending, 'Clock', 'accent'], ['In Progress', s.inProgress, 'Loader2', 'primary'],
    ['Overdue', s.overdue, 'AlertTriangle', 'dark'], ["Today's Tasks", s.today, 'Calendar', 'secondary'], ['This Week', s.week, 'CalendarDays', 'accent'], ['This Month', s.month, 'CalendarClock', 'primary'],
  ];
  return (
    <div className="mb-6 grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
      {cards.map(([l, v, i, a], idx) => <StatsCard key={l} label={l} value={v} icon={i} accent={a} delay={idx * 0.05} />)}
      {extra}
    </div>
  );
}

export function ExpiryWatch({ items, limit = 7 }: { items: Item[]; limit?: number }) {
  const rows = useMemo(() => items.filter(({ m, rec }) => m.expiryField && rec[m.expiryField] && rec.status !== 'Completed').sort((a, b) => daysUntil(a.rec[a.m.expiryField!]) - daysUntil(b.rec[b.m.expiryField!])).slice(0, limit), [items, limit]);
  return (
    <ChartCard title="Expiry watch" subtitle="Domains, SSL, tools and SMTP — soonest first" action={<Icon name="ShieldAlert" className="text-primary" />}>
      {rows.length === 0 ? <p className="py-6 text-center text-sm text-muted">Nothing is expiring soon.</p> : (
        <ul className="divide-y divide-line/10">
          {rows.map(({ m, rec }) => (
            <li key={m.key + rec.id}>
              <Link href={`${moduleHref(m)}?open=${rec.id}`} className="flex items-center justify-between gap-3 py-2 transition hover:translate-x-0.5">
                <span className="min-w-0"><span className="block truncate text-sm font-semibold">{String(rec[m.titleField])}</span><span className="block truncate text-xs text-muted">{m.nav} · {fmtDate(rec[m.expiryField!])}</span></span>
                <ExpiryChip date={rec[m.expiryField!]} />
              </Link>
            </li>
          ))}
        </ul>
      )}
    </ChartCard>
  );
}

export function ActivityFeed({ moduleKeys, limit = 8 }: { moduleKeys?: string[]; limit?: number }) {
  const q = useQuery({ queryKey: ['activity', 'recent'], queryFn: () => api.activity.recent(120) });
  const list = (q.data ?? []).filter((a) => !moduleKeys || moduleKeys.includes(a.module)).slice(0, limit);
  return (
    <ChartCard title="Recent activity" subtitle="Generated automatically from every change">
      {list.length === 0 ? <p className="py-6 text-center text-sm text-muted">No activity yet.</p> : <ActivityTimeline items={list} showRecord />}
    </ChartCard>
  );
}

function ModuleGrid({ team, items }: { team: WorkTeam; items: Item[] }) {
  const { user } = useAuth() as { user: Profile };
  const available = useAvailableModules(user.team === 'admin' ? 'admin' : user.team);
  const layout = useDashboardLayout().value;
  const order = layout.order[team] ?? [];
  const mods = available.filter((m) => m.team === team && !m.group && !layout.hidden.includes(m.key)).sort((a, b) => (order.indexOf(a.key) < 0 ? 1000 : order.indexOf(a.key)) - (order.indexOf(b.key) < 0 ? 1000 : order.indexOf(b.key)));
  return (
    <section aria-label="Work records" className="mb-6">
      <h2 className="mb-3 text-lg font-extrabold">Work records</h2>
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {mods.filter((m) => !m.readonly || m.key === 'user-log').map((m, i) => {
          const mine = items.filter((x) => x.m.key === m.key);
          const s = summarize(mine);
          return (
            <Reveal key={m.key} delay={Math.min(i, 8) * 0.03}>
              <Link href={moduleHref(m)} className="panel group flex items-center gap-3 p-3.5 transition hover:-translate-y-1 hover:shadow-lift">
                <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-primary to-secondary-400 text-white shadow-md transition group-hover:rotate-6 group-hover:scale-110"><Icon name={m.icon} size={20} /></span>
                <span className="min-w-0 flex-1"><span className="block truncate font-bold">{m.nav}</span><span className="block text-xs text-muted">{m.readonly ? 'Audit trail' : `${mine.length} records · ${s.progress}% done`}</span></span>
                {s.overdue > 0 && <span className="animate-pulseRing rounded-full bg-primary-900 px-2 py-0.5 text-[11px] font-bold text-white" title="Overdue">{s.overdue}</span>}
                <Icon name="ChevronRight" size={16} className="text-muted transition group-hover:translate-x-1" />
              </Link>
            </Reveal>
          );
        })}
      </div>
    </section>
  );
}

function CommonCharts({ items, title }: { items: Item[]; title: string }) {
  const dist = useMemo(() => statusDistribution(items), [items]);
  const mods = useMemo(() => byModule(items), [items]);
  const monthly = useMemo(() => monthlyActivity(items), [items]);
  const done = items.filter(({ m, rec }) => effStatus(m, rec) === 'Completed').length;
  const colors: Record<string, string> = { Completed: CH[1], 'In Progress': CH[0], Pending: CH[2], Overdue: CH[5], 'On Hold': CH[6], Cancelled: '#cfe0dc' };
  return (
    <div className="mb-6 grid gap-4 lg:grid-cols-3">
      <ChartCard title="Task completion" subtitle={title}><DonutChart data={dist.map((d) => ({ ...d, color: colors[d.name] }))} center={<div><div className="text-3xl font-extrabold">{items.length ? Math.round((done / items.length) * 100) : 0}%</div><div className="text-[11px] text-muted">completed</div></div>} /></ChartCard>
      <ChartCard title="Pending vs completed" subtitle="By module" className="lg:col-span-2"><BarsChart data={mods} series={[{ key: 'completed', name: 'Completed', color: CH[1] }, { key: 'pending', name: 'Pending', color: CH[0] }, { key: 'overdue', name: 'Overdue', color: CH[5] }]} stacked height={250} /></ChartCard>
      <ChartCard title="Monthly activity" subtitle="Records created, last 6 months" className="lg:col-span-2"><LinesChart data={monthly} series={[{ key: 'total', name: 'Records', color: CH[0] }]} area /></ChartCard>
      <ChartCard title="Overdue records" subtitle="By module"><BarsChart data={mods.filter((x) => x.overdue > 0)} series={[{ key: 'overdue', name: 'Overdue', color: CH[5] }]} /></ChartCard>
    </div>
  );
}

export function TeamDashboard({ team }: { team: WorkTeam }) {
  const { user } = useAuth() as { user: Profile };
  const lk = useLookups();
  const mods = useMemo(() => modulesForTeam(team), [team]);
  const { items, loading, error, refetch } = useItems(mods);
  const s = useMemo(() => summarize(items), [items]);
  if (loading) return <LoadingState variant="page" />;
  if (error) return <ErrorState message={error.message} onRetry={refetch} />;
  return (
    <div>
      <TeamHero team={team} name={user.name} current={s.total - s.completed} completed={s.completed} progress={s.progress}>
        <Link href={moduleHref(mods[0])} className="btn border border-white/40 bg-white/10 text-white backdrop-blur hover:bg-white/20">Open {mods[0].nav}<Icon name="ArrowRight" size={16} /></Link>
      </TeamHero>

      <CustomCards scope={team} />
      <StatGrid s={s} extra={team === 'creative' && ['web', 'videos', 'artworks'].map((k, i) => <StatsCard key={k} label={`Total ${MODULE_BY_KEY[k].nav}`} value={items.filter((x) => x.m.key === k).length} icon={MODULE_BY_KEY[k].icon} accent={(['primary', 'secondary', 'accent'] as const)[i]} delay={0.4 + i * 0.05} />)} />

      {team === 'development' && (
        <div className="mb-6 grid gap-4 lg:grid-cols-2">
          <DailyCheckCard rows={items.filter((x) => x.m.key === 'daily-check').map((x) => x.rec)} href="/development/daily-checks" />
          <ExpiryWatch items={items} />
        </div>
      )}
      <CommonCharts items={items} title={`${team[0].toUpperCase() + team.slice(1)} team`} />
      {team === 'marketing' && <MarketingCharts items={items} />}
      {team === 'creative' && <CreativeCharts items={items} />}
      {team === 'development' && <ChartCard title="Development activity" subtitle="Records by module" className="mb-6"><BarsChart data={byModule(items)} series={[{ key: 'total', name: 'Records', color: CH[0] }]} height={220} /></ChartCard>}
      <ModuleGrid team={team} items={items} />
      <div className="mb-6 grid gap-4 lg:grid-cols-2">
        <ActivityFeed moduleKeys={mods.map((m) => m.key)} />
        <RecentCompleted items={items} lk={lk} />
      </div>
    </div>
  );
}

function MarketingCharts({ items }: { items: Item[] }) {
  const mail = items.filter((x) => x.m.key === 'mailer-reports').map((x) => x.rec).sort((a, b) => String(a.send_date).localeCompare(String(b.send_date)));
  const data = mail.map((r) => ({ name: String(r.campaign_name).slice(0, 10), open: r.delivered && r.unique_opens != null ? +((r.unique_opens / r.delivered) * 100).toFixed(1) : 0, click: r.delivered && r.unique_clicks != null ? +((r.unique_clicks / r.delivered) * 100).toFixed(1) : 0 }));
  return <ChartCard title="Marketing performance" subtitle="Email open and click rates by campaign" className="mb-6"><LinesChart data={data} series={[{ key: 'open', name: 'Open rate %', color: CH[0] }, { key: 'click', name: 'Click rate %', color: CH[1] }]} unit="%" area /></ChartCard>;
}
function CreativeCharts({ items }: { items: Item[] }) {
  const data = ['web', 'videos', 'artworks'].map((k) => { const mine = items.filter((x) => x.m.key === k); const s = summarize(mine); return { name: MODULE_BY_KEY[k].nav, completed: s.completed, active: s.inProgress + s.pending, overdue: s.overdue }; });
  return <ChartCard title="Creative production" subtitle="Output by type" className="mb-6"><BarsChart data={data} series={[{ key: 'completed', name: 'Completed', color: CH[1] }, { key: 'active', name: 'In pipeline', color: CH[0] }, { key: 'overdue', name: 'Overdue', color: CH[5] }]} stacked /></ChartCard>;
}

function RecentCompleted({ items, lk }: { items: Item[]; lk: ReturnType<typeof useLookups> }) {
  const list = recent(items, 'completed', 6);
  return (
    <ChartCard title="Recently completed" subtitle="Latest wins">
      {list.length === 0 ? <EmptyState title="Nothing completed yet" message="Completed work shows up here." /> : (
        <ul className="divide-y divide-line/10">
          {list.map(({ m, rec }) => (
            <li key={rec.id}><Link href={`${moduleHref(m)}?open=${rec.id}`} className="flex items-center gap-3 py-2 hover:translate-x-0.5">
              <span className="grid h-8 w-8 place-items-center rounded-lg bg-secondary-400 text-white"><Icon name="Check" size={16} /></span>
              <span className="min-w-0 flex-1"><span className="block truncate text-sm font-semibold">{m.titleField === 'client_id' ? lk.client(rec.client_id) : String(rec[m.titleField])}</span><span className="block text-xs text-muted">{m.nav} · {lk.user(rec.updated_by)}</span></span>
              <span className="text-xs text-muted">{fmtDate(rec.updated_at)}</span>
            </Link></li>
          ))}
        </ul>
      )}
    </ChartCard>
  );
}

export function AdminDashboard() {
  const { user } = useAuth() as { user: Profile };
  const lk = useLookups();
  const mods = useMemo(() => modulesForTeam('admin'), []);
  const { items, loading, error, refetch } = useItems(mods);
  const s = useMemo(() => summarize(items), [items]);
  const teams = useMemo(() => byTeam(items), [items]);
  if (loading) return <LoadingState variant="page" />;
  if (error) return <ErrorState message={error.message} onRetry={refetch} />;
  const monthly = monthlyActivity(items);
  return (
    <div>
      <TeamHero team="admin" name={user.name} current={s.total - s.completed} completed={s.completed} progress={s.progress}>
        <Link href="/admin/overview" className="btn bg-white text-primary-800 shadow-md hover:-translate-y-0.5"><Icon name="MonitorCheck" size={16} />Admin Overview</Link>
        <Link href="/admin/reports" className="btn border border-white/40 bg-white/10 text-white backdrop-blur hover:bg-white/20">Reports<Icon name="ArrowRight" size={16} /></Link>
      </TeamHero>
      <ExecutiveOverview items={items} />
      <CustomCards scope="admin" />
      <StatGrid s={s} extra={teams.map((t, i) => <StatsCard key={t.team} label={`${t.name} tasks`} value={t.total} icon={t.team === 'development' ? 'Code2' : t.team === 'marketing' ? 'Megaphone' : 'Palette'} accent={(['primary', 'secondary', 'accent'] as const)[i]} href={`/${t.team}`} delay={0.4 + i * 0.05} hint={`${t.progress}% complete`} />)} />
      <h2 className="mb-3 text-lg font-extrabold">Teams</h2>
      <div className="mb-6 grid gap-4 lg:grid-cols-3">{WORK_TEAMS.map((t, i) => <TeamCard key={t} team={t} s={teams[i]} delay={i * 0.1} />)}</div>
      <div className="mb-6 grid gap-4 lg:grid-cols-3">
        <ChartCard title="Team comparison" subtitle="Completed, open and overdue" className="lg:col-span-2"><BarsChart data={teams} series={[{ key: 'completed', name: 'Completed', color: CH[1] }, { key: 'inProgress', name: 'In progress', color: CH[0] }, { key: 'pending', name: 'Pending', color: CH[2] }, { key: 'overdue', name: 'Overdue', color: CH[5] }]} stacked height={260} /></ChartCard>
        <ChartCard title="Task completion" subtitle="All teams"><DonutChart data={statusDistribution(items).map((d) => ({ ...d, color: ({ Completed: CH[1], 'In Progress': CH[0], Pending: CH[2], Overdue: CH[5], 'On Hold': CH[6], Cancelled: '#cfe0dc' } as Record<string, string>)[d.name] }))} height={260} center={<div><div className="text-3xl font-extrabold">{s.progress}%</div><div className="text-[11px] text-muted">completed</div></div>} /></ChartCard>
        <ChartCard title="Monthly activity" subtitle="Records created per team" className="lg:col-span-2"><LinesChart data={monthly} area series={[{ key: 'development', name: 'Development', color: CH[0] }, { key: 'marketing', name: 'Marketing', color: CH[1] }, { key: 'creative', name: 'Creative', color: CH[2] }]} /></ChartCard>
        <DailyCheckCard rows={items.filter((x) => x.m.key === 'daily-check').map((x) => x.rec)} href="/development/daily-checks" />
      </div>
      <div className="mb-6 grid gap-4 lg:grid-cols-2">
        <ExpiryWatch items={items} />
        <RecentCompleted items={items} lk={lk} />
      </div>
      <ActivityFeed limit={10} />
    </div>
  );
}
