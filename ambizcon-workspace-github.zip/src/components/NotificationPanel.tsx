'use client';
import { motion } from 'framer-motion';
import Link from 'next/link';
import { Icon } from './Icon';
import { EmptyState } from './ui';
import { useNotifications } from '@/lib/hooks';
import type { AppNotification } from '@/lib/types';
import { cn } from '@/lib/utils';

const KIND_ICON: Record<AppNotification['kind'], string> = {
  expiry: 'ShieldAlert', due: 'Clock', overdue: 'AlertTriangle', creative: 'Palette', marketing: 'Megaphone', completed: 'CircleCheck', admin: 'Info', priority: 'Flame', check: 'ListChecks',
};

function ago(iso: string) {
  const s = (Date.now() - new Date(iso).getTime()) / 1000;
  if (s < 60) return 'just now';
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return `${Math.floor(s / 86400)}d ago`;
}

export function NotificationList({ limit, onNavigate }: { limit?: number; onNavigate?: () => void }) {
  const { list, markRead } = useNotifications();
  const rows = limit ? list.slice(0, limit) : list;
  if (!rows.length) return <EmptyState title="You're all caught up." message="New alerts will show up here." />;
  return (
    <ul className="divide-y divide-line/10">
      {rows.map((n, i) => (
        <motion.li key={n.id} initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: Math.min(i, 8) * 0.03 }}>
          <Link href={n.link ?? '#'} onClick={() => { void markRead(n); onNavigate?.(); }} className={cn('flex gap-3 px-4 py-3 transition hover:bg-primary/5', !n.read && 'bg-primary/[.06]')}>
            <span className={cn('mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-lg', n.kind === 'overdue' || n.kind === 'expiry' || n.kind === 'check' ? 'bg-primary-900 text-white' : 'bg-primary/15 text-primary')}>
              <Icon name={KIND_ICON[n.kind]} size={16} />
            </span>
            <span className="min-w-0 flex-1">
              <span className="flex items-center gap-2 text-sm font-semibold">
                <span className="truncate">{n.title}</span>
                {!n.read && <span className="h-2 w-2 shrink-0 rounded-full bg-primary" aria-label="unread" />}
              </span>
              <span className="line-clamp-2 text-xs text-muted">{n.body}</span>
              <span className="text-[11px] text-muted/80">{ago(n.created_at)}</span>
            </span>
          </Link>
        </motion.li>
      ))}
    </ul>
  );
}

export function NotificationPanel({ onClose }: { onClose: () => void }) {
  const { markAllRead, unread } = useNotifications();
  return (
    <motion.div initial={{ opacity: 0, y: -8, scale: 0.97 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: -8 }} className="panel absolute right-0 top-12 z-50 w-[min(94vw,24rem)] overflow-hidden shadow-lift" style={{ background: 'rgb(var(--surface) / .97)' }} role="dialog" aria-label="Notifications">
      <div className="flex items-center justify-between border-b border-line/15 px-4 py-3">
        <h2 className="text-sm font-bold">Notifications {unread > 0 && <span className="ml-1 rounded-full bg-primary px-2 py-0.5 text-xs text-white">{unread}</span>}</h2>
        <button className="text-xs font-semibold text-primary hover:underline" onClick={() => void markAllRead()}>Mark all read</button>
      </div>
      <div className="max-h-[22rem] overflow-y-auto"><NotificationList limit={12} onNavigate={onClose} /></div>
      <Link href="/notifications" onClick={onClose} className="block border-t border-line/15 px-4 py-2.5 text-center text-xs font-semibold text-primary hover:bg-primary/5">View all notifications</Link>
    </motion.div>
  );
}
