'use client';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { Icon } from './Icon';
import ModulePage from './records/ModulePage';
import { PageHeader } from './ui';
import { useClients } from '@/lib/hooks';
import { BRIEF_MODULES } from '@/lib/modules';
import { cn } from '@/lib/utils';

/** /creative/client-briefs — the nine-section client brand & content brief. */
export function BriefsPage() {
  const sp = useSearchParams();
  const router = useRouter();
  const clients = (useClients().data ?? []).filter((c) => c.status !== 'archived');
  const client = sp.get('client') ?? '';
  const m = BRIEF_MODULES.find((x) => x.slug === sp.get('section')) ?? BRIEF_MODULES[0];
  const href = (section: string, c = client) => `/creative/client-briefs?section=${section}${c ? `&client=${c}` : ''}`;
  const current = clients.find((c) => c.id === client);
  return (
    <div>
      <PageHeader icon="Brush" title="Client Brand & Content Brief" subtitle="Nine linked sections per client: use them to brief designs, videos and campaigns."
        actions={<label className="flex items-center gap-2 text-sm"><span className="font-semibold">Client</span>
          <select className="input !w-64" aria-label="Choose client" value={client} onChange={(e) => router.replace(href(m.slug, e.target.value))}>
            <option value="">All clients</option>{clients.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select></label>} />
      {current && <p className="mb-3 text-sm text-muted">Showing the brief for <Link href={`/clients/${current.id}`} className="font-semibold text-primary hover:underline dark:text-primary-200">{current.name}</Link>. New records are linked to this client automatically.</p>}
      <nav aria-label="Brief sections" className="mb-4 flex gap-1 overflow-x-auto rounded-2xl bg-surface2 p-1" role="tablist">
        {BRIEF_MODULES.map((b, i) => (
          <Link key={b.key} role="tab" aria-selected={b.key === m.key} href={href(b.slug)} className={cn('flex items-center gap-2 whitespace-nowrap rounded-xl px-3 py-2 text-sm font-semibold transition', b.key === m.key ? 'bg-gradient-to-r from-primary to-secondary-500 text-white shadow' : 'text-muted hover:text-ink')}>
            <span className="text-xs opacity-80">{String(i + 1).padStart(2, '0')}</span>{b.nav}
          </Link>
        ))}
      </nav>
      <p className="mb-3 flex items-center gap-2 text-sm text-muted"><Icon name={m.icon} size={16} />{m.blurb}</p>
      <ModulePage key={`${m.key}:${client}`} m={m} embedded />
    </div>
  );
}
