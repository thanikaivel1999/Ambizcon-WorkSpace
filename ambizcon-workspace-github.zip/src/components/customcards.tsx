'use client';
import { StatsCard } from './ui';
import { moduleFromCustom } from '@/lib/custom';
import { useCustomModules, useRecords, useSetting } from '@/lib/hooks';
import { MODULE_BY_KEY } from '@/lib/modules';
import { effStatus } from '@/lib/stats';
import type { CustomCard } from './studio';

function CardView({ card }: { card: CustomCard }) {
  const custom = useCustomModules().data;
  const m = MODULE_BY_KEY[card.moduleKey] ?? (custom ?? []).filter((c) => `custom:${c.id}` === card.moduleKey).map(moduleFromCustom)[0];
  const q = useRecords(m ?? MODULE_BY_KEY.backups);
  if (!m || q.isLoading) return null;
  const rows = q.data ?? [];
  let value = 0;
  let hint: string | undefined;
  if (card.metric === 'count') value = rows.length;
  else if (card.metric === 'open') value = rows.filter((r) => { const s = effStatus(m, r); return s && s !== 'Completed' && s !== 'Cancelled'; }).length;
  else if (card.metric === 'overdue') value = rows.filter((r) => effStatus(m, r) === 'Overdue').length;
  else if (card.metric === 'completed') value = rows.filter((r) => effStatus(m, r) === 'Completed').length;
  else if (card.field) {
    const nums = rows.map((r) => r[card.field!]).filter((v) => typeof v === 'number' && Number.isFinite(v)) as number[];
    value = card.metric === 'sum' ? nums.reduce((a, b) => a + b, 0) : nums.length ? Math.round((nums.reduce((a, b) => a + b, 0) / nums.length) * 10) / 10 : 0;
    hint = `${nums.length} of ${rows.length} records have a value`;
  }
  return <StatsCard label={card.title} value={Math.round(value)} icon={card.icon || 'ChartColumn'} accent="secondary" hint={hint ?? m.title} />;
}

/** Cards an admin built in the Customization Studio, shown on the matching dashboards. */
export function CustomCards({ scope }: { scope: 'admin' | 'development' | 'marketing' | 'creative' }) {
  const cards = useSetting<CustomCard[]>('custom_cards', [], (r) => (Array.isArray(r) ? (r as CustomCard[]) : [])).value.filter((c) => c.scope === 'all' || c.scope === scope);
  if (!cards.length) return null;
  return (
    <section aria-label="Custom cards" className="mb-6">
      <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">{cards.map((c) => <CardView key={c.id} card={c} />)}</div>
    </section>
  );
}
